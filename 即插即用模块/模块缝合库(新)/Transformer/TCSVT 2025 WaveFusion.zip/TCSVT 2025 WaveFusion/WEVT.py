import torch
import torch.nn as nn
from timm.models.layers import DropPath, trunc_normal_
import numpy as np
from einops import rearrange
from DWT_IDWT.DWT_IDWT_layer import DWT_2D, IDWT_2D

# 基于Swin Transformer窗口注意力机制，融合离散小波变换（DWT）与逆离散小波变换（IDWT）的增强型Transformer模块
# 核心目标：通过小波变换分离高低频特征，分别优化处理，提升特征表达能力与模型性能

class WMSA(nn.Module):
    """
    窗口多头自注意力模块（基于Swin Transformer的改进实现）
    功能：在局部窗口内计算自注意力，支持普通窗口注意力（W型）和移位窗口注意力（SW型）
    核心设计：
        - 可学习的相对位置编码：提升局部窗口内位置敏感性
        - 动态生成移位窗口掩码：解决移位窗口带来的边界歧义问题
        - 头维度拆分与重组：实现多头并行注意力计算
    """

    def __init__(self, input_dim, output_dim, head_dim, window_size, type):
        super(WMSA, self).__init__()
        self.input_dim = input_dim  # 输入特征维度
        self.output_dim = output_dim  # 输出特征维度
        self.head_dim = head_dim  # 每个注意力头的维度
        self.scale = self.head_dim ** -0.5  # 注意力得分缩放因子（避免数值过大）
        self.n_heads = input_dim // head_dim  # 注意力头数量（输入维度必须能被头维度整除）
        self.window_size = window_size  # 注意力计算窗口大小（正方形窗口）
        self.type = type  # 注意力类型：'W'（普通窗口）/'SW'（移位窗口）

        # 线性投影层：将输入映射为Q、K、V三个向量（总维度3*input_dim）
        self.embedding_layer = nn.Linear(self.input_dim, 3 * self.input_dim, bias=True)
        # 相对位置编码参数：(2*window_size-1)×(2*window_size-1)对应所有可能的相对位置
        self.relative_position_params = nn.Parameter(
            torch.zeros((2 * window_size - 1) * (2 * window_size - 1), self.n_heads))
        self.linear = nn.Linear(self.input_dim, self.output_dim)  # 输出投影层

        trunc_normal_(self.relative_position_params, std=.02)  # 初始化相对位置参数
        # 调整参数形状：[n_heads, 2w-1, 2w-1]（适配注意力头维度）
        self.relative_position_params = torch.nn.Parameter(
            self.relative_position_params.view(2 * window_size - 1, 2 * window_size - 1, self.n_heads).transpose(1,
                                                                                                                 2).transpose(
                0, 1))

    def generate_mask(self, h, w, p, shift):
        """
        生成移位窗口注意力的掩码（仅SW型注意力使用）
        Args:
            h: 窗口行数（特征图划分后的窗口数量）
            w: 窗口列数
            p: 窗口大小
            shift: 移位步长（默认window_size//2）
        Returns:
            attn_mask: 掩码张量，shape=[1,1,(h*w),p²,p²]，True表示需要屏蔽的位置
        """
        # 初始化掩码（全False，不屏蔽）
        attn_mask = torch.zeros(h, w, p, p, p, p, dtype=torch.bool, device=self.relative_position_params.device)
        if self.type == 'W':  # 普通窗口无需掩码
            return attn_mask
        s = p - shift  # 移位后窗口重叠边界
        # 标记跨窗口边界的位置（需要屏蔽，避免不同原始窗口特征混淆）
        attn_mask[-1, :, :s, :, s:, :] = True
        attn_mask[-1, :, s:, :, :s, :] = True
        attn_mask[:, -1, :, :s, :, s:] = True
        attn_mask[:, -1, :, s:, :, :s] = True
        # 调整掩码形状适配注意力计算
        attn_mask = rearrange(attn_mask, 'w1 w2 p1 p2 p3 p4 -> 1 1 (w1 w2) (p1 p2) (p3 p4)')
        return attn_mask

    def relative_embedding(self):
        """生成相对位置编码向量"""
        # 生成窗口内所有位置的坐标：[(0,0), (0,1), ..., (w-1,w-1)]
        cord = torch.tensor(np.array([[i, j] for i in range(self.window_size) for j in range(self.window_size)]))
        # 计算所有位置对的相对坐标差 + 偏移量（确保非负）
        relation = cord[:, None, :] - cord[None, :, :] + self.window_size - 1
        # 提取相对位置对应的编码参数
        return self.relative_position_params[:, relation[:, :, 0].long(), relation[:, :, 1].long()]

    def forward(self, x):
        """
        前向传播：窗口多头自注意力计算
        Args:
            x: 输入张量，shape=[b, h, w, c]（b=批量大小，h=高度，w=宽度，c=通道数）
        Returns:
            output: 输出张量，shape=[b, h, w, c]（与输入维度一致）
        """
        # 移位窗口注意力：对输入特征图进行循环移位（消除边界歧义）
        if self.type != 'W':
            x = torch.roll(x, shifts=(-(self.window_size // 2), -(self.window_size // 2)), dims=(1, 2))

        # 特征图划分窗口：[b, h, w, c] → [b, w1, w2, p1, p2, c]（w1=h/p1，w2=w/p2）
        x = rearrange(x, 'b (w1 p1) (w2 p2) c -> b w1 w2 p1 p2 c', p1=self.window_size, p2=self.window_size)
        h_windows, w_windows = x.size(1), x.size(2)  # 窗口行数和列数

        # 重组为窗口维度：[b, (w1*w2), (p1*p2), c]（每个窗口展平为一维向量）
        x = rearrange(x, 'b w1 w2 p1 p2 c -> b (w1 w2) (p1 p2) c', p1=self.window_size, p2=self.window_size)

        # 生成Q、K、V：[b, nw, np, 3hc] → 拆分3个[h, b, nw, np, c]（h=注意力头数）
        qkv = self.embedding_layer(x)
        q, k, v = rearrange(qkv, 'b nw np (threeh c) -> threeh b nw np c', c=self.head_dim).chunk(3, dim=0)

        # 计算注意力得分：Q@K^T * 缩放因子 + 相对位置编码
        sim = torch.einsum('hbwpc,hbwqc->hbwpq', q, k) * self.scale
        sim = sim + rearrange(self.relative_embedding(), 'h p q -> h 1 1 p q')

        # 移位窗口注意力添加掩码（屏蔽跨原始窗口的注意力）
        if self.type != 'W':
            attn_mask = self.generate_mask(h_windows, w_windows, self.window_size, shift=self.window_size // 2)
            sim = sim.masked_fill_(attn_mask, float("-inf"))  # 屏蔽位置设为负无穷（softmax后趋近于0）

        # 注意力权重归一化 + 加权求和V
        probs = nn.functional.softmax(sim, dim=-1)
        output = torch.einsum('hbwij,hbwjc->hbwic', probs, v)

        # 重组输出：[h, b, nw, np, c] → [b, nw, np, (h*c)] → 线性投影
        output = rearrange(output, 'h b w p c -> b w p (h c)')
        output = self.linear(output)

        # 窗口重组为特征图：[b, (w1*w2), (p1*p2), c] → [b, (w1*p1), (w2*p2), c]
        output = rearrange(output, 'b (w1 w2) (p1 p2) c -> b (w1 p1) (w2 p2) c', w1=h_windows, p1=self.window_size)

        # 移位窗口注意力：恢复特征图原始位置
        if self.type != 'W':
            output = torch.roll(output, shifts=(self.window_size // 2, self.window_size // 2), dims=(1, 2))

        return output


class WaveTransBlock(nn.Module):
    """
    小波增强Transformer块（WEVT核心模块）
    功能：融合小波变换与窗口注意力，分离高低频特征并分别优化
    核心设计：
        - DWT分解：将特征拆分为低频（LL）和高频（LH、HL、HH）分量
        - 注意力聚焦低频：在低频分量上应用窗口注意力（保留全局结构）
        - 高频增强：通过卷积增强高频细节（边缘、纹理等）
        - IDWT重构：融合处理后的高低频特征，恢复完整特征图
    """

    def __init__(self, input_dim, output_dim, head_dim, window_size, drop_path, type='W', input_resolution=None):
        super(WaveTransBlock, self).__init__()
        self.input_dim = input_dim  # 输入特征维度
        self.output_dim = output_dim  # 输出特征维度
        assert type in ['W', 'SW']  # 注意力类型校验
        self.type = type  # 注意力类型（根据输入分辨率自适应调整）
        if input_resolution <= window_size:  # 特征图分辨率≤窗口大小时，使用普通窗口注意力
            self.type = 'W'

        # 预归一化层（Transformer标准设计）
        self.ln1 = nn.LayerNorm(input_dim)
        # 窗口多头自注意力模块（核心注意力组件）
        self.msa = WMSA(input_dim, input_dim, head_dim, window_size, self.type)
        # 随机深度层（DropPath）：防止过拟合
        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()
        # 第二个预归一化层
        self.ln2 = nn.LayerNorm(input_dim)
        # 前馈网络（MLP）：特征非线性变换
        self.mlp = nn.Sequential(
            nn.Linear(input_dim, 4 * input_dim),  # 升维（4倍）
            nn.GELU(),  # 激活函数（比ReLU更平滑）
            nn.Linear(4 * input_dim, output_dim),  # 降维到输出维度
        )

        # 小波变换相关组件
        self.dwt_down = DWT_2D(wavename='haar')  # 离散小波变换（ Haar小波，计算高效）
        # 高频分量增强卷积：3×3卷积+LeakyReLU（保留边缘细节）
        self.conv_high_freq = nn.Sequential(
            nn.Conv2d(input_dim, input_dim, kernel_size=3, padding=1, stride=1),
            nn.LeakyReLU(inplace=True),
        )
        self.dwt_up = IDWT_2D(wavename='haar')  # 逆离散小波变换（恢复特征图尺寸）
        self.conv_1x1 = nn.Conv2d(input_dim, input_dim, kernel_size=1, padding=0, stride=1)  # 1×1卷积：特征融合调整

    def forward(self, x):
        """
        前向传播：小波增强注意力流程
        Args:
            x: 输入张量，shape=[b, h, w, c]（b=批量大小，h=高度，w=宽度，c=通道数）
        Returns:
            output: 输出张量，shape=[b, h, w, c]（与输入维度一致）
        """
        residual = x  # 残差连接：保存原始输入
        x = self.ln1(x)  # 预归一化
        x = x.permute(0, 3, 1, 2)  # 维度转换：[b, h, w, c] → [b, c, h, w]（适配卷积/DWT输入格式）

        # 1. 离散小波变换（DWT）：分解为低频分量（LL）和3个高频分量（LH、HL、HH）
        X_LL, X_LH, X_HL, X_HH = self.dwt_down(x)

        # 2. 低频分量处理：应用窗口注意力（捕捉全局结构信息）
        # 维度转换：[b, c, h/2, w/2] → [b, h/2, w/2, c]（适配WMSA输入格式）
        X_LL = self.msa(X_LL.permute(0, 2, 3, 1)).permute(0, 3, 1, 2)

        # 3. 高频分量处理：卷积增强细节特征（边缘、纹理等）
        X_high_freq = [X_LH, X_HL, X_HH]
        X_high_freq = [self.conv_high_freq(component) for component in X_high_freq]

        # 4. 逆离散小波变换（IDWT）：融合高低频特征，恢复原始尺寸
        x = self.dwt_up(X_LL, *X_high_freq)
        x = self.conv_1x1(x)  # 1×1卷积调整通道特征

        # 维度转换：[b, c, h, w] → [b, h, w, c]（恢复原始维度顺序）
        x = x.permute(0, 2, 3, 1)

        # 5. 残差连接 + MLP非线性变换
        x = residual + self.drop_path(x)  # 第一残差连接（注意力路径）
        x = x + self.drop_path(self.mlp(self.ln2(x)))  # 第二残差连接（MLP路径）

        return x



if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 32, 32, 64).to(device)
    model = WaveTransBlock(64, 64, 4, 4, 0.1, input_resolution=32).to(device)

    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN、小红书：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)
