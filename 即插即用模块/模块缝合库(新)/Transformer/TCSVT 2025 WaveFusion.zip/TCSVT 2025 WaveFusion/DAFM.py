import torch
import torch.nn as nn
from einops import rearrange


class DualModalAttention(nn.Module):
    """
        双聚合融合模块（DAFM）：通过自注意力+跨模态注意力双聚合，增强双模态特征交互
        核心创新：
            1. 双注意力聚合：自注意力强化单模态内关联，跨模态注意力挖掘模态间互补；
            2. 可学习平衡因子：动态调整两种注意力的贡献比例；
            3. 轻量化设计：深度卷积+1×1卷积，降低计算量；
            4. 双输出保持：增强后仍输出双模态特征，支持后续灵活融合。
        输入：
            x1: 第一模态特征 [B, dim, H, W]（如RGB、空间特征）
            x2: 第二模态特征 [B, dim, H, W]（如红外、频域特征）
        输出：
            out_x1: 增强后第一模态特征 [B, dim, H, W]
            out_x2: 增强后第二模态特征 [B, dim, H, W]
        Args:
            dim: 输入/输出通道数（双模态通道数需一致）
            num_heads: 注意力头数
            bias: 卷积层是否加偏置（默认False）
        """
    def __init__(self, dim=36, num_heads=6, bias=False):
        super(DualModalAttention, self).__init__()

        assert dim % num_heads == 0, "Dimension must be divisible by the number of heads"

        self.num_heads = num_heads
        self.temperature = nn.Parameter(torch.ones(num_heads, 1, 1))
        self.beta = nn.Parameter(torch.zeros(1))  # 可学习的平衡因子

        self.qkv1 = nn.Conv2d(dim, dim * 3, kernel_size=1, bias=bias)
        self.qkv_dwconv1 = nn.Conv2d(dim * 3, dim * 3, kernel_size=3, stride=1, padding=1, groups=dim * 3, bias=bias)
        self.qkv2 = nn.Conv2d(dim, dim * 3, kernel_size=1, bias=bias)
        self.qkv_dwconv2 = nn.Conv2d(dim * 3, dim * 3, kernel_size=3, stride=1, padding=1, groups=dim * 3, bias=bias)

        self.project_out = nn.Conv2d(dim, dim, kernel_size=1, bias=bias)

    def forward(self, x1, x2):
        b, c, h, w = x1.shape

        qkv1 = self.qkv_dwconv1(self.qkv1(x1))
        q1, k1, v1 = qkv1.chunk(3, dim=1)

        qkv2 = self.qkv_dwconv2(self.qkv2(x2))
        q2, k2, v2 = qkv2.chunk(3, dim=1)

        enhanced_x1 = self.compute_attention(q1, k1, v1, k2, v2, b, h, w)
        enhanced_x2 = self.compute_attention(q2, k2, v2, k1, v1, b, h, w)

        # out_x1 = self.project_out(enhanced_x1) + x1
        # out_x2 = self.project_out(enhanced_x2) + x2
        out_x1 = self.project_out(enhanced_x1)
        out_x2 = self.project_out(enhanced_x2)

        return out_x1, out_x2

    def compute_attention(self, q, k_self, v_self, k_cross, v_cross, b, h, w):
        """
        双注意力聚合核心函数：自注意力+跨模态注意力融合
        Args:
            q: 当前模态查询（Q）
            k_self/v_self: 当前模态键值（K/V）→ 自注意力
            k_cross/v_cross: 另一模态键值（K/V）→ 跨模态注意力
            b/h/w: 批次/高度/宽度
        返回：双注意力聚合后的特征
        """
        q = rearrange(q, 'b (head c) h w -> b head c (h w)', head=self.num_heads)
        k_self = rearrange(k_self, 'b (head c) h w -> b head c (h w)', head=self.num_heads)
        v_self = rearrange(v_self, 'b (head c) h w -> b head c (h w)', head=self.num_heads)
        k_cross = rearrange(k_cross, 'b (head c) h w -> b head c (h w)', head=self.num_heads)
        v_cross = rearrange(v_cross, 'b (head c) h w -> b head c (h w)', head=self.num_heads)

        q = torch.nn.functional.normalize(q, dim=-1)
        k_self = torch.nn.functional.normalize(k_self, dim=-1)
        k_cross = torch.nn.functional.normalize(k_cross, dim=-1)

        self_attn = (q @ k_self.transpose(-2, -1)) * self.temperature
        self_attn = self_attn.softmax(dim=-1)
        self_out = self_attn @ v_self

        cross_attn = (q @ k_cross.transpose(-2, -1)) * self.temperature
        cross_attn = (-cross_attn).softmax(dim=-1)
        cross_out = cross_attn @ v_cross

        beta = torch.sigmoid(self.beta)
        out_combined = beta * self_out + cross_out
        out = rearrange(out_combined, 'b head c (h w) -> b (head c) h w', head=self.num_heads, h=h, w=w)

        return out

if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x1 = torch.randn(1, 64, 32, 32).to(device)
    x2 = torch.randn(1, 64, 32, 32).to(device)
    model = DualModalAttention(64, 4).to(device)

    y1, y2 = model(x1, x2)

    # 后续可以双模态特征融合或者执行其他操作

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN、小红书：十小大")

    print("输入模态1特征维度：", x1.shape)
    print("输入模态2特征维度：", x2.shape)
    print("输出模态1特征维度：", y1.shape)
    print("输出模态2特征维度：", y2.shape)