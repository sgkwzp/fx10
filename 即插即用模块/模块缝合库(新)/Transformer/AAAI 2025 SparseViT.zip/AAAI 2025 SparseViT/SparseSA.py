import torch
import torch.nn as nn
import torch.nn.functional as F
import math
from timm.models.layers import trunc_normal_, DropPath, to_2tuple

# 全局配置：层缩放开关与初始值
layer_scale = True
init_value = 1e-6


class Mlp(nn.Module):
    """
    前馈网络（MLP）：含深度卷积的混合前馈层，增强局部特征关联
    核心作用：结合线性层与深度卷积，平衡全局通道交互与局部空间关联
    输入：
        x: 序列特征 [B, N, C]
        H/W: 原始特征图高/宽
    输出：增强后序列特征 [B, N, C]
    """
    def __init__(self, in_features, hidden_features=None, out_features=None, act_layer=nn.GELU, drop=0.):
        super().__init__()
        out_features = out_features or in_features
        hidden_features = hidden_features or in_features
        self.fc1 = nn.Linear(in_features, hidden_features)  # 升维
        self.dwconv = DWConv(hidden_features)  # 深度卷积（局部增强）
        self.act = act_layer()  # 非线性激活
        self.fc2 = nn.Linear(hidden_features, out_features)  # 降维
        self.drop = nn.Dropout(drop)  # 正则化
        self.apply(self._init_weights)  # 参数初始化

    def _init_weights(self, m):
        """参数初始化：适配不同层类型"""
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=.02)
            if m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.LayerNorm):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)
        elif isinstance(m, nn.Conv2d):
            fan_out = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
            fan_out //= m.groups
            m.weight.data.normal_(0, math.sqrt(2.0 / fan_out))
            if m.bias is not None:
                m.bias.data.zero_()

    def forward(self, x, H, W):
        x = self.fc1(x)
        x = self.dwconv(x, H, W)  # 深度卷积局部增强
        x = self.act(x)
        x = self.drop(x)
        x = self.fc2(x)
        x = self.drop(x)
        return x

class DWConv(nn.Module):
    """
    深度可分离卷积：捕捉局部空间关联，轻量化设计
    输入：序列特征 [B, N, C]
    输出：局部增强序列特征 [B, N, C]
    """
    def __init__(self, dim=768):
        super(DWConv, self).__init__()
        self.dwconv = nn.Conv2d(dim, dim, 3, 1, 1, bias=True, groups=dim)  # 深度卷积

    def forward(self, x, H, W):
        B, N, C = x.shape
        # 序列→空间：[B, N, C]→[B, C, H, W]
        x = x.transpose(1, 2).view(B, C, H, W)
        x = self.dwconv(x)
        # 空间→序列：[B, C, H, W]→[B, N, C]
        x = x.flatten(2).transpose(1, 2)
        return x

class Attention(nn.Module):
    """
    标准多头自注意力：基础注意力计算单元
    输入：序列特征 [B, N, C]
    输出：注意力增强特征 [B, N, C]
    """
    def __init__(self, dim, num_heads=8, qkv_bias=False, qk_scale=None, attn_drop=0., proj_drop=0.):
        super().__init__()
        self.num_heads = num_heads
        head_dim = dim // num_heads
        self.scale = qk_scale or head_dim ** -0.5  # 缩放因子
        self.qkv = nn.Linear(dim, dim * 3, bias=qkv_bias)  # QKV联合投影
        self.attn_drop = nn.Dropout(attn_drop)  # 注意力Dropout
        self.proj = nn.Linear(dim, dim)  # 输出投影
        self.proj_drop = nn.Dropout(proj_drop)  # 输出Dropout

    def forward(self, x):
        B, N, C = x.shape
        # QKV生成与拆分
        qkv = self.qkv(x).reshape(B, N, 3, self.num_heads, C // self.num_heads).permute(2, 0, 3, 1, 4)
        q, k, v = qkv[0], qkv[1], qkv[2]
        # 注意力计算
        attn = (q @ k.transpose(-2, -1)) * self.scale
        attn = attn.softmax(dim=-1)
        attn = self.attn_drop(attn)
        # 加权融合与投影
        x = (attn @ v).transpose(1, 2).reshape(B, N, C)
        x = self.proj(x)
        x = self.proj_drop(x)
        return x

def block(x, block_size):
    """
    特征块划分：将特征图按block_size拆分为局部块，用于稀疏化
    输入：特征图 [B, H, W, C]
    输出：
        x: 块划分后特征 [B, H//block_size, W//block_size, block_size, block_size, C]
        H: 原始高度
        Hp: 填充后高度（确保可被block_size整除）
        C: 通道数
    """
    B, H, W, C = x.shape
    # 填充至block_size的整数倍
    pad_h = (block_size - H % block_size) % block_size
    pad_w = (block_size - W % block_size) % block_size
    if pad_h > 0 or pad_w > 0:
        x = F.pad(x, (0, 0, 0, pad_w, 0, pad_h))
    Hp, Wp = H + pad_h, W + pad_w
    # 块划分与维度重排
    x = x.reshape(B, Hp // block_size, block_size, Wp // block_size, block_size, C)
    x = x.permute(0, 1, 3, 2, 4, 5).contiguous()
    return x, H, Hp, C

def unblock(x, Ho):
    """
    特征块还原：将划分后的块特征恢复为原始尺寸
    输入：块特征 [B, H_block, W_block, block_size, block_size, C]
    输出：还原后特征 [B, Ho, Wo, C]（Wo=Ho，保持正方形）
    """
    B, H, W, win_H, win_W, C = x.shape
    # 维度重排与还原
    x = x.permute(0, 1, 3, 2, 4, 5).contiguous().reshape(B, H * win_H, W * win_W, C)
    Wp = Hp = H * win_H
    Wo = Ho
    # 裁剪回原始尺寸
    if Hp > Ho or Wp > Wo:
        x = x[:, :Ho, :Wo, :].contiguous()
    return x

def alter_sparse(x, sparse_size=8):
    """
    稀疏化处理：特征图→块划分→稀疏注意力输入格式
    输入：特征图 [B, C, H, W]
    输出：
        x: 稀疏化后特征 [B_block, C, sparse_size, sparse_size]
        H: 原始高度
        Hp: 填充后高度
        C: 通道数
    """
    x = x.permute(0, 2, 3, 1)  # [B, H, W, C]
    assert x.shape[1] % sparse_size == 0 and x.shape[2] % sparse_size == 0, '图像尺寸需能被sparse_size整除'
    grid_size = x.shape[1] // sparse_size
    out, H, Hp, C = block(x, grid_size)  # 块划分
    out = out.permute(0, 3, 4, 1, 2, 5).contiguous()
    out = out.reshape(-1, sparse_size, sparse_size, C)  # 合并批次与块维度
    out = out.permute(0, 3, 1, 2)  # [B_block, C, sparse_size, sparse_size]
    return out, H, Hp, C

def alter_unsparse(x, H, Hp, C, sparse_size=8):
    """
    稀疏还原：稀疏注意力输出→原始特征图格式
    输入：稀疏特征 [B_block, C, sparse_size, sparse_size]
    输出：还原后特征图 [B, C, H, W]
    """
    x = x.permute(0, 2, 3, 1)  # [B_block, sparse_size, sparse_size, C]
    # 还原块维度
    x = x.reshape(-1, Hp // sparse_size, Hp // sparse_size, sparse_size, sparse_size, C)
    x = x.permute(0, 3, 4, 1, 2, 5).contiguous()
    out = unblock(x, H)  # 块还原
    out = out.permute(0, 3, 1, 2)  # [B, C, H, W]
    return out

class SABlock(nn.Module):
    """
    稀疏自注意力模块（SparseSA）：核心模块，通过块划分实现稀疏化注意力
    核心创新：
        1. 块级稀疏化：将特征划分为局部块，仅在块内计算注意力，降低复杂度；
        2. 层缩放机制：可学习缩放因子，动态调整注意力与MLP的贡献；
        3. 混合增强：深度卷积+自注意力，兼顾局部细节与全局关联；
        4. 即插即用：输入输出均为BCHW格式，适配视觉模型。
    输入：特征图 [B, C, H, W]
    输出：增强后特征图 [B, C, H, W]（与输入维度一致）
    Args:
        dim: 输入/输出通道数
        num_heads: 注意力头数
        sparse_size: 稀疏块尺寸（块内计算注意力）
        mlp_ratio: MLP扩展因子
        qkv_bias: QKV投影是否加偏置
        qk_scale: 注意力缩放因子
        drop/attn_drop: Dropout概率
        drop_path: 路径Dropout概率
        act_layer: 激活函数类型
        norm_layer: 归一化类型
    """
    def __init__(self, dim, num_heads, sparse_size=0, mlp_ratio=4., qkv_bias=False, qk_scale=None, drop=0.,
                 attn_drop=0., drop_path=0., act_layer=nn.GELU, norm_layer=nn.LayerNorm):
        super().__init__()
        self.pos_embed = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)  # 位置编码（深度卷积）
        self.norm1 = norm_layer(dim)  # 注意力前归一化
        self.attn = Attention(
            dim, num_heads=num_heads, qkv_bias=qkv_bias, qk_scale=qk_scale,
            attn_drop=attn_drop, proj_drop=drop
        )  # 标准自注意力
        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()  # 路径Dropout
        self.norm2 = norm_layer(dim)  # MLP前归一化
        mlp_hidden_dim = int(dim * mlp_ratio)
        self.mlp = Mlp(in_features=dim, hidden_features=mlp_hidden_dim, act_layer=act_layer, drop=drop)  # 混合MLP
        global layer_scale
        self.ls = layer_scale  # 层缩放开关
        self.sparse_size = sparse_size  # 稀疏块尺寸

        # 层缩放参数（可学习）
        if self.ls:
            global init_value
            print(f"启用层缩放：{layer_scale}，初始值：{init_value}")
            self.gamma_1 = nn.Parameter(init_value * torch.ones((dim)), requires_grad=True)  # 注意力缩放
            self.gamma_2 = nn.Parameter(init_value * torch.ones((dim)), requires_grad=True)  # MLP缩放

    def forward(self, x):
        """
        前向传播流程：稀疏化→块内注意力→还原→MLP增强→残差融合
        """
        # 保存原始特征（用于残差融合）
        x_before = x.flatten(2).transpose(1, 2)  # [B, N, C]
        B, C, H, W = x.shape

        if self.ls:
            # 启用层缩放的流程
            # 步骤1：稀疏化处理（特征图→块特征）
            x_sparse, Ho, Hp, C = alter_sparse(x, self.sparse_size)
            Bf, Nf, Hf, Wf = x_sparse.shape
            # 步骤2：块内注意力计算
            x_seq = x_sparse.flatten(2).transpose(1, 2)  # [B_block, N_block, C]
            x_attn = self.attn(self.norm1(x_seq))  # 块内注意力
            # 步骤3：稀疏还原（块特征→特征图）
            x_attn = x_attn.transpose(1, 2).reshape(Bf, Nf, Hf, Wf)
            x_restore = alter_unsparse(x_attn, Ho, Hp, C, self.sparse_size)
            x_restore_seq = x_restore.flatten(2).transpose(1, 2)  # [B, N, C]
            # 步骤4：注意力残差融合（带层缩放）
            x = x_before + self.drop_path(self.gamma_1 * x_restore_seq)
            # 步骤5：MLP增强（带层缩放）
            x = x + self.drop_path(self.gamma_2 * self.mlp(self.norm2(x), H, W))
        else:
            # 不启用层缩放的流程（逻辑一致，无缩放因子）
            x_sparse, Ho, Hp, C = alter_sparse(x, self.sparse_size)
            Bf, Nf, Hf, Wf = x_sparse.shape
            x_seq = x_sparse.flatten(2).transpose(1, 2)
            x_attn = self.attn(self.norm1(x_seq))
            x_attn = x_attn.transpose(1, 2).reshape(Bf, Nf, Hf, Wf)
            x_restore = alter_unsparse(x_attn, Ho, Hp, C, self.sparse_size)
            x_restore_seq = x_restore.flatten(2).transpose(1, 2)
            x = x_before + self.drop_path(x_restore_seq)
            x = x + self.drop_path(self.mlp(self.norm2(x), H, W))

        # 格式还原：[B, N, C]→[B, C, H, W]
        x = x.transpose(1, 2).reshape(B, C, H, W)
        return x

if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    x = torch.randn(1, 64, 32, 32).to(device)

    model = SABlock(64, 4, 4).to(device)
    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN：十小大")
    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)