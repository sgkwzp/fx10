import torch
import torch.nn as nn
from einops import rearrange
from typing import Tuple

def rotate_every_two(x):
    """
    实现RoPE（旋转位置编码）中的成对旋转操作
    将输入张量按通道维度两两分组，对每组进行旋转（x1→-x2, x2→x1）
    Args:
        x: 输入张量，形状为(b, n_heads, seq_len, head_dim)
    Returns:
        旋转后的张量，形状与输入保持一致
    """
    x1 = x[:, :, :, ::2]  # 取偶索引通道
    x2 = x[:, :, :, 1::2]  # 取奇索引通道
    x = torch.stack([-x2, x1], dim=-1)  # 堆叠旋转后的通道
    return x.flatten(-2)  # 展平最后两个维度，恢复原形状


def theta_shift(x, sin, cos):
    """
    应用RoPE旋转位置编码
    通过sin和cos将输入张量进行位置偏移，注入位置信息
    Args:
        x: 输入张量（query或key）
        sin: 位置编码的正弦分量
        cos: 位置编码的余弦分量
    Returns:
        注入位置信息后的张量
    """
    return (x * cos) + (rotate_every_two(x) * sin)


class RoPE(nn.Module):
    """
    二维旋转位置编码（Rotary Position Embedding）模块
    为2D特征（如图像）生成位置相关的sin/cos编码，支持高度和宽度维度的位置信息注入
    """

    def __init__(self, embed_dim, num_heads):
        """
        Args:
            embed_dim: 总嵌入维度
            num_heads: 注意力头数量
        """
        super().__init__()
        # 生成角度参数（10000^(-2i/d)），用于计算位置编码
        angle = 1.0 / (10000 ** torch.linspace(0, 1, embed_dim // num_heads // 4))
        angle = angle.unsqueeze(-1).repeat(1, 2).flatten()  # 扩展为成对角度
        self.register_buffer('angle', angle)  # 注册为非训练参数

    def forward(self, slen: Tuple[int]):
        """
        生成二维位置编码的sin和cos分量
        Args:
            slen: 特征的空间尺寸(h, w)
        Returns:
            展平后的sin和cos编码，形状为((h*w), head_dim)
        """
        h, w = slen
        # 生成高度和宽度维度的索引
        index_h = torch.arange(h).to(self.angle)
        index_w = torch.arange(w).to(self.angle)

        # 计算高度相关的sin/cos编码并扩展到整个空间
        sin_h = torch.sin(index_h[:, None] * self.angle[None, :])  # (h, d/2)
        sin_h = sin_h.unsqueeze(1).repeat(1, w, 1)  # (h, w, d/2)
        cos_h = torch.cos(index_h[:, None] * self.angle[None, :])  # (h, d/2)
        cos_h = cos_h.unsqueeze(1).repeat(1, w, 1)  # (h, w, d/2)

        # 计算宽度相关的sin/cos编码并扩展到整个空间
        sin_w = torch.sin(index_w[:, None] * self.angle[None, :])  # (w, d/2)
        sin_w = sin_w.unsqueeze(0).repeat(h, 1, 1)  # (h, w, d/2)
        cos_w = torch.cos(index_w[:, None] * self.angle[None, :])  # (w, d/2)
        cos_w = cos_w.unsqueeze(0).repeat(h, 1, 1)  # (h, w, d/2)

        # 拼接高度和宽度编码，展平为序列形式
        sin = torch.cat([sin_h, sin_w], -1).flatten(0, 1)  # (h*w, d)
        cos = torch.cat([cos_h, cos_w], -1).flatten(0, 1)  # (h*w, d)
        return (sin, cos)


class AddLinearAttention(nn.Module):
    """
    加法线性注意力（Additive Linear Attention）模块
    基于线性注意力机制，通过简化注意力计算降低复杂度，同时引入位置编码和局部增强
    """

    def __init__(self, dim, num_heads):
        """
        Args:
            dim: 输入特征维度
            num_heads: 注意力头数量
        """
        super().__init__()
        self.dim = dim
        self.num_heads = num_heads
        self.head_dim = dim // num_heads  # 每个注意力头的维度
        self.qkvo = nn.Conv2d(dim, dim * 4, 1)  # 一次性生成q、k、v、o的卷积
        self.lepe = nn.Conv2d(dim, dim, 5, 1, 2, groups=dim)  # 局部位置增强卷积（深度可分离）
        self.proj = nn.Conv2d(dim, dim, 1)  # 输出投影卷积
        self.scale = self.head_dim ** -0.5  # 缩放因子
        self.elu = nn.ELU()  # 激活函数，用于将q/k映射为正值

    def forward(self, x: torch.Tensor, sin: torch.Tensor, cos: torch.Tensor):
        """
        前向传播过程
        Args:
            x: 输入特征，形状为(b, c, h, w)
            sin: RoPE的正弦分量，形状为((h*w), head_dim)
            cos: RoPE的余弦分量，形状为((h*w), head_dim)
        Returns:
            输出特征，形状与输入保持一致(b, c, h, w)
        """
        B, C, H, W = x.shape
        qkvo = self.qkvo(x)  # (b, 4*dim, h, w)
        qkv = qkvo[:, :3 * self.dim, :, :]  # 提取q、k、v
        o = qkvo[:, 3 * self.dim:, :, :]  # 提取o（用于输出调制）
        lepe = self.lepe(qkv[:, 2 * self.dim:, :, :])  # 对v应用局部增强

        # 重塑q、k、v为多头形式：(3, b, num_heads, h*w, head_dim)
        q, k, v = rearrange(qkv, 'b (m n d) h w -> m b n (h w) d', m=3, n=self.num_heads)

        # 将q、k通过ELU激活映射为正值（符合线性注意力的正值假设）
        q = self.elu(q) + 1
        k = self.elu(k) + 1

        # 计算z值（用于注意力调制）
        z = q @ k.mean(dim=-2, keepdim=True).transpose(-2, -1) * self.scale

        # 对q、k应用RoPE位置编码
        q = theta_shift(q, sin, cos)
        k = theta_shift(k, sin, cos)

        # 计算简化的kv乘积（线性注意力核心）
        kv = (k.transpose(-2, -1) * (self.scale / (H * W)) ** 0.5) @ (v * (self.scale / (H * W)) ** 0.5)

        # 计算最终注意力输出（包含调制机制）
        res = q @ kv * (1 + 1 / (z + 1e-6)) - z * v.mean(dim=2, keepdim=True)

        # 重塑回空间维度并添加局部增强，最终投影输出
        res = rearrange(res, 'b n (h w) d -> b (n d) h w', h=H, w=W)
        res = res + lepe
        return self.proj(res * o)

if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 64, 32, 32).to(device)
    _, _, h, w = x.size()

    rope = RoPE(64, 4)
    model = AddLinearAttention(64, 4)

    rope.to(device)
    model.to(device)

    sin, cos = rope((h, w))
    y = model(x, sin, cos)

    print("微信公众号：十小大的底层视觉工坊")
    print("知乎、CSDN：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)