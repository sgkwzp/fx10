import torch
import torch.nn as nn
import torch.nn.functional as F
import einops
from timm.models.layers import trunc_normal_

from natten.functional import na2d_qk, na2d_av

FUSED = True
try:
    from natten.functional import na2d
except ImportError:
    FUSED = False
    print("natten 0.17 not installed, using dummy implementation")


class DeformableNeighborhoodAttention(nn.Module):
    """
    可变形邻域注意力模块（DSWA核心实现）：融合可变形窗口与邻域注意力
    核心创新：
        1. 动态偏移预测：根据输入特征预测窗口偏移，适配目标形状；
        2. 分组邻域注意力：降低计算量，增强多尺度特征捕捉；
        3. 相对位置偏置+深度可分离位置编码：提升注意力定位精度。
    输入：特征图 [B, C, H, W]
    输出：注意力增强特征 [B, C, H, W]（与输入维度一致，支持即插即用）
    """

    def __init__(
            self,
            dim: int,  # 输入特征通道数（如64）
            num_heads: int,  # 注意力头数（如4，需整除dim）
            kernel_size: int,  # 基础窗口大小（如3，动态偏移后窗口形状自适应）
            dilation: int = 1,  # 窗口扩张率（控制邻域范围）
            offset_range_factor=1.0,  # 偏移范围因子（控制窗口偏移幅度）
            stride=1,  # 窗口滑动步长（默认1，保持特征尺寸）
            use_pe=True,  # 是否使用位置编码
            dwc_pe=True,  # 是否使用深度可分离位置编码
            no_off=False,  # 是否禁用偏移（退化为固定窗口注意力）
            fixed_pe=False,  # 是否使用固定位置编码（不参与梯度更新）
            is_causal: bool = False,  # 是否因果注意力（用于时序任务，默认关闭）
            rel_pos_bias: bool = False,  # 是否使用相对位置偏置
            attn_drop: float = 0.0,  # 注意力权重dropout概率
            proj_drop: float = 0.0,  # 输出投影dropout概率
    ):
        super().__init__()
        self.n_head_channels = dim // num_heads  # 单头通道数（如64//4=16）
        self.n_groups = num_heads  # 分组数（与头数一致，实现分组注意力）
        self.dwc_pe = dwc_pe  # 深度可分离位置编码开关
        self.scale = self.n_head_channels ** -0.5  # 注意力缩放因子（缓解梯度消失）
        self.n_heads = num_heads
        self.nc = n_head_channels * num_heads  # 总通道数（与dim一致）
        self.n_group_channels = self.nc // self.n_groups  # 每组通道数（如64//4=16）
        self.n_group_heads = self.n_heads // self.n_groups  # 每组头数（如4//4=1）
        self.use_pe = use_pe
        self.fixed_pe = fixed_pe
        self.no_off = no_off  # 禁用偏移开关（调试用）
        self.offset_range_factor = offset_range_factor  # 偏移范围控制
        self.ksize = kernel_size
        self.kernel_size = (kernel_size, kernel_size)  # 窗口大小（H×W）
        self.stride = stride
        self.dilation = dilation
        self.is_causal = is_causal  # 因果注意力（时序任务专用）

        # 1. 偏移预测网络：基于分组特征预测窗口偏移（2个通道：x/y方向）
        pad_size = kk // 2 if kk != stride else 0  # padding确保偏移预测后尺寸不变
        self.conv_offset = nn.Sequential(
            # 深度可分离卷积：提取分组特征的局部关联（降低计算量）
            nn.Conv2d(self.n_group_channels, self.n_group_channels,
                      kk, stride, pad_size, groups=self.n_group_channels),
            LayerNorm2d(self.n_group_channels),  # 归一化稳定训练
            nn.GELU(),  # 非线性激活，增强偏移预测能力
            nn.Conv2d(self.n_group_channels, 2, 1, 1, 0, bias=False)  # 输出2通道偏移（x/y）
        )
        # 若禁用偏移，冻结偏移预测网络参数
        if self.no_off:
            for m in self.conv_offset.parameters():
                m.requires_grad_(False)

        # 2. QKV投影层：1×1卷积实现通道映射（避免全连接层的空间信息丢失）
        self.proj_q = nn.Conv2d(self.nc, self.nc, kernel_size=1, stride=1, padding=0)
        self.proj_k = nn.Conv2d(self.nc, self.nc, kernel_size=1, stride=1, padding=0)
        self.proj_v = nn.Conv2d(self.nc, self.nc, kernel_size=1, stride=1, padding=0)

        # 3. 输出投影层：恢复通道维度，增强特征表达
        self.proj_out = nn.Conv2d(self.nc, self.nc, kernel_size=1, stride=1, padding=0)

        # 4. 相对位置偏置（RPB）：增强窗口内像素的位置关联捕捉
        if rel_pos_bias:
            self.rpb = nn.Parameter(
                torch.zeros(
                    num_heads,
                    (2 * self.kernel_size[0] - 1),  # 高度方向偏置范围
                    (2 * self.kernel_size[1] - 1),  # 宽度方向偏置范围
                )
            )
            # 截断正态分布初始化偏置（避免初始值过大）
            trunc_normal_(self.rpb, std=0.02, mean=0.0, a=-2.0, b=2.0)
        else:
            self.register_parameter("rpb", None)  # 无偏置时注册为None

        # 5. Dropout层：正则化，避免过拟合
        self.proj_drop = nn.Dropout(proj_drop, inplace=True)
        self.attn_drop = nn.Dropout(attn_drop, inplace=True)

        # 6. 深度可分离位置编码（DWC-PE）：增强位置敏感性，降低计算量
        self.rpe_table = nn.Conv2d(
            self.nc, self.nc, kernel_size=3, stride=1, padding=1, groups=self.nc)  # 分组卷积=深度可分离

    @torch.no_grad()
    def _get_ref_points(self, H_key, W_key, B, dtype, device):
        """
        生成参考点网格：用于计算窗口偏移的基准坐标（归一化到[-1,1]范围）
        输入：H_key/W_key（偏移预测后的特征高/宽）、B（批次大小）、dtype/device（数据类型/设备）
        输出：参考点网格 [B×n_groups, H_key, W_key, 2]（2=xy坐标）
        """
        # 生成网格坐标（中心对齐，如32×32特征的坐标为0.5~31.5）
        ref_y, ref_x = torch.meshgrid(
            torch.linspace(0.5, H_key - 0.5, H_key, dtype=dtype, device=device),
            torch.linspace(0.5, W_key - 0.5, W_key, dtype=dtype, device=device),
            indexing='ij'  # 按行优先生成网格（i=行=y，j=列=x）
        )
        ref = torch.stack((ref_y, ref_x), -1)  # [H_key, W_key, 2]

        # 坐标归一化到[-1,1]（适配grid_sample的输入要求）
        ref[..., 1].div_(W_key - 1.0).mul_(2.0).sub_(1.0)  # x坐标归一化
        ref[..., 0].div_(H_key - 1.0).mul_(2.0).sub_(1.0)  # y坐标归一化

        # 扩展到批次×分组维度（每组独立计算偏移）
        ref = ref[None, ...].expand(B * self.n_groups, -1, -1, -1)
        return ref

    @torch.no_grad()
    def _get_q_grid(self, H, W, B, dtype, device):
        """生成查询点网格（与_get_ref_points逻辑一致，用于时序任务的因果注意力）"""
        ref_y, ref_x = torch.meshgrid(
            torch.arange(0, H, dtype=dtype, device=device),
            torch.arange(0, W, dtype=dtype, device=device),
            indexing='ij'
        )
        ref = torch.stack((ref_y, ref_x), -1)
        ref[..., 1].div_(W - 1.0).mul_(2.0).sub_(1.0)
        ref[..., 0].div_(H - 1.0).mul_(2.0).sub_(1.0)
        ref = ref[None, ...].expand(B * self.n_groups, -1, -1, -1)
        return ref

    def forward(self, x):
        """
        前向传播流程：偏移预测→动态采样→分组邻域注意力→位置编码融合→输出
        """
        B, C, H, W = x.size()  # 解析输入维度
        dtype, device = x.dtype, x.device

        # 步骤1：生成查询（Q）并预测窗口偏移
        q = self.proj_q(x)  # [B, C, H, W]（Q投影）
        # 分组维度重排：[B, C, H, W]→[B×n_groups, n_group_channels, H, W]（每组独立预测偏移）
        q_off = einops.rearrange(
            q, 'b (g c) h w -> (b g) c h w', g=self.n_groups, c=self.n_group_channels)
        # 预测偏移：[B×n_groups, 2, H, W]（2=xy方向偏移）
        offset = self.conv_offset(q_off).contiguous()
        Hk, Wk = offset.size(2), offset.size(3)  # 偏移特征的高/宽（与输入一致）

        # 步骤2：偏移范围控制（避免偏移过大导致采样异常）
        if self.offset_range_factor >= 0 and not self.no_off:
            # 计算偏移范围（基于特征尺寸，确保偏移后坐标在[-1,1]内）
            offset_range = torch.tensor(
                [1.0 / (Hk - 1.0), 1.0 / (Wk - 1.0)], device=device).reshape(1, 2, 1, 1)
            # tanh限制偏移幅度+范围缩放（控制窗口变形程度）
            offset = offset.tanh().mul(offset_range).mul(self.offset_range_factor)

        # 步骤3：生成动态采样网格（参考点+偏移）
        offset = einops.rearrange(offset, 'b p h w -> b h w p')  # [B×n_groups, H, W, 2]
        reference = self._get_ref_points(Hk, Wk, B, dtype, device)  # 参考点网格
        if self.no_off:
            offset = offset.fill_(0.0)  # 禁用偏移时，偏移量设为0
        # 计算最终采样位置（参考点+偏移，确保坐标在[-1,1]内）
        if self.offset_range_factor >= 0:
            pos = offset + reference
        else:
            pos = (offset + reference).clamp(-1., +1.)  # 强制截断异常值

        # 步骤4：动态采样关键特征（K）和值特征（V）
        if self.no_off:
            # 禁用偏移时，用平均池化模拟固定窗口采样（调试用）
            x_sampled = F.avg_pool2d(x, kernel_size=self.stride, stride=self.stride)
            assert x_sampled.size(2) == Hk and x_sampled.size(3) == Wk, "采样尺寸不匹配"
        else:
            # 分组采样：用grid_sample实现动态窗口采样（双线性插值）
            x_sampled = F.grid_sample(
                input=x.reshape(B * self.n_groups, self.n_group_channels, H, W),  # 分组输入
                grid=pos[..., (1, 0)],  # 交换xy坐标（grid_sample要求x在前，y在后）
                mode='bilinear', align_corners=True  # 双线性插值，确保边界对齐
            )  # [B×n_groups, n_group_channels, H, W]
        # 恢复批次维度：[B×n_groups, C, H, W]→[B, C, H, W]
        x_sampled = x_sampled.reshape(B, C, H, W)

        # 步骤5：深度可分离位置编码（DWC-PE）：增强位置敏感性
        residual_lepe = self.rpe_table(q)  # [B, C, H, W]（PE特征）

        # 步骤6：分组邻域注意力计算（分融合版/非融合版，适配不同natten版本）
        if self.rpb is not None or not FUSED:
            # 非融合版：QK计算→Softmax→AV计算（分步执行）
            # 维度重排：[B, C, H, W]→[B, n_groups, H, W, n_group_channels]（分组头）
            q = einops.rearrange(q, 'b (g c) h w -> b g h w c',
                                 g=self.n_groups, b=B, c=self.n_group_channels, h=H, w=W)
            k = einops.rearrange(self.proj_k(x_sampled), 'b (g c) h w -> b g h w c',
                                 g=self.n_groups, b=B, c=self.n_group_channels, h=H, w=W)
            v = einops.rearrange(self.proj_v(x_sampled), 'b (g c) h w -> b g h w c',
                                 g=self.n_groups, b=B, c=self.n_group_channels, h=H, w=W)

            q = q * self.scale  # Q缩放，缓解梯度消失
            # 邻域QK相似度计算（含相对位置偏置）
            attn = na2d_qk(
                q, k,
                kernel_size=self.kernel_size,
                dilation=self.dilation,
                is_causal=self.is_causal,
                rpb=self.rpb,
            )  # [B, n_groups, H, W, k²]（k²=窗口内像素数）

            attn = attn.softmax(dim=-1)  # 注意力权重归一化
            attn = self.attn_drop(attn)  # 注意力dropout

            # 邻域AV加权计算（V与注意力权重融合）
            out = na2d_av(
                attn, v,
                kernel_size=self.kernel_size,
                dilation=self.dilation,
                is_causal=self.is_causal,
            )  # [B, n_groups, H, W, n_group_channels]

            # 恢复通道维度：[B, n_groups, H, W, c]→[B, C, H, W]
            out = einops.rearrange(out, 'b g h w c -> b (g c) h w')
        else:
            # 融合版：QKV一步计算（natten 0.17+支持，效率更高）
            q = einops.rearrange(q, 'b (g c) h w -> b h w g c',
                                 g=self.n_groups, b=B, c=self.n_group_channels, h=H, w=W)
            k = einops.rearrange(self.proj_k(x_sampled), 'b (g c) h w -> b h w g c',
                                 g=self.n_groups, b=B, c=self.n_group_channels, h=H, w=W)
            v = einops.rearrange(self.proj_v(x_sampled), 'b (g c) h w -> b h w g c',
                                 g=self.n_groups, b=B, c=self.n_group_channels, h=H, w=W)

            # 融合邻域注意力计算
            out = na2d(
                q, k, v,
                kernel_size=self.kernel_size,
                dilation=self.dilation,
                is_causal=self.is_causal,
                rpb=self.rpb,
                scale=self.scale,
            )  # [B, H, W, C]

            # 恢复维度顺序：[B, H, W, C]→[B, C, H, W]
            out = out.reshape(B, H, W, C).permute(0, 3, 1, 2)

        # 步骤7：位置编码融合+输出投影
        if self.use_pe and self.dwc_pe:
            out = out + residual_lepe  # PE特征残差融合
        # 输出投影+dropout：增强特征表达，避免过拟合
        y = self.proj_drop(self.proj_out(out))

        return y

if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 64, 32, 32).to(device)
    model = DeformableNeighborhoodAttention(64, 4, 3)

    model.to(device)
    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("知乎、CSDN：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)