'''
模块出处：CAS-ViT: Convolutional Additive Self-attention Vision Transformers for Efficient Mobile Applications
文章链接：https://arxiv.org/pdf/2408.03703
完整源码：https://github.com/Tianfang-Zhang/CAS-ViT

微信公众号：十小大的底层视觉工坊
知乎、CSDN：十小大
'''


import torch
import torch.nn as nn

class SpatialOperation(nn.Module):
    """
    空间注意力操作模块：对特征图的空间维度（H×W）进行权重分配
    核心逻辑：通过深度卷积提取空间特征，再通过1×1卷积压缩为单通道注意力图，最终与原特征相乘实现空间增强
    """
    def __init__(self, dim):
        super().__init__()
        self.block = nn.Sequential(
            # 深度卷积（Groups=dim）：仅捕捉空间信息，不跨通道交互，计算量低
            nn.Conv2d(dim, dim, 3, 1, 1, groups=dim),
            # 批量归一化：加速训练收敛，缓解内部协变量偏移
            nn.BatchNorm2d(dim),
            # ReLU激活函数：引入非线性，增强特征表达能力
            nn.ReLU(True),
            # 1×1卷积：将多通道特征压缩为单通道注意力权重图，无偏置减少参数
            nn.Conv2d(dim, 1, 1, 1, 0, bias=False),
            # Sigmoid激活函数：将权重值映射到[0,1]区间，实现空间位置的重要性区分
            nn.Sigmoid(),
        )

    def forward(self, x):
        # 输入x维度：(B, C, H, W)，输出维度与x一致（注意力图广播到所有通道）
        return x * self.block(x)

class ChannelOperation(nn.Module):
    """
    通道注意力操作模块：对特征图的通道维度（C）进行权重分配
    核心逻辑：通过全局平均池化压缩空间信息，再通过1×1卷积学习通道依赖，实现通道增强
    """
    def __init__(self, dim):
        super().__init__()
        self.block = nn.Sequential(
            # 自适应平均池化：将任意H×W压缩为1×1，保留通道维度的全局信息
            nn.AdaptiveAvgPool2d((1, 1)),
            # 1×1卷积：学习通道间的依赖关系，生成通道权重，无偏置减少参数
            nn.Conv2d(dim, dim, 1, 1, 0, bias=False),
            # Sigmoid激活函数：将通道权重映射到[0,1]区间，实现通道的重要性区分
            nn.Sigmoid(),
        )

    def forward(self, x):
        # 输入x维度：(B, C, H, W)，输出维度与x一致（通道权重广播到所有空间位置）
        return x * self.block(x)

class LocalIntegration(nn.Module):
    """
    局部特征整合模块：通过"1×1卷积降维→归一化→深度卷积提特征→激活→1×1卷积升维"的流程
    实现局部空间-通道特征的高效交互，为后续注意力计算提供更丰富的局部上下文
    """
    def __init__(self, dim, ratio=1, act_layer=nn.ReLU, norm_layer=nn.GELU):
        super().__init__()
        mid_dim = round(ratio * dim)  # 中间维度，默认与输入维度一致（ratio=1）
        self.network = nn.Sequential(
            # 1×1卷积升维/降维：调整通道数，为后续深度卷积做准备
            nn.Conv2d(dim, mid_dim, 1, 1, 0),
            # 归一化层（默认GELU）：稳定训练，增强特征表达
            norm_layer(mid_dim),
            # 深度卷积：捕捉局部空间特征，计算量低
            nn.Conv2d(mid_dim, mid_dim, 3, 1, 1, groups=mid_dim),
            # 激活函数（默认ReLU）：引入非线性
            act_layer(),
            # 1×1卷积：恢复通道数至输入维度，完成局部特征整合
            nn.Conv2d(mid_dim, dim, 1, 1, 0),
        )

    def forward(self, x):
        # 输入输出维度均为(B, C, H, W)，仅对特征内容进行局部优化
        return self.network(x)

class AdditiveTokenMixer(nn.Module):
    """
    核心模块：加性Token混合器（CATM），CAS-ViT的核心创新点
    设计差异：不同于传统自注意力对Q/K分别投影后计算相似度，CATM先对Q+K融合特征投影
    核心优势：用卷积替代矩阵乘法，降低计算复杂度，适配移动设备
    """
    def __init__(self, dim=512, attn_bias=False, proj_drop=0.):
        super().__init__()
        # 1×1卷积：将输入特征一次性投影为Q、K、V三个特征图（通道数均为dim）
        self.qkv = nn.Conv2d(dim, 3 * dim, 1, stride=1, padding=0, bias=attn_bias)
        # Q特征优化：串联空间注意力+通道注意力，增强Q的特征区分度
        self.oper_q = nn.Sequential(
            SpatialOperation(dim),
            ChannelOperation(dim),
        )
        # K特征优化：与Q采用相同结构，增强K的特征匹配能力
        self.oper_k = nn.Sequential(
            SpatialOperation(dim),
            ChannelOperation(dim),
        )
        # 深度卷积：对Q+K的融合特征进行局部空间信息提取，替代传统自注意力的矩阵乘法
        self.dwc = nn.Conv2d(dim, dim, 3, 1, 1, groups=dim)
        # 深度卷积投影：对"融合特征×V"的结果进行特征转换，输出最终注意力特征
        self.proj = nn.Conv2d(dim, dim, 3, 1, 1, groups=dim)
        # Dropout层：防止过拟合，概率由proj_drop控制
        self.proj_drop = nn.Dropout(proj_drop)

    def forward(self, x):
        # 1. QKV生成：输入x(B,C,H,W)→qkv卷积→拆分出Q(B,dim,H,W)、K(B,dim,H,W)、V(B,dim,H,W)
        q, k, v = self.qkv(x).chunk(3, dim=1)
        # 2. Q/K优化：通过空间+通道注意力增强Q和K的特征表达
        q = self.oper_q(q)
        k = self.oper_k(k)
        # 3. 加性混合：Q+K融合→深度卷积提局部特征→与V逐元素相乘→投影转换→Dropout
        out = self.proj(self.dwc(q + k) * v)
        out = self.proj_drop(out)
        # 输出维度与输入一致：(B, C, H, W)，保证模块可堆叠性
        return out

if __name__ == '__main__':
    # 设备选择：优先使用GPU（cuda:0），无GPU则使用CPU
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    # 构造输入特征：(批量大小=1, 通道数=64, 高度=64, 宽度=64)，模拟图像特征图
    x = torch.randn(1, 64, 64, 64).to(device)
    # 初始化CATM模块（输入通道数=64）并移动到目标设备
    catm = AdditiveTokenMixer(64).to(device)
    # 前向传播计算
    y = catm(x)
    # 打印结果：验证输入输出维度一致性（应均为(1,64,64,64)）
    print("微信公众号：十小大的底层视觉工坊")
    print("知乎、CSDN：十小大")
    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)