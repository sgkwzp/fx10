import torch
import torch.nn as nn
import torch.nn.functional as F
from einops import rearrange



# AFFN: Autocorrelation feed-forward network 自相关前馈网络核心实现
class DFFN_AutoCorr(nn.Module):
    def __init__(self, dim, ffn_expansion_factor, bias):
        super(DFFN_AutoCorr, self).__init__()
        hidden_features = int(dim * ffn_expansion_factor)  # FFN通道扩张系数
        self.patch_size = 8  # 局部自相关计算的patch尺寸，平衡计算量与建模范围
        self.dim = dim

        # 【对应结构图输入预处理】1×1卷积升维，将输入特征映射到高维空间
        self.project_in = nn.Conv2d(dim, hidden_features * 2, kernel_size=1, bias=bias)
        # 【对应结构图DConv】深度可分离卷积，捕捉局部空间细节，与全局自相关建模互补
        self.dwconv = nn.Conv2d(hidden_features * 2, hidden_features * 2, kernel_size=3,
                                stride=1, padding=1, groups=hidden_features * 2, bias=bias)
        # 【对应结构图最终Conv】1×1卷积降维，输出与输入通道一致，实现即插即用
        self.project_out = nn.Conv2d(hidden_features, dim, kernel_size=1, bias=bias)

        # 【对应结构图频域滤波】可学习频域核，对patch内的频域特征做自适应滤波
        self.fft = nn.Parameter(torch.ones((hidden_features * 2, 1, 1, self.patch_size, self.patch_size // 2 + 1)))
        # 可学习融合权重α：控制频域自相关功率谱的增强强度，对应结构图α分支
        self.alpha = nn.Parameter(torch.tensor(0.5))
        # 可学习融合权重β：控制空域自相关矩阵的增强强度，对应结构图β分支
        self.beta = nn.Parameter(torch.tensor(0.5))

    def forward(self, x):
        # 步骤1：输入特征升维，映射到高维特征空间
        x = self.project_in(x)
        # 步骤2：特征分块，将全局特征拆分为8×8的局部patch，适配局部自相关计算
        x_patch = rearrange(
            x, 'b c (h ph) (w pw) -> b c h w ph pw',
            ph=self.patch_size, pw=self.patch_size
        )

        # -------------------------- 核心自相关频域建模 对应结构图FFT→功率谱计算双分支 --------------------------
        # 【对应结构图FFT模块】对每个patch做2D实值FFT，映射到频域
        Xf = torch.fft.rfft2(x_patch.float())
        # 可学习频域滤波，自适应筛选有效频带
        Xf = Xf * self.fft

        # 【对应结构图conj+元素乘】维纳-辛钦定理：自相关函数的傅里叶变换=功率谱|Xf|²
        power = Xf * torch.conj(Xf)  # 计算频域自相关功率谱，表征周期结构特性
        # 【对应结构图β分支IFFT】功率谱逆FFT，得到空域自相关矩阵R，表征局部结构的周期相似性
        R = torch.fft.irfft2(power, s=(self.patch_size, self.patch_size))

        # 【对应结构图α分支】频域增强：原始频域特征 + 功率谱加权，强化周期结构分量
        Xf_new = Xf + self.alpha * power
        # 【对应结构图α分支IFFT】增强后的频域特征逆变换回空域
        x_patch_new = torch.fft.irfft2(Xf_new, s=(self.patch_size, self.patch_size))
        # 【对应结构图β分支】空域增强：频域增强特征 + 自相关矩阵加权，强化结构相似性
        x_patch_new = x_patch_new + self.beta * R

        # 步骤3：patch重组，恢复原始特征尺寸
        x = rearrange(
            x_patch_new, 'b c h w ph pw -> b c (h ph) (w pw)',
            ph=self.patch_size, pw=self.patch_size
        )

        # -------------------------- 局部细节增强与门控融合 对应结构图Split→DConv→门控→最终Conv --------------------------
        # 通道拆分，适配门控线性单元(GLU)
        x1, x2 = self.dwconv(x).chunk(2, dim=1)
        # GELU门控融合，实现特征的非线性筛选，强化有效特征
        x = F.gelu(x1) * x2
        # 通道降维，输出与输入同尺寸的增强特征
        x = self.project_out(x)
        return x

# 模块测试代码
if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    x = torch.randn(1, 64, 32, 32).to(device)
    model = DFFN_AutoCorr(64, 2, False).to(device)
    y = model(x)
    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("小红书：十小大，主页获取往期全部即插即用代码，200+大合集")
    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)