import torch
import torch.nn as nn
import torch.nn.functional as F
from einops import rearrange
from pytorch_wavelets import DWTForward, DWTInverse

# WDAM: Wavelet-based Directional Attention Module 基于小波的方向注意力模块核心实现
# 完整对应结构图(c) WDAM全流程：DWT分解→方向高频特征提取→高频引导窗口注意力→高低频协同优化→IDWT重建
class DWT_WindowAttention_SW(nn.Module):
    def __init__(self, dim, num_heads, input_resolution, window_size=8, shift_size=4, bias=False):
        super(DWT_WindowAttention_SW, self).__init__()
        self.dim = dim                  # 输入特征通道数
        self.num_heads = num_heads      # 注意力头数
        self.shift_size = shift_size    # 窗口滑动步长（Swin风格移位窗口）
        self.window_size = window_size  # 注意力窗口尺寸
        # 自适应窗口尺寸：当输入分辨率小于窗口尺寸时，自动适配为小波分解后的尺寸
        if (input_resolution//2)  <= window_size:
            self.shift_size = 0
            self.window_size = input_resolution //2
            window_size = input_resolution //2

        # 注意力可学习温度系数，控制注意力分布平滑度
        self.temperature = nn.Parameter(torch.ones(num_heads, 1, 1))

        # -------------------------- 对应结构图(c) DWT/IDWT模块 --------------------------
        self.dwt = DWTForward(J=1, wave='haar')  # 1级Haar小波分解，解耦高低频+方向分量
        self.idwt = DWTInverse(wave='haar')      # 小波逆变换，重建最终特征

        # -------------------------- 对应结构图(c) 方向高频特征处理分支 --------------------------
        # 水平/垂直方向高频(LH/HL)融合卷积，提取方向权重
        self.high_conv = nn.Sequential(
            nn.Conv2d(dim*2, dim*2, kernel_size=3, padding=1, groups=2, bias=bias),
            nn.ReLU(inplace=True),
            nn.Conv2d(dim*2, dim, kernel_size=1, bias=bias),
            nn.ReLU(inplace=True)
        )
        # 三方向高频(LH/HL/HH)联合优化卷积，提升细节重建能力
        self.high_out = nn.Sequential(
            nn.Conv2d(dim*3, dim*3, kernel_size=3, padding=1, groups=3, bias=bias),
            nn.ReLU(inplace=True)
        )

        # -------------------------- 对应结构图(c) 低频窗口注意力分支 --------------------------
        # 低频特征QKV生成：1×1卷积+深度卷积，降低计算量
        self.qkv = nn.Conv2d(dim, dim*3, kernel_size=1, bias=bias)
        self.qkv_dwconv = nn.Conv2d(dim*3, dim*3, kernel_size=3, stride=1, padding=1, groups=dim*3, bias=bias)
        self.project_out = nn.Conv2d(dim, dim, kernel_size=1, bias=bias)  # 注意力输出投影

        # -------------------------- Swin风格相对位置偏置 --------------------------
        self.relative_position_bias_table = nn.Parameter(
            torch.zeros((2*window_size-1)*(2*window_size-1), num_heads)
        )
        # 预计算相对位置索引
        coords = torch.stack(torch.meshgrid(torch.arange(window_size), torch.arange(window_size)))
        coords_flatten = coords.flatten(1)
        relative_coords = coords_flatten[:, :, None] - coords_flatten[:, None, :]
        relative_coords = relative_coords.permute(1, 2, 0).contiguous()
        relative_coords[:, :, 0] += window_size - 1
        relative_coords[:, :, 1] += window_size - 1
        relative_coords[:, :, 0] *= 2*window_size - 1
        relative_position_index = relative_coords.sum(-1)
        self.register_buffer("relative_position_index", relative_position_index)

    # ========================= 窗口操作工具函数 =========================
    def window_partition(self, x):
        """将特征划分为不重叠的窗口，适配窗口注意力计算"""
        B, C, H, W = x.shape
        ws = self.window_size
        x = x.view(B, C, H//ws, ws, W//ws, ws)
        x = x.permute(0, 2, 4, 1, 3, 5).contiguous()
        x = x.view(-1, C, ws, ws)
        return x

    def window_reverse(self, windows, H, W):
        """将窗口特征还原为原始特征尺寸"""
        B = int(windows.shape[0] / (H * W / self.window_size / self.window_size))
        C = windows.shape[1]
        ws = self.window_size
        x = windows.view(B, H//ws, W//ws, C, ws, ws)
        x = x.permute(0, 3, 1, 4, 2, 5).contiguous()
        x = x.view(B, C, H, W)
        return x

    def shift(self, x, shift_size):
        """窗口循环移位，实现跨窗口信息交互"""
        if shift_size > 0:
            x = torch.roll(x, shifts=(-shift_size, -shift_size), dims=(2, 3))
        return x

    def reverse_shift(self, x, shift_size):
        """逆循环移位，还原特征位置"""
        if shift_size > 0:
            x = torch.roll(x, shifts=(shift_size, shift_size), dims=(2, 3))
        return x

    def window_attention(self, q, k, v):
        """
        带相对位置偏置的窗口注意力计算
        q,k,v: (窗口数, 注意力头数, 单头通道数, 窗口像素数)
        返回: 注意力加权后的特征
        """
        # L2归一化，提升注意力稳定性
        q = F.normalize(q, dim=-2)
        k = F.normalize(k, dim=-2)
        # Q^T·K 计算注意力相似度矩阵
        attn = torch.matmul(q.transpose(-2, -1), k)
        # 注入相对位置偏置
        N = self.window_size * self.window_size
        relative_position_bias = self.relative_position_bias_table[self.relative_position_index.view(-1)]
        relative_position_bias = relative_position_bias.view(N, N, -1).permute(2,0,1).unsqueeze(0)
        attn = attn + relative_position_bias
        # 温度系数缩放+Softmax归一化
        attn = attn * self.temperature
        attn = attn.softmax(dim=-1)
        # 注意力矩阵加权V，得到输出特征
        out = torch.matmul(v, attn.transpose(-2, -1))
        return out

    def forward(self, x):
        B, C, H, W = x.shape
        # -------------------------- 步骤1：小波分解 对应结构图(c) DWT模块 --------------------------
        # 1级Haar小波分解：LL=低频结构分量，Yh=高频方向分量(LH水平/HL垂直/HH对角)
        LL, Yh = self.dwt(x)
        Yh = Yh[0]
        LH, HL, HH = Yh[:, :, 0, :, :], Yh[:, :, 1, :, :], Yh[:, :, 2, :, :]

        # -------------------------- 步骤2：方向高频特征提取 对应结构图(c) 高频Conv分支 --------------------------
        # 融合水平+垂直方向高频，生成方向引导权重
        filter_hv = self.high_conv(torch.cat([LH, HL], dim=1))

        # -------------------------- 步骤3：低频QKV生成+高频方向引导 对应结构图(c) 注意力分支 --------------------------
        # 低频特征生成QKV
        qkv = self.qkv_dwconv(self.qkv(LL))
        q, k, v_inp = qkv.chunk(3, dim=1)
        # 核心创新：用方向高频特征加权V，让注意力聚焦于边缘/纹理区域，实现方向引导
        v = v_inp * filter_hv + v_inp

        # -------------------------- 步骤4：移位窗口注意力计算 --------------------------
        # 窗口循环移位，实现跨窗口信息交互
        x_shifted = self.shift(LL, self.shift_size)
        # 特征划分为窗口
        q = self.window_partition(x_shifted)
        k = self.window_partition(x_shifted)
        v = self.window_partition(v)
        # 维度重整，适配多头注意力
        B_win, Cq, ws, _ = q.shape
        q = q.view(B_win, self.num_heads, Cq//self.num_heads, ws*ws)
        k = k.view(B_win, self.num_heads, Cq//self.num_heads, ws*ws)
        v = v.view(B_win, self.num_heads, Cq//self.num_heads, ws*ws)
        # 窗口注意力计算
        out = self.window_attention(q, k, v)
        # 窗口还原+逆移位
        out = out.view(B_win, Cq, ws, ws)
        out = self.window_reverse(out, H//2, W//2)
        out = self.reverse_shift(out, self.shift_size)
        # 注意力输出投影
        out = self.project_out(out)

        # -------------------------- 步骤5：高频分量优化+小波逆变换重建 对应结构图(c) IDWT模块 --------------------------
        # 三方向高频分量联合优化
        Yh = self.high_out(torch.cat([LH, HL, HH], dim=1))
        LH, HL, HH = Yh.chunk(3, dim=1)
        Yh = torch.stack([LH, HL, HH], dim=2)
        # 逆小波变换，融合优化后的低频+高频分量，重建最终特征
        x_hat = self.idwt((out, [Yh]))
        return x_hat

# 模块测试代码
if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    x = torch.randn(1, 64, 32, 32).to(device)
    model = DWT_WindowAttention_SW(64, 4, 32).to(device)
    y = model(x)
    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("小红书：十小大，主页获取往期全部即插即用代码，200+大合集")
    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)