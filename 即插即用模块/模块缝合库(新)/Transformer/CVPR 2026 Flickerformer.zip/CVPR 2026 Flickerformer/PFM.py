import torch
import torch.nn as nn
import torch.nn.functional as F


class PhaseGuidedFilter(nn.Module):
    def __init__(self, dim, ffn_expansion_factor=2.66, bias=False):
        super(PhaseGuidedFilter, self).__init__()

        hidden_dim = int(dim * ffn_expansion_factor)

        self.net12 = nn.Sequential(
            nn.Conv2d(dim, hidden_dim, kernel_size=3, padding=1, bias=bias),
            nn.ReLU(inplace=True),
            nn.Conv2d(hidden_dim, hidden_dim, kernel_size=3, padding=1, bias=bias),
            nn.ReLU(inplace=True),
            nn.Conv2d(hidden_dim, dim, kernel_size=1, bias=bias),
            nn.Sigmoid()
        )
        self.net23 = nn.Sequential(
            nn.Conv2d(dim, hidden_dim, kernel_size=3, padding=1, bias=bias),
            nn.ReLU(inplace=True),
            nn.Conv2d(hidden_dim, hidden_dim, kernel_size=3, padding=1, bias=bias),
            nn.ReLU(inplace=True),
            nn.Conv2d(hidden_dim, dim, kernel_size=1, bias=bias),
            nn.Sigmoid()
        )
        self.fusion = nn.Conv2d(dim * 3, dim, 3, 1, 1)

        self.group_conv = nn.Conv2d(dim * 3, dim * 3, 3, 1, 1, groups=3)

        self.eps = float(1e-8)

    def forward(self, x):
        x1, x2, x3 = x.chunk(3, dim=1)

        f1 = torch.fft.rfft2(x1)
        f2 = torch.fft.rfft2(x2)
        f3 = torch.fft.rfft2(x3)

        mag_1 = torch.abs(f1)
        mag_2 = torch.abs(f2)
        mag_3 = torch.abs(f3)

        phase1 = f1 / (mag_1 + self.eps)
        phase2 = f2 / (mag_2 + self.eps)
        phase3 = f3 / (mag_3 + self.eps)

        C12 = torch.abs(phase1 * torch.conj(phase2))
        C23 = torch.abs(phase3 * torch.conj(phase2))

        C12 = self.net12(C12)
        C23 = self.net23(C23)

        f1_filtered = C12 * f1
        f3_filtered = C23 * f3

        x1_filtered = torch.fft.irfft2(f1_filtered)
        x3_filtered = torch.fft.irfft2(f3_filtered)

        out = torch.cat([x1_filtered, x2, x3_filtered], dim=1)

        out = self.fusion(out)

        return out


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 192, 32, 32).to(device)
    model = PhaseGuidedFilter(64, 2, False).to(device)

    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("小红书：十小大，主页获取往期全部即插即用代码，200+大合集")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)