import torch
import torch.nn as nn
import torch.nn.functional as F
from einops import rearrange


class CAFMAttention(nn.Module):
    """
    自适应通道融合多尺度模块（ACFM）：核心模块，通过局部卷积+全局自注意力双分支，增强多尺度特征
    核心创新：
        1. 3D卷积适配：用3D卷积处理2D特征（扩展通道维度），兼顾通道与空间关联；
        2. 双分支融合：局部卷积捕捉细节，全局自注意力捕捉长距离关联；
        3. 自适应通道映射：通过全连接层动态调整通道权重，优化特征融合；
        4. 轻量化设计：深度卷积+分组卷积，降低计算量，适配高分辨率。
    输入：2D特征图 [B, C, H, W]（如CNN/Transformer中层特征）
    输出：增强后2D特征图 [B, C, H, W]（与输入维度完全一致）
    Args:
        dim: 输入/输出通道数
        num_heads: 注意力头数
        bias: 卷积层是否加偏置
    """

    def __init__(self, dim, num_heads=2, bias=False):
        super(CAFMAttention, self).__init__()
        self.num_heads = num_heads
        self.temperature = nn.Parameter(torch.ones(num_heads, 1, 1))  # 注意力温度参数（可学习）

        # QKV生成：1×1×1 3D卷积（适配扩展后的维度）
        self.qkv = nn.Conv3d(dim, dim * 3, kernel_size=(1, 1, 1), bias=bias)
        # QKV深度卷积：3×3×3 3D深度卷积（增强局部关联）
        self.qkv_dwconv = nn.Conv3d(
            dim * 3, dim * 3, kernel_size=(3, 3, 3), stride=1, padding=1,
            groups=dim * 3, bias=bias
        )
        # 全局分支输出投影：1×1×1 3D卷积（恢复通道）
        self.project_out = nn.Conv3d(dim, dim, kernel_size=(1, 1, 1), bias=bias)

        # 自适应通道映射：调整多头部通道权重
        self.fc = nn.Conv3d(3 * self.num_heads, 9, kernel_size=(1, 1, 1), bias=True)
        # 局部分支深度卷积：分组深度卷积（增强局部特征）
        self.dep_conv = nn.Conv3d(
            9 * dim // self.num_heads, dim, kernel_size=(3, 3, 3), bias=True,
            groups=dim // self.num_heads, padding=1
        )

    def forward(self, x):
        """
        前向传播流程：维度扩展→QKV生成→双分支（局部卷积+全局注意力）→融合输出
        """
        b, c, h, w = x.shape  # 输入维度：[B, C, H, W]

        # 步骤1：维度扩展（2D→3D）：适配3D卷积，新增通道维度（维度2）
        x_3d = x.unsqueeze(2)  # [B, C, 1, H, W]

        # 步骤2：QKV生成与局部增强（3D卷积）
        qkv = self.qkv(x_3d)  # [B, 3C, 1, H, W]（生成QKV）
        qkv = self.qkv_dwconv(qkv)  # 3D深度卷积增强局部关联
        qkv_2d = qkv.squeeze(2)  # 恢复2D：[B, 3C, H, W]

        # 步骤3：局部卷积分支（捕捉细节特征）
        # 通道维度重组与自适应映射
        f_all = qkv_2d.reshape(b, h * w, 3 * self.num_heads, -1).permute(0, 2, 1, 3)  # [B, 3×heads, H×W, C//heads]
        f_all = self.fc(f_all.unsqueeze(2))  # 3D卷积调整通道权重：[B, 3×heads, 1, H×W, C//heads]
        f_all = f_all.squeeze(2)  # 恢复：[B, 3×heads, H×W, C//heads]
        # 格式转换与分组深度卷积
        f_conv = f_all.permute(0, 3, 1, 2).reshape(b, 9 * c // self.num_heads, h, w)  # [B, 9×C//heads, H, W]
        f_conv_3d = f_conv.unsqueeze(2)  # 3D适配：[B, 9×C//heads, 1, H, W]
        out_conv = self.dep_conv(f_conv_3d).squeeze(2)  # 局部增强输出：[B, C, H, W]

        # 步骤4：全局自注意力分支（捕捉长距离关联）
        # QKV拆分与多头重组
        q, k, v = qkv_2d.chunk(3, dim=1)  # 各为[B, C, H, W]
        q = rearrange(q, 'b (head c) h w -> b head c (h w)', head=self.num_heads)  # [B, heads, C//heads, H×W]
        k = rearrange(k, 'b (head c) h w -> b head c (h w)', head=self.num_heads)
        v = rearrange(v, 'b (head c) h w -> b head c (h w)', head=self.num_heads)
        # 归一化与注意力计算
        q = F.normalize(q, dim=-1)
        k = F.normalize(k, dim=-1)
        attn = (q @ k.transpose(-2, -1)) * self.temperature  # 注意力分数
        attn = attn.softmax(dim=-1)  # 权重归一化
        out_attn = (attn @ v)  # 注意力加权
        # 格式恢复与投影
        out_attn = rearrange(out_attn, 'b head c (h w) -> b (head c) h w', head=self.num_heads, h=h,
                             w=w)  # [B, C, H, W]
        out_attn = self.project_out(out_attn.unsqueeze(2)).squeeze(2)  # 3D投影输出：[B, C, H, W]

        # 步骤5：双分支融合（局部+全局）
        output = out_attn + out_conv

        return output


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    x = torch.randn(1, 64, 32, 32).to(device)

    model = CAFMAttention(64).to(device)
    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN：十小大")
    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)