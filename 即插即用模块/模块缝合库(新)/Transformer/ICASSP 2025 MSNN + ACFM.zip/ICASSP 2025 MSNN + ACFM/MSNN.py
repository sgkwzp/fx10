import torch
import torch.nn as nn
import torch.nn.functional as F


class MSFN(nn.Module):
    """
    多尺度特征网络模块（MSNN）：通过多 dilation 率空洞卷积+3D卷积，高效捕捉多尺度特征
    核心创新：
        1. 多尺度空洞卷积：3种 dilation 率（1/2/3），覆盖不同感受野；
        2. 3D-2D混合卷积：3D卷积适配特征维度，2D空洞卷积捕捉空间关联；
        3. 元素级乘法融合：强化有效特征，抑制冗余；
        4. 轻量化设计：深度卷积+1×1卷积，计算量低，即插即用。
    输入：2D特征图 [B, dim, H, W]（如CNN/Transformer中层特征）
    输出：增强后2D特征图 [B, dim, H, W]（与输入维度完全一致）
    Args:
        dim: 输入/输出通道数
        ffn_expansion_factor: 中间通道扩展因子（默认2.66）
        bias: 卷积层是否加偏置（默认False）
    """

    def __init__(self, dim, ffn_expansion_factor=2.66, bias=False):
        super(MSFN, self).__init__()
        hidden_features = int(dim * ffn_expansion_factor)  # 中间通道数（dim×扩展因子）

        # 输入投影：1×1×1 3D卷积（将2D特征扩展为3D，适配多尺度分支）
        self.project_in = nn.Conv3d(dim, hidden_features * 3, kernel_size=(1, 1, 1), bias=bias)

        # 多尺度分支卷积（3种 dilation 率，覆盖不同感受野）
        # 分支1：3×3×3 3D深度卷积（dilation=1，小感受野，捕捉局部细节）
        self.dwconv1 = nn.Conv3d(
            hidden_features, hidden_features, kernel_size=(3, 3, 3), stride=1, dilation=1,
            padding=1, groups=hidden_features, bias=bias
        )
        # 分支2：3×3 2D深度卷积（dilation=2，中感受野，捕捉中程关联）
        self.dwconv2 = nn.Conv2d(
            hidden_features, hidden_features, kernel_size=(3, 3), stride=1, dilation=2,
            padding=2, groups=hidden_features, bias=bias
        )
        # 分支3：3×3 2D深度卷积（dilation=3，大感受野，捕捉长距离关联）
        self.dwconv3 = nn.Conv2d(
            hidden_features, hidden_features, kernel_size=(3, 3), stride=1, dilation=3,
            padding=3, groups=hidden_features, bias=bias
        )

        # 输出投影：1×1×1 3D卷积（将3D特征恢复为2D，压缩通道至dim）
        self.project_out = nn.Conv3d(hidden_features, dim, kernel_size=(1, 1, 1), bias=bias)

    def forward(self, x):
        """
        前向传播流程：维度扩展→多分支特征提取→元素级融合→输出投影
        """
        # 步骤1：维度扩展（2D→3D）：新增通道维度（dim=2），适配3D卷积
        x_3d = x.unsqueeze(2)  # [B, dim, 1, H, W]

        # 步骤2：输入投影+分支拆分
        x_proj = self.project_in(x_3d)  # [B, 3×hidden_features, 1, H, W]
        x1, x2, x3 = x_proj.chunk(3, dim=1)  # 拆分为3个分支，各[B, hidden_features, 1, H, W]

        # 步骤3：多尺度分支特征提取
        # 分支1：3D深度卷积（dilation=1）→ 恢复2D
        x1 = self.dwconv1(x1).squeeze(2)  # [B, hidden_features, H, W]
        # 分支2：2D空洞卷积（dilation=2）→ 直接处理2D特征
        x2 = self.dwconv2(x2.squeeze(2))  # [B, hidden_features, H, W]
        # 分支3：2D空洞卷积（dilation=3）→ 直接处理2D特征
        x3 = self.dwconv3(x3.squeeze(2))  # [B, hidden_features, H, W]

        # 步骤4：元素级乘法融合（强化有效特征，抑制冗余）
        x_fuse = F.gelu(x1) * x2 * x3  # [B, hidden_features, H, W]

        # 步骤5：输出投影（3D→2D）
        x_out = self.project_out(x_fuse.unsqueeze(2)).squeeze(2)  # [B, dim, H, W]

        return x_out


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    x = torch.randn(1, 64, 32, 32).to(device)

    model = MSFN(64).to(device)
    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN：十小大")
    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)