import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from timm.models.layers import to_2tuple


def get_relative_position_cpb(query_size, key_size, pretrain_size=None):
    """
    生成连续相对位置编码（CPB）：计算查询与键的相对位置映射及坐标表
    核心作用：为注意力提供细粒度位置信息，适配不同尺寸的查询/键
    输入：
        query_size: 查询特征尺寸 (Hq, Wq)
        key_size: 键特征尺寸 (Hk, Wk)
        pretrain_size: 预训练尺寸（默认与query_size一致）
    输出：
        idx_map: 相对位置索引映射 [Hq×Wq × Hk×Wk]
        relative_coords_table: 归一化相对坐标表 [M, 2]（M为唯一相对位置数）
    """
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    pretrain_size = pretrain_size or query_size

    # 生成查询/键的坐标轴，并自适应池化匹配尺寸
    axis_qh = torch.arange(query_size[0], dtype=torch.float32, device=device)
    axis_kh = F.adaptive_avg_pool1d(axis_qh.unsqueeze(0), key_size[0]).squeeze(0)
    axis_qw = torch.arange(query_size[1], dtype=torch.float32, device=device)
    axis_kw = F.adaptive_avg_pool1d(axis_qw.unsqueeze(0), key_size[1]).squeeze(0)

    # 生成坐标网格并展平
    axis_kh, axis_kw = torch.meshgrid(axis_kh, axis_kw)
    axis_qh, axis_qw = torch.meshgrid(axis_qh, axis_qw)
    axis_kh = torch.reshape(axis_kh, [-1])
    axis_kw = torch.reshape(axis_kw, [-1])
    axis_qh = torch.reshape(axis_qh, [-1])
    axis_qw = torch.reshape(axis_qw, [-1])

    # 计算归一化相对位置（映射到[-8, 8]区间）
    relative_h = (axis_qh[:, None] - axis_kh[None, :]) / (pretrain_size[0] - 1) * 8
    relative_w = (axis_qw[:, None] - axis_kw[None, :]) / (pretrain_size[1] - 1) * 8
    relative_hw = torch.stack([relative_h, relative_w], dim=-1).view(-1, 2)

    # 去重得到唯一相对坐标表及索引映射
    relative_coords_table, idx_map = torch.unique(relative_hw, return_inverse=True, dim=0)
    # 对数归一化，增强位置敏感性
    relative_coords_table = torch.sign(relative_coords_table) * torch.log2(
        torch.abs(relative_coords_table) + 1.0) / torch.log2(torch.tensor(8, dtype=torch.float32))

    return idx_map, relative_coords_table


class Attention(nn.Module):
    """
    混合头注意力模块（MoHA）：核心模块，通过共享头+路由头混合机制，高效捕捉多尺度特征
    核心创新：
        1. 混合头架构：共享头捕捉全局通用特征，路由头动态适配特定特征；
        2. 连续相对位置偏置：MLP生成细粒度位置偏置，适配不同尺寸；
        3. 动态路由机制：基于输入特征自适应选择路由头，平衡效率与精度；
        4. 负载均衡损失：训练时优化头的负载分布，避免冗余。
    输入：
        x: 序列特征 [B, N, C]（N=H×W）
        H/W: 特征图高/宽
        relative_pos_index: 相对位置索引映射
        relative_coords_table: 归一化相对坐标表
    输出：
        增强后特征 [B, N, C]（与输入维度一致）
    Args:
        dim: 输入/输出通道数
        input_resolution: 输入特征分辨率 (H, W)
        num_heads: 总注意力头数
        qkv_bias: QKV投影是否加偏置
        attn_drop: 注意力Dropout概率
        proj_drop: 输出投影Dropout概率
        shared_head: 共享头数量（捕捉通用特征）
        routed_head: 路由头数量（动态适配特征）
    """
    LOAD_BALANCING_LOSSES = []  # 存储负载均衡损失

    def __init__(self, dim, input_resolution, num_heads=8, qkv_bias=True, attn_drop=0.,
                 proj_drop=0., shared_head=4, routed_head=0):
        super().__init__()
        assert dim % num_heads == 0, f"通道数 {dim} 需能被头数 {num_heads} 整除"
        self.dim = dim
        self.num_heads = num_heads
        self.head_dim = dim // num_heads
        self.input_resolution = input_resolution

        # 注意力温度参数（Softplus激活确保为正）
        self.temperature = nn.Parameter(
            torch.log((torch.ones(num_heads, 1, 1) / 0.24).exp() - 1)
        )  # 初始化后 Softplus(temperature) = 1/0.24

        # 序列长度缩放因子（预计算日志值）
        self.register_buffer(
            "seq_length_scale",
            torch.as_tensor(np.log(input_resolution[0] * input_resolution[1])),
            persistent=False
        )

        # QKV联合投影层
        self.qkv = nn.Linear(dim, dim * 3, bias=qkv_bias)
        # 查询嵌入（增强查询特征判别性）
        self.query_embedding = nn.Parameter(
            nn.init.trunc_normal_(torch.empty(self.num_heads, 1, self.head_dim), mean=0, std=0.02)
        )

        # 正则化层
        self.attn_drop = nn.Dropout(attn_drop)
        self.proj = nn.Linear(dim, dim)  # 输出投影
        self.proj_drop = nn.Dropout(proj_drop)

        # 连续相对位置偏置生成器（MLP）
        self.cpb_fc1 = nn.Linear(2, 512, bias=True)
        self.cpb_act = nn.ReLU(inplace=True)
        self.cpb_fc2 = nn.Linear(512, num_heads, bias=True)

        # 混合头配置
        self.shared_head = shared_head  # 共享头数量
        self.routed_head = routed_head  # 路由头数量

        # 路由头相关层（动态选择路由头）
        if self.routed_head > 0:
            self.wg = torch.nn.Linear(dim, num_heads - shared_head, bias=False)  # 路由头权重
            if self.shared_head > 0:
                self.wg_0 = torch.nn.Linear(dim, 2, bias=False)  # 共享头与路由头权重分配

        # 多共享头权重层（共享头>1时启用）
        if self.shared_head > 1:
            self.wg_1 = torch.nn.Linear(dim, shared_head, bias=False)

    def forward(self, x, H, W, relative_pos_index, relative_coords_table):
        """
        前向传播流程：QKV生成→相对位置偏置→混合头注意力→动态路由→输出投影
        """
        B, N, C = x.shape  # B=批次，N=序列长度（H×W），C=通道数
        _x = x.reshape(B * N, C)  # 展平为[B×N, C]，适配路由计算

        # 步骤1：路由头权重计算（动态选择路由头）
        routed_head_gates = None
        if self.routed_head > 0:
            logits = self.wg(_x)  # 路由头得分：[B×N, routed_head_num]
            gates = F.softmax(logits, dim=1)  # 路由头权重归一化
            num_tokens, num_experts = gates.shape

            # 选择Top-k路由头（k=routed_head）
            _, indices = torch.topk(gates, k=self.routed_head, dim=1)
            mask = F.one_hot(indices, num_classes=num_experts).sum(dim=1)  # 路由头掩码

            # 训练时计算负载均衡损失（避免头负载不均）
            if self.training:
                me = gates.mean(dim=0)  # 平均权重
                ce = mask.float().mean(dim=0)  # 平均负载
                l_aux = torch.mean(me * ce) * num_experts * num_experts  # 负载均衡损失
                Attention.LOAD_BALANCING_LOSSES.append(l_aux)

            # 路由头权重归一化
            routed_head_gates = gates * mask
            denom_s = torch.sum(routed_head_gates, dim=1, keepdim=True)
            denom_s = torch.clamp(denom_s, min=torch.finfo(denom_s.dtype).eps)
            routed_head_gates /= denom_s
            routed_head_gates = routed_head_gates.reshape(B, N, -1) * self.routed_head  # 缩放权重

        # 步骤2：QKV生成与拆分
        qkv = self.qkv(x).reshape(B, -1, 3 * self.num_heads, self.head_dim).permute(0, 2, 1, 3)
        q, k, v = qkv.chunk(3, dim=1)  # 各为[B, num_heads, N, head_dim]

        # 步骤3：生成连续相对位置偏置
        rel_bias = self.cpb_fc2(self.cpb_act(self.cpb_fc1(relative_coords_table))).transpose(0, 1)
        rel_bias = rel_bias[:, relative_pos_index.view(-1)].view(-1, N, N)  # [num_heads, N, N]

        # 步骤4：混合头注意力计算（余弦注意力+位置偏置）
        attn = (
                       (F.normalize(q, dim=-1) + self.query_embedding)  # 查询归一化+嵌入增强
                       * F.softplus(self.temperature)  # 温度缩放
                       * self.seq_length_scale  # 序列长度缩放
               ) @ F.normalize(k, dim=-1).transpose(-2, -1)  # 与归一化键计算相似度
        attn = attn + rel_bias  # 添加位置偏置
        attn = attn.softmax(dim=-1)  # 注意力权重归一化
        attn = self.attn_drop(attn)  # 注意力Dropout

        # 步骤5：混合头权重融合（共享头+路由头）
        x = (attn @ v).transpose(1, 2)  # [B, N, num_heads, head_dim]

        if self.routed_head > 0:
            # 多共享头权重计算
            if self.shared_head > 1:
                shared_head_weight = self.wg_1(_x)
                shared_head_gates = F.softmax(shared_head_weight, dim=1).reshape(B, N, -1) * self.shared_head
            else:
                # 单共享头：默认等权重
                shared_head_gates = torch.ones((B, N, self.shared_head)).to(_x.device).to(_x.dtype) * self.shared_head

            # 共享头与路由头权重分配
            if self.shared_head == 0:
                masked_gates = routed_head_gates
            else:
                weight_0 = self.wg_0(_x)
                weight_0 = F.softmax(weight_0, dim=1).reshape(B, N, 2) * 2  # 分配权重
                shared_head_gates = torch.einsum("bn,bne->bne", weight_0[:, :, 0], shared_head_gates)
                routed_head_gates = torch.einsum("bn,bne->bne", weight_0[:, :, 1], routed_head_gates)
                masked_gates = torch.cat([shared_head_gates, routed_head_gates], dim=2)  # 拼接权重

            # 权重加权融合
            x = torch.einsum("bne,bned->bned", masked_gates, x)
            x = x.reshape(B, N, C)
        else:
            # 无路由头：仅共享头融合
            shared_head_weight = self.wg_1(_x)
            masked_gates = F.softmax(shared_head_weight, dim=1).reshape(B, N, -1) * self.shared_head
            x = torch.einsum("bne,bned->bned", masked_gates, x)
            x = x.reshape(B, N, C)

        # 步骤6：输出投影与正则化
        x = self.proj(x)
        x = self.proj_drop(x)

        return x

if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    dim = 64
    H, W = 32, 32
    img_size = 32
    i = 0
    x = torch.randn(1, H*W, dim).to(device)


    relative_pos_index, relative_coords_table = get_relative_position_cpb(
        query_size=to_2tuple(img_size // (2 ** (i + 2))),
        key_size=to_2tuple(img_size // ((2 ** (i + 2))) * 8),
        pretrain_size=to_2tuple(img_size // (2 ** (i + 2))))

    model = Attention(64, to_2tuple(img_size // (2 ** (i + 2))), 4).to(device)
    y = model(x, H, W, relative_pos_index, relative_coords_table)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN：十小大")
    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)