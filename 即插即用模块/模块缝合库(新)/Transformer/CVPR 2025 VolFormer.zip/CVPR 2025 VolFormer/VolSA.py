import torch
import math
import torch.nn as nn
from timm.models.layers import trunc_normal_
from einops import rearrange


class DecayPos1d(nn.Module):
    """
    1D衰减位置编码模块：生成随距离衰减的位置掩码，建模光谱维度的位置依赖
    核心作用：为光谱注意力提供"距离越远权重衰减"的先验，适配高光谱图像的光谱连续性
    输入：slen（光谱维度长度，如高光谱波段数）
    输出：衰减掩码 [num_heads, slen, slen]（每个注意力头的位置衰减权重）
    """

    def __init__(self, embed_dim, num_heads, initial_value, heads_range):
        '''
        参数说明：
            embed_dim: 总特征维度（如64）
            num_heads: 注意力头数（如4）
            initial_value: 初始衰减系数（控制衰减起始强度）
            heads_range: 头间衰减范围（控制不同头的衰减差异）
        '''
        super().__init__()
        # 生成位置编码角度基数（参考RoPE设计，适配光谱维度）
        angle = 1.0 / (10000 ** torch.linspace(0, 1, embed_dim // num_heads // 2))
        angle = angle.unsqueeze(-1).repeat(1, 2).flatten()  # 扩展为适配单头维度的长度

        self.initial_value = initial_value
        self.heads_range = heads_range
        self.num_heads = num_heads

        # 计算每个注意力头的衰减系数：随头索引增加，衰减强度增强
        decay = torch.log(
            1 - 2 ** (-initial_value - heads_range * torch.arange(num_heads, dtype=torch.float) / num_heads)
        )
        # 注册为缓冲区（不参与梯度更新），避免每次前向重新计算
        self.register_buffer('angle', angle)
        self.register_buffer('decay', decay)

    def generate_1d_decay(self, l: int):
        '''
        生成1D衰减掩码：距离越远，衰减系数越小（抑制远距离光谱波段的干扰）
        参数：l - 光谱维度长度（如高光谱波段数）
        返回：衰减掩码 [num_heads, l, l]
        '''
        index = torch.arange(l).to(self.decay)  # 生成0~l-1的索引
        mask = index[:, None] - index[None, :]  # 计算所有位置对的差值（l×l）
        mask = mask.abs()  # 取绝对值，得到位置距离
        # 按注意力头应用衰减系数：[num_heads, 1, 1] × [l, l] → [num_heads, l, l]
        mask = mask * self.decay[:, None, None]
        return mask

    def forward(self, slen):
        '''
        前向传播：生成光谱维度的衰减位置掩码
        参数：slen - 光谱维度长度（如64//4=16，单头光谱维度）
        返回：衰减掩码 [num_heads, slen, slen]
        '''
        mask_c = self.generate_1d_decay(slen)
        retention_rel_pos = mask_c
        return retention_rel_pos


class VolSelfAttention(nn.Module):
    r""" 体积自注意力（VolSA）：融合空间注意力（Spatial-wise）与光谱注意力（Spectral-wise）
    核心创新：
        1. 双路径注意力：空间路径捕捉像素位置关联，光谱路径捕捉波段间依赖；
        2. 光谱位置先验：DecayPos1d提供光谱衰减掩码，适配高光谱图像特性；
        3. 多路径融合：空间、光谱、空间引导光谱特征协同增强，提升高维数据表达能力。
    输入：特征图 [B×num_windows, N, C]（B=批次，num_windows=窗口数，N=窗口内像素数，C=特征维度）
    输出：体积注意力增强后的特征 [B×num_windows, N, C]（与输入维度一致）
    """

    def __init__(self, dim, window_size=(8, 8), num_heads=4, qkv_bias=True, qk_scale=None, attn_drop=0., proj_drop=0.):
        super().__init__()
        self.dim = dim  # 总特征维度（如64）
        self.window_size = window_size  # 空间窗口大小（如8×8，控制空间注意力范围）
        self.num_heads = num_heads  # 注意力头数（如4）
        head_dim = dim // num_heads  # 单头特征维度（如64//4=16）
        self.scale = qk_scale or head_dim ** -0.5  # 空间注意力缩放因子（缓解梯度消失）
        self.temperature = nn.Parameter(torch.ones(num_heads, 1, 1))  # 光谱注意力温度参数（可学习）

        # 1. 空间注意力：相对位置偏置表（捕捉窗口内像素的相对位置关联）
        # 相对位置偏置表大小：(2Wh-1)(2Ww-1) × num_heads（Wh/Ww为窗口高/宽）
        self.relative_position_bias_table = nn.Parameter(
            torch.zeros((2 * window_size[0] - 1) * (2 * window_size[1] - 1), num_heads)
        )
        # 生成窗口内像素的相对位置索引
        coords_h = torch.arange(self.window_size[0])  # 0~Wh-1
        coords_w = torch.arange(self.window_size[1])  # 0~Ww-1
        coords = torch.stack(torch.meshgrid([coords_h, coords_w]))  # [2, Wh, Ww]（坐标网格）
        coords_flatten = torch.flatten(coords, 1)  # [2, Wh×Ww]（展平为2行，每行Wh×Ww个坐标）
        # 计算所有像素对的相对坐标：[2, Wh×Ww, Wh×Ww]
        relative_coords = coords_flatten[:, :, None] - coords_flatten[:, None, :]
        relative_coords = relative_coords.permute(1, 2, 0).contiguous()  # [Wh×Ww, Wh×Ww, 2]
        # 坐标偏移：将负坐标转为非负（便于索引偏置表）
        relative_coords[:, :, 0] += self.window_size[0] - 1
        relative_coords[:, :, 1] += self.window_size[1] - 1
        # 计算相对位置索引（将2D坐标转为1D索引，用于查询偏置表）
        relative_coords[:, :, 0] *= 2 * self.window_size[1] - 1
        relative_position_index = relative_coords.sum(-1)  # [Wh×Ww, Wh×Ww]
        self.register_buffer("relative_position_index", relative_position_index)

        # 2. 空间注意力投影层（线性层实现，适配序列格式输入）
        self.qkv = nn.Linear(dim, dim * 3, bias=qkv_bias)  # 一次性生成Q/K/V
        self.attn_drop = nn.Dropout(attn_drop)  # 注意力权重 dropout
        self.proj = nn.Linear(dim, dim)  # 空间注意力输出投影
        self.proj_drop = nn.Dropout(proj_drop)  # 输出 dropout

        # 3. 光谱位置先验模块（DecayPos1d）：建模光谱维度的衰减依赖
        self.realPos = DecayPos1d(64, num_heads, 2, 4)  # 适配总特征64，4个头，初始衰减2，范围4

        # 4. 光谱注意力投影层（卷积层实现，适配2D特征格式）
        self.qkv_C = nn.Conv2d(dim, dim * 3, kernel_size=1, bias=False)  # 1×1卷积生成Q/K/V
        # 深度可分离卷积：增强光谱特征的局部关联性（groups=dim×3确保通道独立卷积）
        self.qkv_dwconv_C = nn.Conv2d(dim * 3, dim * 3, kernel_size=3, stride=1,
                                      padding=1, groups=dim * 3, bias=False)
        self.proj_C = nn.Conv2d(dim, dim, kernel_size=1)  # 光谱注意力输出投影

        # 5. 参数初始化：相对位置偏置表用截断正态分布初始化
        trunc_normal_(self.relative_position_bias_table, std=.02)
        self.softmax = nn.Softmax(dim=-1)  # 注意力权重归一化

        # 6. 空间引导光谱注意力（Gao_spatial_attention）：用空间注意力权重引导光谱特征
        self.Gao_spatial_attention = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),  # 全局平均池化：[B, num_heads, H, W]→[B, num_heads, 1, 1]
            nn.Conv2d(num_heads, 32, 3, 1, 1),  # 3×3卷积增强特征
            nn.BatchNorm2d(32),  # BN稳定训练
            nn.Conv2d(32, 64, 3, 1, 1),  # 3×3卷积升维至64（适配光谱特征通道）
        )

        # 7. 光谱通道注意力（Gao_channel_attention）：筛选光谱维度关键通道
        self.Gao_channel_attention = nn.Sequential(
            nn.Conv2d(dim // num_heads, 8, 3, 1, 1),  # 3×3卷积压缩通道（单头维度→8）
            nn.BatchNorm2d(8),  # BN稳定训练
            nn.GELU(),  # GELU激活增强非线性
            nn.Conv2d(8, 1, 3, 1, 1),  # 3×3卷积恢复为1通道（通道权重）
        )

    def forward(self, x, mask=None):
        """
        前向传播流程：空间注意力路径 → 光谱注意力路径 → 空间引导光谱融合 → 多路径输出
        Args:
            x: 输入特征 [B×num_windows, N, C]（B=批次，num_windows=窗口数，N=Wh×Ww，C=特征维度）
            mask: 窗口掩码 [num_windows, N, N]（可选，用于遮挡无效窗口区域）
        """
        B_, N, C = x.shape  # 解析输入维度：B_=B×num_windows，N=Wh×Ww，C=dim
        bs, hw, c = x.size()  # 冗余解析（与B_, N, C一致）
        hh = int(math.sqrt(hw))  # 窗口高度/宽度（如Wh=Ww=8，hh=8）

        # -------------------------- 1. 空间注意力路径（Spatial-wise Projection）--------------------------
        # 生成Q/K/V：[B_, N, 3C] → [3, B_, num_heads, N, head_dim] → 拆分Q/K/V
        qkv = self.qkv(x).reshape(B_, N, 3, self.num_heads, C // self.num_heads).permute(2, 0, 3, 1, 4)
        q, k, v = qkv[0], qkv[1], qkv[2]  # Q/K/V: [B_, num_heads, N, head_dim]

        # 计算空间注意力权重：Q@K^T → 缩放 → 加相对位置偏置 → 掩码（可选）→ Softmax → Dropout
        q = q * self.scale  # 缩放Q，缓解梯度消失
        attn = (q @ k.transpose(-2, -1))  # [B_, num_heads, N, N]（空间注意力矩阵）

        # 加入相对位置偏置：查询偏置表 → 调整维度 → 广播至批次
        relative_position_bias = self.relative_position_bias_table[self.relative_position_index.view(-1)].view(
            self.window_size[0] * self.window_size[1], self.window_size[0] * self.window_size[1], -1
        )  # [N, N, num_heads]
        relative_position_bias = relative_position_bias.permute(2, 0, 1).contiguous()  # [num_heads, N, N]
        attn = attn + relative_position_bias.unsqueeze(0)  # [B_, num_heads, N, N]

        # 应用窗口掩码（如遮挡图像边缘的无效窗口）
        if mask is not None:
            nW = mask.shape[0]  # 窗口数
            attn = attn.view(B_ // nW, nW, self.num_heads, N, N) + mask.unsqueeze(1).unsqueeze(0)
            attn = attn.view(-1, self.num_heads, N, N)
            attn = self.softmax(attn)
        else:
            attn = self.softmax(attn)

        attn = self.attn_drop(attn)  # 注意力权重 dropout

        # 空间注意力输出：attn@V → 重组维度 → 投影 → Dropout
        x1 = (attn @ v).transpose(1, 2).reshape(B_, N, C)  # [B_, N, C]
        x1 = self.proj(x1)  # 线性投影增强特征
        x1 = self.proj_drop(x1)  # 输出 dropout

        # -------------------------- 2. 光谱注意力路径（Spectral-wise Projection）--------------------------
        # 光谱位置先验：生成衰减掩码 [num_heads, C//num_heads, C//num_heads]（单头光谱维度）
        realPos = self.realPos(c / self.num_heads)

        # 维度重排：[B_, N, C] → [B_, C, hh, hh]（适配卷积输入格式）
        x_s = rearrange(x, 'b (h w) c -> b c h w ', h=hh, w=hh)

        # 生成光谱Q/K/V：1×1卷积 → 深度可分离卷积 → 拆分Q/K/V
        qkv_c = self.qkv_dwconv_C(self.qkv_C(x_s))  # [B_, 3C, hh, hh]
        q_c, k_c, v_c = qkv_c.chunk(3, dim=1)  # 按通道拆分：各[B_, C, hh, hh]

        # 维度重排：适配光谱注意力计算（将通道维度作为光谱维度）
        # [B_, C, hh, hh] → [B_, num_heads, head_dim, N]（N=hh×hh，光谱维度=head_dim）
        q_c = rearrange(q_c, 'b (head c) h w -> b head c (h w)', head=self.num_heads)
        k_c = rearrange(k_c, 'b (head c) h w -> b head c (h w)', head=self.num_heads)
        v_c = rearrange(v_c, 'b (head c) h w -> b head c (h w)', head=self.num_heads)

        # 光谱注意力计算：归一化Q/K → Q@K^T → 加光谱位置先验 → Softmax
        q_c = torch.nn.functional.normalize(q_c, dim=-1)  # 光谱维度归一化
        k_c = torch.nn.functional.normalize(k_c, dim=-1)
        # 计算光谱注意力权重：[B_, num_heads, head_dim, head_dim]
        attn_c = (q_c @ k_c.transpose(-2, -1)) * self.temperature + realPos
        attn_c = attn_c.softmax(dim=-1)  # 归一化光谱权重

        # 光谱注意力输出：attn_c@V → 重组维度 → 卷积投影 → 重排回序列格式
        x2 = (attn_c @ v_c)  # [B_, num_heads, head_dim, N]
        # 重排为2D特征：[B_, num_heads×head_dim, hh, hh] = [B_, C, hh, hh]
        x2 = rearrange(x2, 'b head c (h w) -> b (head c) h w', head=self.num_heads, h=hh, w=hh)
        x2 = self.proj_C(x2)  # 1×1卷积投影增强
        x2 = rearrange(x2, 'b c h w -> b (h w) c', h=hh, w=hh)  # [B_, N, C]（回序列格式）

        # -------------------------- 3. 空间引导光谱融合（VolAtt）--------------------------
        # 空间注意力权重处理：[B_, num_heads, N, N] → 全局池化 → 重排为引导权重
        attn_spatial = attn  # 空间注意力权重矩阵
        attn_spatial = self.Gao_spatial_attention(attn_spatial)  # [B_, 64, 1, 1]
        attn_b, _, _, _ = attn_spatial.shape
        # 重排为引导权重：[B_, N, 1]（每个像素位置对应一个引导系数）
        attn_spatial = attn_spatial.reshape(attn_b, hh * hh, 1)

        # 空间引导光谱特征：光谱特征 × 空间引导权重
        x4 = attn_spatial * x2  # [B_, N, C]

        # -------------------------- 4. 多路径融合输出 --------------------------
        x5 = x1 + x2 + x4  # 空间特征 + 光谱特征 + 空间引导光谱特征
        return x5

    def extra_repr(self) -> str:
        """模块额外信息打印（print(model)时显示）"""
        return f'dim={self.dim}, window_size={self.window_size}, num_heads={self.num_heads}'

if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    # b,n,c
    x = torch.randn(1, 8*8, 64).to(device)
    model = VolSelfAttention(64)

    model.to(device)
    model.eval()
    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("知乎、CSDN：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)
