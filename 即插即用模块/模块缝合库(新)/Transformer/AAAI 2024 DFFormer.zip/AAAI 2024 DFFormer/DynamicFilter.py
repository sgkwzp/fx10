import torch
import torch.nn as nn
from timm.models.layers import to_2tuple

def resize_complex_weight(origin_weight, new_h, new_w):
    """
    调整复数滤波器权重的空间尺寸（适配输入特征图大小变化）
    Args:
        origin_weight: 原始复数权重 [h, w, num_heads, 2]（最后一维存实部/虚部）
        new_h: 目标高度
        new_w: 目标宽度
    Returns:
        调整后复数权重 [new_h, new_w, num_heads, 2]
    """
    h, w, num_heads = origin_weight.shape[0:3]  # size, w, c, 2
    origin_weight = origin_weight.reshape(1, h, w, num_heads * 2).permute(0, 3, 1, 2)
    # 双三次插值调整尺寸
    new_weight = torch.nn.functional.interpolate(
        origin_weight,
        size=(new_h, new_w),
        mode='bicubic',
        align_corners=True
    ).permute(0, 2, 3, 1).reshape(new_h, new_w, num_heads, 2)
    return new_weight


class StarReLU(nn.Module):
    """
    StarReLU: s * relu(x) ** 2 + b
    """

    def __init__(self, scale_value=1.0, bias_value=0.0,
                 scale_learnable=True, bias_learnable=True,
                 mode=None, inplace=False):
        super().__init__()
        self.inplace = inplace
        self.relu = nn.ReLU(inplace=inplace)
        self.scale = nn.Parameter(scale_value * torch.ones(1),
                                  requires_grad=scale_learnable)
        self.bias = nn.Parameter(bias_value * torch.ones(1),
                                 requires_grad=bias_learnable)

    def forward(self, x):
        return self.scale * self.relu(x) ** 2 + self.bias


class Mlp(nn.Module):
    """ MLP as used in MetaFormer models, eg Transformer, MLP-Mixer, PoolFormer, MetaFormer baslines and related networks.
    Mostly copied from timm.
    """

    def __init__(self, dim, mlp_ratio=4, out_features=None, act_layer=StarReLU, drop=0.,
                 bias=False, **kwargs):
        super().__init__()
        in_features = dim
        out_features = out_features or in_features
        hidden_features = int(mlp_ratio * in_features)
        drop_probs = to_2tuple(drop)

        self.fc1 = nn.Linear(in_features, hidden_features, bias=bias)
        self.act = act_layer()
        self.drop1 = nn.Dropout(drop_probs[0])
        self.fc2 = nn.Linear(hidden_features, out_features, bias=bias)
        self.drop2 = nn.Dropout(drop_probs[1])

    def forward(self, x):
        x = self.fc1(x)
        x = self.act(x)
        x = self.drop1(x)
        x = self.fc2(x)
        x = self.drop2(x)
        return x


class DynamicFilter(nn.Module):
    """
    核心动态滤波器模块（DF）：通过输入特征自适应生成复数滤波器，在频域进行特征调制
    Args:
        dim: 输入/输出特征通道数
        expansion_ratio: 中间特征通道放大比例（pwconv1升维用）
        reweight_expansion_ratio: 权重生成MLP的隐藏层放大比例
        act1_layer: 第一层激活函数类型
        act2_layer: 第二层激活函数类型（默认恒等映射）
        bias: 全连接层是否带偏置
        num_filters: 基础滤波器数量（用于动态加权组合）
        size: 初始滤波器尺寸（(H, W)，W//2+1对应rfft2的频域尺寸）
        weight_resize: 是否根据输入特征图尺寸调整滤波器大小
    """
    def __init__(self, dim, expansion_ratio=2, reweight_expansion_ratio=.25,
                 act1_layer=StarReLU, act2_layer=nn.Identity,
                 bias=False, num_filters=4, size=14, weight_resize=False,
                 **kwargs):
        super().__init__()
        size = to_2tuple(size)
        self.size = size[0]  # 空间维度H
        self.filter_size = size[1] // 2 + 1  # 频域维度W（rfft2后尺寸）
        self.num_filters = num_filters  # 基础滤波器数量
        self.dim = dim  # 输入通道数
        self.med_channels = int(expansion_ratio * dim)  # 中间通道数
        self.weight_resize = weight_resize  # 是否动态调整滤波器尺寸

        self.pwconv1 = nn.Linear(dim, self.med_channels, bias=bias)  # 逐点卷积（升维）
        self.act1 = act1_layer()  # 升维后激活
        # 权重生成MLP：输入全局特征均值，输出num_filters个滤波器的权重
        self.reweight = Mlp(dim, reweight_expansion_ratio, num_filters * self.med_channels)
        # 初始化复数滤波器参数 [H, W_freq, num_filters, 2]（2=实部+虚部）
        self.complex_weights = nn.Parameter(
            torch.randn(self.size, self.filter_size, num_filters, 2,
                        dtype=torch.float32) * 0.02)
        self.act2 = act2_layer()  # 频域调制后激活
        self.pwconv2 = nn.Linear(self.med_channels, dim, bias=bias)  # 逐点卷积（降维）

    def forward(self, x):
        """
        前向传播流程：输入特征 → 全局权重生成 → 升维激活 → 频域转换 → 动态滤波 → 时域恢复 → 降维输出
        Args:
            x: 输入特征 [B, H, W, C]（批次、高度、宽度、通道）
        Returns:
            滤波后特征 [B, H, W, C]
        """
        B, H, W, _ = x.shape  # 获取输入尺寸

        # 1. 生成动态权重：全局均值特征 → MLP → 归一化权重（对num_filters维度softmax）
        routeing = self.reweight(x.mean(dim=(1, 2))).view(B, self.num_filters, -1).softmax(dim=1)

        # 2. 特征升维与激活
        x = self.pwconv1(x)  # [B, H, W, C] → [B, H, W, med_channels]
        x = self.act1(x)
        x = x.to(torch.float32)  # 确保精度适配fft

        # 3. 时域→频域转换（2D实值快速傅里叶变换）
        x = torch.fft.rfft2(x, dim=(1, 2), norm='ortho')  # [B, H, W_freq, med_channels]

        # 4. 生成动态复数滤波器（基础滤波器加权组合 + 可选尺寸调整）
        if self.weight_resize:
            # 调整滤波器尺寸以匹配输入特征的频域大小
            complex_weights = resize_complex_weight(self.complex_weights, x.shape[1], x.shape[2])
            complex_weights = torch.view_as_complex(complex_weights.contiguous())  # 转为复数张量 [H, W_freq, num_filters, med_channels]
        else:
            complex_weights = torch.view_as_complex(self.complex_weights)  # 直接使用初始尺寸

        # 5. 动态加权组合基础滤波器：routeing [B, num_filters, med_channels] × complex_weights [H, W_freq, num_filters, med_channels]
        routeing = routeing.to(torch.complex64)  # 转为复数类型
        weight = torch.einsum('bfc,hwf->bhwc', routeing, complex_weights)  # 爱因斯坦求和：按滤波器维度加权组合
        # 调整权重维度以匹配输入特征
        if self.weight_resize:
            weight = weight.view(-1, x.shape[1], x.shape[2], self.med_channels)
        else:
            weight = weight.view(-1, self.size, self.filter_size, self.med_channels)

        # 6. 频域特征调制（元素-wise乘法）
        x = x * weight  # [B, H, W_freq, med_channels] × [B, H, W_freq, med_channels]

        # 7. 频域→时域恢复（逆2D实值快速傅里叶变换）
        x = torch.fft.irfft2(x, s=(H, W), dim=(1, 2), norm='ortho')  # 恢复原始空间尺寸 [B, H, W, med_channels]

        # 8. 激活与降维
        x = self.act2(x)
        x = self.pwconv2(x)  # [B, H, W, med_channels] → [B, H, W, C]

        return x


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 32, 32, 64).to(device)
    model = DynamicFilter(64, weight_resize=True).to(device)

    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN、小红书：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)