import torch
import torch.nn as nn

class Mul(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, q, k):
        return q @ k


class LinearAttention(nn.Module):
    """
    ReLU激活线性注意力模块（ReLULA）：基于线性注意力框架，引入ReLU激活与可学习温度系数
    核心创新（与传统LA的区别）：
        1. Q/K双ReLU激活：增强特征非线性与判别性，抑制噪声；
        2. 可学习温度系数：适配不同任务的注意力权重缩放需求；
        3. 模块化矩阵乘法：提升代码复用性与扩展性；
        4. 数值稳定归一化：clamp函数避免分母过小导致的数值溢出。
    输入：特征序列 [B, N, C]（B=批次，N=序列长度=H×W，C=通道数）
    输出：
        x: 注意力增强特征 [B, N, C]（与输入维度一致）
        attn1: 未归一化注意力中间结果（用于调试/可视化）
    """

    def __init__(self, dim, num_heads=8, qkv_bias=False, qk_scale=None, att_act=nn.ReLU, attn_drop=0., proj_drop=0.):
        """
        参数初始化：
            dim: 输入/输出通道数（需能被num_heads整除）
            num_heads: 注意力头数（默认8）
            qkv_bias: QKV投影层是否添加偏置（默认False）
            qk_scale: 手动指定的缩放因子（默认None，自动计算为head_dim^-0.5）
            att_act: 注意力激活函数（默认nn.ReLU，核心激活组件）
            attn_drop: 注意力权重Dropout概率（默认0.）
            proj_drop: 输出投影Dropout概率（默认0.）
        """
        super().__init__()
        self.num_heads = num_heads  # 注意力头数
        head_dim = dim // num_heads  # 单头通道数
        # 缩放因子：手动指定或自动计算（head_dim^-0.5）
        self.scale = qk_scale or head_dim ** -0.5
        # 可学习温度系数：按注意力头独立设置，适配不同头的特征分布
        self.temperature = nn.Parameter(torch.ones(num_heads, 1, 1) * self.scale)

        # QKV投影层：一次性生成Q、K、V（通道数=3×dim）
        self.qkv = nn.Linear(dim, dim * 3, bias=qkv_bias)
        self.attn_drop = nn.Dropout(attn_drop)  # 注意力Dropout（正则化）
        self.proj = nn.Linear(dim, dim)  # 输出投影层（恢复通道数）
        self.proj_drop = nn.Dropout(proj_drop)  # 输出Dropout（正则化）

        # 矩阵乘法模块（模块化封装）
        self.qk_mul = Mul()  # 用于Q×K^T
        self.kv_mul = Mul()  # 用于K^T×V
        self.extra_mul = Mul()  # 用于Q×(K^T×V)

        self.act = att_act()  # 注意力激活函数（默认ReLU）

    def forward(self, x):
        """
        前向传播流程：QKV生成→ReLU激活→矩阵乘法→温度系数缩放→数值稳定归一化→输出投影
        """
        B, N, C = x.shape  # 解析输入维度：批次、序列长度、通道数

        # 步骤1：QKV生成与维度重排
        # QKV投影：[B, N, C]→[B, N, 3C]→拆分并重排为[3, B, num_heads, N, head_dim]
        qkv = self.qkv(x).reshape(B, N, 3, self.num_heads, C // self.num_heads).permute(2, 0, 3, 1, 4)
        q, k, v = qkv[0], qkv[1], qkv[2]  # 拆分Q/K/V：各[B, num_heads, N, head_dim]

        # 步骤2：Q/K ReLU激活（核心创新1）：增强非线性，抑制噪声特征
        q = self.act(q)
        k = self.act(k)

        # 步骤3：计算归一化分母（数值稳定版）
        # K^T求和→Q×K^T_sum→clamp限制最小值（避免分母过小导致溢出）
        denom = torch.clamp(
            self.qk_mul(q, k.transpose(-2, -1).sum(dim=-1, keepdim=True)),
            min=1e2  # 限制分母最小为100，确保数值稳定
        )

        # 步骤4：线性注意力核心计算
        # K^T×V→温度系数缩放（核心创新2：可学习温度系数）→Q×(K^T×V)
        attn = self.kv_mul(k.transpose(-2, -1), v)  # [B, num_heads, head_dim, N]
        attn = attn * self.temperature  # 可学习温度系数缩放
        attn1 = self.extra_mul(q, attn)  # [B, num_heads, N, N]（未归一化中间结果）

        # 步骤5：归一化（数值稳定）
        attn = attn1.clone() / denom.clone()  # 避免原位操作影响梯度

        # 步骤6：维度恢复+输出投影
        # 多头注意力合并→[B, N, C]→投影→Dropout
        x = attn.transpose(1, 2).reshape(B, N, C)
        x = self.proj(x)
        x = self.proj_drop(x)

        return x, attn1

if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 32*32, 64).to(device)
    model = LinearAttention(64, 4).to(device)

    model.to(device)
    y, _ = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("知乎、CSDN：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)