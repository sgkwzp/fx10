import torch
from torch import nn
from einops import rearrange
from functools import partial
from timm.models.layers import DropPath

NORM_EPS = 1e-5  # BatchNormepsilon值，稳定数值计算


def merge_pre_bn(module, pre_bn_1, pre_bn_2=None):
    """
    BN融合优化：将前置BN层参数融合到后续线性/卷积层，减少推理延迟
    核心作用：推理阶段消除冗余BN层，提升运行速度，不改变模型精度
    输入：
        module: 待融合的线性/卷积层
        pre_bn_1: 第一个前置BN层
        pre_bn_2: 第二个前置BN层（可选，用于多级BN融合）
    """
    weight = module.weight.data
    # 为无偏置层添加偏置参数（适配融合逻辑）
    if module.bias is None:
        zeros = torch.zeros(module.out_channels, device=weight.device).type(weight.type())
        module.bias = nn.Parameter(zeros)
    bias = module.bias.data

    # 单BN融合（pre_bn_2=None）
    if pre_bn_2 is None:
        assert pre_bn_1.track_running_stats and pre_bn_1.affine, "仅支持track_running_stats=True且affine=True的BN层"
        scale_invstd = pre_bn_1.running_var.add(pre_bn_1.eps).pow(-0.5)
        extra_weight = scale_invstd * pre_bn_1.weight
        extra_bias = pre_bn_2.bias - pre_bn_1.weight * pre_bn_1.running_mean * scale_invstd
    # 双BN融合（pre_bn_2存在）
    else:
        assert pre_bn_1.track_running_stats and pre_bn_1.affine and pre_bn_2.track_running_stats and pre_bn_2.affine
        scale_invstd_1 = pre_bn_1.running_var.add(pre_bn_1.eps).pow(-0.5)
        scale_invstd_2 = pre_bn_2.running_var.add(pre_bn_2.eps).pow(-0.5)
        extra_weight = scale_invstd_1 * pre_bn_1.weight * scale_invstd_2 * pre_bn_2.weight
        extra_bias = scale_invstd_2 * pre_bn_2.weight * (
                    pre_bn_1.bias - pre_bn_1.weight * pre_bn_1.running_mean * scale_invstd_1 - pre_bn_2.running_mean) + pre_bn_2.bias

    # 线性层融合
    if isinstance(module, nn.Linear):
        extra_bias = weight @ extra_bias
        weight.mul_(extra_weight.view(1, weight.size(1)).expand_as(weight))
    # 1×1卷积层融合
    elif isinstance(module, nn.Conv2d):
        assert weight.shape[2] == 1 and weight.shape[3] == 1, "仅支持1×1卷积融合"
        weight = weight.reshape(weight.shape[0], weight.shape[1])
        extra_bias = weight @ extra_bias
        weight.mul_(extra_weight.view(1, weight.size(1)).expand_as(weight))
        weight = weight.reshape(weight.shape[0], weight.shape[1], 1, 1)

    # 更新层参数
    bias.add_(extra_bias)
    module.weight.data = weight
    module.bias.data = bias


def _make_divisible(v, divisor, min_value=None):
    """
    通道数调整：确保通道数为divisor的整数倍，适配分组卷积/注意力头数
    输入：
        v: 原始通道数
        divisor: 除数（如32）
        min_value: 最小通道数（默认=divisor）
    返回：
        调整后的通道数（满足divisor整除，且不低于min_value）
    """
    if min_value is None:
        min_value = divisor
    new_v = max(min_value, int(v + divisor / 2) // divisor * divisor)
    if new_v < 0.9 * v:  # 确保调整后通道数不低于原90%
        new_v += divisor
    return new_v


class PatchEmbed(nn.Module):
    """
    补丁嵌入模块：实现特征降采样/通道调整/归一化，适配Transformer输入
    核心作用：
        1. 步长=2时，平均池化降采样+1×1卷积调整通道；
        2. 通道不匹配时，1×1卷积调整通道；
        3. 通道匹配时，直接恒等映射。
    """

    def __init__(self, in_channels, out_channels, stride=1):
        super().__init__()
        norm_layer = partial(nn.BatchNorm2d, eps=NORM_EPS)
        if stride == 2:
            self.avgpool = nn.AvgPool2d((2, 2), stride=2, ceil_mode=True, count_include_pad=False)
            self.conv = nn.Conv2d(in_channels, out_channels, kernel_size=1, stride=1, bias=False)
            self.norm = norm_layer(out_channels)
        elif in_channels != out_channels:
            self.avgpool = nn.Identity()
            self.conv = nn.Conv2d(in_channels, out_channels, kernel_size=1, stride=1, bias=False)
            self.norm = norm_layer(out_channels)
        else:
            self.avgpool = nn.Identity()
            self.conv = nn.Identity()
            self.norm = nn.Identity()

    def forward(self, x):
        return self.norm(self.conv(self.avgpool(x)))


class MHCA(nn.Module):
    """
    多头卷积注意力（MHCA）：基于分组卷积的轻量化局部注意力
    核心作用：通过分组3×3卷积捕捉局部关联，替代传统自注意力的局部计算
    """

    def __init__(self, out_channels, head_dim):
        super().__init__()
        norm_layer = partial(nn.BatchNorm2d, eps=NORM_EPS)
        # 分组卷积（组数=out_channels//head_dim），模拟多头局部注意力
        self.group_conv3x3 = nn.Conv2d(
            out_channels, out_channels, kernel_size=3, stride=1,
            padding=1, groups=out_channels // head_dim, bias=False
        )
        self.norm = norm_layer(out_channels)  # 归一化
        self.act = nn.ReLU(inplace=True)  # 激活
        self.projection = nn.Conv2d(out_channels, out_channels, kernel_size=1, bias=False)  # 输出投影

    def forward(self, x):
        out = self.group_conv3x3(x)
        out = self.norm(out)
        out = self.act(out)
        out = self.projection(out)
        return out


class Mlp(nn.Module):
    """
    多层感知机（MLP）：用于NTB的前馈网络，1×1卷积实现通道扩展与压缩
    """

    def __init__(self, in_features, out_features=None, mlp_ratio=None, drop=0., bias=True):
        super().__init__()
        out_features = out_features or in_features
        hidden_dim = _make_divisible(in_features * mlp_ratio, 32)  # 中间通道数（32的整数倍）
        self.conv1 = nn.Conv2d(in_features, hidden_dim, kernel_size=1, bias=bias)  # 升维
        self.act = nn.ReLU(inplace=True)  # 激活
        self.conv2 = nn.Conv2d(hidden_dim, out_features, kernel_size=1, bias=bias)  # 降维
        self.drop = nn.Dropout(drop)  # Dropout正则化

    def merge_bn(self, pre_norm):
        """融合前置BN层，优化推理速度"""
        merge_pre_bn(self.conv1, pre_norm)

    def forward(self, x):
        x = self.conv1(x)
        x = self.act(x)
        x = self.drop(x)
        x = self.conv2(x)
        x = self.drop(x)
        return x


class E_MHSA(nn.Module):
    """
    高效多头自注意力（E_MHSA）：带降采样的轻量化自注意力
    核心创新：sr_ratio>1时对K/V降采样，降低计算量，适配高分辨率特征
    """

    def __init__(self, dim, out_dim=None, head_dim=32, qkv_bias=True, qk_scale=None,
                 attn_drop=0, proj_drop=0., sr_ratio=1):
        super().__init__()
        self.dim = dim
        self.out_dim = out_dim if out_dim is not None else dim
        self.num_heads = self.dim // head_dim  # 注意力头数（dim需为head_dim整数倍）
        self.scale = qk_scale or head_dim ** -0.5  # 缩放因子
        # QKV投影层（线性层实现）
        self.q = nn.Linear(dim, self.dim, bias=qkv_bias)
        self.k = nn.Linear(dim, self.dim, bias=qkv_bias)
        self.v = nn.Linear(dim, self.dim, bias=qkv_bias)
        self.proj = nn.Linear(self.dim, self.out_dim)  # 输出投影
        self.attn_drop = nn.Dropout(attn_drop)  # 注意力Dropout
        self.proj_drop = nn.Dropout(proj_drop)  # 输出Dropout
        self.sr_ratio = sr_ratio  # 降采样比例
        self.N_ratio = sr_ratio ** 2  # 降采样后序列长度比例
        # 降采样相关层（sr_ratio>1时启用）
        if sr_ratio > 1:
            self.sr = nn.AvgPool1d(kernel_size=self.N_ratio, stride=self.N_ratio)  # 序列降采样
            self.norm = nn.BatchNorm1d(dim, eps=NORM_EPS)  # 降采样后归一化
        self.is_bn_merge = False  # BN融合标记

    def merge_bn(self, pre_bn):
        """融合前置BN层，优化推理速度"""
        merge_pre_bn(self.q, pre_bn)
        if self.sr_ratio > 1:
            merge_pre_bn(self.k, pre_bn, self.norm)
            merge_pre_bn(self.v, pre_bn, self.norm)
        else:
            merge_pre_bn(self.k, pre_bn)
            merge_pre_bn(self.v, pre_bn)
        self.is_bn_merge = True

    def forward(self, x):
        B, N, C = x.shape  # B=批次，N=序列长度，C=通道数
        # Q生成与多头重排：[B, N, C]→[B, num_heads, N, head_dim]
        q = self.q(x)
        q = q.reshape(B, N, self.num_heads, int(C // self.num_heads)).permute(0, 2, 1, 3)

        # K/V生成（支持降采样）
        if self.sr_ratio > 1:
            x_ = x.transpose(1, 2)  # [B, C, N]
            x_ = self.sr(x_)  # 降采样：[B, C, N//N_ratio]
            if not torch.onnx.is_in_onnx_export() and not self.is_bn_merge:
                x_ = self.norm(x_)
            x_ = x_.transpose(1, 2)  # [B, N//N_ratio, C]
            # K/V多头重排：[B, num_heads, head_dim, N//N_ratio]（K）/ [B, num_heads, N//N_ratio, head_dim]（V）
            k = self.k(x_).reshape(B, -1, self.num_heads, int(C // self.num_heads)).permute(0, 2, 3, 1)
            v = self.v(x_).reshape(B, -1, self.num_heads, int(C // self.num_heads)).permute(0, 2, 1, 3)
        else:
            # 无降采样：K/V直接生成
            k = self.k(x).reshape(B, -1, self.num_heads, int(C // self.num_heads)).permute(0, 2, 3, 1)
            v = self.v(x).reshape(B, -1, self.num_heads, int(C // self.num_heads)).permute(0, 2, 1, 3)

        # 注意力计算：Q@K^T→Softmax→加权V
        attn = (q @ k) * self.scale
        attn = attn.softmax(dim=-1)
        attn = self.attn_drop(attn)
        x = (attn @ v).transpose(1, 2).reshape(B, N, C)  # 维度恢复
        x = self.proj(x)
        x = self.proj_drop(x)
        return x


class NTB(nn.Module):
    """
    下一代Transformer块（NTB）：融合E-MHSA与MHCA的混合注意力架构
    核心创新：
        1. 混合注意力：E-MHSA捕捉全局关联，MHCA捕捉局部细节，按比例拆分通道；
        2. 高效优化：BN融合+动态路径dropout，兼顾速度与泛化性；
        3. 灵活适配：支持降采样、通道调整，适配多尺度视觉任务；
        4. 即插即用：输入输出维度一致，无缝嵌入现有架构。
    输入：特征图 [B, in_channels, H, W]
    输出：增强后特征 [B, out_channels, H, W]（与输入维度一致）
    """

    def __init__(
            self, in_channels, out_channels, path_dropout, stride=1, sr_ratio=1,
            mlp_ratio=2, head_dim=32, mix_block_ratio=0.75, attn_drop=0, drop=0,
    ):
        super().__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.mix_block_ratio = mix_block_ratio  # E-MHSA通道占比（剩余为MHCA通道）
        norm_func = partial(nn.BatchNorm2d, eps=NORM_EPS)

        # 通道拆分：按mix_block_ratio分配E-MHSA与MHCA的通道数
        self.mhsa_out_channels = _make_divisible(int(out_channels * mix_block_ratio), 32)
        self.mhca_out_channels = out_channels - self.mhsa_out_channels

        # 1. E-MHSA分支（全局注意力）
        self.patch_embed = PatchEmbed(in_channels, self.mhsa_out_channels, stride)  # 通道调整/降采样
        self.norm1 = norm_func(self.mhsa_out_channels)  # E-MHSA前置BN
        self.e_mhsa = E_MHSA(
            self.mhsa_out_channels, head_dim=head_dim, sr_ratio=sr_ratio,
            attn_drop=attn_drop, proj_drop=drop
        )  # 高效多头自注意力
        self.mhsa_path_dropout = DropPath(path_dropout * mix_block_ratio)  # E-MHSA路径dropout

        # 2. MHCA分支（局部注意力）
        self.projection = PatchEmbed(self.mhsa_out_channels, self.mhca_out_channels, stride=1)  # 通道调整
        self.mhca = MHCA(self.mhca_out_channels, head_dim=head_dim)  # 多头卷积注意力
        self.mhca_path_dropout = DropPath(path_dropout * (1 - mix_block_ratio))  # MHCA路径dropout

        # 3. MLP前馈网络
        self.norm2 = norm_func(out_channels)  # MLP前置BN
        self.mlp = Mlp(out_channels, mlp_ratio=mlp_ratio, drop=drop)  # 前馈网络
        self.mlp_path_dropout = DropPath(path_dropout)  # MLP路径dropout

        self.is_bn_merged = False  # BN融合标记

    def merge_bn(self):
        """融合所有前置BN层，优化推理速度（仅推理阶段调用）"""
        if not self.is_bn_merged:
            self.e_mhsa.merge_bn(self.norm1)
            self.mlp.merge_bn(self.norm2)
            self.is_bn_merged = True

    def forward(self, x):
        """
        前向传播流程：E-MHSA全局增强→MHCA局部增强→通道拼接→MLP增强→残差输出
        """
        # 步骤1：E-MHSA分支（全局注意力）
        x = self.patch_embed(x)  # 通道调整/降采样：[B, in_channels, H, W]→[B, mhsa_out_channels, H', W']
        B, C, H, W = x.shape
        # BN层（推理时已融合，跳过）
        if not torch.onnx.is_in_onnx_export() and not self.is_bn_merged:
            out = self.norm1(x)
        else:
            out = x
        # 空间→序列：[B, C, H, W]→[B, H×W, C]
        out = rearrange(out, "b c h w -> b (h w) c")
        # E-MHSA计算+路径dropout
        out = self.mhsa_path_dropout(self.e_mhsa(out))
        # 序列→空间+残差融合
        x = x + rearrange(out, "b (h w) c -> b c h w", h=H)

        # 步骤2：MHCA分支（局部注意力）
        out = self.projection(x)  # 通道调整：[B, mhsa_out_channels, H', W']→[B, mhca_out_channels, H', W']
        # MHCA计算+路径dropout+残差融合
        out = out + self.mhca_path_dropout(self.mhca(out))

        # 步骤3：通道拼接（E-MHSA分支 + MHCA分支）
        x = torch.cat([x, out], dim=1)  # [B, out_channels, H', W']

        # 步骤4：MLP前馈网络
        # BN层（推理时已融合，跳过）
        if not torch.onnx.is_in_onnx_export() and not self.is_bn_merged:
            out = self.norm2(x)
        else:
            out = x
        # MLP计算+路径dropout+残差融合
        x = x + self.mlp_path_dropout(self.mlp(out))

        return x


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    x = torch.randn(1, 128, 32, 32).to(device)

    model = NTB(128, 128, 0.1)
    model.to(device)
    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN：十小大")
    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)