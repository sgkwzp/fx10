# 几何-语义校正注意力模块（Geometric-Semantic Rectification Attention, GSRA）
# 核心设计：针对双模态融合场景（几何特征+语义特征），通过“模态专属差分投影+双KV增强+注意力校正”的架构，
# 将3D几何特征（如点云、深度）与高维语义特征（如DINO预训练特征）投影至统一维度，
# 生成几何增强KV与语义增强KV，结合原始Q实现双模态引导的注意力计算，
# 校正特征的几何结构与语义一致性，强化双模态互补信息，提升特征表达的精准度


import torch
import torch.nn as nn
from einops import rearrange, repeat
import math


def lambda_init_fn(depth):
    return 0.8 - 0.6 * math.exp(-0.3 * depth)


class DifferentialLinearProjection(nn.Module):
    """Modal-specific Differential Linear Projection"""

    def __init__(self, dim, heads=8, dim_head=64, dropout=0., bias=True):
        super().__init__()
        self.head_dim = dim_head
        inner_dim = dim_head * heads
        self.heads = heads

        # Q projection remains unchanged
        self.to_q = nn.Linear(dim, inner_dim, bias=bias)

        # Create KV projections for two modalities respectively
        self.to_kv_geometric = nn.Linear(dim, inner_dim * 2, bias=bias)  # KV for geometric branch
        self.to_kv_semantic = nn.Linear(dim, inner_dim * 2, bias=bias)  # KV for semantic branch

        # Modal feature projection layer - project different dimension features to unified dimension
        self.geo_proj = nn.Linear(3, dim, bias=bias)  # Assuming geometric feature is 3D
        self.dino_proj = nn.Linear(1024, dim, bias=bias)  # Assuming DINO feature is 1024D

        # Learnable fusion weights
        self.geo_weight = nn.Parameter(torch.tensor(0.1))
        self.sem_weight = nn.Parameter(torch.tensor(0.1))

        self.dim = dim
        self.inner_dim = inner_dim
        print("Modal-specific differential transformer initialized!")

    def forward(self, x, geo_feat, dino_feat, attn_kv=None):
        B_, N, C = x.shape
        attn_kv = x if attn_kv is None else attn_kv

        # Q remains as is
        q = self.to_q(x).reshape(B_, N, 1, self.heads, self.head_dim).permute(2, 0, 3, 1, 4)
        q = q[0]  # [B_, heads, N, head_dim]

        # Project modal features to unified dimension
        geo_feat_proj = self.geo_proj(geo_feat)  # [B_, N, dim]
        dino_feat_proj = self.dino_proj(dino_feat)  # [B_, N, dim]

        # Simple feature fusion - weighted sum
        geo_enhanced = attn_kv + self.geo_weight * geo_feat_proj
        semantic_enhanced = attn_kv + self.sem_weight * dino_feat_proj

        # Calculate two sets of KV respectively
        kv_geo = self.to_kv_geometric(geo_enhanced).reshape(B_, N, 2, self.heads, self.head_dim).permute(2, 0, 3, 1, 4)
        kv_sem = self.to_kv_semantic(semantic_enhanced).reshape(B_, N, 2, self.heads, self.head_dim).permute(2, 0, 3, 1,
                                                                                                             4)

        # Combine into final KV
        # kv[0] = Geometric enhanced KV, kv[1] = Semantic enhanced KV
        k = torch.stack([kv_geo[0], kv_sem[0]], dim=0)  # [2, B_, heads, N, head_dim]
        v = torch.stack([kv_geo[1], kv_sem[1]], dim=0)  # [2, B_, heads, N, head_dim]

        return q, k, v


class DifferentialLinearProjection_Concat_kv(nn.Module):
    """Concat version of Modal-specific Differential Linear Projection"""

    def __init__(self, dim, heads=8, dim_head=64, dropout=0., bias=True):
        super().__init__()
        self.head_dim = dim_head
        inner_dim = dim_head * heads
        self.heads = heads

        # Basic QKV projection
        self.to_qkv = nn.Linear(dim, inner_dim * 3, bias=bias)

        # Additional KV projections for two modalities
        self.to_kv_geometric = nn.Linear(dim, inner_dim * 2, bias=bias)
        self.to_kv_semantic = nn.Linear(dim, inner_dim * 2, bias=bias)

        # Modal feature projection layer
        self.geo_proj = nn.Linear(3, dim, bias=bias)
        self.dino_proj = nn.Linear(1024, dim, bias=bias)

        # Learnable fusion weights
        self.geo_weight = nn.Parameter(torch.tensor(0.1))
        self.sem_weight = nn.Parameter(torch.tensor(0.1))

        self.dim = dim
        self.inner_dim = inner_dim

    def forward(self, x, geo_feat, dino_feat, attn_kv=None):
        B_, N, C = x.shape
        attn_kv = x if attn_kv is None else attn_kv

        # Basic QKV
        qkv_dec = self.to_qkv(x).reshape(B_, N, 3, self.heads, self.head_dim).permute(2, 0, 3, 1, 4)
        q, k_d, v_d = qkv_dec[0], qkv_dec[1], qkv_dec[2]

        # Project modal features to unified dimension
        geo_feat_proj = self.geo_proj(geo_feat)
        dino_feat_proj = self.dino_proj(dino_feat)

        # Simple feature fusion
        geo_enhanced = attn_kv + self.geo_weight * geo_feat_proj
        semantic_enhanced = attn_kv + self.sem_weight * dino_feat_proj

        # Calculate two sets of additional KV respectively
        kv_geo = self.to_kv_geometric(geo_enhanced).reshape(B_, N, 2, self.heads, self.head_dim).permute(2, 0, 3, 1, 4)
        kv_sem = self.to_kv_semantic(semantic_enhanced).reshape(B_, N, 2, self.heads, self.head_dim).permute(2, 0, 3, 1,
                                                                                                             4)

        k_geo, v_geo = kv_geo[0], kv_geo[1]
        k_sem, v_sem = kv_sem[0], kv_sem[1]

        # Concat: [Basic KV, Geometric KV, Semantic KV]
        k = torch.cat((k_d, k_geo, k_sem), dim=2)
        v = torch.cat((v_d, v_geo, v_sem), dim=2)

        return q, k, v


class DifferentialWindowAttention(nn.Module):
    """
    几何-语义校正注意力模块（Geometric-Semantic Rectification Attention, GSRA）
    功能：融合双模态增强KV与原始Q，通过注意力计算实现几何-语义校正
    核心设计：
        - 双投影适配：支持基础版/拼接版差分投影，灵活选择融合模式
        - 注意力校正：通过双模态KV引导Q的注意力分配，校正几何结构与语义一致性
        - 可学习融合权重：动态平衡不同模态KV的贡献
        - 残差连接：保留原始特征信息，避免过度校正
    Args:
        dim: 输入/输出通道数
        heads: 注意力头数（默认8）
        dim_head: 每个注意力头的通道数（默认64）
        dropout: dropout概率（默认0.）
        bias: 线性层是否带偏置（默认True）
        proj_type: 投影模块类型（"base"=基础版，"concat"=拼接版，默认"base"）
        depth: 网络层深度（用于lambda系数初始化，默认1）
    """
    def __init__(self, dim, win_size, num_heads, depth=1, token_projection='linear',
                 qkv_bias=True, qk_scale=None, attn_drop=0., proj_drop=0., se_layer=False,
                 geo_dim=3, dino_dim=1024):  # New parameters
        super().__init__()
        self.dim = dim
        self.win_size = win_size
        self.num_heads = num_heads
        self.head_dim = dim // num_heads
        self.scale = qk_scale or self.head_dim ** -0.5

        # Pre-define feature projection layers
        self.geo_dim = geo_dim
        self.dino_dim = dino_dim
        self.geo_adaptive_proj = nn.Linear(geo_dim, 3) if geo_dim != 3 else nn.Identity()
        self.dino_adaptive_proj = nn.Linear(dino_dim, 1024) if dino_dim != 1024 else nn.Identity()

        # Differential parameters
        self.lambda_init = lambda_init_fn(depth)
        self.lambda_q1 = nn.Parameter(torch.ones(1) * 0.5)
        self.lambda_k1 = nn.Parameter(torch.ones(1) * 0.5)
        self.lambda_q2 = nn.Parameter(torch.ones(1) * 0.5)
        self.lambda_k2 = nn.Parameter(torch.ones(1) * 0.5)

        self.subln = nn.LayerNorm(dim)

        # Use modal-specific projection layers
        if token_projection == 'linear_concat':
            self.qkv = DifferentialLinearProjection_Concat_kv(dim, num_heads, dim // num_heads, bias=qkv_bias)
        else:
            self.qkv = DifferentialLinearProjection(dim, num_heads, dim // num_heads, bias=qkv_bias)

        # Relative position encoding
        self.relative_position_bias_table = nn.Parameter(
            torch.zeros((2 * win_size[0] - 1) * (2 * win_size[1] - 1), num_heads))

        coords_h = torch.arange(self.win_size[0])
        coords_w = torch.arange(self.win_size[1])
        coords = torch.stack(torch.meshgrid([coords_h, coords_w], indexing='ij'))
        coords_flatten = torch.flatten(coords, 1)
        relative_coords = coords_flatten[:, :, None] - coords_flatten[:, None, :]
        relative_coords = relative_coords.permute(1, 2, 0).contiguous()
        relative_coords[:, :, 0] += self.win_size[0] - 1
        relative_coords[:, :, 1] += self.win_size[1] - 1
        relative_coords[:, :, 0] *= 2 * self.win_size[1] - 1
        relative_position_index = relative_coords.sum(-1)
        self.register_buffer("relative_position_index", relative_position_index)

        self.token_projection = token_projection
        self.attn_drop = nn.Dropout(attn_drop)
        self.proj = nn.Linear(dim, dim)
        self.proj_drop = nn.Dropout(proj_drop)

        nn.init.trunc_normal_(self.relative_position_bias_table, std=.02)
        self.softmax = nn.Softmax(dim=-1)

    def forward(self, x, dino_mat, point_feature, attn_kv=None, mask=None):
        B_, N, C = x.shape

        # Prepare modal features
        dino_mat = self.dino_adaptive_proj(dino_mat)
        point_feature = self.geo_adaptive_proj(point_feature)

        geo_feat = point_feature
        dino_feat = dino_mat

        # QKV projection
        q, k, v = self.qkv(x, geo_feat, dino_feat, attn_kv)
        q = q * self.scale

        # k, v format: [2, B_, heads, N, head_dim]
        k_geo, k_sem = k[0], k[1]  # K for geometry and semantics
        v_geo, v_sem = v[0], v[1]  # V for geometry and semantics

        # All heads calculate both attentions
        attn_geo = torch.matmul(q, k_geo.transpose(-2, -1))  # [B_, heads, N, N]
        attn_sem = torch.matmul(q, k_sem.transpose(-2, -1))  # [B_, heads, N, N]

        # Add relative position bias
        relative_position_bias = self.relative_position_bias_table[
            self.relative_position_index.view(-1)
        ].view(self.win_size[0] * self.win_size[1], self.win_size[0] * self.win_size[1], -1)
        relative_position_bias = relative_position_bias.permute(2, 0, 1).contiguous()

        ratio = attn_geo.size(-1) // relative_position_bias.size(-1)
        if ratio > 1:
            relative_position_bias = repeat(relative_position_bias, 'nH l c -> nH l (c d)', d=ratio)

        attn_geo = attn_geo + relative_position_bias.unsqueeze(0)
        attn_sem = attn_sem + relative_position_bias.unsqueeze(0)

        # Handle mask
        if mask is not None:
            nW = mask.shape[0]
            mask = repeat(mask, 'nW m n -> nW m (n d)', d=ratio)
            attn_geo = attn_geo.view(B_ // nW, nW, self.num_heads, N, N * ratio) + mask.unsqueeze(1).unsqueeze(0)
            attn_sem = attn_sem.view(B_ // nW, nW, self.num_heads, N, N * ratio) + mask.unsqueeze(1).unsqueeze(0)
            attn_geo = attn_geo.view(-1, self.num_heads, N, N * ratio)
            attn_sem = attn_sem.view(-1, self.num_heads, N, N * ratio)

        # Softmax
        attn_geo = self.softmax(attn_geo)
        attn_sem = self.softmax(attn_sem)

        # Differential Attention: Subtract geometry from semantics
        lambda_val = torch.sigmoid(self.lambda_q1 * self.lambda_k1) + self.lambda_init
        attn_diff = attn_sem - lambda_val * attn_geo

        # Apply attention
        attn_geo = self.attn_drop(attn_geo)
        attn_diff = self.attn_drop(attn_diff)

        # Outputs of two branches
        x_geo = torch.matmul(attn_geo, v_geo)  # Geometric branch
        x_diff = torch.matmul(attn_diff, v_sem)  # Difference branch

        # Weighted fusion
        x = x_geo + x_diff  # Or use learnable weights
        x = x.transpose(1, 2).contiguous().view(B_, N, C)
        x = self.subln(x)
        x = x * (1 - self.lambda_init)
        x = self.proj(x)
        x = self.proj_drop(x)

        return x

    def extra_repr(self) -> str:
        return f'dim={self.dim}, win_size={self.win_size}, num_heads={self.num_heads}, ' \
               f'head_dim={self.head_dim}, lambda_init={self.lambda_init:.3f}'


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    input = torch.randn(1, 8*8, 64).to(device)
    sem = torch.randn(1, 8*8, 1024).to(device)
    geo = torch.randn(1, 8*8, 3).to(device)
    model = DifferentialWindowAttention(64, (8, 8), 8).to(device)

    output = model(input, sem, geo)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("小红书：十小大，主页获取往期全部即插即用代码，200+大合集")

    print("输入局部特征维度：", input.shape)
    print("输入全局特征维度：", output.shape)
