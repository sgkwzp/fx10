import torch
import torch.nn as nn


class RoPE(torch.nn.Module):
    r"""
    旋转位置编码（RoPE）：通过旋转操作注入位置信息，增强特征的位置敏感性
    核心作用：
        1. 位置编码与特征内容解耦，支持任意长度序列扩展；
        2. 旋转矩阵随位置和维度动态调整，适配高分辨率特征；
        3. 无额外可学习参数，轻量化设计，不增加推理负担。
    输入：特征张量 [B, H, W, C]（通道最后格式，需与初始化shape匹配）
    输出：注入位置信息的特征 [B, H, W, C]（与输入维度一致）
    """

    def __init__(self, shape, base=10000):
        super(RoPE, self).__init__()
        channel_dims, feature_dim = shape[:-1], shape[-1]  # channel_dims=(H,W)，feature_dim=C
        k_max = feature_dim // (2 * len(channel_dims))  # 计算每个维度的最大频率数
        assert feature_dim % k_max == 0, "特征通道数需能被k_max整除"

        # 步骤1：计算角度系数（theta_ks）
        theta_ks = 1 / (base ** (torch.arange(k_max) / k_max))  # 频率衰减序列

        # 步骤2：生成网格位置的角度矩阵
        # 生成空间位置网格→计算每个位置的角度→拼接为完整角度矩阵
        angles = torch.cat([
            t.unsqueeze(-1) * theta_ks
            for t in torch.meshgrid([torch.arange(d) for d in channel_dims], indexing='ij')
        ], dim=-1)

        # 步骤3：生成旋转矩阵（实部+虚部）
        rotations_re = torch.cos(angles).unsqueeze(dim=-1)  # 旋转矩阵实部
        rotations_im = torch.sin(angles).unsqueeze(dim=-1)  # 旋转矩阵虚部
        rotations = torch.cat([rotations_re, rotations_im], dim=-1)  # 合并为复数旋转矩阵

        self.register_buffer('rotations', rotations)  # 注册为缓冲区，不参与梯度更新

    def forward(self, x):
        # 类型转换：确保输入为float32，避免精度问题
        if x.dtype != torch.float32:
            x = x.to(torch.float32)

        # 步骤1：特征转为复数格式（通道维度拆分为实部和虚部）
        x_complex = torch.view_as_complex(x.reshape(*x.shape[:-1], -1, 2))
        # 步骤2：旋转操作（复数乘法注入位置信息）
        pe_x_complex = torch.view_as_complex(self.rotations) * x_complex
        # 步骤3：复数转实数→展平通道维度，恢复原始形状
        return torch.view_as_real(pe_x_complex).flatten(-2)


class LinearAttention(nn.Module):
    r"""
    多增强线性注意力（MLLA）核心模块：融合RoPE、LePE、ELU激活的线性注意力
    核心创新：
        1. 线性复杂度：O(N)替代传统注意力O(N²)，适配高分辨率特征；
        2. 双位置增强：RoPE注入全局位置，LePE补充局部细节；
        3. 特征激活增强：ELU+1确保Q/K非负，提升注意力稳定性；
        4. 即插即用：输入输出维度一致，适配现有Transformer/CNN架构。
    输入：特征序列 [B, N, C]（N=H×W，序列长度=空间像素总数）
    输出：增强后特征 [B, N, C]（与输入维度完全一致）
    """

    def __init__(self, dim, input_resolution, num_heads, qkv_bias=True, **kwargs):
        super().__init__()
        self.dim = dim  # 输入/输出通道数
        self.input_resolution = input_resolution  # 输入特征空间分辨率 (H,W)
        self.num_heads = num_heads  # 注意力头数
        self.head_dim = dim // num_heads  # 单头通道数

        # 1. QK投影层：一次性生成查询（Q）和键（K）（通道数=2×dim）
        self.qk = nn.Linear(dim, dim * 2, bias=qkv_bias)
        # 2. 激活函数：ELU+1确保Q/K非负，避免注意力权重抵消
        self.elu = nn.ELU()
        # 3. 局部位置增强（LePE）：深度可分离卷积补充局部细节
        self.lepe = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)
        # 4. 旋转位置编码（RoPE）：注入全局位置信息
        self.rope = RoPE(shape=(*input_resolution, dim))

    def forward(self, x):
        """
        前向传播流程：QK生成→激活增强→RoPE位置注入→线性注意力计算→LePE融合→输出
        """
        b, n, c = x.shape  # 解析输入维度：批次、序列长度、通道数
        h, w = int(n ** 0.5), int(n ** 0.5)  # 恢复空间分辨率（假设N=H×W）
        num_heads = self.num_heads

        # 步骤1：生成Q和K（V直接复用输入x，减少计算）
        qk = self.qk(x).reshape(b, n, 2, c).permute(2, 0, 1, 3)  # [2, B, N, C]
        q, k, v = qk[0], qk[1], x  # Q/K拆分，V=x

        # 步骤2：Q/K激活增强（ELU+1确保非负性）
        q = self.elu(q) + 1.0
        k = self.elu(k) + 1.0

        # 步骤3：RoPE位置注入（需先恢复空间格式）
        # Q/K→空间格式→RoPE→多头维度重排
        q_rope = self.rope(q.reshape(b, h, w, c)).reshape(b, n, num_heads, self.head_dim).permute(0, 2, 1, 3)
        k_rope = self.rope(k.reshape(b, h, w, c)).reshape(b, n, num_heads, self.head_dim).permute(0, 2, 1, 3)

        # 步骤4：多头维度重排（Q/K/V）
        q = q.reshape(b, n, num_heads, self.head_dim).permute(0, 2, 1, 3)  # [B, num_heads, N, head_dim]
        k = k.reshape(b, n, num_heads, self.head_dim).permute(0, 2, 1, 3)
        v = v.reshape(b, n, num_heads, self.head_dim).permute(0, 2, 1, 3)

        # 步骤5：线性注意力核心计算（O(N)复杂度）
        # 归一化因子z = 1/(Q×K均值^T + 1e-6)
        z = 1 / (q @ k.mean(dim=-2, keepdim=True).transpose(-2, -1) + 1e-6)
        # KV融合（注入RoPE位置信息）
        kv = (k_rope.transpose(-2, -1) * (n ** -0.5)) @ (v * (n ** -0.5))
        # 注意力加权：Q_rope×KV×z
        x_attn = q_rope @ kv * z

        # 步骤6：维度恢复
        x_attn = x_attn.transpose(1, 2).reshape(b, n, c)  # [B, N, C]

        # 步骤7：LePE局部增强融合
        # V→空间格式→LePE→序列格式→与注意力输出残差融合
        v_spatial = v.transpose(1, 2).reshape(b, h, w, c).permute(0, 3, 1, 2)  # [B, C, H, W]
        lepe_feature = self.lepe(v_spatial).permute(0, 2, 3, 1).reshape(b, n, c)  # [B, N, C]
        x_attn = x_attn + lepe_feature  # 位置增强融合

        return x_attn

    def extra_repr(self) -> str:
        """模块额外信息（print(model)时显示）"""
        return f'dim={self.dim}, num_heads={self.num_heads}'

if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 32*32, 64).to(device)
    model = LinearAttention(64, (32, 32), 4)

    model.to(device)
    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("微信: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)