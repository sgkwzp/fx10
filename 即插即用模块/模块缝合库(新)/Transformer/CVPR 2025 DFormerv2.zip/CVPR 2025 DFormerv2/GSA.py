import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Tuple


class DWConv2d(nn.Module):
    """
    深度可分离卷积模块（适配通道最后格式）：用于局部位置增强（LEPE）
    核心作用：提取局部空间特征，补充自注意力的局部细节丢失，适配RGB-D图像的几何纹理
    输入：特征图 [B, H, W, C]（通道最后格式，B=批次，H/W=高/宽，C=通道）
    输出：局部增强特征 [B, H, W, C]（与输入维度一致）
    """

    def __init__(self, dim, kernel_size, stride, padding):
        super().__init__()
        # 深度可分离卷积：分组数=通道数，每个通道独立卷积，减少计算量
        self.dwconv = nn.Conv2d(dim, dim, kernel_size, stride, padding, groups=dim)

    def forward(self, x: torch.Tensor):
        """
        前向传播：通道格式转换（HWC→CHW）→深度可分离卷积→格式恢复（CHW→HWC）
        """
        # 通道格式转换：[B, H, W, C]→[B, C, H, W]（适配Conv2d输入）
        x = x.permute(0, 3, 1, 2)
        # 深度可分离卷积：提取局部空间特征（如RGB-D图像的物体边缘）
        x = self.dwconv(x)
        # 格式恢复：[B, C, H, W]→[B, H, W, C]（回归通道最后格式）
        x = x.permute(0, 2, 3, 1)
        return x


def angle_transform(x, sin, cos):
    """
    角度变换函数：基于正弦/余弦编码，增强注意力的几何位置敏感性
    核心作用：将特征按角度分解为水平/垂直分量，适配RGB-D图像的平面几何结构
    输入：
        x: 特征图 [B, num_heads, H, W, C//2]（C为原通道数，仅处理偶数通道）
        sin: 正弦编码 [H, W, C//2]（位置角度的正弦值）
        cos: 余弦编码 [H, W, C//2]（位置角度的余弦值）
    输出：角度变换后特征 [B, num_heads, H, W, C//2]
    """
    # 拆分特征为水平（x1）和垂直（x2）分量（按通道步长2拆分）
    x1 = x[:, :, :, :, ::2]  # 取偶数索引通道（水平分量）
    x2 = x[:, :, :, :, 1::2]  # 取奇数索引通道（垂直分量）
    # 角度变换公式：x' = x*cos - x2*sin（水平分量） + x1*sin（垂直分量），合并为原通道数
    return (x * cos) + (torch.stack([-x2, x1], dim=-1).flatten(-2) * sin)


class GeoPriorGen(nn.Module):
    """
    几何先验生成模块：融合位置衰减与深度衰减，为GSA提供几何约束
    核心创新：
        1. 位置衰减：基于像素坐标的距离衰减，捕捉平面几何关联；
        2. 深度衰减：基于RGB-D深度图的距离衰减，捕捉3D几何关联；
        3. 可学习权重：平衡位置与深度的贡献，适配不同场景。
    输入：
        HW_tuple: (H, W)（特征图高宽）
        depth_map: 深度图 [B, 1, H, W]（RGB-D图像的深度信息）
        split_or_not: 是否拆分水平/垂直维度（适配不同注意力模式）
    输出：
        geo_prior: 几何先验（(sin, cos)角度编码 + (mask_h/mask_w 或 mask)衰减掩码）
    """

    def __init__(self, embed_dim, num_heads, initial_value=2, heads_range=4):
        super().__init__()
        # 角度编码基数（参考RoPE设计，适配通道维度）
        angle = 1.0 / (10000 ** torch.linspace(0, 1, embed_dim // num_heads // 2))
        angle = angle.unsqueeze(-1).repeat(1, 2).flatten()  # 扩展为适配单头偶数通道

        # 可学习权重：平衡位置衰减（weight[0]）与深度衰减（weight[1]）
        self.weight = nn.Parameter(torch.ones(2, 1, 1, 1), requires_grad=True)

        # 注意力头衰减系数：随头索引增加，衰减强度增强（捕捉不同尺度几何关联）
        decay = torch.log(
            1 - 2 ** (-initial_value - heads_range * torch.arange(num_heads, dtype=torch.float) / num_heads)
        )

        # 注册缓冲区（不参与梯度更新）
        self.register_buffer("angle", angle)
        self.register_buffer("decay", decay)

    def generate_depth_decay(self, H: int, W: int, depth_grid):
        """
        生成2D深度衰减掩码：基于深度图计算像素间深度距离，模拟3D几何关联
        输出：衰减掩码 [B, num_heads, H×W, H×W]（B=批次，num_heads=注意力头数）
        """
        B, _, H, W = depth_grid.shape
        # 深度图展平：[B, 1, H, W]→[B, H×W, 1]（每个像素的深度值）
        grid_d = depth_grid.reshape(B, H * W, 1)
        # 计算像素间深度差（绝对值）：[B, H×W, H×W]
        mask_d = grid_d[:, :, None, :] - grid_d[:, None, :, :]
        mask_d = (mask_d.abs()).sum(dim=-1)
        # 按注意力头应用衰减系数：[B, num_heads, H×W, H×W]
        mask_d = mask_d.unsqueeze(1) * self.decay[None, :, None, None]
        return mask_d

    def generate_pos_decay(self, H: int, W: int):
        """
        生成2D位置衰减掩码：基于像素坐标计算空间距离，模拟2D平面几何关联
        输出：衰减掩码 [num_heads, H×W, H×W]
        """
        # 生成坐标网格：[H, W, 2]（每个像素的(x,y)坐标）
        index_h = torch.arange(H).to(self.decay)
        index_w = torch.arange(W).to(self.decay)
        grid = torch.meshgrid([index_h, index_w])
        grid = torch.stack(grid, dim=-1).reshape(H * W, 2)
        # 计算像素间空间距离（曼哈顿距离）：[H×W, H×W]
        mask = grid[:, None, :] - grid[None, :, :]
        mask = (mask.abs()).sum(dim=-1)
        # 按注意力头应用衰减系数：[num_heads, H×W, H×W]
        mask = mask * self.decay[:, None, None]
        return mask

    def generate_1d_depth_decay(self, H, W, depth_grid):
        """
        生成1D深度衰减掩码：拆分水平/垂直维度，适配分块注意力
        输出：衰减掩码 [num_heads, B, W, H, H]（水平拆分）或 [num_heads, B, H, W, W]（垂直拆分）
        """
        # 计算深度差（绝对值）：[B, 1, W, H, H]（水平拆分）
        mask = depth_grid[:, :, :, :, None] - depth_grid[:, :, :, None, :]
        mask = mask.abs()
        # 按注意力头应用衰减系数：[num_heads, B, W, H, H]
        mask = mask * self.decay[:, None, None, None]
        assert mask.shape[2:] == (W, H, H)
        return mask

    def generate_1d_decay(self, l: int):
        """
        生成1D位置衰减掩码：适配分块注意力的水平/垂直维度
        输出：衰减掩码 [num_heads, l, l]（l为维度长度，如H或W）
        """
        index = torch.arange(l).to(self.decay)
        # 计算位置差（绝对值）：[l, l]
        mask = index[:, None] - index[None, :]
        mask = mask.abs()
        # 按注意力头应用衰减系数：[num_heads, l, l]
        mask = mask * self.decay[:, None, None]
        return mask

    def forward(self, HW_tuple: Tuple[int], depth_map, split_or_not=False):
        """
        前向传播：生成角度编码与衰减掩码，组成几何先验
        """
        H, W = HW_tuple
        # 深度图插值：将输入深度图调整为特征图尺寸（H×W）
        depth_map = F.interpolate(depth_map, size=HW_tuple, mode="bilinear", align_corners=False)

        if split_or_not:
            # 分块模式：拆分水平/垂直维度，生成独立衰减掩码
            # 生成角度编码（sin/cos）：[H×W, C//2]→[H, W, C//2]
            index = torch.arange(H * W).to(self.decay)
            sin = torch.sin(index[:, None] * self.angle[None, :])
            sin = sin.reshape(H, W, -1)
            cos = torch.cos(index[:, None] * self.angle[None, :])
            cos = cos.reshape(H, W, -1)

            # 生成深度衰减掩码（水平/垂直拆分）
            mask_d_h = self.generate_1d_depth_decay(H, W, depth_map.transpose(-2, -1))  # 水平维度深度衰减
            mask_d_w = self.generate_1d_depth_decay(W, H, depth_map)  # 垂直维度深度衰减

            # 生成位置衰减掩码（水平/垂直拆分）
            mask_h = self.generate_1d_decay(H)  # 水平位置衰减
            mask_w = self.generate_1d_decay(W)  # 垂直位置衰减

            # 融合位置与深度衰减（可学习权重平衡）
            mask_h = self.weight[0] * mask_h.unsqueeze(0).unsqueeze(2) + self.weight[1] * mask_d_h
            mask_w = self.weight[0] * mask_w.unsqueeze(0).unsqueeze(2) + self.weight[1] * mask_d_w

            # 几何先验：（角度编码）+（水平/垂直衰减掩码）
            geo_prior = ((sin, cos), (mask_h, mask_w))
        else:
            # 全尺寸模式：生成全局衰减掩码
            # 生成角度编码（sin/cos）
            index = torch.arange(H * W).to(self.decay)
            sin = torch.sin(index[:, None] * self.angle[None, :])
            sin = sin.reshape(H, W, -1)
            cos = torch.cos(index[:, None] * self.angle[None, :])
            cos = cos.reshape(H, W, -1)

            # 生成位置衰减与深度衰减掩码
            mask = self.generate_pos_decay(H, W)  # 全局位置衰减
            mask_d = self.generate_depth_decay(H, W, depth_map)  # 全局深度衰减

            # 融合位置与深度衰减（可学习权重平衡）
            mask = self.weight[0] * mask + self.weight[1] * mask_d

            # 几何先验：（角度编码）+（全局衰减掩码）
            geo_prior = ((sin, cos), mask)
        return geo_prior


class Full_GSA(nn.Module):
    """
    全尺寸几何自注意力模块（GSA核心实现）：融合几何先验与自注意力，适配RGB-D图像
    核心流程：QKV投影→角度变换→几何衰减→注意力计算→局部增强→输出投影
    输入：
        x: 特征图 [B, H, W, C]（通道最后格式）
        rel_pos: 几何先验（来自GeoPriorGen，含角度编码与衰减掩码）
        split_or_not: 是否分块处理（适配高分辨率）
    输出：
        注意力增强特征 [B, H, W, C]（与输入维度一致，支持即插即用）
    """

    def __init__(self, embed_dim, num_heads, value_factor=1):
        super().__init__()
        self.factor = value_factor  # Value通道扩展因子（默认1，可增强表达）
        self.embed_dim = embed_dim  # 输入特征通道数
        self.num_heads = num_heads  # 注意力头数
        self.head_dim = self.embed_dim * self.factor // num_heads  # 单头Value通道数
        self.key_dim = self.embed_dim // num_heads  # 单头Q/K通道数
        self.scaling = self.key_dim ** -0.5  # Q/K缩放因子（缓解梯度消失）

        # QKV投影层（线性层，通道最后格式适配）
        self.q_proj = nn.Linear(embed_dim, embed_dim, bias=True)  # Q投影（通道数不变）
        self.k_proj = nn.Linear(embed_dim, embed_dim, bias=True)  # K投影（通道数不变）
        self.v_proj = nn.Linear(embed_dim, embed_dim * self.factor, bias=True)  # V投影（通道数扩展factor倍）

        # 局部位置增强（LEPE）：深度可分离卷积补充局部细节
        self.lepe = DWConv2d(embed_dim * self.factor, 5, 1, 2)

        # 输出投影层：恢复输入通道数
        self.out_proj = nn.Linear(embed_dim * self.factor, embed_dim, bias=True)

        # 参数初始化
        self.reset_parameters()

    def forward(self, x: torch.Tensor, rel_pos, split_or_not=False):
        """
        前向传播：几何注意力计算的完整流程
        """
        bsz, h, w, _ = x.size()  # 解析输入维度（B, H, W, C）
        (sin, cos), mask = rel_pos  # 解析几何先验（角度编码+衰减掩码）
        assert h * w == mask.size(3), "特征图尺寸与掩码尺寸不匹配"

        # 步骤1：QKV投影（线性层转换）
        q = self.q_proj(x)  # [B, H, W, C]→[B, H, W, C]（Q）
        k = self.k_proj(x)  # [B, H, W, C]→[B, H, W, C]（K）
        v = self.v_proj(x)  # [B, H, W, C]→[B, H, W, C×factor]（V，通道扩展）

        # 步骤2：局部位置增强（LEPE）：补充局部细节，避免注意力丢失
        lepe = self.lepe(v)  # [B, H, W, C×factor]→[B, H, W, C×factor]

        # 步骤3：Q缩放（缓解梯度消失）
        k = k * self.scaling  # [B, H, W, C]→[B, H, W, C]

        # 步骤4：维度重排（适配多头注意力）
        # Q/K：[B, H, W, C]→[B, num_heads, H, W, C//num_heads]
        q = q.view(bsz, h, w, self.num_heads, -1).permute(0, 3, 1, 2, 4)
        k = k.view(bsz, h, w, self.num_heads, -1).permute(0, 3, 1, 2, 4)

        # 步骤5：角度变换（增强几何位置敏感性）
        qr = angle_transform(q, sin, cos)  # Q角度变换
        kr = angle_transform(k, sin, cos)  # K角度变换

        # 步骤6：展平空间维度（适配注意力矩阵计算）
        qr = qr.flatten(2, 3)  # [B, num_heads, H, W, C//num_heads]→[B, num_heads, H×W, C//num_heads]
        kr = kr.flatten(2, 3)  # [B, num_heads, H×W, C//num_heads]

        # 步骤7：V维度重排与展平
        vr = v.reshape(bsz, h, w, self.num_heads, -1).permute(0, 3, 1, 2,
                                                              4)  # [B, num_heads, H, W, C×factor//num_heads]
        vr = vr.flatten(2, 3)  # [B, num_heads, H×W, C×factor//num_heads]

        # 步骤8：几何注意力计算
        qk_mat = qr @ kr.transpose(-1, -2)  # QK^T：[B, num_heads, H×W, H×W]
        qk_mat = qk_mat + mask  # 加入几何衰减掩码（位置+深度约束）
        qk_mat = torch.softmax(qk_mat, -1)  # 注意力权重归一化

        # 步骤9：注意力加权V
        output = torch.matmul(qk_mat, vr)  # [B, num_heads, H×W, C×factor//num_heads]

        # 步骤10：维度恢复（展平→空间维度）
        output = output.transpose(1, 2).reshape(bsz, h, w, -1)  # [B, H, W, C×factor]

        # 步骤11：局部增强融合（LEPE+注意力输出）
        output = output + lepe

        # 步骤12：输出投影（恢复输入通道数）
        output = self.out_proj(output)  # [B, H, W, C×factor]→[B, H, W, C]

        return output

    def reset_parameters(self):
        """参数初始化：采用Xavier正态分布，确保梯度稳定"""
        nn.init.xavier_normal_(self.q_proj.weight, gain=2 ** -2.5)
        nn.init.xavier_normal_(self.k_proj.weight, gain=2 ** -2.5)
        nn.init.xavier_normal_(self.v_proj.weight, gain=2 ** -2.5)
        nn.init.xavier_normal_(self.out_proj.weight)
        nn.init.constant_(self.out_proj.bias, 0.0)  # 输出偏置初始化为0


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    embed_dim = 64
    num_heads = 4
    H, W = 32, 32

    x = torch.randn(1, H, W, embed_dim).to(device)
    depth = torch.randn(1, 1, H, W).to(device)  # 深度图（模拟RGB-D图像的深度信息）

    geo = GeoPriorGen(embed_dim=embed_dim, num_heads=num_heads).to(device)
    geo_prior = geo((H, W), depth)  # 生成几何先验（角度编码+衰减掩码）
    model = Full_GSA(embed_dim, num_heads).to(device)

    y = model(x, geo_prior)

    print("微信公众号：十小大的底层视觉工坊")
    print("知乎、CSDN：十小大")
    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)