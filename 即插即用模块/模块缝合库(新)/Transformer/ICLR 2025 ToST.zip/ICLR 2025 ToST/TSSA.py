import torch
import torch.nn as nn
from einops import rearrange

def to_3d(x):
    return rearrange(x, 'b c h w -> b (h w) c')

def to_4d(x,h,w):
    return rearrange(x, 'b (h w) c -> b c h w',h=h,w=w)

class AttentionTSSA(nn.Module):
    """
    基于Token统计的自注意力模块（Token Statistics Self-Attention, TSSA）
    核心创新：不计算token间两两相似度，而是基于token的二阶统计特性（如平方特征）构建注意力，
    将复杂度从传统自注意力的O(n²)降至O(n)，适配长序列、高分辨率任务
    """

    def __init__(self, dim, num_heads=8, qkv_bias=False, qk_scale=None, attn_drop=0., proj_drop=0.):
        """
        Args:
            dim (int): 输入token的通道数（需与特征图通道数一致，如代码示例中为64）
            num_heads (int): 注意力头数（默认8，需满足dim能被num_heads整除）
            qkv_bias (bool): 特征投影线性层是否使用偏置（默认False，减少参数冗余）
            qk_scale (float): 传统注意力的缩放因子（本模块未使用，默认None）
            attn_drop (float): 注意力权重的Dropout概率（默认0.，抑制过拟合）
            proj_drop (float): 输出投影层的Dropout概率（默认0.，抑制过拟合）
        """
        super().__init__()
        self.heads = num_heads  # 注意力头数（多头并行处理不同统计子空间）
        self.attend = nn.Softmax(dim=1)  # 软聚类归一化：用于生成token的子空间归属权重（dim=1对应token维度）
        self.attn_drop = nn.Dropout(attn_drop)  # 注意力权重失活层

        # 特征投影层：将输入token映射到多头特征空间（dim→dim，按头拆分后每头维度为dim//num_heads）
        self.qkv = nn.Linear(dim, dim, bias=qkv_bias)
        # 可学习温度参数：控制软聚类的锐利度（每头独立，形状：[num_heads, 1]）
        self.temp = nn.Parameter(torch.ones(num_heads, 1))
        # 输出投影层：将多头注意力结果映射回原通道，配合Dropout抑制过拟合
        self.to_out = nn.Sequential(
            nn.Linear(dim, dim),  # 通道维度恢复：num_heads×(dim//num_heads)→dim
            nn.Dropout(proj_drop)
        )

    def forward(self, x):
        """
        TSSA前向传播流程：特征投影→多头拆分→统计量计算→软聚类→注意力权重生成→特征更新→输出投影
        Args:
            x (torch.Tensor): 输入3D特征，形状为 [b, n, c]（b=批量，n=token数量，c=通道数=dim）
                             （代码示例中为[1, 1024, 64]，即1个样本、32×32=1024个token、64维通道）
        Returns:
            torch.Tensor: 输出3D特征，形状与输入一致 [b, n, c]，支持后续维度恢复为4D特征图
        """
        # 步骤1：特征投影与多头拆分
        # 线性投影：[b, n, c] → [b, n, c]（映射到多头特征空间）
        # 多头拆分：[b, n, c] → [b, heads, n, c//heads]（每头处理c//heads维特征）
        w = rearrange(self.qkv(x), 'b n (h d) -> b h n d', h=self.heads)
        b, h, n_tokens, d_head = w.shape  # 解析维度：b=批量，h=头数，n_tokens=token数，d_head=单头通道数

        # 步骤2：计算token的归一化二阶统计量（平方特征）
        # 沿token维度（dim=-2）归一化：确保不同token的统计量在同一尺度
        w_normed = torch.nn.functional.normalize(w, dim=-2)
        w_sq = w_normed ** 2  # 二阶统计量：[b, h, n_tokens, d_head]

        # 步骤3：软聚类生成token归属权重（Pi，对应论文Eq.10）
        # 对二阶统计量沿通道维度求和：[b, h, n_tokens, d_head] → [b, h, n_tokens]（每token的统计能量）
        # 乘以温度参数调整聚类锐利度，再通过Softmax归一化：[b, h, n_tokens] → [b, h, n_tokens]
        pi = self.attend(torch.sum(w_sq, dim=-1) * self.temp)
        pi = pi / (pi.sum(dim=-1, keepdim=True) + 1e-8)  # 二次归一化：确保每头内token权重和为1（1e-8避免分母为0）

        # 步骤4：生成注意力权重（基于统计量的抑制/保留权重）
        # 扩展pi维度：[b, h, n_tokens] → [b, h, 1, n_tokens]（适配矩阵乘法）
        # 计算token的加权二阶统计量：[b, h, 1, n_tokens] × [b, h, n_tokens, d_head] → [b, h, 1, d_head]
        dots = torch.matmul(pi.unsqueeze(-2), w ** 2)
        # 注意力权重：1/(1+dots)，实现“低统计能量抑制、高统计能量保留”（dots越大，权重越小，抑制越强）
        attn = 1. / (1 + dots)
        attn = self.attn_drop(attn)  # 注意力权重失活

        # 步骤5：特征更新（统计驱动的特征调整）
        # Pi扩展维度：[b, h, n_tokens] → [b, h, n_tokens, 1]（适配逐元素乘法）
        # 特征加权：w × pi（突出高归属权重token的特征）× (-attn)（抑制低统计能量特征）
        out = -torch.mul(w.mul(pi.unsqueeze(-1)), attn)

        # 步骤6：多头拼接与输出投影
        # 多头结果拼接：[b, h, n_tokens, d_head] → [b, n_tokens, h*d_head] → [b, n_tokens, c]
        out = rearrange(out, 'b h n d -> b n (h d)')
        # 输出投影：恢复通道维度并抑制过拟合 → [b, n, c]
        return self.to_out(out)

if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    input = torch.randn(1, 64, 32, 32).to(device)
    model = AttentionTSSA(64)

    x = to_3d(input)

    model.to(device)
    y = model(x)

    output = to_4d(y, 32, 32)

    print("微信公众号：十小大的底层视觉工坊")
    print("知乎、CSDN：十小大")

    print("输入特征维度：", input.shape)
    print("输出特征维度：", output.shape)