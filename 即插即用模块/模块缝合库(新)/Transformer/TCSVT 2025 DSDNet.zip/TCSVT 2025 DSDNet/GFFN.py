import torch
import torch.nn as nn
import torch.nn.functional as F

class GFFN(nn.Module):
    def __init__(self, dim, expansion_factor, bias):
        super(GFFN, self).__init__()
        h_dim = int(dim * expansion_factor)
        self.project_in = nn.Conv2d(dim, h_dim*2, kernel_size=1, bias=bias)

        self.dwconv = nn.Conv2d(h_dim*2, h_dim*2, kernel_size=3, stride=1, padding=1, groups=h_dim*2, bias=bias)

        self.sca = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(in_channels=h_dim, out_channels=h_dim, kernel_size=1, padding=0, stride=1,
                      groups=1, bias=True),
        )

        self.project_out = nn.Conv2d(h_dim, dim, kernel_size=1, bias=bias)

    def forward(self, x):
        x = self.project_in(x)
        x1, x2 = self.dwconv(x).chunk(2, dim=1)
        x = F.gelu(x1) * x2
        x = x * self.sca(x)
        x = self.project_out(x)
        return x

if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 64, 32, 32).to(device)
    model = GFFN(64,2,False)

    model.to(device)
    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("知乎、CSDN：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)