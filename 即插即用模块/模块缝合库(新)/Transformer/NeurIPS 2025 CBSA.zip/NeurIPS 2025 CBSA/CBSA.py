import torch
from torch import nn

from einops import rearrange


class CBSA(nn.Module):
    """
    收缩-广播自注意力模块（Contract-and-Broadcast Self-Attention, CBSA）
    核心设计：通过“特征收缩（Contract）→子空间注意力→特征广播（Broadcast）”的流程，
    在降低计算复杂度的同时保留全局依赖，适配高分辨率特征图的注意力建模
    """

    def __init__(self, dim, heads, dim_head):
        """
        Args:
            dim (int): 输入特征的通道数（需与上游模块输出通道一致，如代码示例中为64）
            heads (int): 多头注意力头数（默认4，需满足 heads×dim_head = inner_dim ≤ dim）
            dim_head (int): 单头注意力的通道数（默认16，控制单头计算复杂度）
        """
        super().__init__()
        self.inner_dim = heads * dim_head  # 多头注意力的总内部维度（所有头的通道数之和）
        self.heads = heads  # 注意力头数（多头并行处理不同子空间）
        self.dim_head = dim_head  # 单头通道数
        self.scale = dim_head ** -0.5  # 注意力缩放因子（1/√dim_head），缓解Q·K^T点积过大导致的Softmax饱和
        self.attend = nn.Softmax(dim=-1)  # 注意力权重归一化函数（沿最后一维归一化）

        # 特征投影层：将输入通道dim映射到inner_dim（适配多头注意力的内部维度）
        self.proj = nn.Linear(dim, self.inner_dim, bias=False)
        # 可学习步长参数：控制子空间更新幅度（step_rep控制收缩特征更新，step_x控制最终特征更新）
        self.step_x = nn.Parameter(torch.randn(heads, 1, 1))  # 形状：[heads, 1, 1]（每头独立步长）
        self.step_rep = nn.Parameter(torch.randn(heads, 1, 1))  # 形状：[heads, 1, 1]
        # 输出投影层：将多头注意力结果映射回原始通道dim，确保输入输出维度一致
        self.to_out = nn.Linear(self.inner_dim, dim)
        # 特征收缩池化层：自适应平均池化，将任意尺寸特征收缩为8×8（固定输出尺寸，确保收缩后特征量一致）
        self.pool = nn.AdaptiveAvgPool2d(output_size=(8, 8))
        # 占位模块：无实际作用，预留用于QKV生成的扩展（当前代码未启用）
        self.qkv = nn.Identity()

    def attention(self, query, key, value):
        """
        基础多头注意力计算函数：计算Q·K^T相似度→Softmax归一化→注意力加权V
        Args:
            query (torch.Tensor): 查询Q，形状 [B, heads, N_q, dim_head]（N_q为Q的序列长度）
            key (torch.Tensor): 键K，形状 [B, heads, N_k, dim_head]（N_k为K的序列长度）
            value (torch.Tensor): 值V，形状 [B, heads, N_v, dim_head]（N_v为V的序列长度，通常与N_k一致）
        Returns:
            tuple:
                out (torch.Tensor): 注意力加权后的V，形状 [B, heads, N_q, dim_head]
                attn (torch.Tensor): 注意力权重矩阵，形状 [B, heads, N_q, N_k]
        """
        # 计算Q与K的相似度：Q·K^T × 缩放因子 → [B, heads, N_q, N_k]
        dots = (query @ key.transpose(-1, -2)) * self.scale
        attn = self.attend(dots)  # Softmax归一化权重
        out = attn @ value  # 注意力加权V → [B, heads, N_q, dim_head]
        return out, attn

    def forward(self, x, return_attn=False):
        """
        CBSA前向传播流程：特征投影→特征收缩→子空间注意力→收缩特征更新→广播注意力→最终特征更新→输出投影
        Args:
            x (torch.Tensor): 输入特征，形状为 [B, N, C]（B=批量，N=序列长度=H×W，C=通道数=dim）
                             （代码示例中为[1, 256, 64]，即1个样本、16×16=256个token、64维通道）
            return_attn (bool): 是否返回注意力权重矩阵（默认False，仅输出特征；True时返回权重用于分析）
        Returns:
            torch.Tensor: 输出特征，形状与输入完全一致 [B, N, C]；若return_attn=True，额外返回注意力权重
        """
        B, N, C = x.shape  # 解析输入维度：B=批量，N=序列长度，C=通道数
        h = width = int(N ** 0.5)  # 从序列长度N推导特征图的高和宽（默认输入为正方形特征图，N=H×W）

        # 步骤1：特征投影（输入通道dim→inner_dim，适配多头注意力）
        w = self.proj(x)  # 形状：[B, N, inner_dim]
        self.qkv(w)  # 占位操作，预留QKV生成扩展

        # 步骤2：特征收缩（Contract）：通过自适应池化将高分辨率特征收缩为低分辨率子空间
        # 维度转换：[B, N, C] → [B, H, W, C] → [B, C, H, W]（适配池化输入格式）
        # 池化：[B, C, H, W] → [B, C, 8, 8]（固定收缩为8×8）
        # 维度恢复：[B, C, 8, 8] → [B, C, 64] → [B, 64, C]（64=8×8，收缩后的序列长度）
        rep = self.pool(w[:, :, :].reshape(B, h, width, C).permute(0, 3, 1, 2)).reshape(B, C, -1).permute(0, 2, 1)

        # 步骤3：多头维度重排（适配注意力计算格式）
        # 原始特征w重排：[B, N, inner_dim] → [B, N, heads, dim_head] → [B, heads, N, dim_head]
        w = w.reshape(B, N, self.heads, self.dim_head).permute(0, 2, 1, 3)
        # 收缩特征rep重排：[B, 64, C] → [B, 64, heads, dim_head] → [B, heads, 64, dim_head]
        rep = rep.reshape(B, 64, self.heads, self.dim_head).permute(0, 2, 1, 3)

        # 步骤4：子空间注意力（收缩特征→原始特征的注意力）
        # 以收缩特征为Q，原始特征为K/V，计算注意力（捕捉子空间与原始特征的关联）
        rep_delta, attn = self.attention(rep, w, w)  # rep_delta: [B, heads, 64, dim_head]，attn: [B, heads, 64, N]

        # 可选：返回注意力权重矩阵（用于可视化或可解释性分析）
        if return_attn:
            # 计算注意力权重的关联矩阵（K×Q^T），形状：[B, heads, N, N]
            return attn.transpose(-1, -2) @ attn

        # 步骤5：收缩特征更新（基于注意力结果调整收缩子空间）
        rep = rep + self.step_rep * rep_delta  # 残差融合：原始收缩特征 + 步长×注意力更新量

        # 步骤6：广播注意力（收缩特征内部的注意力，为后续广播做准备）
        x_delta, _ = self.attention(rep, rep, rep)  # x_delta: [B, heads, 64, dim_head]

        # 步骤7：特征广播（Broadcast）：将收缩子空间的更新映射回原始特征维度
        # 注意力权重转置后与x_delta相乘：[B, heads, N, 64] × [B, heads, 64, dim_head] → [B, heads, N, dim_head]
        x_delta = attn.transpose(-1, -2) @ x_delta
        # 步长控制更新幅度：[B, heads, N, dim_head] × [heads, 1, 1] → [B, heads, N, dim_head]
        x_delta = self.step_x * x_delta

        # 步骤8：多头结果拼接与输出投影
        # 维度重排：[B, heads, N, dim_head] → [B, N, heads×dim_head] → [B, N, inner_dim]
        x_delta = rearrange(x_delta, 'b h n k -> b n (h k)')
        # 输出投影：inner_dim→dim，确保输入输出维度一致 → [B, N, C]
        return self.to_out(x_delta)

if __name__ == '__main__':
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    # b,n,c
    x = torch.randn(1, 16*16, 64).to(device)
    cbsa = CBSA(64, 4, 16).to(device)
    y = cbsa(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("知乎、CSDN：十小大")
    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)