import torch
import torch.nn as nn

class SeparableAttention(nn.Module):
    """
    分离注意力模块（SepAttn）：将自注意力拆分为深度自注意力（DSA）与点自注意力（PSA），实现高效特征增强
    核心创新：
        1. 双分支分离设计：DSA处理窗口内局部关联，PSA处理窗口间全局关联，兼顾效率与精度；
        2. 窗口化计算：按固定窗口尺寸划分特征，降低局部注意力计算量；
        3. 可选PSA分支：支持按需启用全局关联捕捉，适配不同任务需求；
        4. 残差连接：窗口内/窗口间均含残差，稳定深层训练。
    输入：
        x: 窗口化特征 [B, win_num, win_size(+1), C]（win_size=ws×ws，+1可选窗口令牌）
        H/W: 原始特征图高/宽（用于窗口恢复）
    输出：
        x: 增强后特征 [B, N, C]（N=H×W，序列格式）
    """
    def __init__(self, dim, num_heads=8, qkv_bias=False, qk_scale=None, attn_drop=0., proj_drop=0., ws=7, do_PSA=False):
        """
        参数初始化：
            dim: 输入/输出通道数（需能被num_heads整除）
            num_heads: 注意力头数（默认8）
            qkv_bias: QKV投影层是否加偏置（默认False）
            qk_scale: 手动指定缩放因子（默认None，自动计算head_dim^-0.5）
            attn_drop: 注意力权重Dropout概率（默认0.）
            proj_drop: 输出投影Dropout概率（默认0.）
            ws: 窗口尺寸（默认7，ws×ws为每个窗口的像素数）
            do_PSA: 是否启用点自注意力（PSA）分支（默认False，仅启用DSA）
        """
        super(SeparableAttention, self).__init__()
        assert dim % num_heads == 0, f"通道数 {dim} 需能被注意力头数 {num_heads} 整除"
        self.dim = dim  # 通道数
        self.ws = ws  # 窗口尺寸
        self.num_heads = num_heads  # 注意力头数
        head_dim = dim // num_heads  # 单头通道数
        self.scale = qk_scale or head_dim ** -0.5  # 缩放因子（缓解梯度消失）

        # 1. 深度自注意力（DSA）：处理窗口内局部关联
        self.DSA_qkv = nn.Linear(dim, dim * 3, bias=qkv_bias)  # DSA的QKV投影层
        self.DSA_attn_drop = nn.Dropout(attn_drop)  # DSA注意力Dropout

        # 2. 点自注意力（PSA）：处理窗口间全局关联（可选）
        self.do_PSA = do_PSA
        if self.do_PSA:
            self.win_tokens_norm = nn.LayerNorm(dim)  # 窗口令牌归一化
            self.win_tokens_act = nn.GELU()  # 窗口令牌激活
            self.PSA_qk = nn.Linear(dim, dim * 2, bias=qkv_bias)  # PSA的QK投影层（V复用DSA输出）
            self.PSA_attn_drop = nn.Dropout(attn_drop)  # PSA注意力Dropout

        # 3. 输出投影层：恢复通道数并正则化
        self.proj = nn.Linear(dim, dim)
        self.proj_drop = nn.Dropout(proj_drop)

    def forward(self, x, H, W):
        """
        前向传播流程：DSA窗口内增强→（可选）PSA窗口间增强→投影输出
        """
        B, win_num, _, C = x.shape  # 解析输入维度：批次、窗口数、窗口尺寸+令牌数、通道数
        h_group, w_group = int(H / self.ws), int(W / self.ws)  # 窗口分组数（高×宽）
        win_size = self.ws * self.ws  # 每个窗口的像素数

        # 步骤1：深度自注意力（DSA）- 窗口内局部关联捕捉
        # QKV生成与维度重排：[B, win_num, win_size(+1), 3×dim]→[3, B, win_num, num_heads, win_size(+1), head_dim]
        DSA_qkv = self.DSA_qkv(x).reshape(
            B, win_num, -1, 3, self.num_heads, C // self.num_heads
        ).permute(3, 0, 1, 4, 2, 5)
        DSA_q, DSA_k, DSA_v = DSA_qkv[0], DSA_qkv[1], DSA_qkv[2]  # 拆分Q/K/V

        # DSA注意力计算：窗口内QK^T→Softmax→加权V
        DSA_attn = (DSA_q @ DSA_k.transpose(-2, -1)) * self.scale  # [B, win_num, num_heads, win_size(+1), win_size(+1)]
        DSA_attn = DSA_attn.softmax(dim=-1)  # 注意力权重归一化
        DSA_attn = self.DSA_attn_drop(DSA_attn)  # Dropout正则化

        # 注意力加权与维度恢复：[B, win_num, num_heads, win_size(+1), head_dim]→[B, win_num, win_size(+1), C]
        attn_out = (DSA_attn @ DSA_v).transpose(2, 3).reshape(B, win_num, -1, C)
        attn_out = attn_out + x  # DSA残差连接，保留原始窗口特征

        # 步骤2：点自注意力（PSA）- 窗口间全局关联捕捉（可选）
        if self.do_PSA:
            # 拆分窗口令牌与窗口内像素特征
            win_tokens = attn_out[:, :, 0, :]  # 窗口令牌 [B, win_num, C]（全局关联载体）
            attn_x = attn_out[:, :, 1:, :]     # 窗口内像素特征 [B, win_num, win_size, C]

            # 窗口令牌增强：归一化+激活
            win_tokens = self.win_tokens_norm(win_tokens)
            win_tokens = self.win_tokens_act(win_tokens)

            # PSA QK生成与维度重排：[B, win_num, 2×dim]→[2, B, num_heads, win_num, head_dim]
            PSA_qk = self.PSA_qk(win_tokens).reshape(
                B, win_num, 2, self.num_heads, -1
            ).permute(2, 0, 3, 1, 4)
            PSA_q, PSA_k = PSA_qk[0], PSA_qk[1]  # 拆分Q/K

            # PSA V生成：窗口内像素特征重排为多头格式
            PSA_v = attn_x.reshape(
                B, win_num, win_size, self.num_heads, -1
            ).permute(0, 3, 1, 2, 4).reshape(
                B, self.num_heads, win_num, -1
            )  # [B, num_heads, win_num, win_size×head_dim]

            # PSA注意力计算：窗口间QK^T→Softmax→加权V
            PSA_attn = (PSA_q @ PSA_k.transpose(-2, -1)) * self.scale  # [B, num_heads, win_num, win_num]
            PSA_attn = PSA_attn.softmax(dim=-1)  # 权重归一化
            PSA_attn = self.PSA_attn_drop(PSA_attn)  # Dropout

            # 注意力加权与维度恢复：[B, num_heads, win_num, win_size×head_dim]→[B, win_num, win_size, C]
            attn_out = (PSA_attn @ PSA_v).transpose(1, 2).reshape(
                B, win_num, self.num_heads, win_size, -1
            ).transpose(2, 3).reshape(B, win_num, win_size, C)
            attn_out = attn_out + attn_x  # PSA残差连接

            # 窗口特征恢复为原始空间序列：[B, h_group, w_group, ws, ws, C]→[B, H×W, C]
            attn_out = attn_out.reshape(B, h_group, w_group, self.ws, self.ws, C)
            attn_out = attn_out.transpose(2, 3).reshape(B, -1, C)
        else:
            # 不启用PSA时，直接挤压窗口维度，恢复序列格式
            attn_out = attn_out.squeeze(1)  # [B, 1, N, C]→[B, N, C]

        # 步骤3：输出投影与正则化
        x = self.proj(attn_out)
        x = self.proj_drop(x)

        return x

if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 32*32, 64).to(device)
    x_attn = x.unsqueeze(1)
    model = SeparableAttention(64)

    model.to(device)
    y = model(x_attn, 32, 32)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)