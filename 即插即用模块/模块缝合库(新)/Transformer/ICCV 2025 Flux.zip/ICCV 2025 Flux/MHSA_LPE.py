import torch
from torch import nn
from einops import rearrange

from flash_attn.flash_attn_interface import flash_attn_varlen_qkvpacked_func
from flash_attn.bert_padding import unpad_input, pad_input

class FlashAttention(nn.Module):
    """Implement the scaled dot product attention with softmax.
    Arguments
    ---------
        softmax_scale: The temperature to use for the softmax attention.
                      (default: 1/sqrt(d_keys) where d_keys is computed at
                      runtime)
        attention_dropout: The dropout rate to apply to the attention
                           (default: 0.0)
    """

    def __init__(self, softmax_scale=None, attention_dropout=0.0, device=None, dtype=None):
        super().__init__()
        self.softmax_scale = softmax_scale
        self.dropout_p = attention_dropout

    def forward(self, qkv, key_padding_mask=None, causal=False, cu_seqlens=None,
                max_s=None, need_weights=False):
        """Implements the multihead softmax attention.
        Arguments
        ---------
            qkv: The tensor containing the query, key, and value. (B, S, 3, H, D) if key_padding_mask is None
                if unpadded: (nnz, 3, h, d)
            key_padding_mask: a bool tensor of shape (B, S)
        """
        assert not need_weights
        assert qkv.dtype in [torch.float16, torch.bfloat16]
        assert qkv.is_cuda

        if cu_seqlens is None:
            batch_size = qkv.shape[0]
            seqlen = qkv.shape[1]
            if key_padding_mask is None:
                qkv = rearrange(qkv, 'b s ... -> (b s) ...')
                max_s = seqlen
                cu_seqlens = torch.arange(0, (batch_size + 1) * seqlen, step=seqlen, dtype=torch.int32,
                                          device=qkv.device)
                output = flash_attn_varlen_qkvpacked_func(
                    qkv, cu_seqlens, max_s, self.dropout_p if self.training else 0.0,
                    softmax_scale=self.softmax_scale, causal=causal
                )
                output = rearrange(output, '(b s) ... -> b s ...', b=batch_size)
            else:
                nheads = qkv.shape[-2]
                x = rearrange(qkv, 'b s three h d -> b s (three h d)')
                x_unpad, indices, cu_seqlens, max_s = unpad_input(x, key_padding_mask)
                x_unpad = rearrange(x_unpad, 'nnz (three h d) -> nnz three h d', three=3, h=nheads)
                output_unpad = flash_attn_varlen_qkvpacked_func(
                    x_unpad, cu_seqlens, max_s, self.dropout_p if self.training else 0.0,
                    softmax_scale=self.softmax_scale, causal=causal
                )
                output = rearrange(pad_input(rearrange(output_unpad, 'nnz h d -> nnz (h d)'),
                                             indices, batch_size, seqlen),
                                   'b s (h d) -> b s h d', h=nheads)
        else:
            assert max_s is not None
            output = flash_attn_varlen_qkvpacked_func(
                qkv, cu_seqlens, max_s, self.dropout_p if self.training else 0.0,
                softmax_scale=self.softmax_scale, causal=causal
            )

        return output, None

class DepthwiseConv3D(nn.Module):
    """
    3D深度可分离卷积模块：为局部位置增强（LPE）提供空间-时序局部特征提取
    核心作用：在3D特征（如视频的时序-空间维度）上提取局部关联，补充自注意力的局部细节丢失
    输入：3D特征 [B, C, T, H, W]（B=批次，C=通道，T=时序步，H/W=空间高/宽）
    输出：局部增强特征 [B, C, T, H, W]（与输入维度一致）
    """

    def __init__(self, in_channels, kernel_size=(1, 1, 1), stride=(1, 1, 1), padding=0):
        super(DepthwiseConv3D, self).__init__()
        # 3D深度可分离卷积：分组数=通道数，每个通道独立卷积，减少计算量
        self.depthwise_conv = nn.Conv3d(
            in_channels, in_channels, kernel_size=kernel_size,
            stride=stride, padding=padding, groups=in_channels
        )
        # 参数初始化：权重设为1（初始无增强），偏置设为0（避免初始偏移）
        nn.init.constant_(self.depthwise_conv.weight, 1.)
        if self.depthwise_conv.bias is not None:
            nn.init.constant_(self.depthwise_conv.bias, 0.)

    def forward(self, x):
        # 3D深度可分离卷积：提取局部时序-空间特征（如视频帧的相邻时序关联）
        dwconv = self.depthwise_conv(x)
        return dwconv


class Attention(nn.Module):
    """
    带局部位置增强的多头自注意力（MHSA-LPE）：整合LPE、Flash注意力、QK归一化
    核心创新：
        1. LPE局部增强：3D深度可分离卷积补充局部细节，解决自注意力"局部模糊"问题；
        2. 双注意力模式：支持传统朴素注意力（_naive_attn）与Flash注意力（_flash_attn），平衡精度与效率；
        3. QK归一化：独立归一化Q/K，增强注意力稳定性，适配高分辨率特征；
        4. 模块化设计：各组件（LPE、Flash、归一化）可开关，适配不同任务需求。
    输入：特征序列 [B, N, C]（B=批次，N=序列长度=H×W×T，C=通道）
    输出：注意力增强特征 [B, N, C]（与输入维度一致，支持即插即用）
    """

    def __init__(self, dim, num_heads=8, qkv_bias=False, attn_drop=0., proj_drop=0., use_flash_attn=False,
                 causal=False, norm_layer=nn.LayerNorm, qk_normalization=False, use_fused_rmsnorm=False, use_lpe=False):
        super().__init__()
        # 校验通道数与头数兼容性（确保每头通道数为整数）
        assert dim % num_heads == 0, f"通道数 {dim} 需能被注意力头数 {num_heads} 整除"

        self.num_heads = num_heads  # 注意力头数
        self.head_dim = dim // num_heads  # 单头通道数（如64//8=8）
        self.scale = self.head_dim ** -0.5  # 注意力缩放因子（缓解梯度消失）

        # QKV投影层：线性层一次性生成Q（查询）、K（键）、V（值）
        self.qkv = nn.Linear(dim, dim * 3, bias=qkv_bias)
        # 注意力权重Dropout（正则化，避免过拟合）
        self.attn_drop = nn.Dropout(attn_drop)
        # 输出投影层：恢复通道维度，增强特征表达
        self.proj = nn.Linear(dim, dim)
        # 输出Dropout（正则化）
        self.proj_drop = nn.Dropout(proj_drop)

        # Flash注意力开关（GPU加速，适配高分辨率/长序列）
        self.use_flash_attn = use_flash_attn
        if use_flash_attn:
            self.causal = causal  # 是否启用因果注意力（时序任务专用，如语言模型）
            self.inner_attn = FlashAttention(attention_dropout=attn_drop)  # Flash注意力实例

        # 局部位置增强（LPE）开关（补充局部细节）
        self.use_lpe = use_lpe
        if use_lpe:
            self.lpe = DepthwiseConv3D(dim)  # LPE核心：3D深度可分离卷积

        # QK归一化开关（独立归一化Q/K，增强稳定性）
        self.qk_normalization = qk_normalization
        self.q_norm = norm_layer(dim) if qk_normalization else nn.Identity()  # Q归一化
        self.k_norm = norm_layer(dim) if qk_normalization else nn.Identity()  # K归一化

        # 融合RMS归一化开关（适配Flash注意力的低精度计算）
        self.use_fused_rmsnorm = use_fused_rmsnorm

    def _naive_attn(self, x, return_attn=False):
        """
        传统朴素多头自注意力：适用于中小序列长度（如N<1e4），支持注意力权重返回（可视化）
        参数：return_attn - 是否返回注意力权重（用于调试/可视化）
        返回：注意力输出 + 可选注意力权重
        """
        B, N, C = x.shape  # 解析输入维度：批次、序列长度、通道数

        # 步骤1：生成QKV并维度重排
        # QKV投影：[B, N, C]→[B, N, 3C]→拆分Q/K/V→[3, B, num_heads, N, head_dim]
        qkv = self.qkv(x).reshape(B, N, 3, self.num_heads, C // self.num_heads).permute(2, 0, 3, 1, 4)
        q, k, v = qkv.unbind(0)  # 拆分Q/K/V：各[B, num_heads, N, head_dim]

        # 步骤2：Q/K归一化（可选，增强稳定性）
        if self.qk_normalization:
            B_, H_, N_, D_ = q.shape
            # Q归一化：[B, H, N, D]→[B, N, H*D]→归一化→[B, N, H, D]→[B, H, N, D]
            q = self.q_norm(q.transpose(1, 2).flatten(-2, -1)).view(B_, N_, H_, D_).transpose(1, 2)
            # K归一化（同Q）
            k = self.k_norm(k.transpose(1, 2).flatten(-2, -1)).view(B_, N_, H_, D_).transpose(1, 2)

        # 步骤3：局部位置增强（LPE，可选，作用于V）
        v_lpe = None  # 初始化LPE特征
        if self.use_lpe:
            # V维度重排：[B, H, N, D]→[B, N, H*D]→[B, H*D, N]（适配3D卷积输入）
            v = v.permute(0, 2, 1, 3).reshape(B, N, -1)
            lpe = v.contiguous().permute(0, 2, 1)  # [B, C, N]（C=H*D）
            B, C, N = lpe.shape
            # 扩展为3D特征：[B, C, N]→[B, C, 1, N, 1]（时序T=1，空间H=N, W=1，适配3D卷积）
            lpe = lpe.reshape(B, C, 1, N, 1)
            # LPE增强：3D深度可分离卷积→挤压冗余维度→重排为[B, N, C]
            v_lpe = self.lpe(lpe).squeeze().permute(0, 2, 1)
            # V恢复多头维度：[B, N, C]→[B, N, H, D]→[B, H, N, D]
            v = v.reshape(B, N, self.num_heads, C // self.num_heads).permute(0, 2, 1, 3)

        # 步骤4：计算注意力权重
        # Q缩放→QK^T→Softmax→Dropout
        attn = ((q * self.scale) @ k.transpose(-2, -1))  # [B, H, N, N]（注意力矩阵）
        attn = attn.softmax(dim=-1)  # 权重归一化
        attn = self.attn_drop(attn)  # 权重Dropout

        # 步骤5：注意力加权V并恢复维度
        x = (attn @ v).transpose(1, 2).reshape(B, N, C)  # [B, H, N, D]→[B, N, H*D]

        # 步骤6：融合LPE（可选）+ 输出投影
        if self.use_lpe:
            x = self.proj(x + v_lpe)  # LPE特征残差融合
        else:
            x = self.proj(x)  # 直接投影
        x = self.proj_drop(x)  # 输出Dropout

        # 步骤7：返回注意力输出与可选权重
        if return_attn:
            attn_ = attn.detach()  # 注意力权重（不参与梯度）
            return x, attn_
        return x

    def _flash_attn(self, x, key_padding_mask=None, need_weights=False, require_qkv=False):
        """
        Flash注意力：GPU优化的高效注意力，适用于高分辨率/长序列（如N>1e4）
        优势：内存占用低（O(N√N)）、计算速度快（融合CUDA内核）
        参数：
            key_padding_mask - 键填充掩码（忽略无效序列）
            need_weights - 是否返回注意力权重（Flash注意力通常不支持，默认False）
            require_qkv - 是否返回QKV（用于调试）
        返回：注意力输出 + 可选QKV
        """
        B, N, C = x.shape  # 解析输入维度

        # 步骤1：生成QKV并维度重排（适配Flash注意力格式）
        qkv = self.qkv(x)  # [B, N, 3C]
        # 重排为：[B, N, 3, H, D]（3=Q/K/V，H=头数，D=单头维度）
        qkv = rearrange(qkv, "b s (three h d) -> b s three h d", three=3, h=self.num_heads)

        # 步骤2：Q/K归一化（可选）
        if self.qk_normalization:
            q, k, v = qkv.unbind(2)  # 拆分Q/K/V：各[B, N, H, D]
            if self.use_fused_rmsnorm:
                # 融合RMS归一化（Flash注意力专用，低精度优化）
                q = self.q_norm(q.flatten(-2, -1))[0].view(q.shape)
                k = self.k_norm(k.flatten(-2, -1))[0].view(k.shape)
            else:
                # 普通归一化
                q = self.q_norm(q.flatten(-2, -1)).view(q.shape)
                k = self.k_norm(k.flatten(-2, -1)).view(k.shape)
            qkv = torch.stack([q, k, v], dim=2)  # 重组QKV：[B, N, 3, H, D]

        # 步骤3：局部位置增强（LPE，可选，作用于V）
        v_lpe = None
        if self.use_lpe:
            q, k, v = qkv.unbind(2)  # 拆分Q/K/V
            # V维度重排：[B, N, H, D]→[B, N, C]→[B, C, N]（适配3D卷积）
            lpe = v.reshape(B, N, -1).contiguous().permute(0, 2, 1)
            B, C, N = lpe.shape
            # 扩展为3D特征：[B, C, N]→[B, C, 1, N, 1]
            lpe = lpe.reshape(B, C, 1, N, 1)
            # LPE增强→重排为[B, N, C]
            lpe = self.lpe(lpe).squeeze().permute(0, 2, 1)

        # 步骤4：Flash注意力计算
        context, _ = self.inner_attn(
            qkv, key_padding_mask=key_padding_mask, need_weights=need_weights, causal=self.causal
        )  # context: [B, N, H, D]（注意力输出）

        # 步骤5：融合LPE（可选）+ 输出投影
        if self.use_lpe:
            # 重排context→[B, N, C] + LPE→投影
            outs = self.proj(rearrange(context, "b s h d -> b s (h d)") + lpe)
        else:
            # 直接重排+投影
            outs = self.proj(rearrange(context, "b s h d -> b s (h d)"))
        outs = self.proj_drop(outs)  # 输出Dropout

        # 步骤6：返回输出与可选QKV
        if require_qkv:
            return outs, qkv
        else:
            return outs

    def forward(self, x, return_attn=False):
        """
        前向传播：根据开关选择朴素注意力或Flash注意力
        参数：return_attn - 是否返回注意力权重（仅朴素注意力支持）
        返回：注意力输出 + 可选注意力权重
        """
        if not self.use_flash_attn:
            # 朴素注意力：支持返回权重
            return self._naive_attn(x, return_attn=return_attn)
        else:
            # Flash注意力：不支持返回权重（效率优先）
            return self._flash_attn(x)


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    x = torch.randn(2, 32 * 32, 64).to(device)

    model = Attention(dim=64, use_flash_attn=False, use_lpe=True)
    model.to(device)

    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("知乎、CSDN：十小大")
    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)