import torch
import torch.nn as nn
from timm.models.layers import trunc_normal_
import math
import pywt
from torch.autograd import Function

class DWT_Function(Function):
    @staticmethod
    def forward(ctx, x, w_ll, w_lh, w_hl, w_hh):
        x = x.contiguous()
        ctx.save_for_backward(w_ll, w_lh, w_hl, w_hh)
        ctx.shape = x.shape

        dim = x.shape[1]
        x_ll = torch.nn.functional.conv2d(x, w_ll.expand(dim, -1, -1, -1), stride=2, groups=dim)
        x_lh = torch.nn.functional.conv2d(x, w_lh.expand(dim, -1, -1, -1), stride=2, groups=dim)
        x_hl = torch.nn.functional.conv2d(x, w_hl.expand(dim, -1, -1, -1), stride=2, groups=dim)
        x_hh = torch.nn.functional.conv2d(x, w_hh.expand(dim, -1, -1, -1), stride=2, groups=dim)
        x = torch.cat([x_ll, x_lh, x_hl, x_hh], dim=1)
        return x

    @staticmethod
    def backward(ctx, dx):
        if ctx.needs_input_grad[0]:
            w_ll, w_lh, w_hl, w_hh = ctx.saved_tensors
            B, C, H, W = ctx.shape
            dx = dx.view(B, 4, -1, H // 2, W // 2)

            dx = dx.transpose(1, 2).reshape(B, -1, H // 2, W // 2)
            filters = torch.cat([w_ll, w_lh, w_hl, w_hh], dim=0).repeat(C, 1, 1, 1)
            dx = torch.nn.functional.conv_transpose2d(dx, filters, stride=2, groups=C)

        return dx, None, None, None, None


class IDWT_Function(Function):
    @staticmethod
    def forward(ctx, x, filters):
        ctx.save_for_backward(filters)
        ctx.shape = x.shape

        B, _, H, W = x.shape
        x = x.view(B, 4, -1, H, W).transpose(1, 2)
        C = x.shape[1]
        x = x.reshape(B, -1, H, W)
        filters = filters.repeat(C, 1, 1, 1)
        x = torch.nn.functional.conv_transpose2d(x, filters, stride=2, groups=C)
        return x

    @staticmethod
    def backward(ctx, dx):
        if ctx.needs_input_grad[0]:
            filters = ctx.saved_tensors
            filters = filters[0]
            B, C, H, W = ctx.shape
            C = C // 4
            dx = dx.contiguous()

            w_ll, w_lh, w_hl, w_hh = torch.unbind(filters, dim=0)
            x_ll = torch.nn.functional.conv2d(dx, w_ll.unsqueeze(1).expand(C, -1, -1, -1), stride=2, groups=C)
            x_lh = torch.nn.functional.conv2d(dx, w_lh.unsqueeze(1).expand(C, -1, -1, -1), stride=2, groups=C)
            x_hl = torch.nn.functional.conv2d(dx, w_hl.unsqueeze(1).expand(C, -1, -1, -1), stride=2, groups=C)
            x_hh = torch.nn.functional.conv2d(dx, w_hh.unsqueeze(1).expand(C, -1, -1, -1), stride=2, groups=C)
            dx = torch.cat([x_ll, x_lh, x_hl, x_hh], dim=1)
        return dx, None


class IDWT_2D(nn.Module):
    def __init__(self, wave):
        super(IDWT_2D, self).__init__()
        w = pywt.Wavelet(wave)
        rec_hi = torch.Tensor(w.rec_hi)
        rec_lo = torch.Tensor(w.rec_lo)

        w_ll = rec_lo.unsqueeze(0) * rec_lo.unsqueeze(1)
        w_lh = rec_lo.unsqueeze(0) * rec_hi.unsqueeze(1)
        w_hl = rec_hi.unsqueeze(0) * rec_lo.unsqueeze(1)
        w_hh = rec_hi.unsqueeze(0) * rec_hi.unsqueeze(1)

        w_ll = w_ll.unsqueeze(0).unsqueeze(1)
        w_lh = w_lh.unsqueeze(0).unsqueeze(1)
        w_hl = w_hl.unsqueeze(0).unsqueeze(1)
        w_hh = w_hh.unsqueeze(0).unsqueeze(1)
        filters = torch.cat([w_ll, w_lh, w_hl, w_hh], dim=0)
        self.register_buffer('filters', filters)
        self.filters = self.filters.to(dtype=torch.float32)

    def forward(self, x):
        return IDWT_Function.apply(x, self.filters)

class DWT_2D(nn.Module):
    def __init__(self, wave):
        super(DWT_2D, self).__init__()
        w = pywt.Wavelet(wave)
        dec_hi = torch.Tensor(w.dec_hi[::-1])
        dec_lo = torch.Tensor(w.dec_lo[::-1])

        w_ll = dec_lo.unsqueeze(0) * dec_lo.unsqueeze(1)
        w_lh = dec_lo.unsqueeze(0) * dec_hi.unsqueeze(1)
        w_hl = dec_hi.unsqueeze(0) * dec_lo.unsqueeze(1)
        w_hh = dec_hi.unsqueeze(0) * dec_hi.unsqueeze(1)

        self.register_buffer('w_ll', w_ll.unsqueeze(0).unsqueeze(0))
        self.register_buffer('w_lh', w_lh.unsqueeze(0).unsqueeze(0))
        self.register_buffer('w_hl', w_hl.unsqueeze(0).unsqueeze(0))
        self.register_buffer('w_hh', w_hh.unsqueeze(0).unsqueeze(0))

        self.w_ll = self.w_ll.to(dtype=torch.float32)
        self.w_lh = self.w_lh.to(dtype=torch.float32)
        self.w_hl = self.w_hl.to(dtype=torch.float32)
        self.w_hh = self.w_hh.to(dtype=torch.float32)

    def forward(self, x):
        return DWT_Function.apply(x, self.w_ll, self.w_lh, self.w_hl, self.w_hh)


class WaveAttention(nn.Module):
    """
    小波多头注意力（WaveMHA）：融合小波变换与多头注意力，增强高频细节捕捉
    核心创新：
        1. 频域注意力：在小波分解的频域空间计算注意力，聚焦高频细节（如纹理、边缘）；
        2. 高低频融合：DWT分解→注意力增强→IDWT重构，兼顾全局结构与局部细节；
        3. 轻量化设计：小波降采样减少注意力计算量，比传统MHA效率高4倍；
        4. 即插即用：输入输出维度一致，可替换传统MHA。
    输入：
        x: 特征序列 [B, N, C]（N=H×W，序列长度；C=通道数）
        H/W: 原始特征图的高/宽（用于维度重排）
    输出：
        注意力增强特征 [B, N, C]（与输入维度一致）
    """

    def __init__(self, dim, num_heads, sr_ratio):
        super().__init__()
        self.num_heads = num_heads  # 注意力头数
        self.head_dim = dim // num_heads  # 单头通道数
        self.scale = self.head_dim ** -0.5  # 注意力缩放因子（缓解梯度消失）
        self.sr_ratio = sr_ratio  # 空间降采样比例（进一步降低计算量）

        # 小波变换模块（默认haar小波，平衡效率与细节捕捉）
        self.dwt = DWT_2D(wave='haar')  # 离散小波分解
        self.idwt = IDWT_2D(wave='haar')  # 逆离散小波重构

        # 高频特征通道压缩：降低IDWT重构的计算量（dim→dim//4）
        self.reduce = nn.Sequential(
            nn.Conv2d(dim, dim // 4, kernel_size=1, padding=0, stride=1),  # 通道压缩
            nn.BatchNorm2d(dim // 4),  # 稳定训练
            nn.ReLU(inplace=True),  # 非线性激活
        )

        # 高频特征滤波：增强小波分解后的高频细节（如去噪、边缘增强）
        self.filter = nn.Sequential(
            nn.Conv2d(dim, dim, kernel_size=3, padding=1, stride=1, groups=1),  # 3×3卷积
            nn.BatchNorm2d(dim),
            nn.ReLU(inplace=True),
        )

        # K/V空间降采样：sr_ratio>1时用卷积降采样，减少注意力计算量
        self.kv_embed = nn.Conv2d(
            dim, dim, kernel_size=sr_ratio, stride=sr_ratio
        ) if sr_ratio > 1 else nn.Identity()

        # Q/K/V投影层
        self.q = nn.Linear(dim, dim)  # Query投影（序列域）
        self.kv = nn.Sequential(
            nn.LayerNorm(dim),  # K/V归一化（稳定注意力计算）
            nn.Linear(dim, dim * 2)  # 一次性生成K和V（频域空间）
        )

        # 输出投影：融合注意力特征与IDWT重构特征（dim + dim//4 → dim）
        self.proj = nn.Linear(dim + dim // 4, dim)

        # 参数初始化
        self.apply(self._init_weights)

    def _init_weights(self, m):
        """参数初始化：确保各层参数分布合理，避免梯度消失"""
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=.02)  # 线性层权重截断正态分布初始化
            if m.bias is not None:
                nn.init.constant_(m.bias, 0)  # 偏置初始化为0
        elif isinstance(m, nn.LayerNorm):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)  # LN权重初始化为1
        elif isinstance(m, nn.Conv2d):
            # 卷积层权重He初始化（适配ReLU激活）
            fan_out = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
            fan_out //= m.groups
            m.weight.data.normal_(0, math.sqrt(2.0 / fan_out))
            if m.bias is not None:
                m.bias.data.zero_()

    def forward(self, x, H, W):
        """
        前向传播流程：序列→空间维度重排→DWT分解→频域注意力→IDWT重构→特征融合→输出
        """
        B, N, C = x.shape  # 解析输入维度：批次、序列长度、通道数

        # 步骤1：生成Query（Q）并适配多头格式
        q = self.q(x).reshape(B, N, self.num_heads, C // self.num_heads).permute(0, 2, 1, 3)
        # Q维度：[B, num_heads, N, head_dim]

        # 步骤2：序列→空间维度重排（适配小波变换）
        x = x.view(B, H, W, C).permute(0, 3, 1, 2)  # [B, C, H, W]

        # 步骤3：小波分解（DWT）与高频特征处理
        # 通道压缩→DWT分解（尺寸减半，通道×4）→高频滤波
        x_dwt = self.dwt(self.reduce(x))  # [B, C//4×4, H//2, W//2] = [B, C, H//2, W//2]
        x_dwt = self.filter(x_dwt)  # 增强高频细节（如边缘、纹理）

        # 步骤4：生成Key（K）和Value（V）（频域空间）
        # K/V空间降采样→维度重排（空间→序列）→K/V投影→多头适配
        kv = self.kv_embed(x_dwt).reshape(B, C, -1).permute(0, 2, 1)  # [B, N//(4×sr_ratio²), C]
        kv = self.kv(kv).reshape(B, -1, 2, self.num_heads, C // self.num_heads).permute(2, 0, 3, 1, 4)
        k, v = kv[0], kv[1]  # K/V维度：[B, num_heads, N_kv, head_dim]

        # 步骤5：频域多头注意力计算
        attn = (q @ k.transpose(-2, -1)) * self.scale  # QK^T×缩放因子：[B, num_heads, N, N_kv]
        attn = attn.softmax(dim=-1)  # 注意力权重归一化
        attn = attn  # 可添加Dropout（代码中未实现，可自行扩展）

        # 步骤6：注意力加权Value（V）并恢复维度
        x_attn = (attn @ v).transpose(1, 2).reshape(B, N, C)  # [B, N, C]

        # 步骤7：IDWT重构高频特征（恢复原始尺寸）
        x_idwt = self.idwt(x_dwt)  # [B, C//4, H, W]（尺寸恢复为H×W）
        # 重构特征→序列维度：[B, C//4, H, W]→[B, H×W, C//4]
        x_idwt = x_idwt.view(B, -1, x_idwt.size(-2) * x_idwt.size(-1)).transpose(1, 2)

        # 步骤8：特征融合（注意力特征 + IDWT重构特征）→输出投影
        x = self.proj(torch.cat([x_attn, x_idwt], dim=-1))  # [B, N, C + C//4]→[B, N, C]

        return x

if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 32*32, 64).to(device)
    model = WaveAttention(64, 4, 1)

    model.to(device)
    y = model(x, 32, 32)

    print("微信公众号：十小大的底层视觉工坊")
    print("知乎、CSDN：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)
