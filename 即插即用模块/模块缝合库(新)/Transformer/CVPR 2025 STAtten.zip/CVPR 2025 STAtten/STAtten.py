from spikingjelly.clock_driven.neuron import MultiStepLIFNode  # 多步长LIF神经元（SNN核心组件）
import torch
import torch.nn as nn

class dvs_pooling(nn.Module):
    """
    DVS数据专用池化模块：针对事件相机的3D脉冲序列（T×B×C×H×W）设计
    功能：在时间维度保持完整的同时，对空间维度进行最大池化，抑制噪声并保留关键空间特征
    输入：脉冲序列 [T, B, C, H, W]（T=时间步，B=批次，C=通道，H/W=空间尺寸）
    输出：池化后序列 [T, B, C, H, W]（空间尺寸不变，时间维度无压缩）
    """

    def __init__(self) -> None:
        super().__init__()
        self.pool = nn.MaxPool3d(
            kernel_size=(1, 3, 3),  # 时间维度不池化（1），空间维度3×3池化
            stride=(1, 1, 1),  # 步长1，保持空间尺寸
            padding=(0, 1, 1)  # 空间维度padding=1，确保池化后尺寸不变
        )

    def forward(self, x):
        return self.pool(x)


class MS_SSA_Conv(nn.Module):
    """
    多步长时空自注意力卷积模块（STAtten核心实现）：融合脉冲神经元与时空联合注意力
    核心创新：
        1. 脉冲驱动QKV生成：用LIF神经元实现二值化Q/K/V，适配SNN低功耗特性；
        2. 分块时空注意力：时间维度分块处理，平衡时序建模与计算效率；
        3. 即插即用设计：兼容DVS数据与常规视频序列，支持多注意力模式切换。
    输入：
        x: 脉冲序列 [T, B, C, H, W]
        hook: 钩子函数（可选，用于特征可视化与调试）
    输出：
        x: 时空增强后的脉冲序列 [T, B, C, H, W]
        v: 中间值特征 V（用于后续模块复用）
        hook: 含调试信息的钩子字典
    """

    def __init__(
            self,
            dim,  # 输入特征通道数（需被num_heads整除）
            num_heads=8,  # 注意力头数（默认8，适配多尺度空间特征）
            mode="direct_xor",  # 脉冲融合模式（预留，用于脉冲二值化逻辑）
            dvs=False,  # 是否处理DVS事件数据（True时启用dvs_pooling）
            layer=0,  # 模块所在网络层数（用于钩子命名）
            attention_mode="T_STAtten",  # 注意力模式："STAtten"（时空）/"SDT"（脉冲驱动）
            chunk_size=2,  # 时间分块大小（如2表示每2个时间步为一个块）
            spike_mode="lif"  # 脉冲神经元类型（默认LIF，Leaky Integrate-and-Fire）
    ):
        super().__init__()
        # 校验通道数与头数兼容性（确保每头通道数为整数）
        assert (
                dim % num_heads == 0
        ), f"通道数 {dim} 需能被注意力头数 {num_heads} 整除"

        self.dim = dim
        self.dvs = dvs  # DVS数据处理开关
        self.num_heads = num_heads  # 注意力头数
        self.attention_mode = attention_mode  # 注意力模式
        self.chunk_size = chunk_size  # 时间分块大小

        # DVS数据专用池化（抑制空间噪声）
        if dvs:
            self.pool = dvs_pooling()

        self.scale = 0.125  # 注意力缩放因子（缓解梯度消失）

        # -------------------------- Q/K/V生成模块（脉冲驱动）--------------------------
        # Q生成：1×1卷积（通道映射）→ BN（稳定训练）→ LIF神经元（二值化）
        self.q_conv = nn.Conv2d(dim, dim, kernel_size=1, stride=1, bias=False)
        self.q_bn = nn.BatchNorm2d(dim)
        self.q_lif = MultiStepLIFNode(tau=2.0, detach_reset=True, backend="cupy")  # LIF神经元，tau=2.0控制膜电位衰减

        # K生成（与Q结构一致，确保维度匹配）
        self.k_conv = nn.Conv2d(dim, dim, kernel_size=1, stride=1, bias=False)
        self.k_bn = nn.BatchNorm2d(dim)
        self.k_lif = MultiStepLIFNode(tau=2.0, detach_reset=True, backend="cupy")

        # V生成（与Q结构一致，用于注意力加权）
        self.v_conv = nn.Conv2d(dim, dim, kernel_size=1, stride=1, bias=False)
        self.v_bn = nn.BatchNorm2d(dim)
        self.v_lif = MultiStepLIFNode(tau=2.0, detach_reset=True, backend="cupy")

        # -------------------------- 注意力与输出模块 --------------------------
        # 注意力结果脉冲神经元（阈值0.5，增强二值化锐度）
        self.attn_lif = MultiStepLIFNode(tau=2.0, v_threshold=0.5, detach_reset=True, backend="cupy")
        # 多头注意力通信（1×1卷积，融合多头信息）
        self.talking_heads = nn.Conv1d(num_heads, num_heads, kernel_size=1, stride=1, bias=False)
        self.talking_heads_lif = MultiStepLIFNode(tau=2.0, v_threshold=0.5, detach_reset=True, backend="cupy")

        # 输出投影（恢复通道维度）→ BN（稳定特征）
        self.proj_conv = nn.Conv2d(dim, dim, kernel_size=1, stride=1)
        self.proj_bn = nn.BatchNorm2d(dim)

        # 残差连接脉冲神经元（保留原始特征，避免梯度消失）
        self.shortcut_lif = MultiStepLIFNode(tau=2.0, detach_reset=True, backend="cupy")

        # 辅助参数（模式、层数，用于钩子命名与调试）
        self.mode = mode
        self.layer = layer

    def forward(self, x, hook=None):
        # 解析输入维度：T=时间步，B=批次，C=通道，H/W=空间尺寸
        T, B, C, H, W = x.shape
        head_dim = C // self.num_heads  # 单头通道数（如64//8=8）
        identity = x  # 残差连接的原始特征
        N = H * W  # 空间像素总数（如32×32=1024）

        # 残差分支脉冲处理（保留原始特征结构）
        x = self.shortcut_lif(x)
        # 钩子记录：保存首次LIF处理后的特征（用于调试）
        if hook is not None:
            hook[self._get_name() + str(self.layer) + "_first_lif"] = x.detach()

        # DVS数据空间池化（抑制噪声，仅DVS模式启用）
        if self.dvs:
            x_pool = self.pool(x)

        # 维度调整：将时间步与批次合并（T×B），适配2D卷积输入格式
        x_for_qkv = x.flatten(0, 1)  # [T×B, C, H, W]

        # -------------------------- 1. 生成Q（查询）--------------------------
        q_conv_out = self.q_conv(x_for_qkv)  # 1×1卷积：[T×B, C, H, W]
        # 维度恢复+BN+LIF神经元二值化：[T×B, C, H, W]→[T, B, C, H, W]→[T, B, C, H, W]
        q_conv_out = self.q_bn(q_conv_out).reshape(T, B, C, H, W).contiguous()
        q_conv_out = self.q_lif(q_conv_out)
        # DVS模式下对Q进行空间池化
        if self.dvs:
            q_conv_out = self.pool(q_conv_out)
        # 钩子记录Q的LIF输出
        if hook is not None:
            hook[self._get_name() + str(self.layer) + "_q_lif"] = q_conv_out.detach()

        # Q维度重排：适配多头注意力格式
        # [T, B, C, H, W]→[T, B, N, num_heads, head_dim]→[T, B, num_heads, N, head_dim]
        q = (q_conv_out.flatten(3).transpose(-1, -2).reshape(
            T, B, N, self.num_heads, C // self.num_heads
        ).permute(0, 1, 3, 2, 4).contiguous())

        # -------------------------- 2. 生成K（键）--------------------------
        k_conv_out = self.k_conv(x_for_qkv)  # 1×1卷积：[T×B, C, H, W]
        k_conv_out = self.k_bn(k_conv_out).reshape(T, B, C, H, W).contiguous()  # 维度恢复+BN
        k_conv_out = self.k_lif(k_conv_out)  # LIF二值化
        if self.dvs:
            k_conv_out = self.pool(k_conv_out)  # DVS空间池化
        if hook is not None:
            hook[self._get_name() + str(self.layer) + "_k_lif"] = k_conv_out.detach()

        # K维度重排（与Q一致，确保矩阵乘法兼容）
        k = (k_conv_out.flatten(3).transpose(-1, -2).reshape(
            T, B, N, self.num_heads, C // self.num_heads
        ).permute(0, 1, 3, 2, 4).contiguous())

        # -------------------------- 3. 生成V（值）--------------------------
        v_conv_out = self.v_conv(x_for_qkv)  # 1×1卷积：[T×B, C, H, W]
        v_conv_out = self.v_bn(v_conv_out).reshape(T, B, C, H, W).contiguous()  # 维度恢复+BN
        v_conv_out = self.v_lif(v_conv_out)  # LIF二值化
        if self.dvs:
            v_conv_out = self.pool(v_conv_out)  # DVS空间池化
        if hook is not None:
            hook[self._get_name() + str(self.layer) + "_v_lif"] = v_conv_out.detach()

        # V维度重排（与Q/K一致）
        v = (v_conv_out.flatten(3).transpose(-1, -2).reshape(
            T, B, N, self.num_heads, C // self.num_heads
        ).permute(0, 1, 3, 2, 4).contiguous())

        # -------------------------- 4. 注意力计算（分模式处理）--------------------------
        if self.attention_mode == "STAtten":
            # 时空注意力模式：分块处理时间维度，联合建模时空依赖
            # 计算缩放因子（DVS数据按空间尺寸调整，常规数据按H调整）
            if self.dvs:
                scaling_factor = 1 / (H * H * self.chunk_size)
            else:
                scaling_factor = 1 / H

            # 时间分块：将T个时间步拆分为num_chunks个块（每块chunk_size个时间步）
            num_chunks = T // self.chunk_size
            # 维度重排：[T, B, num_heads, N, head_dim]→[num_chunks, B, num_heads, chunk_size, N, head_dim]
            q_chunks = q.view(num_chunks, self.chunk_size, B, self.num_heads, N, head_dim).permute(0, 2, 3, 1, 4, 5)
            k_chunks = k.view(num_chunks, self.chunk_size, B, self.num_heads, N, head_dim).permute(0, 2, 3, 1, 4, 5)
            v_chunks = v.view(num_chunks, self.chunk_size, B, self.num_heads, N, head_dim).permute(0, 2, 3, 1, 4, 5)

            # 合并时间块与空间维度：便于批量计算注意力（chunk_size×N为新的序列长度）
            q_chunks = q_chunks.reshape(num_chunks, B, self.num_heads, self.chunk_size * N, head_dim)
            k_chunks = k_chunks.reshape(num_chunks, B, self.num_heads, self.chunk_size * N, head_dim)
            v_chunks = v_chunks.reshape(num_chunks, B, self.num_heads, self.chunk_size * N, head_dim)

            # 时空注意力计算（批量处理所有块）
            # K^T @ V：计算全局上下文（[num_chunks, B, num_heads, head_dim, head_dim]）
            attn = torch.matmul(k_chunks.transpose(-2, -1), v_chunks) * scaling_factor
            # Q @ 上下文：得到注意力输出（[num_chunks, B, num_heads, chunk_size×N, head_dim]）
            out = torch.matmul(q_chunks, attn)

            # 维度恢复：拆分时间块与空间维度→合并块为完整时间步
            out = out.reshape(num_chunks, B, self.num_heads, self.chunk_size, N, head_dim).permute(0, 3, 1, 2, 4, 5)
            output = out.reshape(T, B, self.num_heads, N, head_dim)  # [T, B, num_heads, N, head_dim]

            # 维度重排+脉冲处理：[T, B, num_heads, N, head_dim]→[T, B, C, H, W]
            x = output.transpose(4, 3).reshape(T, B, C, N).contiguous()
            x = self.attn_lif(x).reshape(T, B, C, H, W)

            # DVS模式下融合池化特征（增强空间鲁棒性）
            if self.dvs:
                x = x.mul(x_pool)  # 逐元素乘法：突出池化后的关键区域
                x = x + x_pool  # 残差融合：保留池化特征

            # 钩子记录注意力后特征
            if hook is not None:
                hook[self._get_name() + str(self.layer) + "_after_qkv"] = x

            # 输出投影：1×1卷积增强特征→BN稳定分布
            x = (
                self.proj_bn(self.proj_conv(x.flatten(0, 1)))
                .reshape(T, B, C, H, W)
                .contiguous()
            )

        elif self.attention_mode == "SDT":
            # 脉冲驱动Transformer模式（SDT）：简化注意力计算，降低能耗
            kv = k.mul(v)  # K与V逐元素乘法：压缩维度，减少计算
            if hook is not None:
                hook[self._get_name() + str(self.layer) + "_kv_before"] = kv

            # DVS模式下池化（抑制噪声）
            if self.dvs:
                kv = self.pool(kv)

            # 空间维度求和+多头通信：[T, B, num_heads, N, head_dim]→[T, B, num_heads, 1, head_dim]
            kv = kv.sum(dim=-2, keepdim=True)
            kv = self.talking_heads_lif(kv)  # 脉冲神经元二值化
            if hook is not None:
                hook[self._get_name() + str(self.layer) + "_kv"] = kv.detach()

            # Q与KV逐元素乘法：得到注意力输出
            x = q.mul(kv)
            if self.dvs:
                x = self.pool(x)  # DVS空间池化
            if hook is not None:
                hook[self._get_name() + str(self.layer) + "_x_after_qkv"] = x.detach()

            # 维度重排+输出投影
            x = x.transpose(3, 4).reshape(T, B, C, H, W).contiguous()
            x = (
                self.proj_bn(self.proj_conv(x.flatten(0, 1)))
                .reshape(T, B, C, H, W)
                .contiguous()
            )

        else:
            raise ValueError(f"不支持的注意力模式：{self.attention_mode}，仅支持'STAtten'或'SDT'")

        # 残差连接：注意力输出 + 原始特征（保留初始信息，避免梯度消失）
        x = x + identity
        return x, v, hook


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    x = torch.randn(4, 1, 64, 32, 32).to(device) # [T, B, C, H, W]

    model = MS_SSA_Conv(64)
    model.to(device)

    y, _, _ = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("知乎、CSDN：十小大")
    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)