import torch
import torch.nn as nn
import numpy as np
import torch.nn.functional as F


class LRSA(nn.Module):
    """
    低分辨率自注意力模块（Low-Resolution Self-Attention, LRSA）
    核心设计：通过“查询（Q）低分辨率采样+键值（K/V）金字塔池化”，在降低注意力计算复杂度的同时，
    保留全局依赖建模能力，适配高分辨率视觉任务
    """

    def __init__(self, dim, num_heads=2, qkv_bias=False, qk_scale=None, attn_drop=0., proj_drop=0.,
                 pooled_sizes=[11, 8, 6, 4], q_pooled_size=1, q_conv=False):
        """
        Args:
            dim (int): 输入特征的通道数（需与上游模块输出通道一致，如代码示例中为64）
            num_heads (int): 多头注意力的头数（默认2，需满足dim能被num_heads整除）
            qkv_bias (bool): 生成Q/K/V的线性层是否使用偏置（默认False，减少参数冗余）
            qk_scale (float): 注意力缩放因子（默认None，自动使用1/√(dim//num_heads)）
            attn_drop (float): 注意力权重的Dropout概率（默认0.，抑制过拟合）
            proj_drop (float): 输出投影层的Dropout概率（默认0.，抑制过拟合）
            pooled_sizes (list): K/V金字塔池化的目标尺寸列表（如[11,8,6,4]，多尺度捕捉全局信息）
            q_pooled_size (int): Q的低分辨率采样尺寸（默认1，即不采样；>1时按比例缩小Q的空间维度）
            q_conv (bool): 是否对Q使用深度可分离卷积增强（默认False，True时启用3×3深度卷积）
        """
        super().__init__()
        # 校验：确保通道数dim能被注意力头数num_heads整除（多头注意力的基础要求）
        assert dim % num_heads == 0, f"dim {dim} should be divided by num_heads {num_heads}."

        self.dim = dim  # 输入/输出通道数
        self.num_heads = num_heads  # 注意力头数
        # 计算K/V金字塔池化的总元素数（用于校验维度，无实际计算作用）
        self.num_elements = np.array([t * t for t in pooled_sizes]).sum()
        self.head_dim = dim // num_heads  # 单头注意力的通道数
        # 注意力缩放因子：若未指定qk_scale，使用1/√(单头通道数)，缓解Q·K^T点积过大导致的Softmax饱和
        self.scale = qk_scale or self.head_dim ** -0.5

        # Q/K/V生成模块：线性层（无激活，仅做维度映射）
        self.q = nn.Sequential(nn.Linear(dim, dim, bias=qkv_bias))  # Q生成：dim→dim
        self.kv = nn.Sequential(nn.Linear(dim, dim * 2, bias=qkv_bias))  # K/V生成：dim→2×dim

        # Dropout层：注意力权重失活与输出投影失活
        self.attn_drop = nn.Dropout(attn_drop)
        self.proj = nn.Linear(dim, dim)  # 输出投影层：将多头注意力结果映射回dim通道
        self.proj_drop = nn.Dropout(proj_drop)

        self.pooled_sizes = pooled_sizes  # 保存K/V金字塔池化尺寸列表
        self.eps = 0.001  # 数值稳定性参数（用于计算池化尺寸比例时避免整除误差）
        self.norm = nn.LayerNorm(dim)  # K/V金字塔池化后的归一化层，稳定注意力计算

        self.q_pooled_size = q_pooled_size  # 保存Q的低分辨率采样尺寸
        # Q的增强分支（可选）：仅当q_conv=True且q_pooled_size>1时启用
        if q_conv and self.q_pooled_size > 1:
            # 3×3深度可分离卷积：增强Q的局部特征（groups=dim确保逐通道卷积，减少参数量）
            self.q_conv = nn.Conv2d(dim, dim, kernel_size=3, padding=1, stride=1, groups=dim)
            self.q_norm = nn.LayerNorm(dim)  # Q卷积后的归一化层
        else:
            self.q_conv = None  # 禁用Q卷积分支
            self.q_norm = None  # 禁用Q归一化分支

    def forward(self, x, H, W, d_convs=None):
        """
        LRSA前向传播流程：Q低分辨率采样→K/V金字塔池化→多头注意力计算→输出投影→残差维度匹配
        Args:
            x (torch.Tensor): 输入特征，形状为 [B, N, C]（B=批量，N=空间序列长度=H×W，C=通道数=dim）
            H (int/float): 输入特征的原始高度（需转为整数）
            W (int/float): 输入特征的原始宽度（需转为整数）
            d_convs (nn.ModuleList): 与pooled_sizes对应的深度可分离卷积列表（用于增强K/V的局部特征）
        Returns:
            torch.Tensor: 输出特征，形状与输入完全一致 [B, N, C]，支持模块级联
        """
        B, N, C = x.shape  # 解析输入维度（B=批量，N=H×W，C=dim）
        H, W = int(H), int(W)  # 确保H/W为整数（避免浮点型尺寸导致的错误）

        # 步骤1：生成低分辨率查询Q（Query）
        if self.q_pooled_size > 1:
            # 计算Q的采样尺寸：保持原始H/W比例（避免拉伸变形）
            if W >= H:
                # 若宽度≥高度，按高度比例计算宽度采样尺寸（四舍五入，eps确保精度）
                q_pooled_size = (self.q_pooled_size, round(W * float(self.q_pooled_size) / H + self.eps))
            else:
                # 若高度>宽度，按宽度比例计算高度采样尺寸
                q_pooled_size = (round(H * float(self.q_pooled_size) / W + self.eps), self.q_pooled_size)

            # Q的低分辨率采样：自适应平均池化（将[N,C]→[H,W,C]→池化→[H1,W1,C]）
            # 维度转换：[B,N,C] → [B,C,H,W]（适配池化输入格式）
            q = F.adaptive_avg_pool2d(x.transpose(1, 2).reshape(B, C, H, W), q_pooled_size)
            _, _, H1, W1 = q.shape  # 解析Q采样后的高度H1、宽度W1

            # 可选：Q的深度卷积增强（若启用q_conv）
            if self.q_conv is not None:
                q = q + self.q_conv(q)  # 残差融合：原始Q + 卷积增强Q
                # 维度转换：[B,C,H1,W1] → [B,C,H1×W1] → [B,H1×W1,C]（适配LayerNorm输入）
                q = self.q_norm(q.view(B, C, -1).transpose(1, 2))
            else:
                # 禁用卷积时直接转换维度
                q = q.view(B, C, -1).transpose(1, 2)  # [B,H1×W1,C]

            # Q的线性映射与多头维度重排：[B,H1×W1,C] → [B,H1×W1,num_heads,head_dim] → [B,num_heads,H1×W1,head_dim]
            q = self.q(q).reshape(B, -1, self.num_heads, C // self.num_heads).permute(0, 2, 1, 3).contiguous()
        else:
            # Q不采样（q_pooled_size=1），保持原始分辨率
            H1, W1 = H, W  # Q的尺寸与原始输入一致

            # 可选：Q的深度卷积增强（若启用q_conv）
            if self.q_conv is not None:
                # 维度转换：[B,N,C] → [B,C,H,W]（适配卷积输入）
                x1 = x.view(B, -1, C).transpose(1, 2).reshape(B, C, H1, W1)
                q = x1 + self.q_conv(x1)  # 残差融合：原始Q + 卷积增强Q
                # 维度转换：[B,C,H,W] → [B,H×W,C]（适配LayerNorm与线性层）
                q = self.q_norm(q.view(B, C, -1).transpose(1, 2))
                # Q的线性映射与多头重排
                q = self.q(q).reshape(B, -1, self.num_heads, C // self.num_heads).permute(0, 2, 1, 3).contiguous()
            else:
                # 禁用卷积时，直接生成Q并多头重排
                q = self.q(x).reshape(B, -1, self.num_heads, C // self.num_heads).permute(0, 2, 1, 3).contiguous()

        # 步骤2：生成多尺度键值对K/V（Key/Value）—— 金字塔池化
        pools = []  # 存储各尺度池化后的K/V特征
        # 维度转换：[B,N,C] → [B,C,N] → [B,C,H,W]（适配池化输入）
        x_ = x.permute(0, 2, 1).reshape(B, C, H, W)

        # 遍历金字塔池化的每个尺度（与d_convs一一对应）
        for (pooled_size, l) in zip(self.pooled_sizes, d_convs):
            # 计算当前尺度的池化尺寸：保持H/W比例
            if W >= H:
                pooled_size = (pooled_size, round(W * pooled_size / H + self.eps))
            else:
                pooled_size = (round(H * pooled_size / W + self.eps), pooled_size)

            # 自适应平均池化：将[B,C,H,W]池化为[B,C,pooled_H,pooled_W]
            pool = F.adaptive_avg_pool2d(x_, pooled_size)
            # 残差融合：池化特征 + 深度卷积增强特征（l为深度可分离卷积，增强局部细节）
            pool = pool + l(pool)
            # 维度转换：[B,C,pooled_H,pooled_W] → [B,C,pooled_H×pooled_W]（展平空间维度）
            pools.append(pool.view(B, C, -1))

        # 多尺度特征拼接：将各尺度池化结果沿空间维度拼接 → [B,C,sum(pooled_H×pooled_W)]
        pools = torch.cat(pools, dim=2)
        # 维度转换与归一化：[B,C,sum_N] → [B,sum_N,C] → LayerNorm（稳定K/V特征分布）
        pools = self.norm(pools.permute(0, 2, 1))

        # K/V的线性映射与多头维度重排：
        # [B,sum_N,C] → [B,sum_N,2,num_heads,head_dim] → [2,B,num_heads,sum_N,head_dim]
        kv = self.kv(pools).reshape(B, -1, 2, self.num_heads, C // self.num_heads).permute(2, 0, 3, 1, 4)
        k, v = kv[0], kv[1]  # 拆分K和V：k=[B,num_heads,sum_N,head_dim], v=[B,num_heads,sum_N,head_dim]

        # 步骤3：多头自注意力计算
        # 计算注意力权重：Q·K^T × 缩放因子 → [B,num_heads,H1×W1,sum_N]
        attn = (q @ k.transpose(-2, -1)) * self.scale
        attn = attn.softmax(dim=-1)  # Softmax归一化：沿K的序列维度（sum_N）归一化
        attn = self.attn_drop(attn)  # 注意力权重失活

        # 注意力加权V：[B,num_heads,H1×W1,sum_N] × [B,num_heads,sum_N,head_dim] → [B,num_heads,H1×W1,head_dim]
        x = attn @ v
        # 多头结果拼接：[B,num_heads,H1×W1,head_dim] → [B,H1×W1,num_heads×head_dim] → [B,H1×W1,C]
        x = x.transpose(1, 2).reshape(B, -1, C)
        # 输出投影：线性层映射 + Dropout → [B,H1×W1,C]
        x = self.proj(x)
        x = self.proj_drop(x)

        # 步骤4：残差维度匹配（若Q采样后尺寸缩小，需上采样恢复原始尺寸）
        if self.q_pooled_size > 1:
            # 维度转换：[B,H1×W1,C] → [B,C,H1,W1]（适配插值输入）
            x = x.transpose(1, 2).reshape(B, C, H1, W1)
            # 双线性插值：将Q的低分辨率结果上采样至原始尺寸（H,W），align_corners=False避免边缘失真
            x = F.interpolate(x, size=(H, W), mode='bilinear', align_corners=False)
            # 维度转换：[B,C,H,W] → [B,C,H×W] → [B,H×W,C]（恢复输入格式[N,C]）
            x = x.view(B, C, -1).transpose(1, 2)

        # 输出与输入维度一致的特征：[B,N,C]
        return x


if __name__ == "__main__":
    B = 1  # batch size
    C = 64  # embedding dim
    H, W = 32, 32  # height and width
    N = H * W

    # 初始化输入
    x = torch.randn(B, N, C)  # 输入 shape: [B, N, C]

    # 设置 pooling sizes（对应 Pyramid Pooling）
    pooled_sizes = [11, 8, 6, 4]

    # 构造深度卷积模块 d_convs（与 pooled_sizes 一一对应）, 此处参考原论文和源代码
    d_convs = nn.ModuleList([
        nn.Conv2d(C, C, kernel_size=3, padding=1, groups=C) for _ in pooled_sizes
    ])

    # 实例
    attn = LRSA(
        dim=C,
        num_heads=4,
        qkv_bias=True,
        pooled_sizes=pooled_sizes,
        q_pooled_size=1,
        q_conv=False  # 可以设置为 True 来测试 conv 分支
    )

    y = attn(x, H, W, d_convs)

    print("微信公众号：十小大的底层视觉工坊")
    print("知乎、CSDN：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)
