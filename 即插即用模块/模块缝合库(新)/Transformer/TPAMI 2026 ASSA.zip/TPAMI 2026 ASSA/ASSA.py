# 自适应稀疏自注意力模块（Adaptive Sparse Self-Attention, ASSA）
# 核心设计：整合“动态深度卷积+自适应稀疏策略+训练-测试双模式”，通过“特征投影→动态增强→稀疏注意力计算→特征还原”的流程，
# 自适应控制注意力稀疏度，在训练时探索全局依赖，测试时通过局部窗口（TLC）提升推理效率，平衡模型性能与部署效率
# PS：需要在源码获取动态卷积模块：idynamic_dwconv.py，代码太长公众号省略

import torch
import torch.nn as nn
import torch.nn.functional as F
from einops import rearrange
from idynamic_dwconv import IDynamicDWConv


class MaskedSoftmax(nn.Module):
    def __init__(self):
        super(MaskedSoftmax, self).__init__()
        self.softmax = nn.Softmax(dim=-1)

    def forward(self, x):
        mask = x > 0

        x = self.softmax(x)

        x = torch.where(mask > 0, x, torch.zeros_like(x))

        return x


class TopK(nn.Module):
    def __init__(self):
        super(TopK, self).__init__()

    def forward(self, x):
        b, h, C, _ = x.shape

        mask = torch.zeros(b, h, C, C, device=x.device, requires_grad=False)

        index = torch.topk(x, k=int(C/4), dim=-1, largest=True)[1]

        mask.scatter_(-1, index, 1.)

        result = torch.where(mask > 0, x, torch.zeros_like(x))

        return result


# Sparse Self-Attention
class SparseSelfAttention(nn.Module):
    """
    自适应稀疏自注意力模块（Adaptive Sparse Self-Attention, ASSA）
    功能：动态特征增强+自适应稀疏注意力，平衡全局依赖捕捉与计算效率
    核心设计：
        - 动态深度卷积：IDynamicDWConv增强QV特征，提升局部依赖捕捉
        - 多稀疏策略适配：支持ReLU/Softmax/MaskedSoftmax/TopK/GELU/Sigmoid多种激活，灵活控制稀疏度
        - 训练-测试双模式：训练时全局稀疏注意力，测试时TLC局部窗口注意力，兼顾性能与推理速度
        - 可学习温度因子：自适应调整注意力分布锐度，优化稀疏关联
    Args:
        dim: 输入/输出通道数
        num_heads: 注意力头数
        bias: 输出投影是否带偏置（默认False）
        tlc_flag: 是否启用TLC测试模式（默认True）
        tlc_kernel: 测试时局部窗口尺寸（默认48）
        activation: 稀疏策略激活函数（默认'relu'）
    """
    def __init__(self, dim, num_heads, bias, tlc_flag=True, tlc_kernel=48, activation='relu'):
        super(SparseSelfAttention, self).__init__()
        self.tlc_flag = tlc_flag    # TLC flag for validation and test
        self.num_heads = num_heads
        self.temperature = nn.Parameter(torch.ones(num_heads, 1, 1))

        self.project_in = nn.Conv2d(dim, dim * 2, 1, bias=False)
        self.dynamic_conv = IDynamicDWConv(dim * 2, kernel_size=3, bias=False)
        self.project_out = nn.Conv2d(dim, dim, kernel_size=1, bias=bias)

        self.act = nn.Identity()
        if activation == 'relu':
            self.act = nn.ReLU()
        elif activation == 'softmax':
            self.act = nn.Softmax(dim=-1)
        elif activation == 'maskedsoftmax':
            self.act = MaskedSoftmax()
        elif activation == 'topk':
            self.act = TopK()
        elif activation == 'gelu':
            self.act = nn.GELU()
        elif activation == 'sigmoid':
            self.act = nn.Sigmoid()

        # [x2, x3, x4] -> [96, 72, 48]
        self.kernel_size = [tlc_kernel, tlc_kernel]

    def _forward(self, qv):
        q, v = qv.chunk(2, dim=1)

        q = rearrange(q, 'b (head c) h w -> b head c (h w)', head=self.num_heads)
        v = rearrange(v, 'b (head c) h w -> b head c (h w)', head=self.num_heads)

        q = F.normalize(q, dim=-1)
        k = F.normalize(v, dim=-1)

        attn = (q @ k.transpose(-2, -1)) * self.temperature

        attn = self.act(attn)

        out = (attn @ v)

        return out

    def forward(self, x):
        b, c, h, w = x.shape

        qv = self.dynamic_conv(self.project_in(x))

        if self.training or not self.tlc_flag:
            out = self._forward(qv)
            out = rearrange(out, 'b head c (h w) -> b (head c) h w', head=self.num_heads, h=h, w=w)

            out = self.project_out(out)
            return out

        # Then we use the TLC methods in test mode
        qv = self.grids(qv)  # convert to local windows
        out = self._forward(qv)
        out = rearrange(out, 'b head c (h w) -> b (head c) h w', head=self.num_heads, h=qv.shape[-2], w=qv.shape[-1])
        out = self.grids_inverse(out)  # reverse

        out = self.project_out(out)
        return out

    # Code from [megvii-research/TLC] https://github.com/megvii-research/TLC
    def grids(self, x):
        b, c, h, w = x.shape
        self.original_size = (b, c // 2, h, w)
        assert b == 1
        k1, k2 = self.kernel_size
        k1 = min(h, k1)
        k2 = min(w, k2)
        num_row = (h - 1) // k1 + 1
        num_col = (w - 1) // k2 + 1
        self.nr = num_row
        self.nc = num_col

        import math
        step_j = k2 if num_col == 1 else math.ceil((w - k2) / (num_col - 1) - 1e-8)
        step_i = k1 if num_row == 1 else math.ceil((h - k1) / (num_row - 1) - 1e-8)

        parts = []
        idxes = []
        i = 0  # 0~h-1
        last_i = False
        while i < h and not last_i:
            j = 0
            if i + k1 >= h:
                i = h - k1
                last_i = True
            last_j = False
            while j < w and not last_j:
                if j + k2 >= w:
                    j = w - k2
                    last_j = True
                parts.append(x[:, :, i:i + k1, j:j + k2])
                idxes.append({'i': i, 'j': j})
                j = j + step_j
            i = i + step_i

        parts = torch.cat(parts, dim=0)
        self.idxes = idxes
        return parts

    def grids_inverse(self, outs):
        preds = torch.zeros(self.original_size).to(outs.device)
        b, c, h, w = self.original_size

        count_mt = torch.zeros((b, 1, h, w)).to(outs.device)
        k1, k2 = self.kernel_size
        k1 = min(h, k1)
        k2 = min(w, k2)

        for cnt, each_idx in enumerate(self.idxes):
            i = each_idx['i']
            j = each_idx['j']
            preds[0, :, i:i + k1, j:j + k2] += outs[cnt, :, :, :]
            count_mt[0, 0, i:i + k1, j:j + k2] += 1.

        del outs
        torch.cuda.empty_cache()
        return preds / count_mt


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 64, 32, 32).to(device)
    model = SparseSelfAttention(64, num_heads=4, tlc_flag=True, tlc_kernel=48, activation='relu', bias=False).to(device)

    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("小红书：十小大，主页获取往期全部即插即用代码，200+大合集")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)

