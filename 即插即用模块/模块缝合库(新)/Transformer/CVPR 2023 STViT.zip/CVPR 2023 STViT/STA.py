import torch
import torch.nn as nn
import torch.nn.functional as F


class Attention(nn.Module):
    """
    基础注意力模块：用于超级令牌的精细化增强（可选）
    核心作用：通过Conv2d实现轻量化注意力，强化超级令牌的特征表达
    输入：特征图 [B, C, H, W]
    输出：注意力增强特征 [B, C, H, W]（与输入维度一致）
    """

    def __init__(self, dim, window_size=None, num_heads=8, qkv_bias=False, qk_scale=None, attn_drop=0., proj_drop=0.):
        super().__init__()
        self.dim = dim  # 输入/输出通道数
        self.num_heads = num_heads  # 注意力头数
        head_dim = dim // num_heads  # 单头通道数
        self.window_size = window_size  # 窗口尺寸（预留，未实际使用）
        self.scale = qk_scale or head_dim ** -0.5  # 缩放因子

        # QKV投影（Conv2d实现，轻量化）
        self.qkv = nn.Conv2d(dim, dim * 3, 1, bias=qkv_bias)
        self.attn_drop = nn.Dropout(attn_drop)  # 注意力Dropout
        self.proj = nn.Conv2d(dim, dim, 1)  # 输出投影
        self.proj_drop = nn.Dropout(proj_drop)  # 输出Dropout

    def forward(self, x):
        B, C, H, W = x.shape
        N = H * W  # 序列长度
        # QKV生成与拆分：(B, C, H, W)→(B, num_heads, head_dim, N)×3
        q, k, v = self.qkv(x).reshape(B, self.num_heads, C // self.num_heads * 3, N).chunk(3, dim=2)

        # 注意力计算（k转置后与q矩阵乘法，缩放）
        attn = (k.transpose(-1, -2) @ q) * self.scale
        attn = attn.softmax(dim=-2)  # 归一化
        attn = self.attn_drop(attn)

        # 注意力加权与维度恢复
        x = (v @ attn).reshape(B, C, H, W)
        x = self.proj(x)
        x = self.proj_drop(x)
        return x


class Unfold(nn.Module):
    """
    特征展开模块：将特征图按3×3核展开，模拟局部邻域采样
    核心作用：为超级令牌与像素特征的关联提供局部邻域信息
    输入：特征图 [B, C, H, W]
    输出：展开特征 [B, C×9, H×W]（9为3×3核的元素数）
    """

    def __init__(self, kernel_size=3):
        super().__init__()
        self.kernel_size = kernel_size
        # 生成单位矩阵权重（3×3核，对角线为1，其余为0）
        weights = torch.eye(kernel_size ** 2)
        weights = weights.reshape(kernel_size ** 2, 1, kernel_size, kernel_size)
        self.weights = nn.Parameter(weights, requires_grad=False)  # 非可学习参数

    def forward(self, x):
        b, c, h, w = x.shape
        # 展开操作：reshape为单通道→卷积展开→reshape恢复批次和通道
        x = F.conv2d(
            x.reshape(b * c, 1, h, w),
            self.weights,
            stride=1,
            padding=self.kernel_size // 2
        )
        return x.reshape(b, c * 9, h * w)


class Fold(nn.Module):
    """
    特征折叠模块：将展开的特征图恢复为原始尺寸，与Unfold功能互补
    核心作用：重构超级令牌特征，恢复空间维度
    输入：展开特征 [B, C×9, H, W]
    输出：折叠特征 [B, C, H, W]
    """

    def __init__(self, kernel_size=3):
        super().__init__()
        self.kernel_size = kernel_size
        # 生成单位矩阵权重（与Unfold一致）
        weights = torch.eye(kernel_size ** 2)
        weights = weights.reshape(kernel_size ** 2, 1, kernel_size, kernel_size)
        self.weights = nn.Parameter(weights, requires_grad=False)

    def forward(self, x):
        b, _, h, w = x.shape
        # 折叠操作：转置卷积恢复→输出
        x = F.conv_transpose2d(x, self.weights, stride=1, padding=self.kernel_size // 2)
        return x


class StokenAttention(nn.Module):
    """
    超级令牌注意力模块（STA）：通过超级令牌采样与迭代关联，实现高分辨率特征高效增强
    核心创新：
        1. 超级令牌采样：将高分辨率特征压缩为低维令牌，降低计算量；
        2. 迭代关联机制：多轮优化超级令牌与像素特征的关联，提升特征一致性；
        3. 特征重构：Unfold/Fold配合，精准恢复高分辨率特征；
        4. 精细化增强：可选注意力/卷积 refine 模块，优化超级令牌质量。
    输入：特征图 [B, C, H, W]
    输出：增强后特征 [B, C, H, W]（与输入维度一致）
    """

    def __init__(self, dim, stoken_size, n_iter=1, refine=True, refine_attention=True, num_heads=8, qkv_bias=False,
                 qk_scale=None, attn_drop=0., proj_drop=0.):
        super().__init__()
        self.n_iter = n_iter  # 迭代关联次数（默认1，次数越多精度越高但效率越低）
        self.stoken_size = stoken_size  # 超级令牌尺寸 (h, w)，控制令牌数量
        self.refine = refine  # 是否启用超级令牌精细化增强
        self.refine_attention = refine_attention  # refine方式：注意力（True）或卷积（False）
        self.scale = dim ** -0.5  # 关联矩阵缩放因子

        self.unfold = Unfold(3)  # 3×3特征展开
        self.fold = Fold(3)  # 3×3特征折叠

        # 超级令牌精细化模块
        if refine:
            if refine_attention:
                # 注意力 refine：强化令牌特征关联
                self.stoken_refine = Attention(
                    dim, num_heads=num_heads, qkv_bias=qkv_bias,
                    qk_scale=qk_scale, attn_drop=attn_drop, proj_drop=proj_drop
                )
            else:
                # 卷积 refine：轻量化增强令牌特征
                self.stoken_refine = nn.Sequential(
                    nn.Conv2d(dim, dim, 1, 1, 0),  # 1×1投影
                    nn.Conv2d(dim, dim, 5, 1, 2, groups=dim),  # 深度可分离卷积
                    nn.Conv2d(dim, dim, 1, 1, 0)  # 1×1恢复
                )

    def stoken_forward(self, x):
        '''
        超级令牌注意力核心流程：采样→迭代关联→重构→增强
        输入：x [B, C, H0, W0]（原始高分辨率特征）
        输出：pixel_features [B, C, H0, W0]（重构增强后的特征）
        '''
        B, C, H0, W0 = x.shape
        h, w = self.stoken_size  # 超级令牌尺寸
        # 填充：确保特征图尺寸能被令牌尺寸整除
        pad_l = pad_t = 0
        pad_r = (w - W0 % w) % w
        pad_b = (h - H0 % h) % h
        if pad_r > 0 or pad_b > 0:
            x = F.pad(x, (pad_l, pad_r, pad_t, pad_b))
        _, _, H, W = x.shape
        hh, ww = H // h, W // w  # 超级令牌的数量（hh行ww列）

        # 步骤1：超级令牌采样（自适应平均池化压缩特征）
        stoken_features = F.adaptive_avg_pool2d(x, (hh, ww))  # [B, C, hh, ww]

        # 步骤2：像素特征重排（与超级令牌对应）
        pixel_features = x.reshape(B, C, hh, h, ww, w).permute(0, 2, 4, 3, 5, 1).reshape(B, hh * ww, h * w, C)
        # 维度说明：[B, 令牌数, 每个令牌对应像素数, C]

        # 步骤3：迭代关联优化超级令牌（禁用梯度计算，提升效率）
        with torch.no_grad():
            for idx in range(self.n_iter):
                # 令牌特征展开→维度重排：[B, C×9, hh×ww]→[B, hh×ww, C, 9]
                stoken_features_unfold = self.unfold(stoken_features)
                stoken_features_unfold = stoken_features_unfold.transpose(1, 2).reshape(B, hh * ww, C, 9)

                # 计算关联矩阵（像素特征×令牌展开特征，缩放）
                affinity_matrix = pixel_features @ stoken_features_unfold * self.scale  # [B, hh×ww, h×w, 9]
                affinity_matrix = affinity_matrix.softmax(-1)  # 归一化，得到关联权重

                # 关联权重求和→折叠恢复尺寸：用于后续归一化
                affinity_matrix_sum = affinity_matrix.sum(2).transpose(1, 2).reshape(B, 9, hh, ww)
                affinity_matrix_sum = self.fold(affinity_matrix_sum)

                # 非最后一轮迭代：更新超级令牌特征
                if idx < self.n_iter - 1:
                    # 像素特征加权更新令牌→折叠恢复→归一化
                    stoken_features = pixel_features.transpose(-1, -2) @ affinity_matrix  # [B, hh×ww, C, 9]
                    stoken_features = self.fold(
                        stoken_features.permute(0, 2, 3, 1).reshape(B * C, 9, hh, ww)
                    ).reshape(B, C, hh, ww)
                    stoken_features = stoken_features / (affinity_matrix_sum + 1e-12)  # 归一化避免数值溢出

        # 步骤4：最终超级令牌更新与像素特征重构
        stoken_features = pixel_features.transpose(-1, -2) @ affinity_matrix  # [B, hh×ww, C, 9]
        stoken_features = self.fold(
            stoken_features.permute(0, 2, 3, 1).reshape(B * C, 9, hh, ww)
        ).reshape(B, C, hh, ww)
        stoken_features = stoken_features / (affinity_matrix_sum.detach() + 1e-12)  # detach避免梯度传播

        # 步骤5：超级令牌精细化增强（可选）
        if self.refine:
            stoken_features = self.stoken_refine(stoken_features)

        # 步骤6：像素特征重构（超级令牌→像素特征）
        stoken_features_unfold = self.unfold(stoken_features)  # [B, C×9, hh×ww]
        stoken_features_unfold = stoken_features_unfold.transpose(1, 2).reshape(B, hh * ww, C, 9)  # [B, 令牌数, C, 9]
        pixel_features = stoken_features_unfold @ affinity_matrix.transpose(-1, -2)  # [B, hh×ww, C, h×w]

        # 步骤7：维度恢复与裁剪（去除填充）
        pixel_features = pixel_features.reshape(B, hh, ww, C, h, w).permute(0, 3, 1, 4, 2, 5).reshape(B, C, H, W)
        if pad_r > 0 or pad_b > 0:
            pixel_features = pixel_features[:, :, :H0, :W0]  # 裁剪回原始尺寸

        return pixel_features

    def direct_forward(self, x):
        """直接前向传播（超级令牌尺寸为(1,1)时，无采样，仅精细化增强）"""
        B, C, H, W = x.shape
        stoken_features = x
        if self.refine:
            stoken_features = self.stoken_refine(stoken_features)
        return stoken_features

    def forward(self, x):
        """
        总前向传播：根据超级令牌尺寸选择流程
        - stoken_size=(h,w)且h/w>1：走超级令牌采样-关联-重构流程
        - 否则：直接精细化增强
        """
        if self.stoken_size[0] > 1 or self.stoken_size[1] > 1:
            return self.stoken_forward(x)
        else:
            return self.direct_forward(x)


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 64, 32, 32).to(device)
    model = StokenAttention(64, (8, 8))

    model.to(device)
    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)