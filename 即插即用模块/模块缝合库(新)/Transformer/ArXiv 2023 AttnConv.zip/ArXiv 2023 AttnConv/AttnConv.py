import torch
import torch.nn as nn
from typing import List
from efficientnet_pytorch.model import MemoryEfficientSwish


class AttnMap(nn.Module):
    """
    注意力映射模块（用于高频注意力分支的特征交互）
    功能：通过双1×1卷积+Swish激活，对QK乘积后的特征进行非线性变换，增强注意力表达能力
    """
    def __init__(self, dim):
        """
        Args:
            dim: 输入/输出特征通道数（需与高频分支的头维度匹配）
        """
        super().__init__()
        self.act_block = nn.Sequential(
            nn.Conv2d(dim, dim, 1, 1, 0),  # 1×1卷积：通道内特征变换
            MemoryEfficientSwish(),        # 高效Swish激活：引入非线性，避免梯度消失
            nn.Conv2d(dim, dim, 1, 1, 0)   # 1×1卷积：进一步优化特征分布
            # nn.Identity()  # 备用：无变换模式，调试时可启用
        )

    def forward(self, x):
        """前向传播：输入特征 → 双1×1卷积+激活 → 输出"""
        # (b, dim, h, w) → (b, dim, h, w)，经过AttnMap不改变特征维度
        return self.act_block(x)


class EfficientAttention(nn.Module):
    """
    高效注意力模块（EfficientAttention）
    设计思想：分“高频注意力分支”与“低频注意力分支”并行处理特征，
              高频分支捕捉局部细节，低频分支捕捉全局上下文，平衡精度与效率
    """

    def __init__(self, dim, num_heads, group_split: List[int], kernel_sizes: List[int], window_size=7,
                 attn_drop=0., proj_drop=0., qkv_bias=True):
        """
        Args:
            dim: 输入特征通道数（需被num_heads整除）
            num_heads: 注意力头总数（高频分支头数之和 + 低频分支头数 = num_heads）
            group_split: 各分支的注意力头分配列表（最后一个元素为低频分支头数，其余为高频分支）
            kernel_sizes: 高频分支的深度卷积核大小列表（数量 = 高频分支数）
            window_size: 低频分支的平均池化窗口大小（默认7，用于压缩特征尺寸，降低计算量）
            attn_drop: 注意力 dropout 概率（默认0，正则化，防止过拟合）
            proj_drop: 输出投影 dropout 概率（默认0，正则化）
            qkv_bias: QKV生成卷积是否使用偏置（默认True，提升模型表达能力）
        """
        super().__init__()
        # 校验参数合法性：头分配总和=总头数，高频分支数=卷积核列表长度
        assert sum(group_split) == num_heads, "Sum of group_split must equal num_heads"
        assert len(kernel_sizes) + 1 == len(group_split), "Length of kernel_sizes +1 must equal length of group_split"

        self.dim = dim
        self.num_heads = num_heads
        self.dim_head = dim // num_heads  # 单个注意力头的通道数
        self.scalor = self.dim_head ** -0.5  # 注意力缩放因子（避免QK乘积过大）
        self.kernel_sizes = kernel_sizes
        self.window_size = window_size
        self.group_split = group_split

        # 初始化高频分支组件：深度卷积（mixer）、注意力映射（act_blocks）、QKV生成卷积（qkvs）
        convs = []  # 高频分支：深度卷积（分组数=3×头通道数×分支头数，实现通道独立变换）
        act_blocks = []  # 高频分支：AttnMap模块（增强QK交互）
        qkvs = []  # 高频分支：QKV生成（1×1卷积，输出通道=3×分支头数×头通道数）

        for i in range(len(kernel_sizes)):
            kernel_size = kernel_sizes[i]
            group_head = group_split[i]  # 当前高频分支的头数
            if group_head == 0:
                continue  # 头数为0时跳过（兼容灵活配置）

            # 深度卷积：输入输出通道=3×分支头数×头通道数，分组卷积确保各QKV通道独立
            convs.append(nn.Conv2d(
                in_channels=3 * self.dim_head * group_head,
                out_channels=3 * self.dim_head * group_head,
                kernel_size=kernel_size,
                stride=1,
                padding=kernel_size // 2,  # same padding：输入输出尺寸一致
                groups=3 * self.dim_head * group_head  # 深度卷积：每组对应一个Q/K/V通道
            ))

            # 注意力映射模块：输入通道=分支头数×头通道数
            act_blocks.append(AttnMap(self.dim_head * group_head))

            # QKV生成卷积：将输入dim通道转换为3×分支头数×头通道数（Q/K/V各占1/3）， (b, dim, h, w) → (b, 3×group_head×dim_head, h, w)
            qkvs.append(nn.Conv2d(
                in_channels=dim,
                out_channels=3 * group_head * self.dim_head,
                kernel_size=1,
                stride=1,
                padding=0,
                bias=qkv_bias
            ))

        # 初始化低频分支组件（全局注意力）：仅当头数分配非0时生效
        if group_split[-1] != 0:
            # 全局Q生成：(b, dim, h, w) → (b, group_split[-1]×dim_head, h, w)
            self.global_q = nn.Conv2d(  # 低频分支Q生成：输出通道=低频头数×头通道数
                dim, group_split[-1] * self.dim_head, 1, 1, 0, bias=qkv_bias
            )
            # 全局KV生成：(b, dim, h, w) → (b, 2×group_split[-1]×dim_head, h, w)
            self.global_kv = nn.Conv2d(  # 低频分支KV生成：输出通道=2×低频头数×头通道数（K/V各占1/2）
                dim, group_split[-1] * self.dim_head * 2, 1, 1, 0, bias=qkv_bias
            )
            # 平均池化：压缩特征尺寸（步长=窗口大小），降低低频分支计算量
            # (b, c, h, w) → (b, c, h//window_size, w//window_size)（步长=窗口大小）
            self.avgpool = nn.AvgPool2d(window_size, window_size) if window_size != 1 else nn.Identity()

        # 注册模块列表（确保PyTorch可追踪参数）
        self.convs = nn.ModuleList(convs)
        self.act_blocks = nn.ModuleList(act_blocks)
        self.qkvs = nn.ModuleList(qkvs)

        # 输出投影：将多分支拼接后的特征映射回原dim通道
        self.proj = nn.Conv2d(dim, dim, 1, 1, 0, bias=qkv_bias)
        # Dropout层：正则化
        self.attn_drop = nn.Dropout(attn_drop)
        self.proj_drop = nn.Dropout(proj_drop)

    def high_fre_attntion(self, x: torch.Tensor, to_qkv: nn.Module, mixer: nn.Module, attn_block: nn.Module):
        """
        高频注意力分支前向传播（捕捉局部细节特征，如边缘、纹理）
        Args:
            x: 输入特征，shape=(b, c, h, w)
            to_qkv: QKV生成卷积模块
            mixer: 深度卷积模块（特征混合）
            attn_block: AttnMap模块（注意力映射）
        Returns:
            res: 高频注意力输出，shape=(b, group_head×dim_head, h, w)
        """
        b, c, h, w = x.size()
        # 1. 生成QKV：输入dim → 3×group_head×dim_head
        qkv = to_qkv(x)  # shape=(b, 3×m×d, h, w)，m=分支头数，d=头通道数
        # 2. 深度卷积混合：分组卷积增强QKV局部交互，后重塑为(3, b, m×d, h, w)
        qkv = mixer(qkv).reshape(b, 3, -1, h, w).transpose(0, 1).contiguous()
        # 3. 拆分Q、K、V：各shape=(b, m×d, h, w)
        q, k, v = qkv
        # 4. 注意力计算：Q×K（元素乘）→ AttnMap映射 → 缩放 → Tanh激活 → Dropout
        attn = attn_block(q.mul(k)).mul(self.scalor)  # QK元素乘后非线性变换，再缩放
        attn = self.attn_drop(torch.tanh(attn))  # Tanh激活限制注意力范围，Dropout正则化
        # 5. 注意力加权V：Attn × V（元素乘）
        res = attn.mul(v)  # shape=(b, m×d, h, w)
        return res

    def low_fre_attention(self, x: torch.Tensor, to_q: nn.Module, to_kv: nn.Module, avgpool: nn.Module):
        """
        低频注意力分支前向传播（捕捉全局上下文特征，如目标整体结构）
        Args:
            x: 输入特征，shape=(b, c, h, w)
            to_q: Q生成卷积模块
            to_kv: KV生成卷积模块
            avgpool: 平均池化模块（压缩KV尺寸）
        Returns:
            res: 低频注意力输出，shape=(b, group_head×dim_head, h, w)
        """
        b, c, h, w = x.size()
        # 1. 生成Q：输入dim → group_head×dim_head，重塑为多头注意力格式
        q = to_q(x).reshape(b, -1, self.dim_head, h * w).transpose(-1, -2).contiguous()
        # shape=(b, m, h×w, d)，m=低频分支头数，d=头通道数

        # 2. 生成KV：先池化压缩尺寸（降低计算量），再生成KV
        kv = avgpool(x)  # shape=(b, c, H, W)，H=h//window_size，W=w//window_size
        kv = to_kv(kv).view(  # 生成KV并重塑为多头格式
            b, 2, -1, self.dim_head, (h * w) // (self.window_size ** 2)
        ).permute(1, 0, 2, 4, 3).contiguous()
        # shape=(2, b, m, H×W, d)，拆分后K/V shape=(b, m, H×W, d)

        # 3. 拆分K、V
        k, v = kv
        # 4. 注意力计算：Q@K^T（矩阵乘）→ 缩放 → Softmax → Dropout
        attn = self.scalor * q @ k.transpose(-1, -2)  # shape=(b, m, h×w, H×W)
        attn = self.attn_drop(attn.softmax(dim=-1))  # Softmax归一化注意力权重
        # 5. 注意力加权V：Attn@V（矩阵乘），后重塑为空间特征格式
        res = attn @ v  # shape=(b, m, h×w, d)
        res = res.transpose(2, 3).reshape(b, -1, h, w).contiguous()  # shape=(b, m×d, h, w)
        return res

    def forward(self, x: torch.Tensor):
        """
        整体前向传播：高频分支并行计算 → 低频分支计算 → 分支拼接 → 输出投影
        Args:
            x: 输入特征，shape=(b, c, h, w)
        Returns:
            最终注意力输出，shape=(b, dim, h, w)（与输入尺寸一致）
        """
        res = []  # 存储各分支输出
        # 1. 高频分支计算：遍历所有高频分支，添加输出到res
        for i in range(len(self.kernel_sizes)):
            if self.group_split[i] == 0:
                continue  # 跳过头数为0的分支
            res.append(self.high_fre_attntion(
                x, self.qkvs[i], self.convs[i], self.act_blocks[i]
            ))
        # 2. 低频分支计算：若头数非0，添加输出到res
        if self.group_split[-1] != 0:
            res.append(self.low_fre_attention(
                x, self.global_q, self.global_kv, self.avgpool
            ))
        # 3. 分支拼接 → 输出投影 → Dropout：恢复原dim通道，返回最终结果
        return self.proj_drop(self.proj(torch.cat(res, dim=1)))


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    # 3个头，dim需要被3整除
    x = torch.randn(1, 96, 56, 56).to(device)
    model = EfficientAttention(96, 3, [1, 1, 1], [7, 5])

    # 4个头
    # x = torch.randn(1, 96, 56, 56).to(device)
    # model = EfficientAttention(96, 4, [1, 1, 1, 1], [9, 7, 5])

    model.to(device)
    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("知乎、CSDN：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)