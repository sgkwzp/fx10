import torch
import itertools

class Conv2d_BN(torch.nn.Sequential):
    def __init__(self, a, b, ks=1, stride=1, pad=0, dilation=1,
                 groups=1, bn_weight_init=1, resolution=-10000):
        super().__init__()
        self.add_module('c', torch.nn.Conv2d(
            a, b, ks, stride, pad, dilation, groups, bias=False))
        self.add_module('bn', torch.nn.BatchNorm2d(b))
        torch.nn.init.constant_(self.bn.weight, bn_weight_init)
        torch.nn.init.constant_(self.bn.bias, 0)

    @torch.no_grad()
    def fuse(self):
        c, bn = self._modules.values()
        w = bn.weight / (bn.running_var + bn.eps)**0.5
        w = c.weight * w[:, None, None, None]
        b = bn.bias - bn.running_mean * bn.weight / \
            (bn.running_var + bn.eps)**0.5
        m = torch.nn.Conv2d(w.size(1) * self.c.groups, w.size(
            0), w.shape[2:], stride=self.c.stride, padding=self.c.padding, dilation=self.c.dilation, groups=self.c.groups)
        m.weight.data.copy_(w)
        m.bias.data.copy_(b)
        return m

class CascadedGroupAttention(torch.nn.Module):
    r"""
    级联组注意力模块（CGA）：EfficientViT的核心注意力组件
    核心创新：
        1. 级联注意力头：多头特征逐次累加，强化特征传递；
        2. 分组特征处理：输入按头拆分，降低单头计算量；
        3. 位置偏置优化：基于像素偏移量的共享偏置，提升位置敏感性；
        4. 卷积-注意力融合：查询分支加深度卷积，增强局部特征捕捉。
    输入：
        x: 特征图 [B, dim, H, W]（dim=输入通道数，H=W=resolution）
    输出：
        增强后特征 [B, dim, H, W]（与输入维度完全一致）
    Args:
        dim (int): 输入通道数
        key_dim (int): 查询（Q）和键（K）的维度
        num_heads (int): 注意力头数
        attn_ratio (int): 值（V）维度相对于Q的倍数（V_dim = attn_ratio × key_dim）
        resolution (int): 输入特征分辨率（H=W=resolution）
        kernels (List[int]): 每个注意力头中Q分支的深度卷积核尺寸
    """
    def __init__(self, dim, key_dim, num_heads=4,
                 attn_ratio=4,
                 resolution=14,
                 kernels=[5, 5, 5, 5],):
        super().__init__()
        self.num_heads = num_heads  # 注意力头数
        self.scale = key_dim ** -0.5  # 注意力缩放因子（缓解梯度消失）
        self.key_dim = key_dim  # Q/K维度
        self.d = int(attn_ratio * key_dim)  # V维度（attn_ratio倍Q维度）
        self.attn_ratio = attn_ratio

        # 初始化每个头的QKV生成层和Q分支深度卷积层
        qkvs = []  # 每个头的QKV生成（Conv2d_BN）
        dws = []   # 每个头的Q分支深度卷积（Conv2d_BN）
        for i in range(num_heads):
            # QKV生成层：输入为单头通道数（dim//num_heads），输出为Q+K+V（key_dim×2 + d）
            qkvs.append(Conv2d_BN(dim // num_heads, self.key_dim * 2 + self.d, resolution=resolution))
            # Q分支深度卷积：分组卷积（groups=key_dim），增强Q的局部特征
            dws.append(Conv2d_BN(self.key_dim, self.key_dim, kernels[i], 1, kernels[i]//2, groups=self.key_dim, resolution=resolution))
        self.qkvs = torch.nn.ModuleList(qkvs)
        self.dws = torch.nn.ModuleList(dws)

        # 输出投影层：融合所有头的V特征，恢复输入通道数
        self.proj = torch.nn.Sequential(
            torch.nn.ReLU(),
            Conv2d_BN(self.d * num_heads, dim, bn_weight_init=0, resolution=resolution)
        )

        # 生成位置偏置：基于像素间偏移量，共享相同偏移的偏置
        points = list(itertools.product(range(resolution), range(resolution)))  # 所有像素坐标
        N = len(points)  # 像素总数（N=resolution×resolution）
        attention_offsets = {}  # 偏移量→索引映射
        idxs = []  # 每个（p1,p2）对对应的偏置索引
        for p1 in points:
            for p2 in points:
                offset = (abs(p1[0] - p2[0]), abs(p1[1] - p2[1]))  # 像素间偏移（仅与距离相关，与位置无关）
                if offset not in attention_offsets:
                    attention_offsets[offset] = len(attention_offsets)  # 偏移量分配唯一索引
                idxs.append(attention_offsets[offset])
        # 可学习位置偏置（每个头对应一组偏置）
        self.attention_biases = torch.nn.Parameter(torch.zeros(num_heads, len(attention_offsets)))
        # 注册偏置索引缓冲区（不参与梯度更新）
        self.register_buffer('attention_bias_idxs', torch.LongTensor(idxs).view(N, N))

    @torch.no_grad()
    def train(self, mode=True):
        """训练/推理模式切换：推理时预计算位置偏置，提升速度"""
        super().train(mode)
        if mode and hasattr(self, 'ab'):
            del self.ab  # 训练时删除预计算偏置
        else:
            # 推理时预计算每个头的位置偏置矩阵（N×N）
            self.ab = self.attention_biases[:, self.attention_bias_idxs]

    def forward(self, x):  # x: (B, C, H, W)
        """
        前向传播流程：分组特征→级联注意力头→特征融合→输出投影
        """
        B, C, H, W = x.shape
        # 训练时实时生成位置偏置，推理时使用预计算偏置
        trainingab = self.attention_biases[:, self.attention_bias_idxs]

        # 步骤1：输入特征按头分组（dim//num_heads通道/头）
        feats_in = x.chunk(len(self.qkvs), dim=1)  # 拆分后：num_heads × [B, dim//num_heads, H, W]
        feats_out = []  # 存储每个头的输出V特征
        feat = feats_in[0]  # 第一个头的输入特征

        # 步骤2：级联处理每个注意力头
        for i, qkv in enumerate(self.qkvs):
            if i > 0:  # 从第二个头开始，累加前一个头的输出（级联核心）
                feat = feat + feats_in[i]
            # 生成QKV特征
            feat = qkv(feat)  # [B, key_dim×2 + d, H, W]
            # 拆分Q、K、V
            q, k, v = feat.view(B, -1, H, W).split([self.key_dim, self.key_dim, self.d], dim=1)  # 各为[B, dim, H, W]
            # Q分支深度卷积增强局部特征
            q = self.dws[i](q)
            # 展平空间维度（H×W→N）
            q, k, v = q.flatten(2), k.flatten(2), v.flatten(2)  # 各为[B, dim, N]

            # 步骤3：计算注意力权重
            attn = (
                (q.transpose(-2, -1) @ k) * self.scale  # Q^T @ K × 缩放因子（[B, N, N]）
                + (trainingab[i] if self.training else self.ab[i])  # 位置偏置（[N, N]）
            )
            attn = attn.softmax(dim=-1)  # 归一化注意力权重

            # 步骤4：注意力加权V特征
            feat = (v @ attn.transpose(-2, -1)).view(B, self.d, H, W)  # [B, d, H, W]
            feats_out.append(feat)  # 保存当前头的输出

        # 步骤5：融合所有头的特征→投影输出
        x = self.proj(torch.cat(feats_out, 1))  # 拼接后通道数=num_heads×d，投影回dim通道
        return x

if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')


    resolution = 32
    dim = 256
    key_dim = 16
    num_head = 4
    attn_ratio = 4
    kernels = [5, 5, 5, 5]

    # dim // num_head = attn_ratio * key_dim

    x = torch.randn(1, dim, resolution, resolution).to(device)
    model = CascadedGroupAttention(dim, key_dim, num_heads=num_head, attn_ratio=attn_ratio, resolution=resolution, kernels=kernels).to(device)

    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)