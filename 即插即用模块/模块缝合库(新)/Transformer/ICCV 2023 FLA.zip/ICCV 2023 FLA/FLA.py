import torch
import torch.nn as nn
import torch.nn.functional as F


class FocusedLinearAttention(nn.Module):
    def __init__(self, dim, num_patches, num_heads=8, qkv_bias=False, qk_scale=None, attn_drop=0., proj_drop=0.,
                 sr_ratio=1,
                 focusing_factor=3, kernel_size=5):
        super().__init__()
        # 确保输入维度能被头数整除
        assert dim % num_heads == 0, f"dim {dim} should be divided by num_heads {num_heads}."

        self.dim = dim  # 输入特征维度
        self.num_heads = num_heads  # 注意力头数
        head_dim = dim // num_heads  # 每个头的维度

        # QKV投影层（仅Q单独投影，KV联合投影）
        self.q = nn.Linear(dim, dim, bias=qkv_bias)
        self.kv = nn.Linear(dim, dim * 2, bias=qkv_bias)
        self.attn_drop = nn.Dropout(attn_drop)  # 注意力 dropout
        self.proj = nn.Linear(dim, dim)  # 输出投影层
        self.proj_drop = nn.Dropout(proj_drop)  # 输出 dropout

        self.sr_ratio = sr_ratio  # 空间缩减比例（降低计算量）
        if sr_ratio > 1:
            # 空间缩减卷积（类似下采样）
            self.sr = nn.Conv2d(dim, dim, kernel_size=sr_ratio, stride=sr_ratio)
            self.norm = nn.LayerNorm(dim)  # 空间缩减后的归一化

        self.focusing_factor = focusing_factor  # 聚焦因子（增强重要特征）
        # 深度可分离卷积（捕获局部特征）
        self.dwc = nn.Conv2d(in_channels=head_dim, out_channels=head_dim, kernel_size=kernel_size,
                             groups=head_dim, padding=kernel_size // 2)
        self.scale = nn.Parameter(torch.zeros(size=(1, 1, dim)))  # 缩放参数
        # 位置编码（补充空间位置信息）
        self.positional_encoding = nn.Parameter(torch.zeros(size=(1, num_patches // (sr_ratio * sr_ratio), dim)))
        print('Linear Attention sr_ratio{} f{} kernel{}'.
              format(sr_ratio, focusing_factor, kernel_size))

    def forward(self, x, H, W):
        B, N, C = x.shape  # B:批次，N:序列长度（patch数），C:特征维度
        q = self.q(x)  # Q投影：(B, N, C)

        # 计算KV（根据sr_ratio决定是否空间缩减）
        if self.sr_ratio > 1:
            # 空间缩减：将序列维度从N=H*W缩减为(H/sr_ratio)*(W/sr_ratio)
            x_ = x.permute(0, 2, 1).reshape(B, C, H, W)  # (B, C, H, W)
            x_ = self.sr(x_).reshape(B, C, -1).permute(0, 2, 1)  # (B, N', C)，N'=N/(sr_ratio^2)
            x_ = self.norm(x_)
            kv = self.kv(x_).reshape(B, -1, 2, C).permute(2, 0, 1, 3)  # 分离K和V
        else:
            kv = self.kv(x).reshape(B, -1, 2, C).permute(2, 0, 1, 3)
        k, v = kv[0], kv[1]  # K和V: (B, N', C)
        n = k.shape[1]  # 缩减后的序列长度

        # 位置编码注入K
        k = k + self.positional_encoding
        # 聚焦机制：增强重要特征的权重
        focusing_factor = self.focusing_factor
        kernel_function = nn.ReLU()  # 激活函数确保非负性
        scale = nn.Softplus()(self.scale)  # 缩放参数（确保为正）
        q = kernel_function(q) + 1e-6  # 避免零值
        k = kernel_function(k) + 1e-6
        q = q / scale  # 缩放
        k = k / scale
        # 归一化后通过聚焦因子增强
        q_norm = q.norm(dim=-1, keepdim=True)
        k_norm = k.norm(dim=-1, keepdim=True)
        q = q ** focusing_factor  # 逐元素幂运算增强差异
        k = k ** focusing_factor
        # 恢复原始模长比例
        q = (q / q.norm(dim=-1, keepdim=True)) * q_norm
        k = (k / k.norm(dim=-1, keepdim=True)) * k_norm

        # 多头注意力拆分
        q = q.reshape(B, N, self.num_heads, -1).permute(0, 2, 1, 3)  # (B, num_heads, N, head_dim)
        k = k.reshape(B, n, self.num_heads, -1).permute(0, 2, 1, 3)  # (B, num_heads, N', head_dim)
        v = v.reshape(B, n, self.num_heads, -1).permute(0, 2, 1, 3)  # (B, num_heads, N', head_dim)

        # 线性注意力计算（低复杂度O(N)）
        z = 1 / (q @ k.mean(dim=-2, keepdim=True).transpose(-2, -1) + 1e-6)  # 归一化因子
        kv = (k.transpose(-2, -1) * (n ** -0.5)) @ (v * (n ** -0.5))  # K^T @ V（带缩放）
        x = q @ kv * z  # 注意力输出

        # 若使用空间缩减，需将V插值回原始序列长度（用于后续局部特征融合）
        if self.sr_ratio > 1:
            v = F.interpolate(v.transpose(-2, -1).reshape(B * self.num_heads, -1, n),
                              size=N, mode='linear').reshape(B, self.num_heads, -1, N).transpose(-2, -1)

        # 融合局部特征（深度可分离卷积）
        x = x.transpose(1, 2).reshape(B, N, C)  # 多头合并：(B, N, C)
        v = v.reshape(B * self.num_heads, H, W, -1).permute(0, 3, 1, 2)  # 重塑为特征图
        x = x + self.dwc(v).reshape(B, C, N).permute(0, 2, 1)  # 局部特征残差连接

        # 输出投影和dropout
        x = self.proj(x)
        x = self.proj_drop(x)

        return x

if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 32*32, 64).to(device)
    model = FocusedLinearAttention(64, 32*32).to(device)

    y = model(x, 32, 32)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)