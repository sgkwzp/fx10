# 循环注意力模块（Circulant Attention）
# 核心设计：基于频域DFT变换优化注意力计算，通过“时域→频域→元素乘法→时域”的流程，
# 将传统自注意力O(N²)复杂度降至O(NlogN)，在保证全局依赖捕捉能力的同时，大幅提升计算效率

import torch
import torch.nn as nn


class Linear(nn.Linear):
    """
    复数线性层：适配复数输入的线性变换，支持频域特征的线性投影
    核心逻辑：将复数拆分为实部-虚部，完成线性变换后重组为复数
    Args:
        in_features: 输入特征维度
        out_features: 输出特征维度
        device: 设备（默认None）
        dtype: 数据类型（默认None）
    """
    def __init__(self, in_features, out_features, device=None, dtype=None):
        super(Linear, self).__init__(in_features, out_features, False, device, dtype)

    def forward(self, x):
        # 复数→实虚部分离→转置适配线性层→线性变换→还原复数格式
        x = torch.view_as_real(x).transpose(-2, -1)
        x = torch.nn.functional.linear(x, self.weight).transpose(-2, -1)
        if x.dtype != torch.float32:
            x = x.to(torch.float32)
        x = torch.view_as_complex(x.contiguous())
        return x


class CirculantAttention(nn.Module):
    """
    循环注意力模块（Circulant Attention）
    功能：频域优化的全局注意力，高效捕捉长距离依赖
    核心设计：
        - 频域降复杂度：利用DFT性质，将注意力矩阵乘法转化为频域元素乘法，复杂度从O(N²)降至O(NlogN)
        - 复数线性投影：适配频域复数特征的QKV生成
        - 门控调制：通过SiLU门控动态调整特征权重，提升表达能力
        - 正交归一化：FFT使用ortho norm，隐含1/N归一化因子，保证计算稳定性
    论文参考：https://arxiv.org/abs/2512.21542
    Args:
        dim: 输入/输出通道数
        proj_drop: 输出dropout概率（默认0.）
    """

    def __init__(self, dim, proj_drop=0.):
        super().__init__()
        self.qkv = Linear(dim, dim * 3)  # 复数QKV生成（1个线性层生成3路特征）
        self.gate = nn.Sequential(nn.Linear(dim, dim), nn.SiLU())  # 门控调制
        self.proj = nn.Linear(dim, dim)  # 输出投影
        self.proj_drop = nn.Dropout(proj_drop)  # 输出dropout

    def forward(self, x):
        """
        前向传播：时域→频域→注意力计算→时域→输出
        Args:
            x: 输入特征，shape=[b, c, h, w]
        Returns:
            注意力增强特征，shape=[b, c, h, w]（与输入维度一致）
        """
        b, c, h, w = x.shape
        n = h * w  # 空间像素总数

        # 1. 维度转换：[b, c, h, w]→[b, n, c]（适配门控计算）
        x_seq = x.reshape(b, c, n).permute(0, 2, 1)

        # 2. 门控生成：动态调制特征权重
        gate = self.gate(x_seq)

        # 3. 时域→频域转换：[b, n, c]→[b, h, w, c]→RFFT→复数频域特征
        x_spatial = x_seq.reshape(b, h, w, c)
        x_fft = torch.fft.rfft2(x_spatial, dim=(1, 2), norm='ortho')  # [b, h, w, c]（复数）

        # 4. QKV生成：复数线性层投影→拆分Q/K/V
        qkv = self.qkv(x_fft)  # [b, h, w, 3c]
        q, k, v = torch.chunk(qkv, chunks=3, dim=-1)  # 各[b, h, w, c]

        # 5. 频域注意力计算（论文公式15）：共轭Q × K → 逆RFFT→时域softmax
        attn_fft = torch.conj(q) * k  # 频域元素乘法（替代时域矩阵乘法）
        attn_spatial = torch.fft.irfft2(attn_fft, s=(h, w), dim=(1, 2), norm='ortho')  # 频域→时域
        attn_weight = attn_spatial.reshape(b, n, c).softmax(dim=1).reshape(b, h, w, c)  # 注意力权重归一化

        # 6. 价值加权（论文公式16）：注意力权重→频域→共轭×V→逆RFFT→时域
        attn_fft = torch.fft.rfft2(attn_weight, dim=(1, 2))  # 权重→频域
        v_weighted_fft = torch.conj(attn_fft) * v  # 频域加权V
        v_weighted_spatial = torch.fft.irfft2(v_weighted_fft, s=(h, w), dim=(1, 2), norm='ortho')  # 频域→时域

        # 7. 门控调制→输出投影→维度还原
        out_seq = v_weighted_spatial.reshape(b, n, c) * gate  # 门控加权
        out_seq = self.proj(out_seq)  # 线性投影
        out = out_seq.reshape(b, c, h, w)  # 还原为输入格式
        out = self.proj_drop(out)

        return out


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 64, 32, 32).to(device)
    model = CirculantAttention(64).to(device)

    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)