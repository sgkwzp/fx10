import torch

class GroupNorm(torch.nn.GroupNorm):
    """
    Group Normalization with 1 group.
    Input: tensor in shape [B, C, H, W]
    """
    def __init__(self, num_channels, **kwargs):
        super().__init__(1, num_channels, **kwargs)


class Conv2d_BN(torch.nn.Sequential):
    def __init__(self, a, b, ks=1, stride=1, pad=0, dilation=1,
                 groups=1, bn_weight_init=1):
        super().__init__()
        self.add_module('c', torch.nn.Conv2d(
            a, b, ks, stride, pad, dilation, groups, bias=False))
        self.add_module('bn', torch.nn.BatchNorm2d(b))
        torch.nn.init.constant_(self.bn.weight, bn_weight_init)
        torch.nn.init.constant_(self.bn.bias, 0)

    @torch.no_grad()
    def fuse(self):
        c, bn = self._modules.values()
        w = bn.weight / (bn.running_var + bn.eps)**0.5
        w = c.weight * w[:, None, None, None]
        b = bn.bias - bn.running_mean * bn.weight / \
            (bn.running_var + bn.eps)**0.5
        m = torch.nn.Conv2d(w.size(1) * self.c.groups, w.size(
            0), w.shape[2:], stride=self.c.stride, padding=self.c.padding, dilation=self.c.dilation, groups=self.c.groups,
            device=c.weight.device)
        m.weight.data.copy_(w)
        m.bias.data.copy_(b)
        return m


class SHSA(torch.nn.Module):
    """
    单头自注意力模块（Single-Head Self-Attention, SHSA）
    核心设计：将输入特征分为“注意力分支”与“身份分支”，仅对注意力分支计算单头自注意力，
    结合卷积与归一化操作，在保证全局依赖建模能力的同时，大幅降低计算复杂度
    """

    def __init__(self, dim, qk_dim, pdim):
        """
        Args:
            dim (int): 输入/输出特征图的总通道数（需与上游模块输出一致，如代码示例中为64）
            qk_dim (int): 注意力Q/K的通道数（单头注意力的维度，如代码示例中为16，控制注意力计算量）
            pdim (int): 注意力分支的通道数（从总通道dim中拆分，用于生成Q/K/V，如代码示例中为32）
        """
        super().__init__()
        self.scale = qk_dim ** -0.5  # 注意力缩放因子（1/√qk_dim），缓解Q·K^T点积结果过大导致的Softmax饱和
        self.qk_dim = qk_dim  # 保存Q/K维度，用于后续拆分
        self.dim = dim  # 保存总通道数，用于特征拆分与拼接
        self.pdim = pdim  # 保存注意力分支通道数，用于特征拆分

        self.pre_norm = GroupNorm(pdim)  # 注意力分支的预归一化：使用单组归一化，稳定注意力训练
        # Q/K/V生成模块：1×1卷积+BN，将注意力分支（pdim通道）映射为Q/K/V（qk_dim*2 + pdim通道）
        self.qkv = Conv2d_BN(pdim, qk_dim * 2 + pdim)
        # 输出投影模块：ReLU激活+1×1卷积+BN，对拼接后的特征进行非线性变换与维度调整
        # BN权重初始化为0：确保初始训练时投影模块接近恒等映射，稳定网络收敛
        self.proj = torch.nn.Sequential(
            torch.nn.ReLU(),  # 引入非线性，增强特征表达
            Conv2d_BN(dim, dim, bn_weight_init=0)  # 通道数保持dim不变，确保输入输出一致
        )

    def forward(self, x):
        """
        SHSA前向传播流程：特征分支拆分→注意力分支预处理→Q/K/V生成→单头注意力计算→特征融合→输出投影
        Args:
            x (torch.Tensor): 输入特征图，形状为 [B, dim, H, W]（如代码示例中为[1, 64, 32, 32]）
        Returns:
            torch.Tensor: 输出特征图，形状与输入完全一致 [B, dim, H, W]，支持模块级联
        """
        B, C, H, W = x.shape  # B=批量，C=总通道数（dim），H=高度，W=宽度

        # 步骤1：特征分支拆分（总通道dim分为“注意力分支（pdim）”与“身份分支（dim-pdim）”）
        # 身份分支（x2）直接保留，不参与注意力计算，减少复杂度；注意力分支（x1）用于生成Q/K/V
        x1, x2 = torch.split(x, [self.pdim, self.dim - self.pdim], dim=1)  # x1: [B,pdim,H,W], x2: [B,dim-pdim,H,W]

        # 步骤2：注意力分支预处理（预归一化→生成Q/K/V）
        x1 = self.pre_norm(x1)  # 归一化：稳定注意力计算，避免特征分布偏移
        qkv = self.qkv(x1)  # 卷积映射：[B,pdim,H,W] → [B, qk_dim*2 + pdim, H, W]
        # 拆分Q/K/V：按通道维度拆分，Q/K各占qk_dim通道，V占pdim通道
        q, k, v = qkv.split([self.qk_dim, self.qk_dim, self.pdim], dim=1)  # q/k: [B,qk_dim,H,W], v: [B,pdim,H,W]

        # 步骤3：单头注意力计算（展平空间维度为序列）
        # 展平：将[H,W]空间维度展平为1D序列，形状变为 [B, 通道数, H*W]（适配自注意力的序列输入格式）
        q, k, v = q.flatten(2), k.flatten(2), v.flatten(2)
        # 计算注意力权重：Q^T · K（转置Q以匹配序列维度）→ 缩放 → Softmax归一化
        attn = (q.transpose(-2, -1) @ k) * self.scale  # attn: [B, H*W, H*W]（序列长度×序列长度）
        attn = attn.softmax(dim=-1)  # 沿最后一维归一化，得到注意力权重

        # 注意力加权V：V · 注意力权重 → 恢复空间维度
        x1 = (v @ attn.transpose(-2, -1)).reshape(B, self.pdim, H, W)  # x1: [B,pdim,H,W]（与原始注意力分支维度一致）

        # 步骤4：特征融合与输出投影
        # 拼接：注意力分支结果（x1）与身份分支（x2）按通道维度拼接，恢复总通道dim
        x_concat = torch.cat([x1, x2], dim=1)  # [B, pdim + (dim-pdim), H, W] = [B, dim, H, W]
        # 投影：非线性变换与维度调整，输出最终特征
        x = self.proj(x_concat)  # [B, dim, H, W]

        return x

if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 64, 32, 32).to(device)
    model = SHSA(64, 16, 32)

    model.to(device)
    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("知乎、CSDN：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)