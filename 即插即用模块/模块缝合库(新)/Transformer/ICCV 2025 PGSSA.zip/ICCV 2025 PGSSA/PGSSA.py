import torch
import torch.nn as nn
import torch.nn.functional as F
from einops import rearrange


def to_3d(x):
    return rearrange(x, 'b c h w -> b (h w) c')


def to_4d(x,h,w):
    return rearrange(x, 'b (h w) c -> b c h w',h=h,w=w)


class Spectral_Attention(nn.Module):
    """
    全局谱注意力模块：基于QKV的全局谱特征增强，捕捉长距离全局关联
    核心作用：通过谱域注意力筛选全局有效特征，强化全局结构关联
    输入：空间特征 [B, C, H, W]
    输出：全局增强特征 [B, C, H, W]
    Args:
        dim: 输入/输出通道数
        num_heads: 注意力头数
        bias: 卷积层是否加偏置
    """

    def __init__(self, dim, num_heads, bias):
        super(Spectral_Attention, self).__init__()
        self.num_heads = num_heads
        self.temperature = nn.Parameter(torch.ones(num_heads, 1, 1))  # 注意力温度参数（可学习）
        # QKV生成：1×1卷积（通道映射）
        self.qkv = nn.Conv2d(dim, dim * 3, kernel_size=1, bias=bias)
        # QKV深度卷积：3×3深度卷积增强局部谱特征
        self.qkv_dwconv = nn.Conv2d(
            dim * 3, dim * 3, kernel_size=3, stride=1, padding=1,
            groups=dim * 3, bias=bias
        )
        # 输出投影：1×1卷积恢复通道
        self.project_out = nn.Conv2d(dim, dim, kernel_size=1, bias=bias)

    def forward(self, x):
        b, c, h, w = x.shape
        # QKV生成+深度卷积增强
        qkv = self.qkv_dwconv(self.qkv(x))  # [B, 3C, H, W]
        q, k, v = qkv.chunk(3, dim=1)  # 拆分Q/K/V，各[B, C, H, W]

        # 多头重组+归一化
        q = rearrange(q, 'b (head c) h w -> b head c (h w)', head=self.num_heads)  # [B, heads, C//heads, H×W]
        k = rearrange(k, 'b (head c) h w -> b head c (h w)', head=self.num_heads)
        v = rearrange(v, 'b (head c) h w -> b head c (h w)', head=self.num_heads)
        q = F.normalize(q, dim=-1)
        k = F.normalize(k, dim=-1)

        # 全局谱注意力计算
        attn = (q @ k.transpose(-2, -1)) * self.temperature  # 注意力分数
        attn = attn.softmax(dim=-1)  # 权重归一化
        out = (attn @ v)  # 注意力加权

        # 格式恢复+投影输出
        out = rearrange(out, 'b head c (h w) -> b (head c) h w', head=self.num_heads, h=h, w=w)
        out = self.project_out(out)
        return out


class PG_Spectral_Attention(nn.Module):
    """
    提示引导局部谱注意力模块：通过可学习提示与通道压缩，强化局部谱特征
    核心作用：利用提示引导筛选关键局部谱特征，降低计算量的同时提升针对性
    输入：序列特征 [B, N, C]（N=H×W）
    输出：局部增强序列特征 [B, N, C]
    Args:
        dim: 输入/输出通道数
        compress_ratio: 通道压缩比例（默认8）
        num_heads: 注意力头数
        prompt_len: 提示向量长度（默认128）
        bias: 线性层是否加偏置
    """

    def __init__(self, dim, compress_ratio, num_heads, prompt_len, bias):
        super(PG_Spectral_Attention, self).__init__()
        self.num_heads = num_heads
        self.scale = (dim // compress_ratio) ** -0.5  # 注意力缩放因子
        # 通道压缩/恢复：降低计算量
        self.linear_down = nn.Linear(dim, dim // compress_ratio, bias=bias)  # 压缩至C//8
        self.linear_up = nn.Linear(dim // compress_ratio, dim, bias=bias)  # 恢复至C
        # 提示权重生成：基于全局平均特征
        self.linear_prompt = nn.Linear(dim, prompt_len, bias=bias)
        # 可学习提示参数：引导局部谱特征筛选
        self.prompt_param = nn.Parameter(torch.rand(1, 1, prompt_len, dim // compress_ratio))  # [1,1,128,8]
        # 局部注意力QKV生成
        self.q = nn.Linear(dim // compress_ratio, dim // compress_ratio, bias=bias)
        self.kv = nn.Linear(dim // compress_ratio, dim * 2 // compress_ratio, bias=bias)
        self.proj = nn.Linear(dim // compress_ratio, dim // compress_ratio)  # 注意力输出投影

    def forward(self, x_kv):
        shortcut = x_kv  # 残差连接：保留原始特征
        B_, N, C = x_kv.shape  # [B, H×W, C]

        # 步骤1：全局平均特征提取（生成提示权重的基础）
        x_global = x_kv.mean(dim=1).unsqueeze(1)  # [B, 1, C]（全局统计特征）

        # 步骤2：提示权重生成+提示向量融合
        prompt_weights = F.softmax(self.linear_prompt(x_global), dim=-1)  # [B,1,prompt_len]（提示权重）
        x_compress = self.linear_down(x_global)  # [B,1,C//compress_ratio]（通道压缩）
        # 提示向量加权融合（可学习提示×权重）
        spectral_prompt = prompt_weights.unsqueeze(-1) * self.prompt_param.repeat(B_, 1, 1, 1)  # [B,1,prompt_len,C//8]
        spectral_prompt = torch.sum(spectral_prompt, dim=2)  # [B,1,C//8]（融合为单提示向量）

        # 步骤3：局部谱注意力计算
        q = self.q(spectral_prompt)  # [B,1,C//8]（提示引导的Q）
        kv = self.kv(x_compress)  # [B,1,2×C//8]（KV生成）
        k, v = kv.chunk(2, dim=2)  # 拆分K/V，各[B,1,C//8]
        # 注意力权重计算
        attn_weights = torch.matmul(q.transpose(-2, -1), k) * self.scale  # [B,C//8,C//8]
        attn_weights = attn_weights.softmax(dim=-1)
        # 注意力加权+投影
        out = (attn_weights @ v.transpose(-2, -1)).transpose(-2, -1).contiguous()  # [B,1,C//8]
        out = self.proj(out)

        # 步骤4：通道恢复+残差融合
        out = self.linear_up(out)  # [B,1,C]（恢复原始通道）
        out = out * shortcut  # 逐元素乘法融合（提示引导增强原始特征）

        return out

class PGSSA(nn.Module):

    def __init__(self, dim, num_heads, compress_ratio=8, prompt_len=128, bias=False):
        super(PGSSA,self).__init__()
        self.dim = dim
        self.num_heads = num_heads

        self.gobal_spectral_attn = Spectral_Attention(dim, num_heads, bias)
        self.local_spectral_attn = PG_Spectral_Attention(dim, compress_ratio, num_heads, prompt_len, bias)

    def forward(self, x):
        B, C, H, W = x.shape

        x1 = to_3d(x)
        x1 = self.local_spectral_attn(x1)
        x1 = to_4d(x1, H, W)

        x2 = self.gobal_spectral_attn(x)

        x = x1 + x2
        return x


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 64, 32, 32).to(device)
    model = PGSSA(64, 4).to(device)

    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN、小红书：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)


