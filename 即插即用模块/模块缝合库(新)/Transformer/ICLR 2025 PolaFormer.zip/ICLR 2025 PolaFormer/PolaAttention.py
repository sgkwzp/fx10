import torch
import torch.nn as nn
from einops import rearrange

def to_3d(x):
    return rearrange(x, 'b c h w -> b (h w) c')

def to_4d(x,h,w):
    return rearrange(x, 'b (h w) c -> b c h w', h=h, w=w)


class PolaLinearAttention(nn.Module):
    """
    极性感知线性注意力模块（Polarity-aware Linear Attention）
    核心创新：显式建模查询（Q）与键（K）的正/负极性交互（正-正、负-负、正-负、负-正），
    解决传统线性注意力因非负约束丢失负值信息的问题；同时通过可学习幂函数降低注意力熵，
    在保持O(n)线性复杂度的同时，提升注意力图的判别力（接近Softmax注意力的“尖峰”特性）
    """

    def __init__(self, dim, num_patches, num_heads=8, qkv_bias=False, qk_scale=None, attn_drop=0., proj_drop=0.,
                 sr_ratio=1, kernel_size=5, alpha=4):
        """
        Args:
            dim (int): 输入token的通道数（需与特征图通道数一致，如代码示例中为64）
            num_patches (int): 输入特征的总token数（h*w，用于初始化位置编码）
            num_heads (int): 注意力头数（默认8，需满足dim能被num_heads整除）
            qkv_bias (bool): 生成Q/K/V/G的线性层是否使用偏置（默认False，减少参数冗余）
            qk_scale (float): 传统注意力的缩放因子（本模块未使用，默认None）
            attn_drop (float): 注意力权重的Dropout概率（默认0.，抑制过拟合）
            proj_drop (float): 输出投影层的Dropout概率（默认0.，抑制过拟合）
            sr_ratio (int): 下采样比例（默认1，>1时通过卷积下采样K/V，进一步降低复杂度）
            kernel_size (int): 深度可分离卷积的核大小（默认5，用于增强V的局部特征）
            alpha (int): 幂函数参数的缩放系数（默认4，控制可学习幂次的调整范围）
        """
        super().__init__()
        # 校验：确保通道数dim能被注意力头数num_heads整除（多头注意力的基础要求）
        assert dim % num_heads == 0, f"dim {dim} should be divided by num_heads {num_heads}."

        self.dim = dim  # 输入/输出通道数
        self.num_heads = num_heads  # 注意力头数
        self.head_dim = dim // num_heads  # 单头注意力的通道数
        self.alpha = alpha  # 幂函数参数缩放系数

        # Q/G生成层：将输入token映射为查询Q（dim→dim）和门控G（dim→dim），共输出2×dim通道
        self.qg = nn.Linear(dim, 2 * dim, bias=qkv_bias)
        # K/V生成层：将输入token（或下采样后的token）映射为键K（dim→dim）和值V（dim→dim），共输出2×dim通道
        self.kv = nn.Linear(dim, dim * 2, bias=qkv_bias)

        # Dropout层：注意力权重失活与输出投影失活
        self.attn_drop = nn.Dropout(attn_drop)
        self.proj = nn.Linear(dim, dim)  # 输出投影层：将注意力结果映射回原通道
        self.proj_drop = nn.Dropout(proj_drop)

        self.sr_ratio = sr_ratio  # K/V下采样比例（>1时启用）
        # K/V下采样模块：通过卷积下采样减少K/V的token数量，降低计算量
        if sr_ratio > 1:
            self.sr = nn.Conv2d(dim, dim, kernel_size=sr_ratio, stride=sr_ratio)  # 下采样卷积（步长=比例）
            self.norm = nn.LayerNorm(dim)  # 下采样后的归一化层，稳定K/V特征分布

        # 深度可分离卷积：增强V的局部特征（逐头独立卷积，groups=head_dim确保单头通道内卷积）
        self.dwc = nn.Conv2d(
            in_channels=self.head_dim,
            out_channels=self.head_dim,
            kernel_size=kernel_size,
            groups=self.head_dim,  # 深度可分离卷积（逐通道卷积）
            padding=kernel_size // 2  # 对称padding，确保卷积后尺寸不变
        )

        # 可学习参数：控制注意力熵与极性交互
        self.power = nn.Parameter(torch.zeros(size=(1, self.num_heads, 1, self.head_dim)))  # 幂次参数（每头每通道独立）
        self.scale = nn.Parameter(torch.zeros(size=(1, 1, dim)))  # Q/K的全局缩放因子（Softplus激活确保正值）
        # 位置编码：为K添加位置信息，增强空间关联性（下采样后token数=num_patches/(sr_ratio^2)）
        self.positional_encoding = nn.Parameter(
            torch.zeros(size=(1, num_patches // (sr_ratio * sr_ratio), dim))
        )

        # 打印模块配置信息（便于调试与日志记录）
        print('Linear Attention sr_ratio{} f{} kernel{}'.format(sr_ratio, alpha, kernel_size))

    def forward(self, x, H, W):
        """
        前向传播流程：Q/G生成→K/V生成（可选下采样）→极性分解→幂函数变换→双分支注意力计算→局部特征增强→门控融合→输出投影
        Args:
            x (torch.Tensor): 输入3D特征，形状为 [b, n, c]（b=批量，n=token数量=h*w，c=通道数=dim）
                             （代码示例中为[1, 1024, 64]，即1个样本、32×32=1024个token、64维通道）
            H (int): 输入特征图的高度
            W (int): 输入特征图的宽度
        Returns:
            torch.Tensor: 输出3D特征，形状与输入一致 [b, n, c]，支持后续维度恢复为4D特征图
        """
        B, N, C = x.shape  # 解析输入维度：b=批量，n=token数，c=通道数

        # 步骤1：生成Q（查询）与G（门控）
        # 线性投影：[b, n, c] → [b, n, 2c] → 按通道拆分Q和G（各[b, n, c]）
        q, g = self.qg(x).reshape(B, N, 2, C).unbind(2)

        # 步骤2：生成K（键）与V（值）（可选下采样）
        if self.sr_ratio > 1:
            # K/V下采样流程：3D→4D→卷积下采样→4D→3D→归一化
            x_ = x.permute(0, 2, 1).reshape(B, C, H, W)  # 3D→4D：[b, n, c] → [b, c, h, w]
            x_ = self.sr(x_)  # 卷积下采样：[b, c, h, w] → [b, c, h/sr, w/sr]
            x_ = x_.reshape(B, C, -1).permute(0, 2, 1)  # 4D→3D：[b, c, n/sr²] → [b, n/sr², c]
            x_ = self.norm(x_)  # 归一化：稳定下采样后的K/V特征
            # 生成K/V并调整维度：[b, n/sr², 2c] → [2, b, n/sr², c] → 拆分K和V（各[b, n/sr², c]）
            kv = self.kv(x_).reshape(B, -1, 2, C).permute(2, 0, 1, 3)
        else:
            # 无下采样：直接生成K/V
            kv = self.kv(x).reshape(B, -1, 2, C).permute(2, 0, 1, 3)
        k, v = kv[0], kv[1]  # 拆分K和V：k=[b, n_k, c], v=[b, n_k, c]（n_k为K的token数，n_k≤n）
        n_k = k.shape[1]  # 记录K的token数

        # 步骤3：K添加位置编码（增强空间关联性）
        k = k + self.positional_encoding  # [b, n_k, c] + [1, n_k, c] → [b, n_k, c]

        # 步骤4：初始化极性交互相关组件
        kernel_function = nn.ReLU()  # 极性分解函数：分离正/负分量（ReLU保留正值，-ReLU保留负值）
        scale = nn.Softplus()(self.scale)  # 全局缩放因子：Softplus确保正值，避免零除
        # 可学习幂次：1 + α×sigmoid(power)，sigmoid确保幂次在[1, 1+α]范围内（α=4时为[1,5]）
        power = 1 + self.alpha * nn.functional.sigmoid(self.power)

        # 步骤5：Q/K全局缩放（平衡特征尺度）
        q = q / scale  # [b, n, c] → [b, n, c]
        k = k / scale  # [b, n_k, c] → [b, n_k, c]

        # 步骤6：多头拆分（按头维度重排，便于并行处理极性交互）
        # Q重排：[b, n, c] → [b, n, heads, head_dim] → [b, heads, n, head_dim]
        q = q.reshape(B, N, self.num_heads, -1).permute(0, 2, 1, 3).contiguous()
        # K重排：[b, n_k, c] → [b, n_k, heads, head_dim] → [b, heads, n_k, head_dim]
        k = k.reshape(B, n_k, self.num_heads, -1).permute(0, 2, 1, 3).contiguous()
        # V重排：[b, n_k, c] → [b, n_k, heads, head_dim] → [b, heads, n_k, head_dim]
        v = v.reshape(B, n_k, self.num_heads, -1).permute(0, 2, 1, 3).contiguous()

        # 步骤7：极性分解与幂函数变换（核心步骤，显式建模正/负交互）
        # Q的正/负分量：ReLU(q)取正，ReLU(-q)取负，再求幂次（增强强弱信号区分）
        q_pos = kernel_function(q) ** power  # [b, heads, n, head_dim]（Q正分量）
        q_neg = kernel_function(-q) ** power  # [b, heads, n, head_dim]（Q负分量）
        # K的正/负分量：同Q的分解逻辑
        k_pos = kernel_function(k) ** power  # [b, heads, n_k, head_dim]（K正分量）
        k_neg = kernel_function(-k) ** power  # [b, heads, n_k, head_dim]（K负分量）

        # 步骤8：构建极性交互分支（同符号交互+异符号交互）
        # 同符号分支（Q_sim）：[Q正, Q负] → 对应K的[K正, K负]，捕捉正-正、负-负交互
        q_sim = torch.cat([q_pos, q_neg], dim=-1)  # [b, heads, n, 2×head_dim]
        # 异符号分支（Q_opp）：[Q负, Q正] → 对应K的[K正, K负]，捕捉负-正、正-负交互
        q_opp = torch.cat([q_neg, q_pos], dim=-1)  # [b, heads, n, 2×head_dim]
        # K拼接：[K正, K负] → 统一适配两个分支的查询
        k = torch.cat([k_pos, k_neg], dim=-1)  # [b, heads, n_k, 2×head_dim]
        # V拆分：将V分为两部分，分别适配同符号、异符号分支的注意力加权
        v1, v2 = torch.chunk(v, 2, dim=-1)  # 各[b, heads, n_k, head_dim]

        # 步骤9：同符号分支注意力计算（线性注意力，复杂度O(n×n_k)）
        # 分母归一化：q_sim与K的均值点积，避免注意力权重过大
        z = 1 / (q_sim @ k.mean(dim=-2, keepdim=True).transpose(-2, -1) + 1e-6)  # [b, heads, n, 1]
        # KV乘积：K^T × V1（线性注意力的核心，预计算全局信息）
        kv = (k.transpose(-2, -1) * (n_k ** -0.5)) @ (v1 * (n_k ** -0.5))  # [b, heads, 2×head_dim, head_dim]
        # 注意力加权：q_sim × KV × 归一化因子 → 同符号交互结果
        x_sim = q_sim @ kv * z  # [b, heads, n, head_dim]

        # 步骤10：异符号分支注意力计算（与同符号分支逻辑一致，适配v2）
        z = 1 / (q_opp @ k.mean(dim=-2, keepdim=True).transpose(-2, -1) + 1e-6)  # [b, heads, n, 1]
        kv = (k.transpose(-2, -1) * (n_k ** -0.5)) @ (v2 * (n_k ** -0.5))  # [b, heads, 2×head_dim, head_dim]
        x_opp = q_opp @ kv * z  # [b, heads, n, head_dim]

        # 步骤11：双分支结果拼接（同符号+异符号交互）
        x = torch.cat([x_sim, x_opp],
                      dim=-1)  # [b, heads, n, 2×head_dim] → [b, heads, n, c]（因2×head_dim=dim/heads×2？不，实际为head_dim×2，拼接后为dim/heads×2？此处需注意：因dim=heads×head_dim，2×head_dim=2×(dim/heads)，拼接后每头维度为2×(dim/heads)，但后续reshape会合并为dim）
        # 多头结果重组：[b, heads, n, c] → [b, n, heads×c] → [b, n, c]（因heads×(2×head_dim) = 2×dim？不，实际代码中通过reshape强制匹配dim，需确保通道数一致）
        x = x.transpose(1, 2).reshape(B, N, C)

        # 步骤12：V的局部特征增强（深度可分离卷积）
        if self.sr_ratio > 1:
            # 若K/V下采样，需将V上采样至原始token数N（线性插值）
            v = nn.functional.interpolate(
                v.transpose(-2, -1).reshape(B * self.num_heads, -1, n_k),  # [b×heads, head_dim, n_k]
                size=N,  # 上采样至N个token
                mode='linear'  # 线性插值（适配序列维度）
            ).reshape(B, self.num_heads, -1, N).transpose(-2, -1)  # 重组为[b, heads, n, head_dim]
        # V的维度转换与卷积增强：[b, heads, n, head_dim] → 4D卷积格式 → 深度可分离卷积 → 3D格式
        v = v.reshape(B * self.num_heads, H, W, -1).permute(0, 3, 1, 2)  # [b×heads, head_dim, h, w]
        v = self.dwc(v)  # 深度可分离卷积：增强局部特征 → [b×heads, head_dim, h, w]
        v = v.reshape(B, C, N).permute(0, 2, 1)  # 4D→3D：[b, c, n] → [b, n, c]

        # 步骤13：特征融合与门控机制
        x = x + v  # 注意力结果 + 局部增强V（残差融合）
        x = x * g  # 门控融合：通过G筛选重要特征 → [b, n, c]

        # 步骤14：输出投影与失活
        x = self.proj(x)  # 线性投影：确保输出通道与输入一致 → [b, n, c]
        x = self.proj_drop(x)  # 输出失活：抑制过拟合

        return x

if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    B = 1
    C = 64
    H = 32
    W = 32
    N = H * W

    input = torch.randn(B, C, H, W).to(device)
    model = PolaLinearAttention(C, N)

    x = to_3d(input)

    model.to(device)
    y = model(x, H, W)

    output = to_4d(y, H, W)

    print("微信公众号：十小大的底层视觉工坊")
    print("知乎、CSDN：十小大")

    print("输入特征维度：", input.shape)
    print("输出特征维度：", output.shape)