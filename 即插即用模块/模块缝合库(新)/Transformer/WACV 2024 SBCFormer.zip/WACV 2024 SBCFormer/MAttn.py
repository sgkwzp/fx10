import torch
import torch.nn as nn
import itertools  # 用于生成网格点坐标，计算注意力偏置索引

class Conv2d_BN(nn.Module):
    def __init__(self, in_features, out_features=None, kernel_size=3, stride=1, padding=0, dilation=1,
                 groups=1, bn_weight_init=1):
        super().__init__()
        self.conv = nn.Conv2d(in_features, out_features, kernel_size, stride, padding, dilation, groups, bias=False)
        self.bn = nn.BatchNorm2d(out_features)
        torch.nn.init.constant_(self.bn.weight, bn_weight_init)
        torch.nn.init.constant_(self.bn.bias, 0)

    def forward(self, x):
        x = self.conv(x)
        x = self.bn(x)
        return x


class MAttn(torch.nn.Module):
    def __init__(self, dim=384, key_dim=32, num_heads=8, attn_ratio=2):
        """
        Args:
            dim: 输入/输出特征通道数（模块保持通道数不变，即插即用）
            key_dim: 单个注意力头的键（K）维度，控制注意力计算粒度
            num_heads: 多头注意力头数，并行捕捉不同维度特征
            attn_ratio: 值（V）维度相对于K维度的扩展比例，默认2（V_dim = attn_ratio * key_dim * num_heads）
        """
        super().__init__()
        self.key_dim = key_dim
        self.num_heads = num_heads
        self.attn_ratio = attn_ratio
        # 注意力缩放因子：避免Q@K^T内积结果过大导致softmax梯度消失
        self.scale = key_dim ** -0.5

        # 计算关键维度：适配多头注意力拆分
        self.nh_kd = key_dim * num_heads          # 所有头的K维度总和（Q与K维度一致）
        self.qk_dim = 2 * self.nh_kd              # Q+K的总维度（2*所有头K维度）
        self.v_dim = int(attn_ratio * key_dim) * num_heads  # 所有头的V维度总和
        dim_h = self.v_dim + self.qk_dim          # 输入通道扩展后的总维度（QK+V）

        # 核心卷积层：实现特征维度转换与增强
        self.pwconv = nn.Conv2d(dim, dim_h, kernel_size=1, stride=1, padding=0)  # 1x1卷积：将输入通道扩展为dim_h（拆分QK与V）
        self.dwconv = Conv2d_BN(self.v_dim, self.v_dim, kernel_size=3, stride=1, padding=1, groups=self.v_dim)  # 深度可分离卷积：增强V的局部特征
        self.proj_out = nn.Conv2d(self.v_dim, dim, kernel_size=1, stride=1, padding=0)  # 1x1卷积：将V维度恢复为输入dim，保证输出一致
        self.act = nn.GELU()  # 激活函数：引入非线性，增强特征表达（相比ReLU更适合Transformer类模块）

        # 预计算空间注意力偏置：基于像素坐标偏移，捕捉空间位置依赖
        max_res = 64  # 支持的最大分辨率（可根据任务调整，如128）
        # 生成max_res×max_res的网格点坐标（(0,0), (0,1), ..., (max_res-1, max_res-1)）
        points = list(itertools.product(range(max_res), range(max_res)))
        N = len(points)
        attention_offsets = {}  # 存储（行偏移，列偏移）到索引的映射
        idxs = []  # 存储每个（p1,p2）对的偏移索引

        # 遍历所有像素对，计算偏移并分配唯一索引
        for p1 in points:
            for p2 in points:
                # 计算p1与p2的绝对偏移（行偏移，列偏移）：与位置无关，仅与相对距离有关
                offset = (abs(p1[0] - p2[0]), abs(p1[1] - p2[1]))
                if offset not in attention_offsets:
                    attention_offsets[offset] = len(attention_offsets)  # 新偏移分配新索引
                idxs.append(attention_offsets[offset])  # 记录当前像素对的偏移索引

        # 可学习空间偏置：每个注意力头对不同偏移的偏好不同
        self.attention_biases = torch.nn.Parameter(torch.zeros(num_heads, len(attention_offsets)))
        # 注册偏移索引缓冲区：无需梯度更新，形状为[N, N]（N=max_res×max_res）
        self.register_buffer('attention_bias_idxs', torch.LongTensor(idxs).view(N, N))

    @torch.no_grad()  # 无梯度计算：仅修改模块状态，不影响参数更新
    def train(self, mode=True):
        """
        重写train方法：训练时删除预计算偏置（保证动态更新），测试时预计算当前分辨率偏置（加速推理）
        """
        super().train(mode)
        if mode and hasattr(self, 'ab'):
            del self.ab  # 训练模式：删除预计算的偏置ab，避免复用旧分辨率偏置
        else:
            # 测试模式：根据当前分辨率截取偏置，存储为ab（后续直接复用）
            h = self.current_resolution  # 当前输入分辨率（h=w）
            N = h * h  # 当前分辨率的像素总数
            self.ab = self.attention_biases[:, self.attention_bias_idxs[:N, :N]]  # 截取N×N的偏置矩阵

    def forward(self, x):
        """
        前向传播：输入(b,c,h,w)，输出(b,c,h,w)，核心流程为「维度转换→QKV生成→注意力计算→特征恢复」
        Args:
            x: 输入特征，形状[B, C, H, W]（B=批次，C=通道数=dim，H=高，W=宽）
        Returns:
            x: 输出特征，形状与输入一致[B, dim, H, W]
        """
        B, C, H, W = x.shape
        self.current_resolution = H  # 记录当前输入分辨率（假设H=W，适配常见视觉任务）
        N = H * W  # 当前分辨率的像素总数（展平后序列长度）

        # 步骤1：通道扩展与QKV拆分
        x = self.pwconv(x)  # [B, dim, H, W] → [B, dim_h, H, W]（dim_h=QK+V维度）
        # 按通道拆分QK和V：QK占前qk_dim通道，V占后v_dim通道
        qk, v1 = x.split([self.qk_dim, self.v_dim], dim=1)  # qk: [B, qk_dim, H, W]; v1: [B, v_dim, H, W]

        # 步骤2：Q与K维度转换（适配多头注意力）
        # 1. 拆分QK为2（Q/K）×num_heads×key_dim，形状变为[B, 2, num_heads, key_dim, H, W]
        qk = qk.reshape(B, 2, self.num_heads, self.key_dim, H, W)
        # 2. 转置维度：将分辨率维度（H,W）移至序列维度，展平为N=H×W，最终形状[2, B, num_heads, N, key_dim]
        qk = qk.permute(1, 0, 2, 4, 5, 3).reshape(2, B, self.num_heads, N, self.key_dim)
        q, k = qk[0], qk[1]  # 分别提取Q和K：均为[B, num_heads, N, key_dim]

        # 步骤3：V维度转换与局部增强
        # 1. 深度可分离卷积增强V的局部特征：保持通道数和尺寸不变
        v1 = v1 + self.act(self.dwconv(v1))  # [B, v_dim, H, W] → 残差连接增强局部信息
        # 2. 拆分V为num_heads个注意力头，展平为序列维度，最终形状[B, num_heads, N, v_dim/num_heads]
        v = v1.reshape(B, self.num_heads, -1, H, W).permute(0, 1, 3, 4, 2).reshape(B, self.num_heads, N, -1)

        # 步骤4：空间偏置注意力计算
        # 1. 基础注意力权重：Q@K^T × 缩放因子（避免内积过大）
        attn = (q @ k.transpose(-2, -1)) * self.scale  # [B, num_heads, N, N]
        # 2. 添加空间偏置：训练时动态截取，测试时用预计算偏置
        if self.training:
            # 训练模式：截取当前分辨率的N×N偏置矩阵
            attn_bias = self.attention_biases[:, self.attention_bias_idxs[:N, :N]]
            attn = attn + attn_bias  # [B, num_heads, N, N] + [num_heads, N, N] → 广播后相加
        else:
            # 测试模式：直接使用预计算的偏置ab，加速推理
            attn = attn + self.ab
        # 3. softmax归一化：得到注意力权重（每行和为1）
        attn = attn.softmax(dim=-1)  # [B, num_heads, N, N]

        # 步骤5：注意力加权与维度恢复
        # 1. 注意力加权V：用注意力权重筛选有效特征
        x = (attn @ v)  # [B, num_heads, N, v_dim/num_heads]
        # 2. 转置与重塑：将多头维度合并，恢复空间维度（H,W）
        x = x.transpose(1, 2).reshape(B, H, W, self.v_dim)  # [B, N, v_dim] → [B, H, W, v_dim]
        # 3. 通道维度转置：从[B, H, W, C]转为CNN常用的[B, C, H, W]
        x = x.permute(0, 3, 1, 2)  # [B, v_dim, H, W]

        # 步骤6：输出投影（恢复输入通道数）
        x = self.proj_out(x)  # [B, v_dim, H, W] → [B, dim, H, W]（与输入维度一致）

        return x


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    x = torch.randn(1, 96, 32, 32).to(device)
    model = MAttn(dim=96, key_dim=16, num_heads=3, attn_ratio=2)        # 根据实际情况修改参数
    model.to(device)
    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("知乎、CSDN：十小大")
    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)