import torch
import torch.nn as nn
import torch.nn.functional as F
from timm.models.layers import trunc_normal_
from einops import rearrange


def to_4d(x, h, w):
    """
    序列特征转4D空间特征：将BNC格式（批次×序列长度×通道）转为BCHW格式（批次×通道×高×宽）
    参数：
        x: 输入特征 [B, N, C]（N=h×w）
        h/w: 目标特征图的高/宽
    返回：
        4D空间特征 [B, C, h, w]
    """
    return rearrange(x, 'b (h w) c -> b c h w', h=h, w=w)


class StarReLU(nn.Module):
    """
    星型激活函数（StarReLU）：s * relu(x)² + b，增强非线性表达与特征判别性
    核心作用：比传统ReLU更平滑，适配频域特征的连续分布，提升模型泛化性
    输入：任意维度特征张量
    输出：激活后特征张量（维度与输入一致）
    """

    def __init__(self, scale_value=1.0, bias_value=0.0,
                 scale_learnable=True, bias_learnable=True,
                 mode=None, inplace=False):
        super().__init__()
        self.inplace = inplace
        self.relu = nn.ReLU(inplace=inplace)  # 基础ReLU激活
        # 可学习缩放因子s（默认1.0，支持是否训练）
        self.scale = nn.Parameter(scale_value * torch.ones(1), requires_grad=scale_learnable)
        # 可学习偏置b（默认0.0，支持是否训练）
        self.bias = nn.Parameter(bias_value * torch.ones(1), requires_grad=bias_learnable)

    def forward(self, x):
        """前向传播：relu(x)平方×缩放因子+偏置"""
        return self.scale * self.relu(x) ** 2 + self.bias


class AttentionwithAttInv(nn.Module):
    """
    逆注意力模块（AttInv，FDAM核心组件1）：融合低频增强与高频调制，提升频域特征判别性
    核心创新：
        1. 低频动态增强：通过可学习权重强化低频全局结构特征；
        2. 高频残差调制：基于注意力残差（v - x）动态优化高频细节；
        3. 星型激活适配：StarReLU增强特征非线性，适配频域分布；
        4. 轻量化设计：无额外冗余参数，仅新增少量线性层与可学习因子。
    输入：
        x: 序列特征 [B, N, C]（N=h×w，序列长度=空间像素总数）
        H/W: 特征图高/宽（可选，预留空间维度适配）
    输出：
        逆注意力增强特征 [B, N, C]（与输入维度一致）
    """

    def __init__(self, dim, num_heads=8, qkv_bias=False, qk_scale=None, attn_drop=0., proj_drop=0., lf_dy_weight=True,
                 hf_dy_weight=True):
        super().__init__()
        self.num_heads = num_heads  # 注意力头数
        head_dim = dim // num_heads  # 单头通道数
        self.scale = qk_scale or head_dim ** -0.5  # 注意力缩放因子（缓解梯度消失）

        # QKV投影层：一次性生成查询（Q）、键（K）、值（V）
        self.qkv = nn.Linear(dim, dim * 3, bias=qkv_bias)
        self.attn_drop = nn.Dropout(attn_drop)  # 注意力权重Dropout（正则化）
        self.proj = nn.Linear(dim, dim)  # 输出投影层（恢复通道数）
        self.proj_drop = nn.Dropout(proj_drop)  # 输出Dropout（正则化）

        ### 逆注意力核心配置
        self.lf_dy_weight = lf_dy_weight  # 低频动态权重开关
        self.hf_dy_weight = hf_dy_weight  # 高频动态权重开关

        # 低频增强分支：学习低频特征的动态权重
        if self.lf_dy_weight:
            self.dy_freq_2 = nn.Linear(dim, self.num_heads, bias=True)  # 低频权重预测
            self.lf_gamma = nn.Parameter(1e-5 * torch.ones((dim)), requires_grad=True)  # 低频增强因子

        # 高频调制分支：学习高频特征的动态权重
        if self.hf_dy_weight:
            self.dy_freq = nn.Linear(dim, self.num_heads, bias=True)  # 高频权重预测
            self.hf_gamma = nn.Parameter(1e-5 * torch.ones((dim)), requires_grad=True)  # 高频增强因子

        self.dy_freq_starrelu = StarReLU()  # 星型激活（适配频域特征）
        self.ignore_cls_token = 0  # 忽略CLS令牌（适配ViT类模型，默认不忽略）

    def forward(self, x, H=None, W=None):
        B, N, C = x.shape  # 解析输入维度：批次、序列长度、通道数

        # 步骤1：星型激活提取频域特征（忽略CLS令牌，仅处理空间特征）
        dy_freq_feat = self.dy_freq_starrelu(x[:, self.ignore_cls_token:])  # [B, N-ignore_cls_token, C]

        # 步骤2：低频动态权重计算（可选）
        dy_freq_lf = None
        if hasattr(self, 'dy_freq_2'):
            dy_freq_lf = self.dy_freq_2(dy_freq_feat).tanh_()  # Tanh激活，权重∈[-1,1]
            # 维度适配：[B, N', num_heads]→[B, N', C]（扩展至通道维度）
            dy_freq_lf = dy_freq_lf.reshape(B, N - self.ignore_cls_token, self.num_heads, 1).repeat(1, 1, 1,
                                                                                                    C // self.num_heads)
            dy_freq_lf = dy_freq_lf.reshape(B, N - self.ignore_cls_token, C)

        # 步骤3：高频动态权重计算（可选）
        dy_freq = None
        if hasattr(self, 'dy_freq'):
            dy_freq = F.softplus(self.dy_freq(dy_freq_feat))  # Softplus激活，确保权重非负
            dy_freq2 = dy_freq ** 2  # 增强权重区分度
            dy_freq = 2 * dy_freq2 / (dy_freq2 + 0.3678)  # 归一化至[0,2]
            # 维度适配+CLS令牌补零（若存在）
            dy_freq = dy_freq.reshape(B, N - self.ignore_cls_token, self.num_heads, 1).repeat(1, 1, 1,
                                                                                              C // self.num_heads)
            dy_freq = dy_freq.reshape(B, N - self.ignore_cls_token, C)
            if self.ignore_cls_token > 0:
                dy_freq = torch.cat([torch.zeros([B, self.ignore_cls_token, C], device=dy_freq.device), dy_freq], dim=1)

        # 步骤4：标准多头注意力计算
        # QKV生成与维度重排：[B, N, 3C]→[3, B, num_heads, N, C//num_heads]
        qkv = self.qkv(x).reshape(B, N, 3, self.num_heads, C // self.num_heads).permute(2, 0, 3, 1, 4)
        q, k, v = qkv[0], qkv[1], qkv[2]  # 拆分Q/K/V
        q = q * self.scale  # Q缩放

        # 注意力分数计算→Softmax→Dropout
        attn = (q @ k.transpose(-2, -1))  # [B, num_heads, N, N]
        attn = attn.softmax(dim=-1)
        attn = self.attn_drop(attn)

        # 注意力加权V→维度恢复
        x_attn = (attn @ v).transpose(1, 2).reshape(B, N, C)  # [B, N, C]

        # 步骤5：逆注意力融合（低频增强+高频调制）
        v_reshape = v.permute(0, 2, 1, 3).reshape(B, N, C)  # V维度恢复为[B, N, C]
        v_hf = v_reshape - x_attn  # 注意力残差（高频特征）

        # 低频增强：x_attn（低频主导）+ x_attn×低频权重×增强因子
        if hasattr(self, 'dy_freq_2'):
            x_attn = x_attn + x_attn * dy_freq_lf * self.lf_gamma.view(1, 1, -1)

        # 高频调制：叠加高频残差×高频权重×增强因子
        if hasattr(self, 'dy_freq'):
            x_attn = x_attn + dy_freq * v_hf * self.hf_gamma.view(1, 1, -1)

        # 步骤6：输出投影+Dropout
        x = self.proj(x_attn)
        x = self.proj_drop(x)

        return x


class Mlp(nn.Module):
    """
    多层感知机（MLP）：用于频域权重动态生成，适配MetaFormer架构
    核心作用：从全局特征统计中学习频域调制权重，轻量化设计
    输入：特征张量 [B, N, C]
    输出：权重张量 [B, N, out_features]
    """

    def __init__(self, dim, mlp_ratio=4, out_features=None, act_layer=StarReLU, drop=0.,
                 bias=False, **kwargs):
        super().__init__()
        in_features = dim
        out_features = out_features or in_features
        hidden_features = int(mlp_ratio * in_features)  # 中间通道数（mlp_ratio倍扩展）

        self.fc1 = nn.Linear(in_features, hidden_features, bias=bias)  # 线性层1（升维）
        self.act = act_layer()  # 激活函数（默认StarReLU）
        self.drop1 = nn.Dropout(drop)  # Dropout1
        self.fc2 = nn.Linear(hidden_features, out_features, bias=bias)  # 线性层2（降维）
        self.drop2 = nn.Dropout(drop)  # Dropout2

    def forward(self, x):
        x = self.fc1(x)
        x = self.act(x)
        x = self.drop1(x)
        x = self.fc2(x)
        x = self.drop2(x)
        return x


class GroupDynamicScale(nn.Module):
    """
    频域动态缩放模块（FreqScale，FDAM核心组件2）：基于FFT的频域加权调制
    核心创新：
        1. 频域分组调制：按通道分组学习频域权重，适配不同频段特征；
        2. 动态权重生成：MLP从全局特征统计中学习分组权重，非固定；
        3. 快速傅里叶变换：FFT+频域加权+iFFT，高效处理高频细节；
        4. 插值适配：权重尺寸自适应特征图尺寸，支持多尺度输入。
    输入：空间特征 [B, C, H, W]
    输出：频域增强特征 [B, C, H, W]（与输入维度一致）
    """

    def __init__(self, dim, expansion_ratio=1, reweight_expansion_ratio=.125,
                 act1_layer=StarReLU, act2_layer=nn.Identity,
                 bias=False, num_filters=4, size=14, weight_resize=True, group=32, init_scale=1e-5,
                 **kwargs):
        super().__init__()
        self.size = size  # 初始特征尺寸（用于权重初始化）
        self.filter_size = size // 2 + 1  # 频域滤波器尺寸（rFFT后维度）
        self.num_filters = num_filters  # 频域滤波器数量
        self.dim = dim  # 输入通道数
        self.group = group  # 通道分组数（需整除dim）
        self.med_channels = int(expansion_ratio * dim)  # 中间通道数（预留）
        self.weight_resize = weight_resize  # 权重尺寸自适应开关

        # 动态权重生成MLP：从全局特征统计学习分组滤波器权重
        self.reweight = Mlp(dim, reweight_expansion_ratio, group * num_filters, bias=False)

        # 可学习频域复数权重：[num_filters, dim//group, size, filter_size]
        self.complex_weights = nn.Parameter(
            torch.randn(num_filters, dim // group, self.size, self.filter_size, dtype=torch.float32) * init_scale
        )
        trunc_normal_(self.complex_weights, std=init_scale)  # 截断正态分布初始化
        self.act2 = act2_layer()  # 输出激活（默认恒等映射）

    def forward(self, x):
        B, C, H, W = x.shape  # 解析输入维度：批次、通道、高、宽

        # 步骤1：2D实数快速傅里叶变换（rFFT2）→频域特征
        x_rfft = torch.fft.rfft2(x.to(torch.float32), dim=(2, 3), norm='ortho')  # [B, C, RH, RW]（RH=H//2+1）
        B, C, RH, RW = x_rfft.shape

        # 步骤2：全局特征统计与动态权重生成
        x_spatial = x.permute(0, 2, 3, 1)  # [B, H, W, C]（空间格式）
        # 全局均值统计→MLP生成分组权重→Tanh激活（权重∈[-1,1]）
        routeing = self.reweight(x_spatial.mean(dim=(1, 2))).view(B, -1,
                                                                  self.num_filters).tanh_()  # [B, group, num_filters]

        # 步骤3：频域权重生成（分组加权+维度适配）
        weight = self.complex_weights  # [num_filters, C//group, size, filter_size]
        # 权重尺寸自适应：插值匹配频域特征尺寸
        if not weight.shape[2:4] == x_rfft.shape[2:4]:
            weight = F.interpolate(weight, size=x_rfft.shape[2:4], mode='bicubic', align_corners=True)

        # 分组加权：[B, group, num_filters] × [num_filters, C//group, RH, RW] → [B, group, C//group, RH, RW]
        weight = torch.einsum('bgf,fchw->bgchw', routeing, weight)
        weight = weight.reshape(B, C, RH, RW)  # 维度恢复：[B, C, RH, RW]

        # 步骤4：频域特征加权（实部×权重，虚部×权重）
        x_rfft = torch.view_as_complex(torch.stack([x_rfft.real * weight, x_rfft.imag * weight], dim=-1))

        # 步骤5：逆快速傅里叶变换（iFFT2）→空间特征
        x = torch.fft.irfft2(x_rfft, s=(H, W), dim=(2, 3), norm='ortho')

        return x


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    x = torch.randn(1, 32 * 32, 64).to(device)

    att_inv = AttentionwithAttInv(64).to(device)
    freq_scale = GroupDynamicScale(64).to(device)

    y1 = att_inv(x)
    y1_4d = to_4d(y1, 32, 32)
    y2 = freq_scale(y1_4d)

    print("微信公众号：十小大的底层视觉工坊")
    print("知乎、CSDN：十小大")
    print("输入特征维度：", x.shape)
    print("AttInv输出维度：", y1.shape)
    print("FreqScale输出维度：", y2.shape)