import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.fft as fft

import numbers
from einops import rearrange

class ComplexFFT(nn.Module):
    """复数二维傅里叶变换模块：将空间域特征转换到频率域"""
    def __init__(self):
        super(ComplexFFT, self).__init__()

    def forward(self, x):
        # 对输入特征图沿最后两个维度（高度、宽度）执行2D复数FFT
        x_fft = fft.fft2(x, dim=(-2, -1))
        real = x_fft.real  # 提取频率域结果的实部
        imag = x_fft.imag  # 提取频率域结果的虚部
        return real, imag  # 返回实部和虚部分开的特征

class ComplexIFFT(nn.Module):
    """复数二维逆傅里叶变换模块：将频率域特征转换回空间域"""
    def __init__(self):
        super(ComplexIFFT, self).__init__()

    def forward(self, real, imag):
        # 组合实部和虚部，构建复数张量
        x_complex = torch.complex(real, imag)
        # 沿最后两个维度执行2D复数逆FFT，将频率域特征映射回空间域
        x_ifft = fft.ifft2(x_complex, dim=(-2, -1))
        return x_ifft.real  # 仅返回实部（虚部通常为数值误差，可忽略）

class Conv1x1(nn.Module):
    """1×1深度可分离卷积模块：用于频率域特征的通道内细化"""
    def __init__(self, in_channels):
        super(Conv1x1, self).__init__()
        # 输入通道数为in_channels×2（实部+虚部），采用深度可分离卷积（groups=输入通道数）
        # 仅对每个通道独立卷积，不进行通道间信息交互，避免破坏频率域结构
        self.conv = nn.Conv2d(in_channels * 2, in_channels * 2, kernel_size=1,
                              stride=1, padding=0, groups=in_channels*2)

    def forward(self, x):
        return self.conv(x)  # 对实部+虚部拼接的特征执行1×1深度卷积

class Stage2_fft(nn.Module):
    """频率域特征融合模块（对应网络结构图Stage 2）：完成空间域→频率域→空间域的特征优化"""
    def __init__(self, in_channels):
        super(Stage2_fft, self).__init__()
        self.c_fft = ComplexFFT()  # 傅里叶变换（空间→频率）
        self.conv1x1 = Conv1x1(in_channels)  # 频率域1×1深度卷积
        self.c_ifft = ComplexIFFT()  # 逆傅里叶变换（频率→空间）

    def forward(self, x):
        # Step 1: 空间域转频率域，得到实部和虚部
        real, imag = self.c_fft(x)
        # Step 2: 拼接实部和虚部，形成2×in_channels通道的特征
        combined = torch.cat([real, imag], dim=1)
        # Step 3: 频率域特征细化（1×1深度卷积）
        conv_out = self.conv1x1(combined)
        # Step 4: 拆分卷积结果为新的实部和虚部
        out_channels = conv_out.shape[1] // 2
        real_out = conv_out[:, :out_channels, :, :]  # 新实部
        imag_out = conv_out[:, out_channels:, :, :]  # 新虚部
        # Step 5: 频率域转空间域，返回实部结果
        output = self.c_ifft(real_out, imag_out)
        return output

##########################################################################
## Layer Norm

def to_3d(x):
    return rearrange(x, 'b c h w -> b (h w) c')


def to_4d(x, h, w):
    return rearrange(x, 'b (h w) c -> b c h w', h=h, w=w)


class BiasFree_LayerNorm(nn.Module):
    def __init__(self, normalized_shape):
        super(BiasFree_LayerNorm, self).__init__()
        if isinstance(normalized_shape, numbers.Integral):
            normalized_shape = (normalized_shape,)
        normalized_shape = torch.Size(normalized_shape)

        assert len(normalized_shape) == 1

        self.weight = nn.Parameter(torch.ones(normalized_shape))
        self.normalized_shape = normalized_shape

    def forward(self, x):
        sigma = x.var(-1, keepdim=True, unbiased=False)
        return x / torch.sqrt(sigma + 1e-5) * self.weight


class WithBias_LayerNorm(nn.Module):
    def __init__(self, normalized_shape):
        super(WithBias_LayerNorm, self).__init__()
        if isinstance(normalized_shape, numbers.Integral):
            normalized_shape = (normalized_shape,)
        normalized_shape = torch.Size(normalized_shape)

        assert len(normalized_shape) == 1

        self.weight = nn.Parameter(torch.ones(normalized_shape))
        self.bias = nn.Parameter(torch.zeros(normalized_shape))
        self.normalized_shape = normalized_shape

    def forward(self, x):
        mu = x.mean(-1, keepdim=True)
        sigma = x.var(-1, keepdim=True, unbiased=False)
        return (x - mu) / torch.sqrt(sigma + 1e-5) * self.weight + self.bias


class LayerNorm(nn.Module):
    def __init__(self, dim, LayerNorm_type):
        super(LayerNorm, self).__init__()
        if LayerNorm_type == 'BiasFree':
            self.body = BiasFree_LayerNorm(dim)
        else:
            self.body = WithBias_LayerNorm(dim)

    def forward(self, x):
        h, w = x.shape[-2:]
        return to_4d(self.body(to_3d(x)), h, w)

##########################################################################

# 像素细化自注意力（SPR-SA）：增强局部空间注意力
class spr_sa(nn.Module):
    def __init__(self, dim, growth_rate=2.0):
        super().__init__()
        hidden_dim = int(dim * growth_rate)  # 隐藏层维度（按增长因子扩展）
        # 分组卷积+1×1卷积：增强通道间独立性并压缩维度
        self.conv_0 = nn.Sequential(
            nn.Conv2d(dim, hidden_dim, 3, 1, 1, groups=dim),  # 3×3分组卷积
            nn.Conv2d(hidden_dim, hidden_dim, 1, 1, 0)         # 1×1卷积调整通道
        )
        self.act = nn.GELU()  # 激活函数
        self.conv_1 = nn.Conv2d(hidden_dim, dim, 1, 1, 0)  # 1×1卷积映射回原维度

    def forward(self, x):
        x = self.conv_0(x)
        x1 = F.adaptive_avg_pool2d(x, (1, 1))  # 全局平均池化（压缩空间维度）
        x1 = F.softmax(x1, dim=1)  # 通道维度归一化（生成通道注意力权重）
        x = x1 * x  # 注意力权重施加到特征上
        x = self.act(x)
        x = self.conv_1(x)
        return x

# CPIA-SA
class Attention(nn.Module):
    def __init__(self, dim, num_heads, bias):
        super(Attention, self).__init__()
        self.num_heads = num_heads  # 多头注意力头数
        self.temperature = nn.Parameter(torch.ones(num_heads, 1, 1))  # 注意力温度参数（可学习）
        self.spr_sa = spr_sa(dim // 2, 2)  # 初始化SPR-SA模块（处理通道拆分后的一路特征）
        # 1×1卷积：特征通道拆分前的线性变换
        self.linear_0 = nn.Conv2d(dim, dim, 1, 1, 0)
        self.linear_2 = nn.Conv2d(dim, dim, 1, 1, 0)
        # QKV生成：1×1卷积（输入为拆分后通道的一半）
        self.qkv = nn.Conv2d(dim // 2, dim // 2 * 3, kernel_size=1, bias=bias)
        # QKV深度可分离卷积：增强局部特征关联性
        self.qkv_dwconv = nn.Conv2d(dim // 2 * 3, dim // 2 * 3, kernel_size=3, stride=1, padding=1,
                                    groups=dim // 2 * 3, bias=bias)
        # 注意力输出投影：1×1卷积
        self.project_out = nn.Conv2d(dim, dim, kernel_size=1, bias=bias)
        self.attn_drop = nn.Dropout(0.)  # dropout层（此处未启用）
        # 注意力权重参数（用于多分支注意力融合）
        self.attn1 = torch.nn.Parameter(torch.tensor([0.2]), requires_grad=True)
        self.attn2 = torch.nn.Parameter(torch.tensor([0.2]), requires_grad=True)
        self.attn3 = torch.nn.Parameter(torch.tensor([0.2]), requires_grad=True)
        self.attn4 = torch.nn.Parameter(torch.tensor([0.2]), requires_grad=True)
        # 通道交互模块（生成通道注意力映射）
        self.channel_interaction = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),  # 全局平均池化
            nn.Conv2d(dim // 2, dim // 8, kernel_size=1),  # 通道压缩
            nn.BatchNorm2d(dim // 8),  # 批量归一化
            nn.GELU(),  # 激活函数
            nn.Conv2d(dim // 8, dim // 2, kernel_size=1),  # 通道恢复
        )
        # 空间交互模块（生成空间注意力映射）
        self.spatial_interaction = nn.Sequential(
            nn.Conv2d(dim // 2, dim // 16, kernel_size=1),  # 通道压缩
            nn.BatchNorm2d(dim // 16),  # 批量归一化
            nn.GELU(),  # 激活函数
            nn.Conv2d(dim // 16, 1, kernel_size=1)  # 输出单通道空间注意力
        )
        self.fft = Stage2_fft(in_channels=dim)  # 傅里叶变换模块（频率域融合）
        # 高效提示引导算子（EPGO）：生成动态注意力阈值K
        self.gate = nn.Sequential(
            nn.Conv2d(dim // 2, dim // 4, kernel_size=1),  # 通道压缩
            nn.ReLU(),  # 激活函数
            nn.Conv2d(dim // 4, 1, kernel_size=1),  # 输出单通道引导信号
            nn.Sigmoid()  # 归一化到[0,1]
        )

    def forward(self, x):
        b, c, h, w = x.shape  # b=批量大小, c=通道数, h=高度, w=宽度
        # 通道拆分：将输入特征按通道分为y和x两路（各占c/2通道）
        y, x = self.linear_0(x).chunk(2, dim=1)
        y_d = self.spr_sa(y)  # 对y路应用SPR-SA（空间注意力增强）

        # QKV生成与处理
        qkv = self.qkv_dwconv(self.qkv(x))  # 先1×1卷积生成QKV，再深度可分离卷积增强局部性
        q, k, v = qkv.chunk(3, dim=1)  # 拆分为Q（查询）、K（键）、V（值）
        # 维度重排：适配多头注意力（b, head, c, h*w）
        q = rearrange(q, 'b (head c) h w -> b head c (h w)', head=self.num_heads)
        k = rearrange(k, 'b (head c) h w -> b head c (h w)', head=self.num_heads)
        v = rearrange(v, 'b (head c) h w -> b head c (h w)', head=self.num_heads)
        # 归一化Q和K（增强数值稳定性）
        q = torch.nn.functional.normalize(q, dim=-1)
        k = torch.nn.functional.normalize(k, dim=-1)

        # 高效提示引导（EPGO）：动态计算注意力保留数量K
        _, _, C, _ = q.shape  # C=每个注意力头的通道数
        dynamic_k = int(C * self.gate(x).view(b, -1).mean())  # 按引导信号均值计算K
        # 计算注意力分数（Q×K^T）并乘以温度参数
        attn = (q @ k.transpose(-2, -1)) * self.temperature
        # 生成注意力掩码：仅保留分数最高的dynamic_k个位置
        mask = torch.zeros(b, self.num_heads, C, C, device=x.device, requires_grad=False)
        index = torch.topk(attn, k=dynamic_k, dim=-1, largest=True)[1]  # 取top-K索引
        mask.scatter_(-1, index, 1.)  # 掩码赋值（1表示保留，0表示丢弃）
        # 应用掩码（丢弃低分数位置，设为负无穷，softmax后接近0）
        attn = torch.where(mask > 0, attn, torch.full_like(attn, float('-inf')))
        attn = attn.softmax(dim=-1)  # 注意力分数归一化
        attn = self.attn_drop(attn)  # 应用dropout

        # 多分支注意力融合（通过可学习权重加权求和）
        out1 = (attn @ v)
        out2 = (attn @ v)
        out3 = (attn @ v)
        out4 = (attn @ v)
        out = out1 * self.attn1 + out2 * self.attn2 + out3 * self.attn3 + out4 * self.attn4
        # 维度重排：从多头注意力格式转回4D特征图
        out_att = rearrange(out, 'b head c (h w) -> b (head c) h w', head=self.num_heads, h=h, w=w)

        # 频率自适应交互模块（FAIM）- Stage 1：交叉对齐探索
        channel_map = self.channel_interaction(out_att)  # 生成通道注意力映射（未激活）
        spatial_map = self.spatial_interaction(y_d)  # 生成空间注意力映射（未激活）
        attened_x = out_att * torch.sigmoid(spatial_map)  # 空间注意力施加到注意力输出
        conv_x = y_d * torch.sigmoid(channel_map)  # 通道注意力施加到SPR-SA输出
        x = torch.cat([attened_x, conv_x], dim=1)  # 拼接两路特征
        out = self.project_out(x)  # 投影回原维度

        # 频率自适应交互模块（FAIM）- Stage 2：互补频率融合
        out = self.fft(out)  # 傅里叶变换融合空间域与频率域特征
        return out


if __name__ == '__main__':


    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    x = torch.randn(64, 64, 64, 64).to(device)  # batch_size > 1
    attn = Attention(dim=64, num_heads=4, bias=False).to(device)
    norm = LayerNorm(dim=64, LayerNorm_type='WithBias').to(device)
    y = attn(norm(x))
    print("微信公众号：十小大的底层视觉工坊")
    print("知乎、CSDN：十小大")
    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)