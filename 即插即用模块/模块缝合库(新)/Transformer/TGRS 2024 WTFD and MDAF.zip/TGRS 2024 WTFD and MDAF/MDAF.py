import torch
import torch.nn as nn
import torch.nn.functional as F
import numbers
from einops import rearrange

def to_3d(x):
    return rearrange(x, 'b c h w -> b (h w) c')


def to_4d(x, h, w):
    return rearrange(x, 'b (h w) c -> b c h w', h=h, w=w)


class BiasFree_LayerNorm(nn.Module):
    def __init__(self, normalized_shape):
        super(BiasFree_LayerNorm, self).__init__()
        if isinstance(normalized_shape, numbers.Integral):
            normalized_shape = (normalized_shape,)
        normalized_shape = torch.Size(normalized_shape)

        assert len(normalized_shape) == 1

        self.weight = nn.Parameter(torch.ones(normalized_shape))
        self.normalized_shape = normalized_shape

    def forward(self, x):
        sigma = x.var(-1, keepdim=True, unbiased=False)
        return x / torch.sqrt(sigma + 1e-5) * self.weight


class WithBias_LayerNorm(nn.Module):
    def __init__(self, normalized_shape):
        super(WithBias_LayerNorm, self).__init__()
        if isinstance(normalized_shape, numbers.Integral):
            normalized_shape = (normalized_shape,)
        normalized_shape = torch.Size(normalized_shape)

        assert len(normalized_shape) == 1

        self.weight = nn.Parameter(torch.ones(normalized_shape))
        self.bias = nn.Parameter(torch.zeros(normalized_shape))
        self.normalized_shape = normalized_shape

    def forward(self, x):
        mu = x.mean(-1, keepdim=True)
        sigma = x.var(-1, keepdim=True, unbiased=False)
        return (x - mu) / torch.sqrt(sigma + 1e-5) * self.weight + self.bias


class LayerNorm(nn.Module):
    def __init__(self, dim, LayerNorm_type):
        super(LayerNorm, self).__init__()
        if LayerNorm_type == 'BiasFree':
            self.body = BiasFree_LayerNorm(dim)
        else:
            self.body = WithBias_LayerNorm(dim)

    def forward(self, x):
        h, w = x.shape[-2:]
        return to_4d(self.body(to_3d(x)), h, w)


class MDAF(nn.Module):
    """
    多尺度双表征对齐滤波器（MDAF）：融合双模态特征（如空间-频域），实现多尺度对齐增强
    核心创新：
        1. 双表征独立多尺度映射：两个输入表征分别经多尺度深度卷积提取特征；
        2. 跨表征注意力对齐：通过注意力机制对齐双表征的特征分布；
        3. 多尺度卷积覆盖：不同核尺寸的1D深度卷积，捕捉水平/垂直方向多尺度关联；
        4. 残差融合：原始特征+对齐特征融合，保留原始信息。
    输入：
        x1: 第一类表征特征 [B, C, H, W]（如频域特征）
        x2: 第二类表征特征 [B, C, H, W]（如空间特征）
    输出：
        对齐增强后的融合特征 [B, C, H, W]（与输入维度一致）
    Args:
        dim: 输入/输出通道数
        num_heads: 注意力头数
        LayerNorm_type: 归一化类型（BiasFree/WithBias）
    """
    def __init__(self, dim, num_heads, LayerNorm_type='BiasFree'):
        super(MDAF, self).__init__()
        self.num_heads = num_heads
        # 双表征归一化层
        self.norm1 = LayerNorm(dim, LayerNorm_type)
        self.norm2 = LayerNorm(dim, LayerNorm_type)
        # 输出投影层
        self.project_out = nn.Conv2d(dim, dim, kernel_size=1)

        # 第一表征（x1）多尺度深度卷积（水平方向：1×k）
        self.conv1_1_1 = nn.Conv2d(dim, dim, (1, 7), padding=(0, 3), groups=dim)  # 1×7核
        self.conv1_1_2 = nn.Conv2d(dim, dim, (1, 11), padding=(0, 5), groups=dim) # 1×11核
        self.conv1_1_3 = nn.Conv2d(dim, dim, (1, 21), padding=(0, 10), groups=dim)# 1×21核
        # 第一表征（x1）多尺度深度卷积（垂直方向：k×1）
        self.conv1_2_1 = nn.Conv2d(dim, dim, (7, 1), padding=(3, 0), groups=dim)  # 7×1核
        self.conv1_2_2 = nn.Conv2d(dim, dim, (11, 1), padding=(5, 0), groups=dim) # 11×1核
        self.conv1_2_3 = nn.Conv2d(dim, dim, (21, 1), padding=(10, 0), groups=dim)# 21×1核

        # 第二表征（x2）多尺度深度卷积（水平方向：1×k）
        self.conv2_1_1 = nn.Conv2d(dim, dim, (1, 7), padding=(0, 3), groups=dim)
        self.conv2_1_2 = nn.Conv2d(dim, dim, (1, 11), padding=(0, 5), groups=dim)
        self.conv2_1_3 = nn.Conv2d(dim, dim, (1, 21), padding=(0, 10), groups=dim)
        # 第二表征（x2）多尺度深度卷积（垂直方向：k×1）
        self.conv2_2_1 = nn.Conv2d(dim, dim, (7, 1), padding=(3, 0), groups=dim)
        self.conv2_2_2 = nn.Conv2d(dim, dim, (11, 1), padding=(5, 0), groups=dim)
        self.conv2_2_3 = nn.Conv2d(dim, dim, (21, 1), padding=(10, 0), groups=dim)

    def forward(self, x1, x2):
        """
        前向传播流程：双表征归一化→多尺度映射→注意力对齐→融合输出
        """
        b, c, h, w = x1.shape

        # 步骤1：双表征归一化
        x1_norm = self.norm1(x1)
        x2_norm = self.norm2(x2)

        # 步骤2：双表征独立多尺度映射（深度卷积+求和融合）
        # 第一表征（x1）多尺度特征
        attn1 = self.conv1_1_1(x1_norm) + self.conv1_1_2(x1_norm) + self.conv1_1_3(x1_norm)
        attn1 += self.conv1_2_1(x1_norm) + self.conv1_2_2(x1_norm) + self.conv1_2_3(x1_norm)
        # 第二表征（x2）多尺度特征
        attn2 = self.conv2_1_1(x2_norm) + self.conv2_1_2(x2_norm) + self.conv2_1_3(x2_norm)
        attn2 += self.conv2_2_1(x2_norm) + self.conv2_2_2(x2_norm) + self.conv2_2_3(x2_norm)

        # 步骤3：多尺度特征投影
        out1 = self.project_out(attn1)
        out2 = self.project_out(attn2)

        # 步骤4：跨表征注意力对齐（重塑为注意力格式）
        # 第一表征作为K/V，第二表征作为Q（水平方向对齐）
        k1 = rearrange(out1, 'b (head c) h w -> b head h (w c)', head=self.num_heads)
        v1 = rearrange(out1, 'b (head c) h w -> b head h (w c)', head=self.num_heads)
        q1 = rearrange(out2, 'b (head c) h w -> b head h (w c)', head=self.num_heads)
        # 第二表征作为K/V，第一表征作为Q（垂直方向对齐）
        k2 = rearrange(out2, 'b (head c) h w -> b head w (h c)', head=self.num_heads)
        v2 = rearrange(out2, 'b (head c) h w -> b head w (h c)', head=self.num_heads)
        q2 = rearrange(out1, 'b (head c) h w -> b head w (h c)', head=self.num_heads)

        # 步骤5：注意力计算（L2归一化提升稳定性）
        q1 = F.normalize(q1, dim=-1)
        k1 = F.normalize(k1, dim=-1)
        attn1 = (q1 @ k1.transpose(-2, -1)).softmax(dim=-1)
        out3 = (attn1 @ v1) + q1  # 注意力输出+残差

        q2 = F.normalize(q2, dim=-1)
        k2 = F.normalize(k2, dim=-1)
        attn2 = (q2 @ k2.transpose(-2, -1)).softmax(dim=-1)
        out4 = (attn2 @ v2) + q2  # 注意力输出+残差

        # 步骤6：格式恢复与融合输出
        out3 = rearrange(out3, 'b head h (w c) -> b (head c) h w', head=self.num_heads, h=h, w=w)
        out4 = rearrange(out4, 'b head w (h c) -> b (head c) h w', head=self.num_heads, h=h, w=w)
        # 最终融合：对齐特征+原始特征残差
        out = self.project_out(out3) + self.project_out(out4) + x1 + x2

        return out

if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x_f = torch.randn(1, 64, 32, 32).to(device) # 频域特征
    x_s = torch.randn(1, 64, 32, 32).to(device) # 空间特征
    model = MDAF(64, 4).to(device)

    y = model(x_f, x_s)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN：十小大")

    print("输入特征维度：", x_s.shape)
    print("输出特征维度：", y.shape)