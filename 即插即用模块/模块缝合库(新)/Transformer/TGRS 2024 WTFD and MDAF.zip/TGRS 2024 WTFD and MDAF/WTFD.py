import torch
import torch.nn as nn
from pytorch_wavelets import DWTForward


class WTFD(nn.Module):
    """
    小波变换特征分解器（WTFD）：将输入特征分解为低频全局特征与高频细节特征，分别增强
    核心创新：
        1.  Haar 小波变换：高效分离高低频特征，适配视觉任务的多尺度需求；
        2.  分路增强：低频特征强化全局结构，高频特征强化细节纹理；
        3.  轻量化设计：1×1卷积+BN+ReLU，计算量低，即插即用；
        4.  双通道输出：同时输出增强后的高低频特征，支持后续融合。
    输入：
        x: 原始特征图 [B, in_ch, H, W]
    输出：
        yL: 增强后低频特征 [B, out_ch, H//2, W//2]（分辨率减半）
        yH: 增强后高频特征 [B, out_ch, H//2, W//2]（分辨率减半）
    Args:
        in_ch: 输入通道数
        out_ch: 输出通道数（高低频特征通道数一致）
    """

    def __init__(self, in_ch, out_ch):
        super(WTFD, self).__init__()
        # Haar 小波变换：J=1（1级分解），填充模式=zero，小波类型=haar
        self.wt = DWTForward(J=1, mode='zero', wave='haar')

        # 高频特征增强层：3个高频分量拼接后，1×1卷积降维+BN+ReLU
        self.conv_bn_relu = nn.Sequential(
            nn.Conv2d(in_ch * 3, in_ch, kernel_size=1, stride=1),  # 3个高频分量→in_ch通道
            nn.BatchNorm2d(in_ch),  # 稳定特征分布
            nn.ReLU(inplace=True),  # 非线性激活
        )

        # 低频特征输出层：1×1卷积调整通道+BN+ReLU
        self.outconv_bn_relu_L = nn.Sequential(
            nn.Conv2d(in_ch, out_ch, kernel_size=1, stride=1),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True),
        )

        # 高频特征输出层：1×1卷积调整通道+BN+ReLU
        self.outconv_bn_relu_H = nn.Sequential(
            nn.Conv2d(in_ch, out_ch, kernel_size=1, stride=1),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True),
        )

    def forward(self, x):
        """
        前向传播流程：小波分解→高频拼接→分路增强→双通道输出
        """
        # 步骤1：Haar 小波1级分解，得到低频特征yL和高频特征yH（元组形式）
        yL, yH = self.wt(x)  # yL: [B, in_ch, H//2, W//2]；yH: [(B, in_ch, 3, H//2, W//2)]

        # 步骤2：高频特征拆分与拼接（3个高频分量：HL、LH、HH）
        y_HL = yH[0][:, :, 0, ::]  # 水平高频（Horizontal）
        y_LH = yH[0][:, :, 1, ::]  # 垂直高频（Vertical）
        y_HH = yH[0][:, :, 2, ::]  # 对角高频（Diagonal）
        yH_concat = torch.cat([y_HL, y_LH, y_HH], dim=1)  # 拼接为3×in_ch通道：[B, 3*in_ch, H//2, W//2]

        # 步骤3：高频特征增强
        yH_enhanced = self.conv_bn_relu(yH_concat)  # 1×1卷积降维+增强：[B, in_ch, H//2, W//2]

        # 步骤4：高低频特征分别投影到输出通道
        yL_out = self.outconv_bn_relu_L(yL)  # 低频增强输出：[B, out_ch, H//2, W//2]
        yH_out = self.outconv_bn_relu_H(yH_enhanced)  # 高频增强输出：[B, out_ch, H//2, W//2]

        return yL_out, yH_out


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 64, 32, 32).to(device)
    model = WTFD(64, 64).to(device)

    yL, yH = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("小红书、知乎、CSDN：十小大")

    print("输入特征维度：", x.shape)
    print("输出低频特征维度：", yL.shape)
    print("输出高频特征维度：", yH.shape)

