import torch
import torch.nn as nn
import torch.nn.functional as F
from timm.models.layers import trunc_normal_


class AgentAttention(nn.Module):
    """
    智能体注意力模块（Agent Attention）：通过智能体令牌中间介导，实现高效长距离注意力
    核心创新：
        1. 双阶段注意力：智能体聚合→智能体广播，降低计算复杂度；
        2. 多维度位置偏置：适配智能体与特征、特征与智能体的位置关联；
        3. 局部-全局融合：深度可分离卷积补充局部细节，提升特征完整性；
        4. 空间缩减优化：可选下采样降低KV计算量，适配高分辨率。
    输入：
        x: 特征序列 [B, N, C]（N=H×W，序列长度=空间像素总数）
        H/W: 原始特征图高/宽
    输出：
        增强后特征 [B, N, C]（与输入维度完全一致）
    """
    def __init__(self, dim, num_patches, num_heads=8, qkv_bias=False, qk_scale=None, attn_drop=0., proj_drop=0.,
                 sr_ratio=1, agent_num=49, **kwargs):
        super().__init__()
        assert dim % num_heads == 0, f"通道数 {dim} 需能被注意力头数 {num_heads} 整除"
        self.dim = dim  # 输入/输出通道数
        self.num_patches = num_patches  # 总patch数（N=H×W）
        self.window_size = (int(num_patches ** 0.5), int(num_patches ** 0.5))  # 空间尺寸 (H,W)
        self.num_heads = num_heads  # 注意力头数
        head_dim = dim // num_heads  # 单头通道数
        self.scale = qk_scale or head_dim ** -0.5  # 注意力缩放因子

        # QKV投影层
        self.q = nn.Linear(dim, dim, bias=qkv_bias)  # Q投影
        self.kv = nn.Linear(dim, dim * 2, bias=qkv_bias)  # KV联合投影
        self.attn_drop = nn.Dropout(attn_drop)  # 注意力Dropout
        self.proj = nn.Linear(dim, dim)  # 输出投影层
        self.proj_drop = nn.Dropout(proj_drop)  # 输出Dropout

        # 空间缩减（可选，降低KV计算量）
        self.sr_ratio = sr_ratio
        if sr_ratio > 1:
            self.sr = nn.Conv2d(dim, dim, kernel_size=sr_ratio, stride=sr_ratio)  # 下采样卷积
            self.norm = nn.LayerNorm(dim)  # 下采样后归一化

        self.agent_num = agent_num  # 智能体令牌数量（默认49=7×7）
        self.dwc = nn.Conv2d(in_channels=dim, out_channels=dim, kernel_size=3, padding=1, groups=dim)  # 深度可分离卷积（局部细节补充）

        # 多维度位置偏置（初始化采用截断正态分布）
        # 1. 智能体-特征位置偏置（agent→node）
        self.an_bias = nn.Parameter(torch.zeros(num_heads, agent_num, 7, 7))
        # 2. 特征-智能体位置偏置（node→agent）
        self.na_bias = nn.Parameter(torch.zeros(num_heads, agent_num, 7, 7))
        # 3. 智能体-特征高度/宽度偏置
        self.ah_bias = nn.Parameter(torch.zeros(1, num_heads, agent_num, self.window_size[0] // sr_ratio, 1))
        self.aw_bias = nn.Parameter(torch.zeros(1, num_heads, agent_num, 1, self.window_size[1] // sr_ratio))
        # 4. 特征-智能体高度/宽度偏置
        self.ha_bias = nn.Parameter(torch.zeros(1, num_heads, self.window_size[0], 1, agent_num))
        self.wa_bias = nn.Parameter(torch.zeros(1, num_heads, 1, self.window_size[1], agent_num))

        # 偏置参数初始化
        trunc_normal_(self.an_bias, std=.02)
        trunc_normal_(self.na_bias, std=.02)
        trunc_normal_(self.ah_bias, std=.02)
        trunc_normal_(self.aw_bias, std=.02)
        trunc_normal_(self.ha_bias, std=.02)
        trunc_normal_(self.wa_bias, std=.02)

        # 智能体令牌生成（自适应平均池化）
        pool_size = int(agent_num ** 0.5)
        self.pool = nn.AdaptiveAvgPool2d(output_size=(pool_size, pool_size))
        self.softmax = nn.Softmax(dim=-1)  # 注意力归一化

    def forward(self, x, H, W):
        """
        前向传播流程：智能体生成→双阶段注意力→局部融合→输出投影
        """
        B, N, C = x.shape  # 解析维度：批次、序列长度、通道数
        num_heads = self.num_heads
        head_dim = C // num_heads

        # 步骤1：QKV生成（Q来自原始特征，KV可选空间缩减）
        q = self.q(x)  # [B, N, C]
        if self.sr_ratio > 1:
            # 空间缩减：[B, N, C]→[B, C, H, W]→[B, C, H/sr, W/sr]→[B, N/sr², C]
            x_ = x.permute(0, 2, 1).reshape(B, C, H, W)
            x_ = self.sr(x_).reshape(B, C, -1).permute(0, 2, 1)
            x_ = self.norm(x_)
            kv = self.kv(x_).reshape(B, -1, 2, C).permute(2, 0, 1, 3)  # 分离K/V
        else:
            kv = self.kv(x).reshape(B, -1, 2, C).permute(2, 0, 1, 3)
        k, v = kv[0], kv[1]  # K/V：[B, N', C]（N'=N/sr²）

        # 步骤2：生成智能体令牌（Agent Tokens）
        # 原始特征池化→智能体令牌：[B, N, C]→[B, H, W, C]→[B, C, pool_size, pool_size]→[B, agent_num, C]
        agent_tokens = self.pool(q.reshape(B, H, W, C).permute(0, 3, 1, 2)).reshape(B, C, -1).permute(0, 2, 1)

        # 步骤3：多头维度重排
        q = q.reshape(B, N, num_heads, head_dim).permute(0, 2, 1, 3)  # [B, num_heads, N, head_dim]
        k = k.reshape(B, N // self.sr_ratio ** 2, num_heads, head_dim).permute(0, 2, 1, 3)  # [B, num_heads, N', head_dim]
        v = v.reshape(B, N // self.sr_ratio ** 2, num_heads, head_dim).permute(0, 2, 1, 3)  # [B, num_heads, N', head_dim]
        agent_tokens = agent_tokens.reshape(B, self.agent_num, num_heads, head_dim).permute(0, 2, 1, 3)  # [B, num_heads, agent_num, head_dim]

        # 步骤4：第一阶段注意力（智能体聚合：Agent→KV）
        # 位置偏置插值适配KV尺寸
        kv_size = (self.window_size[0] // self.sr_ratio, self.window_size[1] // self.sr_ratio)
        position_bias1 = F.interpolate(self.an_bias, size=kv_size, mode='bilinear')  # [num_heads, agent_num, N']
        position_bias1 = position_bias1.reshape(1, num_heads, self.agent_num, -1).repeat(B, 1, 1, 1)
        # 高度+宽度偏置融合
        position_bias2 = (self.ah_bias + self.aw_bias).reshape(1, num_heads, self.agent_num, -1).repeat(B, 1, 1, 1)
        total_bias = position_bias1 + position_bias2
        # 智能体-KV注意力计算
        agent_attn = self.softmax((agent_tokens * self.scale) @ k.transpose(-2, -1) + total_bias)  # [B, num_heads, agent_num, N']
        agent_attn = self.attn_drop(agent_attn)
        agent_v = agent_attn @ v  # [B, num_heads, agent_num, head_dim]（智能体聚合KV特征）

        # 步骤5：第二阶段注意力（智能体广播：Q→Agent）
        # 位置偏置插值适配Q尺寸
        agent_bias1 = F.interpolate(self.na_bias, size=self.window_size, mode='bilinear')  # [num_heads, agent_num, N]
        agent_bias1 = agent_bias1.reshape(1, num_heads, self.agent_num, -1).permute(0, 1, 3, 2).repeat(B, 1, 1, 1)
        # 高度+宽度偏置融合
        agent_bias2 = (self.ha_bias + self.wa_bias).reshape(1, num_heads, -1, self.agent_num).repeat(B, 1, 1, 1)
        total_agent_bias = agent_bias1 + agent_bias2
        # Q-智能体注意力计算
        q_attn = self.softmax((q * self.scale) @ agent_tokens.transpose(-2, -1) + total_agent_bias)  # [B, num_heads, N, agent_num]
        q_attn = self.attn_drop(q_attn)
        x = q_attn @ agent_v  # [B, num_heads, N, head_dim]（智能体广播特征）

        # 步骤6：多头合并
        x = x.transpose(1, 2).reshape(B, N, C)  # [B, N, C]

        # 步骤7：局部细节融合（深度可分离卷积）
        v_spatial = v.transpose(1, 2).reshape(B, H // self.sr_ratio, W // self.sr_ratio, C).permute(0, 3, 1, 2)  # [B, C, H', W']
        if self.sr_ratio > 1:
            v_spatial = F.interpolate(v_spatial, size=(H, W), mode='bilinear')  # 恢复原始尺寸
        local_feat = self.dwc(v_spatial).permute(0, 2, 3, 1).reshape(B, N, C)  # [B, N, C]
        x = x + local_feat  # 局部-全局融合

        # 步骤8：输出投影与正则化
        x = self.proj(x)
        x = self.proj_drop(x)

        return x


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 32*32, 64).to(device)
    model = AgentAttention(64, 32*32).to(device)

    y = model(x, 32, 32)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)