# 层融合-分离模块（Layer Fusion-Separation Block, LFSB）
# 核心设计：基于“差分双流注意力+窗口分区交互+门控融合+通道增强”的复合架构，
# 针对双输入特征（如局部-全局、低层-高层、跨模态特征），通过窗口化差分自注意力（SA）与交叉注意力（CA）捕捉空间依赖，
# 结合双流门控实现特征融合-分离，通道注意力强化关键信息，最终通过残差加权融合输出，
# 既保留双输入特征的专属特性，又实现深度互补增强，提升模型对复杂场景的特征表达能力


import torch
import torch.nn as nn
import torch.nn.functional as F
from timm.models.layers import to_2tuple, trunc_normal_
import math
from collections import OrderedDict


def lambda_init_fn(depth):
    """
    动态初始化函数：基于网络深度生成lambda系数（预留用于层权重调制）
    核心公式：lambda = 0.8 - 0.6 * exp(-0.3 * depth)
    特性：深度越深，lambda越接近0.8，适配深层特征的融合强度
    Args:
        depth: 网络当前层深度
    Returns:
        lambda系数（float）
    """
    return 0.8 - 0.6 * math.exp(-0.3 * depth)


class LayerNormFunction(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x, weight, bias, eps):
        ctx.eps = eps
        N, C, H, W = x.size()
        mu = x.mean(1, keepdim=True)
        var = (x - mu).pow(2).mean(1, keepdim=True)
        y = (x - mu) / (var + eps).sqrt()
        ctx.save_for_backward(y, var, weight)
        y = weight.view(1, C, 1, 1) * y + bias.view(1, C, 1, 1)
        return y

    @staticmethod
    def backward(ctx, grad_output):
        eps = ctx.eps
        N, C, H, W = grad_output.size()
        y, var, weight = ctx.saved_tensors
        g = grad_output * weight.view(1, C, 1, 1)
        mean_g = g.mean(dim=1, keepdim=True)
        mean_gy = (g * y).mean(dim=1, keepdim=True)
        gx = 1. / torch.sqrt(var + eps) * (g - y * mean_gy - mean_g)
        return gx, (grad_output * y).sum(dim=3).sum(dim=2).sum(dim=0), grad_output.sum(dim=3).sum(dim=2).sum(dim=0), None



class LayerNorm2d(nn.Module):
    def __init__(self, channels, eps=1e-6):
        super(LayerNorm2d, self).__init__()
        self.register_parameter('weight', nn.Parameter(torch.ones(channels)))
        self.register_parameter('bias', nn.Parameter(torch.zeros(channels)))
        self.eps = eps

    def forward(self, x):
        return LayerNormFunction.apply(x, self.weight, self.bias, self.eps)

class CABlock(nn.Module):
    def __init__(self, channels):
        super(CABlock, self).__init__()
        self.ca = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(channels, channels, 1)
        )

    def forward(self, x):
        return x * self.ca(x)

class DualStreamGate(nn.Module):
    def forward(self, x, y):
        x1, x2 = x.chunk(2, dim=1)
        y1, y2 = y.chunk(2, dim=1)
        return x1 * y2, y1 * x2

class DualStreamSeq(nn.Sequential):
    def forward(self, x, y=None):
        y = y if y is not None else x
        for module in self:
            x, y = module(x, y)
        return x, y

class DualStreamBlock(nn.Module):
    def __init__(self, *args):
        super(DualStreamBlock, self).__init__()
        self.seq = nn.Sequential()
        if len(args) == 1 and isinstance(args[0], OrderedDict):
            for key, module in args[0].items():
                self.seq.add_module(key, module)
        else:
            for idx, module in enumerate(args):
                self.seq.add_module(str(idx), module)

    def forward(self, x, y):
        return self.seq(x), self.seq(y)

def window_partition(x, window_size):
    if not isinstance(window_size, tuple):
        window_size = (window_size, window_size)
    B, H, W, C = x.shape
    x = x.view(B, H // window_size[0], window_size[0], W // window_size[1], window_size[1], C)
    windows = x.permute(0, 1, 3, 2, 4, 5).contiguous().view(-1, window_size[0], window_size[1], C)
    return windows

def window_reverse(windows, window_size, H, W):
    if not isinstance(window_size, tuple):
        window_size = (window_size, window_size)
    B = int(windows.shape[0] / (H * W / window_size[0] / window_size[1]))
    x = windows.view(B, H // window_size[0], W // window_size[1], window_size[0], window_size[1], -1)
    x = x.permute(0, 1, 3, 2, 4, 5).contiguous().view(B, H, W, -1)
    return x


class DifferentialDualStreamAttention(nn.Module):
    """
    差分双流注意力模块：融合差分机制的双流双维度注意力（自注意力+交叉注意力）
    功能：对双输入特征的窗口分区进行差分注意力计算，强化特征交互与空间依赖
    核心设计：
        - 双注意力分支：自注意力（SA）捕捉单流内部依赖，交叉注意力（CA）捕捉双流间依赖
        - 跨流交互投影：SA/CA分支均引入跨流特征增强，提升双流互补性
        - 差分机制：通过可学习lambda系数计算差分注意力权重，抑制冗余，强化有效关联
        - 相对位置编码：补充窗口内空间位置信息，提升注意力精准度
    Args:
        dim: 输入特征通道数
        window_size: 窗口尺寸（tuple）
        num_heads: 注意力头数
        depth: 模块所在网络深度（用于lambda初始化）
        qkv_bias: QKV生成是否带偏置（默认True）
        qk_scale: 注意力缩放因子（默认None，自动计算head_dim^-0.5）
        attn_drop: 注意力权重dropout概率（默认0.）
        proj_drop: 输出投影dropout概率（默认0.）
    """
    def __init__(self, dim, window_size, num_heads, depth=1, qkv_bias=True, qk_scale=None,
                 attn_drop=0., proj_drop=0.):
        super().__init__()
        self.dim = dim
        self.window_size = window_size
        self.num_heads = num_heads
        self.head_dim = dim // num_heads
        self.scale = qk_scale or self.head_dim ** -0.5

        # Differential parameters
        self.lambda_init = lambda_init_fn(depth)
        self.lambda_sa = nn.Parameter(torch.tensor(0.1))
        self.lambda_ca = nn.Parameter(torch.tensor(0.1))

        # Self-Attention 分支
        self.sa_qkv = nn.Linear(dim, dim * 3, bias=qkv_bias)

        # ===== 新增：跨流交互投影 (SA) =====
        self.sa_cross_trans_proj = nn.Linear(dim, dim, bias=False)
        self.sa_cross_refl_proj = nn.Linear(dim, dim, bias=False)
        self.sa_enhance_weight = nn.Parameter(torch.tensor(0.1))
        # self.sa_enhance_weight = nn.Parameter(torch.tensor(0.2), requires_grad=False)

        # Cross-Attention 分支
        self.ca_q = nn.Linear(dim, dim, bias=qkv_bias)
        self.ca_kv = nn.Linear(dim, dim * 2, bias=qkv_bias)

        # ===== 新增：跨流交互投影 (CA) =====
        self.ca_cross_trans_proj = nn.Linear(dim, dim, bias=False)
        self.ca_cross_refl_proj = nn.Linear(dim, dim, bias=False)
        self.ca_enhance_weight = nn.Parameter(torch.tensor(0.1))
        # self.ca_enhance_weight = nn.Parameter(torch.tensor(0.2), requires_grad=False)

        # 相對位置編碼
        self.relative_position_bias_table = nn.Parameter(
            torch.zeros((2 * window_size[0] - 1) * (2 * window_size[1] - 1), num_heads))

        coords_h = torch.arange(self.window_size[0])
        coords_w = torch.arange(self.window_size[1])
        coords = torch.stack(torch.meshgrid([coords_h, coords_w], indexing='ij'))
        coords_flatten = torch.flatten(coords, 1)
        relative_coords = coords_flatten[:, :, None] - coords_flatten[:, None, :]
        relative_coords = relative_coords.permute(1, 2, 0).contiguous()
        relative_coords[:, :, 0] += self.window_size[0] - 1
        relative_coords[:, :, 1] += self.window_size[1] - 1
        relative_coords[:, :, 0] *= 2 * self.window_size[1] - 1
        relative_position_index = relative_coords.sum(-1)
        self.register_buffer("relative_position_index", relative_position_index)

        self.attn_drop = nn.Dropout(attn_drop)
        self.proj_sa = nn.Linear(dim, dim)
        self.proj_ca = nn.Linear(dim, dim)
        self.proj_drop = nn.Dropout(proj_drop)

        trunc_normal_(self.relative_position_bias_table, std=.02)
        self.softmax = nn.Softmax(dim=-1)

    def forward_sa(self, x_concat):
        """
        Self-Attention: 在 batch 維度 concat，加入跨流交互
        x_concat: [2*B, N, C] - torch.cat([x_windows, y_windows], dim=0)
        返回: [2*B, N, C]
        """
        B2, N, C = x_concat.shape
        B = B2 // 2

        # 分離 trans 和 refl
        x_trans = x_concat[:B]
        x_refl = x_concat[B:]

        # ===== 跨流特徵增強 =====
        trans_enhanced = x_trans + self.sa_enhance_weight * self.sa_cross_refl_proj(x_refl)
        refl_enhanced = x_refl + self.sa_enhance_weight * self.sa_cross_trans_proj(x_trans)

        # 計算各自的 QKV（使用增強後的特徵）
        qkv_trans = self.sa_qkv(trans_enhanced).reshape(B, N, 3, self.num_heads, self.head_dim).permute(2, 0, 3, 1, 4)
        qkv_refl = self.sa_qkv(refl_enhanced).reshape(B, N, 3, self.num_heads, self.head_dim).permute(2, 0, 3, 1, 4)

        q_trans, k_trans, v_trans = qkv_trans[0], qkv_trans[1], qkv_trans[2]
        q_refl, k_refl, v_refl = qkv_refl[0], qkv_refl[1], qkv_refl[2]

        # 計算注意力
        attn_trans = (q_trans * self.scale) @ k_trans.transpose(-2, -1)
        attn_refl = (q_refl * self.scale) @ k_refl.transpose(-2, -1)

        # 添加位置編碼
        relative_position_bias = self.relative_position_bias_table[
            self.relative_position_index.view(-1)
        ].view(N, N, -1).permute(2, 0, 1).contiguous()

        attn_trans = attn_trans + relative_position_bias.unsqueeze(0)
        attn_refl = attn_refl + relative_position_bias.unsqueeze(0)

        attn_trans = self.softmax(attn_trans)
        attn_refl = self.softmax(attn_refl)

        # Differential Attention
        # lambda_sa = torch.sigmoid(self.lambda_sa)
        lambda_sa = torch.clamp(torch.sigmoid(self.lambda_sa), 0.01, 0.99)

        diff_attn_trans = attn_trans - lambda_sa * attn_refl
        diff_attn_refl = attn_refl - lambda_sa * attn_trans

        diff_attn_trans = self.attn_drop(diff_attn_trans)
        diff_attn_refl = self.attn_drop(diff_attn_refl)

        out_trans = (diff_attn_trans @ v_trans).transpose(1, 2).reshape(B, N, C)
        out_refl = (diff_attn_refl @ v_refl).transpose(1, 2).reshape(B, N, C)

        out_trans = self.proj_sa(out_trans)
        out_refl = self.proj_sa(out_refl)
        out_trans = self.proj_drop(out_trans)
        out_refl = self.proj_drop(out_refl)

        # 重新 concat 回去
        return torch.cat([out_trans, out_refl], dim=0)

    def forward_ca(self, x_concat):
        """
        Cross-Attention: 在 sequence 維度 concat，加入跨流交互
        x_concat: [B, 2*N, C] - torch.cat([x_windows, y_windows], dim=-2)
        返回: [B, 2*N, C]
        """
        B, N2, C = x_concat.shape
        N = N2 // 2

        # 分離 trans 和 refl
        x_trans = x_concat[:, :N, :]
        x_refl = x_concat[:, N:, :]

        # ===== 跨流特徵增強 =====
        trans_enhanced = x_trans + self.ca_enhance_weight * self.ca_cross_refl_proj(x_refl)
        refl_enhanced = x_refl + self.ca_enhance_weight * self.ca_cross_trans_proj(x_trans)

        # Query 從增強後的特徵計算
        q_trans = self.ca_q(trans_enhanced).reshape(B, N, self.num_heads, self.head_dim).permute(0, 2, 1, 3)
        q_refl = self.ca_q(refl_enhanced).reshape(B, N, self.num_heads, self.head_dim).permute(0, 2, 1, 3)

        # KV 從增強後的 concat 特徵計算
        x_concat_enhanced = torch.cat([trans_enhanced, refl_enhanced], dim=-2)
        kv = self.ca_kv(x_concat_enhanced).reshape(B, N2, 2, self.num_heads, self.head_dim).permute(2, 0, 3, 1, 4)
        k, v = kv[0], kv[1]

        k_trans, k_refl = k[:, :, :N, :], k[:, :, N:, :]
        v_trans, v_refl = v[:, :, :N, :], v[:, :, N:, :]

        # 計算注意力
        attn_trans = (q_trans * self.scale) @ k_trans.transpose(-2, -1)
        attn_refl = (q_refl * self.scale) @ k_refl.transpose(-2, -1)

        # 添加位置編碼
        relative_position_bias = self.relative_position_bias_table[
            self.relative_position_index.view(-1)
        ].view(N, N, -1).permute(2, 0, 1).contiguous()

        attn_trans = attn_trans + relative_position_bias.unsqueeze(0)
        attn_refl = attn_refl + relative_position_bias.unsqueeze(0)

        attn_trans = self.softmax(attn_trans)
        attn_refl = self.softmax(attn_refl)

        # Differential Cross-Attention
        lambda_ca = torch.clamp(torch.sigmoid(self.lambda_ca), 0.01, 0.99)
        diff_attn_trans = attn_trans - lambda_ca * attn_refl
        diff_attn_refl = attn_refl - lambda_ca * attn_trans

        diff_attn_trans = self.attn_drop(diff_attn_trans)
        diff_attn_refl = self.attn_drop(diff_attn_refl)

        out_trans = (diff_attn_trans @ v_trans).transpose(1, 2).reshape(B, N, C)
        out_refl = (diff_attn_refl @ v_refl).transpose(1, 2).reshape(B, N, C)

        out_trans = self.proj_ca(out_trans)
        out_refl = self.proj_ca(out_refl)
        out_trans = self.proj_drop(out_trans)
        out_refl = self.proj_drop(out_refl)

        # 重新 concat 回去
        return torch.cat([out_trans, out_refl], dim=-2)

# 完整Transformer块
class DifferentialDualAttentionInteractiveBlock(nn.Module):
    """
    层融合-分离模块（Layer Fusion-Separation Block, LFSB）
    功能：双输入特征的窗口化差分注意力交互+门控融合+通道增强，实现深度互补增强
    核心设计：
        - 窗口分区注意力：降低计算成本，聚焦局部空间依赖
        - 差分双流注意力：SA捕捉单流内部依赖，CA捕捉双流间依赖，差分机制强化有效信息
        - 门控融合-分离：双流门控实现特征交叉融合，同时保留各自特性
        - 通道增强+残差加权：CABlock强化关键通道，可学习权重平衡原始与增强特征
    Args:
        dim: 输入特征通道数
        input_resolution: 输入特征图分辨率（tuple）
        num_heads: 注意力头数
        window_size: 窗口尺寸（默认12）
        depth: 模块所在网络深度（用于lambda初始化）
        norm_layer: 归一化层（默认nn.LayerNorm）
    """
    def __init__(self, dim, input_resolution, num_heads, window_size=12, depth=1, norm_layer=nn.LayerNorm):
        super().__init__()
        self.dim = dim
        self.input_resolution = input_resolution
        self.num_heads = num_heads
        self.window_size = window_size

        if min(self.input_resolution) <= self.window_size:
            self.window_size = min(self.input_resolution)

        self.norm1 = DualStreamBlock(norm_layer(dim))

        # Differential 注意力
        self.diff_attention = DifferentialDualStreamAttention(
            dim, to_2tuple(self.window_size), num_heads, depth
        )

        self.feedforward = DualStreamSeq(
            DualStreamBlock(
                LayerNorm2d(dim),
                nn.Conv2d(dim, dim * 2, 1),
                nn.Conv2d(dim * 2, dim * 2, 3, padding=1, groups=dim * 2)
            ),
            DualStreamGate(),
            DualStreamBlock(CABlock(dim)),
            DualStreamBlock(nn.Conv2d(dim, dim, 1))
        )

        self.a = nn.Parameter(torch.zeros((1, 1, dim)), requires_grad=True)
        self.b = nn.Parameter(torch.zeros((1, dim, 1, 1)), requires_grad=True)

    def forward(self, x, y):
        B, C, H, W = x.shape

        x_seq = x.permute(0, 2, 3, 1).contiguous().view(B, H * W, C)
        y_seq = y.permute(0, 2, 3, 1).contiguous().view(B, H * W, C)

        x_skip, y_skip = x_seq, y_seq
        x_norm, y_norm = self.norm1(x_seq, y_seq)

        x_win = x_norm.view(B, H, W, C)
        y_win = y_norm.view(B, H, W, C)

        if not self.training:
            pad_l = pad_t = 0
            pad_r = (self.window_size - W % self.window_size) % self.window_size
            pad_b = (self.window_size - H % self.window_size) % self.window_size
            x_win = F.pad(x_win, (0, 0, pad_l, pad_r, pad_t, pad_b))
            y_win = F.pad(y_win, (0, 0, pad_l, pad_r, pad_t, pad_b))
            _, Hp, Wp, _ = x_win.shape
        else:
            Hp, Wp = H, W
            pad_r, pad_b = 0, 0

        # 窗口分割
        x_windows = window_partition(x_win, self.window_size).view(-1, self.window_size * self.window_size, C)
        y_windows = window_partition(y_win, self.window_size).view(-1, self.window_size * self.window_size, C)

        # ===== 保持原始的 concat + chunk 模式 =====
        # Self-Attention: batch 維度 concat
        xx_windows, yy_windows = self.diff_attention.forward_sa(
            torch.cat([x_windows, y_windows], dim=0)
        ).chunk(2, dim=0)

        # Cross-Attention: sequence 維度 concat
        xy_windows, yx_windows = self.diff_attention.forward_ca(
            torch.cat([x_windows, y_windows], dim=-2)
        ).chunk(2, dim=-2)

        # 加權融合
        x_windows = (xx_windows + xy_windows).view(-1, self.window_size, self.window_size, C)
        y_windows = (yy_windows + yx_windows).view(-1, self.window_size, self.window_size, C)

        # 窗口反轉
        x = window_reverse(x_windows, self.window_size, Hp, Wp)
        y = window_reverse(y_windows, self.window_size, Hp, Wp)

        if pad_r > 0 or pad_b > 0:
            x = x[:, :H, :W, :].contiguous()
            y = y[:, :H, :W, :].contiguous()

        # 殘差連接
        x = x_skip + x.view(B, H * W, C) * self.a
        y = y_skip + y.view(B, H * W, C) * self.a

        # 前饋網路
        x_skip = x.view(B, H, W, C).permute(0, 3, 1, 2).contiguous()
        y_skip = y.view(B, H, W, C).permute(0, 3, 1, 2).contiguous()

        x, y = self.feedforward(x_skip, y_skip)
        x, y = x_skip + x * self.b, y_skip + y * self.b

        return x, y


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 64, 32, 32).to(device)
    y = torch.randn(1, 64, 32, 32).to(device)
    model = DifferentialDualAttentionInteractiveBlock(64, (8, 8), 8, 8, 5).to(device)

    out_x, out_y = model(x, y)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("小红书：十小大，主页获取往期全部即插即用代码，200+大合集")

    print("输入局部特征维度：", x.shape)
    print("输入全局特征维度：", y.shape)
    print("输出局部特征维度：", out_x.shape)
    print("输出全局特征维度：", out_y.shape)