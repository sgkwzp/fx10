# 动态范围直方图自注意力模块（Dynamic-range Histogram Self-Attention, DHSA）
# 核心设计：基于特征的动态分布（直方图特性）构建自注意力，通过双路径（块级/频率级）注意力融合，
# 增强特征对分布模式的捕捉能力，同时保持高效计算
'''
微信公众号：十小大的底层视觉工坊
VX: shixiaodayyds, 备注【即插即用】添加交流群
知乎、CSDN、小红书：十小大
'''

import torch
import torch.nn as nn
import torch.nn.functional as F

from einops import rearrange

#########################################################################

Conv2d = nn.Conv2d

##########################################################################
## Dynamic-range Histogram Self-Attention (DHSA)

class Attention_histogram(nn.Module):
    """
    动态范围直方图自注意力模块（DHSA）
    功能：通过特征排序、双路径注意力计算、分布感知融合，增强特征表达
    核心设计：
        - 特征动态排序：基于特征值分布重构输入，模拟直方图统计特性
        - 双路径注意力：块级（Box）和频率级（Frequency）注意力并行计算
        - 局部深度卷积增强：1×1投影+3×3深度卷积，提升局部特征关联性
        - 自适应温度参数：每个注意力头独立调节注意力权重分布
    """

    def __init__(self, dim, num_heads, bias=False, ifBox=True):
        super(Attention_histogram, self).__init__()
        self.factor = num_heads  # 分块因子（与注意力头数一致）
        self.ifBox = ifBox  # 初始注意力路径标记（实际前向中双路径并行）
        self.num_heads = num_heads  # 注意力头数量
        self.temperature = nn.Parameter(torch.ones(num_heads, 1, 1))  # 每个头的温度参数（可学习）

        # 1×1卷积：将输入特征投影为5个分支（q1, k1, q2, k2, v）
        self.qkv = Conv2d(dim, dim * 5, kernel_size=1, bias=bias)
        # 3×3深度卷积：增强局部特征关联性（groups=dim*5确保深度卷积独立性）
        self.qkv_dwconv = Conv2d(dim * 5, dim * 5, kernel_size=3, stride=1, padding=1, groups=dim * 5, bias=bias)
        # 1×1卷积：注意力输出投影回原维度
        self.project_out = Conv2d(dim, dim, kernel_size=1, bias=bias)

    def pad(self, x, factor):
        """
        对特征图进行零填充，确保维度能被分块因子整除
        Args:
            x: 输入特征，shape=[b, c, hw]（hw=h*w，展平后的空间维度）
            factor: 分块因子（注意力头数）
        Returns:
            x_padded: 填充后的特征
            t_pad: 填充量（用于后续反填充）
        """
        hw = x.shape[-1]
        # 计算需要填充的长度（确保hw能被factor整除）
        t_pad = [0, 0] if hw % factor == 0 else [0, (hw // factor + 1) * factor - hw]
        x = F.pad(x, t_pad, 'constant', 0)  # 右侧零填充
        return x, t_pad

    def unpad(self, x, t_pad):
        """
        移除填充部分，恢复原始特征维度
        Args:
            x: 填充后的特征，shape=[b, c, hw_padded]
            t_pad: 填充量（pad函数输出）
        Returns:
            x_unpadded: 恢复后的原始维度特征
        """
        _, _, hw = x.shape
        return x[:, :, t_pad[0]:hw - t_pad[1]]  # 裁剪填充部分

    def softmax_1(self, x, dim=-1):
        """
        改进版Softmax函数（添加微小常数避免数值不稳定）
        Args:
            x: 注意力得分张量
            dim: 归一化维度
        Returns:
            归一化后的注意力权重
        """
        logit = x.exp()
        logit = logit / (logit.sum(dim, keepdim=True) + 1)  # +1防止分母为0
        return logit

    def normalize(self, x):
        """
        特征标准化（均值方差归一化）
        Args:
            x: 输入特征张量
        Returns:
            标准化后的特征
        """
        mu = x.mean(-2, keepdim=True)  # 计算均值（沿通道维度）
        sigma = x.var(-2, keepdim=True, unbiased=False)  # 计算方差
        return (x - mu) / torch.sqrt(sigma + 1e-5)  # 标准化（加1e-5避免开方为0）

    def reshape_attn(self, q, k, v, ifBox):
        """
        注意力计算核心函数：特征重塑+归一化+注意力权重计算+加权求和
        支持两种重塑模式（对应双路径注意力）
        Args:
            q: 查询向量，shape=[b, c, hw]
            k: 键向量，shape=[b, c, hw]
            v: 值向量，shape=[b, c, hw]
            ifBox: 重塑模式标记（True=块级路径，False=频率级路径）
        Returns:
            out: 注意力计算输出，shape=[b, c, hw]
        """
        b, c = q.shape[:2]
        # 填充特征，确保能按factor分块
        q, t_pad = self.pad(q, self.factor)
        k, t_pad = self.pad(k, self.factor)
        v, t_pad = self.pad(v, self.factor)

        hw = q.shape[-1] // self.factor  # 分块后的单块长度
        # 定义两种重塑模式（对应双路径注意力）
        if ifBox:
            # 块级路径（Box-wise）：b (head c) (factor hw) → b head (c factor) hw
            shape_ori = "b (head c) (factor hw)"
        else:
            # 频率级路径（Frequency-wise）：b (head c) (hw factor) → b head (c factor) hw
            shape_ori = "b (head c) (hw factor)"
        shape_tar = "b head (c factor) hw"  # 目标重塑形状

        # 特征重塑（拆分注意力头）
        q = rearrange(q, '{} -> {}'.format(shape_ori, shape_tar), factor=self.factor, hw=hw, head=self.num_heads)
        k = rearrange(k, '{} -> {}'.format(shape_ori, shape_tar), factor=self.factor, hw=hw, head=self.num_heads)
        v = rearrange(v, '{} -> {}'.format(shape_ori, shape_tar), factor=self.factor, hw=hw, head=self.num_heads)

        # 向量归一化（提升注意力计算稳定性）
        q = torch.nn.functional.normalize(q, dim=-1)
        k = torch.nn.functional.normalize(k, dim=-1)

        # 计算注意力得分：Q@K^T * 温度参数 → 归一化得到权重
        attn = (q @ k.transpose(-2, -1)) * self.temperature
        attn = self.softmax_1(attn, dim=-1)

        # 注意力加权求和：权重 @ V
        out = (attn @ v)

        # 重塑回原始形状
        out = rearrange(out, '{} -> {}'.format(shape_tar, shape_ori), factor=self.factor, hw=hw, b=b,
                        head=self.num_heads)
        out = self.unpad(out, t_pad)  # 反填充恢复原始维度
        return out

    def forward(self, x):
        """
        前向传播：动态范围直方图自注意力完整流程
        Args:
            x: 输入特征，shape=[b, c, h, w]（b=批量，c=通道，h=高度，w=宽度）
        Returns:
            out: 输出特征，shape=[b, c, h, w]（与输入维度一致）
        """
        b, c, h, w = x.shape

        # 1. 特征动态排序（模拟直方图统计，增强分布感知）
        # 对前半通道特征先按高度维度排序，再按宽度维度排序
        x_sort, idx_h = x[:, :c // 2].sort(-2)  # 沿高度维度（-2）排序，记录索引
        x_sort, idx_w = x_sort.sort(-1)  # 沿宽度维度（-1）排序，记录索引
        x[:, :c // 2] = x_sort  # 将排序后的特征替换回原输入

        # 2. QKV生成与局部增强
        # 1×1卷积投影为5分支 → 3×3深度卷积增强局部特征
        qkv = self.qkv_dwconv(self.qkv(x))
        # 拆分5个分支：q1, k1（块级路径）、q2, k2（频率级路径）、v（共享值向量）
        q1, k1, q2, k2, v = qkv.chunk(5, dim=1)

        # 3. 值向量排序与索引对齐
        # 将v展平为[b, c, h*w]，按最后一维排序（与输入特征分布对齐）
        v, idx = v.view(b, c, -1).sort(dim=-1)
        # 将q1, k1, q2, k2按v的排序索引重新排列（保持分布一致性）
        q1 = torch.gather(q1.view(b, c, -1), dim=2, index=idx)
        k1 = torch.gather(k1.view(b, c, -1), dim=2, index=idx)
        q2 = torch.gather(q2.view(b, c, -1), dim=2, index=idx)
        k2 = torch.gather(k2.view(b, c, -1), dim=2, index=idx)

        # 4. 双路径注意力计算
        out1 = self.reshape_attn(q1, k1, v, True)  # 块级注意力（Box-wise）
        out2 = self.reshape_attn(q2, k2, v, False)  # 频率级注意力（Frequency-wise）

        # 5. 索引反排序（恢复原始特征位置）
        out1 = torch.scatter(out1, 2, idx, out1).view(b, c, h, w)
        out2 = torch.scatter(out2, 2, idx, out2).view(b, c, h, w)

        # 6. 双路径特征融合（元素-wise乘法）与输出投影
        out = out1 * out2  # 注意力特征融合
        out = self.project_out(out)  # 1×1卷积投影回原维度

        # 7. 前半通道特征反排序（恢复输入原始分布）
        out_replace = out[:, :c // 2]
        out_replace = torch.scatter(out_replace, -1, idx_w, out_replace)  # 宽度维度反排序
        out_replace = torch.scatter(out_replace, -2, idx_h, out_replace)  # 高度维度反排序
        out[:, :c // 2] = out_replace

        return out

if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 64, 32, 32).to(device)
    model = Attention_histogram(64, 4).to(device)

    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN、小红书：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)