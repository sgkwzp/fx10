import torch
from torch import nn
from einops import rearrange


##  Top-K Sparse Attention (TKSA)
# 定义Top-K稀疏注意力模块，继承自PyTorch的nn.Module
class Attention(nn.Module):
    # 初始化函数，接收维度、头数和是否使用偏置参数
    def __init__(self, dim, num_heads, bias=False):
        # 调用父类的初始化方法
        super(Attention, self).__init__()
        # 保存注意力头数量
        self.num_heads = num_heads

        # 定义温度参数，用于缩放注意力分数，形状为(头数, 1, 1)
        self.temperature = nn.Parameter(torch.ones(num_heads, 1, 1))

        # 1x1卷积，将输入特征映射到3倍维度（分别用于Q、K、V）
        self.qkv = nn.Conv2d(dim, dim * 3, kernel_size=1, bias=bias)
        # 深度可分离卷积，对Q、K、V进行特征提取，groups=dim*3表示每个通道单独卷积
        self.qkv_dwconv = nn.Conv2d(dim * 3, dim * 3, kernel_size=3, stride=1, padding=1, groups=dim * 3, bias=bias)
        # 输出投影层，将注意力结果映射回原始维度
        self.project_out = nn.Conv2d(dim, dim, kernel_size=1, bias=bias)
        # 注意力dropout层（此处 dropout 率为0，实际使用时可调整）
        self.attn_drop = nn.Dropout(0.)

        # 定义4个可学习的注意力权重参数，用于融合不同稀疏度的注意力结果
        self.attn1 = torch.nn.Parameter(torch.tensor([0.2]), requires_grad=True)
        self.attn2 = torch.nn.Parameter(torch.tensor([0.2]), requires_grad=True)
        self.attn3 = torch.nn.Parameter(torch.tensor([0.3]), requires_grad=True)  # 原代码四个参数和为0.8，这里调整为0.3使总和为1（可选优化）
        self.attn4 = torch.nn.Parameter(torch.tensor([0.3]), requires_grad=True)

    # 前向传播函数，接收输入特征x
    def forward(self, x):
        # 获取输入特征的形状：b=批次大小, c=通道数, h=高度, w=宽度
        b, c, h, w = x.shape

        # 先通过1x1卷积生成QKV，再通过深度可分离卷积提取局部特征
        qkv = self.qkv_dwconv(self.qkv(x))
        # 将QKV沿通道维度拆分为Q、K、V三个部分
        q, k, v = qkv.chunk(3, dim=1)

        # 重塑Q的形状：(b, head*c, h, w) -> (b, head, c_per_head, h*w)
        # 其中c_per_head = c / num_heads，即将通道按头数拆分
        q = rearrange(q, 'b (head c) h w -> b head c (h w)', head=self.num_heads)
        # 重塑K的形状，与Q保持一致
        k = rearrange(k, 'b (head c) h w -> b head c (h w)', head=self.num_heads)
        # 重塑V的形状，与Q保持一致
        v = rearrange(v, 'b (head c) h w -> b head c (h w)', head=self.num_heads)

        # 对Q和K进行L2归一化，增强数值稳定性
        q = torch.nn.functional.normalize(q, dim=-1)
        k = torch.nn.functional.normalize(k, dim=-1)

        # 获取Q的形状信息，C为每个注意力头的特征维度
        _, _, C, _ = q.shape

        # 初始化4个掩码矩阵，形状为(b, num_heads, C, C)，用于标记Top-K的位置
        # 掩码矩阵与输入x在同一设备上（CPU/GPU），且不需要计算梯度
        mask1 = torch.zeros(b, self.num_heads, C, C, device=x.device, requires_grad=False)
        mask2 = torch.zeros(b, self.num_heads, C, C, device=x.device, requires_grad=False)
        mask3 = torch.zeros(b, self.num_heads, C, C, device=x.device, requires_grad=False)
        mask4 = torch.zeros(b, self.num_heads, C, C, device=x.device, requires_grad=False)

        # 计算注意力分数：Q与K的转置相乘，再乘以温度参数进行缩放
        # K的转置操作将形状从(b, head, c, n)变为(b, head, n, c)，其中n=h*w
        attn = (q @ k.transpose(-2, -1)) * self.temperature

        # 第一种稀疏度：选取Top-K = C/2的注意力分数
        # 获取每一行中最大的C/2个元素的索引
        index = torch.topk(attn, k=int(C/2), dim=-1, largest=True)[1]
        # 在掩码中标记这些索引位置为1（使用scatter_进行原地操作）
        mask1.scatter_(-1, index, 1.)
        # 保留Top-K的注意力分数，其他位置设为负无穷（softmax后接近0）
        attn1 = torch.where(mask1 > 0, attn, torch.full_like(attn, float('-inf')))

        # 第二种稀疏度：选取Top-K = 2C/3的注意力分数
        index = torch.topk(attn, k=int(C*2/3), dim=-1, largest=True)[1]
        mask2.scatter_(-1, index, 1.)
        attn2 = torch.where(mask2 > 0, attn, torch.full_like(attn, float('-inf')))

        # 第三种稀疏度：选取Top-K = 3C/4的注意力分数
        index = torch.topk(attn, k=int(C*3/4), dim=-1, largest=True)[1]
        mask3.scatter_(-1, index, 1.)
        attn3 = torch.where(mask3 > 0, attn, torch.full_like(attn, float('-inf')))

        # 第四种稀疏度：选取Top-K = 4C/5的注意力分数
        index = torch.topk(attn, k=int(C*4/5), dim=-1, largest=True)[1]
        mask4.scatter_(-1, index, 1.)
        attn4 = torch.where(mask4 > 0, attn, torch.full_like(attn, float('-inf')))

        # 对四种稀疏注意力分数分别进行softmax归一化
        attn1 = attn1.softmax(dim=-1)
        attn2 = attn2.softmax(dim=-1)
        attn3 = attn3.softmax(dim=-1)
        attn4 = attn4.softmax(dim=-1)

        # 计算四种注意力与V的加权求和，得到各自的输出
        out1 = (attn1 @ v)
        out2 = (attn2 @ v)
        out3 = (attn3 @ v)
        out4 = (attn4 @ v)

        # 将四种输出按可学习权重进行融合
        out = out1 * self.attn1 + out2 * self.attn2 + out3 * self.attn3 + out4 * self.attn4

        # 将输出重塑回原始的空间维度：(b, head, c_per_head, h*w) -> (b, head*c_per_head, h, w)
        out = rearrange(out, 'b head c (h w) -> b (head c) h w', head=self.num_heads, h=h, w=w)

        # 通过投影层将特征映射回原始维度，并返回结果
        out = self.project_out(out)
        return out


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 64, 32, 32).to(device)
    model = Attention(64, 4).to(device)

    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN、小红书：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)