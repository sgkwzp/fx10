import math
import torch
import torch.nn as nn
import torch.nn.functional as F

import einops
from timm.models.layers import DropPath, to_2tuple, trunc_normal_
from modules import ModuleParallel, LayerNormParallel
from dat_blocks import DAttentionBaseline, DeformableAttention_gy, LocalAttention, ShiftWindowAttention_mm, CrossLocalAttention, ShiftedCrossLocalAttention



class Attention(nn.Module):
    def __init__(
            self,
            dim,
            num_heads=8,
            qkv_bias=False,
            qk_scale=None,
            attn_drop=0.0,
            proj_drop=0.0,
            sr_ratio=1,
            n_heads=8,
            window_size=7,
    ):
        super().__init__()
        assert (
                dim % num_heads == 0
        ), f"dim {dim} should be divided by num_heads {num_heads}."

        self.dim = dim
        self.num_heads = num_heads
        head_dim = dim // num_heads
        self.scale = qk_scale or head_dim ** -0.5

        self.q = ModuleParallel(nn.Linear(dim, dim, bias=qkv_bias))
        self.kv = ModuleParallel(nn.Linear(dim, dim * 2, bias=qkv_bias))
        self.attn_drop = ModuleParallel(nn.Dropout(attn_drop))
        self.proj = ModuleParallel(nn.Linear(dim, dim))
        self.proj_drop = ModuleParallel(nn.Dropout(proj_drop))

        self.sr_ratio = sr_ratio
        if sr_ratio > 1:
            self.sr = ModuleParallel(
                nn.Conv2d(dim, dim, kernel_size=sr_ratio, stride=sr_ratio)
            )
            self.norm = LayerNormParallel(dim)

        self.cross_heads = n_heads

        self.pixel_crossattention = False

        self.pixel_crossattention_parallel = True
        self.cross_attention_in_pixel = False  # self.pixel_crossattention_parallel must be True
        self.diffential_att = True  # self.pixel_crossattention_parallel must be True
        self.scale_factor = True  # self.pixel_crossattention_parallel must be True

        # self
        self.localattention = False
        self.shiftwindow_mm = False

        # cross
        self.cross_attention = False
        self.crosslocalattention = False
        self.cross_shifted_window_attention = False

        if self.cross_attention:
            self.q_proj_ca = nn.Linear(dim, dim)
            self.k_proj_ca = nn.Linear(dim, dim)
            self.v_proj_ca = nn.Linear(dim, dim)

        if self.pixel_crossattention:
            self.cross_attn_0_to_1 = nn.MultiheadAttention(
                dim, self.cross_heads, dropout=0.0, batch_first=False
            )
            self.cross_attn_1_to_0 = nn.MultiheadAttention(
                dim, self.cross_heads, dropout=0.0, batch_first=False
            )

            self.relation_judger = nn.Sequential(
                Mlp_2(dim * 2, dim, dim), torch.nn.Softmax(dim=-1)
            )

            self.k_noise = nn.Embedding(2, dim)
            self.v_noise = nn.Embedding(2, dim)

        if self.pixel_crossattention_parallel:
            self.cross_attn_0_to_1 = nn.MultiheadAttention(
                dim, self.cross_heads, dropout=0.0, batch_first=False
            )
            self.cross_attn_1_to_0 = nn.MultiheadAttention(
                dim, self.cross_heads, dropout=0.0, batch_first=False
            )

            # self.relation_judger = nn.Sequential(
            #     Mlp_2(dim * 2, dim, dim), torch.nn.Softmax(dim=-1)
            # )
            self.relation_judger = nn.Sequential(
                Mlp_2(dim * 2, dim, dim),
                torch.nn.Sigmoid()
            )
            # self.relation_judger = ECAAttention(dim * 2, dim)
            # self.relation_judger = DynamicSENet()

            self.k_noise = nn.Embedding(2, dim)
            self.v_noise = nn.Embedding(2, dim)

        if self.diffential_att:
            # self.alpha1 = nn.Parameter(torch.tensor(1.0))
            # self.beta1 = nn.Parameter(torch.tensor(1.0))
            # self.alpha2 = nn.Parameter(torch.tensor(1.0))
            # self.beta2 = nn.Parameter(torch.tensor(1.0))
            self.diff_0_to_1 = Mlp_2(dim, dim, dim)
            self.diff_1_to_0 = Mlp_2(dim, dim, dim)

        if self.scale_factor:
            self.scale_factor_0_to_1 = nn.Parameter(torch.tensor([0.5, 0.5]))
            self.scale_factor_1_to_0 = nn.Parameter(torch.tensor([0.5, 0.5]))

        if self.localattention:
            self.local_attn1 = LocalAttention(dim=dim,
                                              heads=self.cross_heads,
                                              window_size=window_size,
                                              attn_drop=0.1,
                                              proj_drop=0.1)
            self.local_attn2 = LocalAttention(dim=dim,
                                              heads=self.cross_heads,
                                              window_size=window_size,
                                              attn_drop=0.1,
                                              proj_drop=0.1)

        if self.shiftwindow_mm:
            self.local_attn1 = ShiftWindowAttention_mm(dim=dim,
                                                       heads=self.cross_heads,
                                                       window_size=window_size,
                                                       attn_drop=0.1,
                                                       proj_drop=0.1,
                                                       shift_size=3)
            self.local_attn2 = ShiftWindowAttention_mm(dim=dim,
                                                       heads=self.cross_heads,
                                                       window_size=window_size,
                                                       attn_drop=0.1,
                                                       proj_drop=0.1,
                                                       shift_size=3)
        self.apply(self._init_weights)

        if self.crosslocalattention:
            self.cla_0_to_1 = CrossLocalAttention(dim=dim, heads=self.cross_heads, window_size=window_size)
            self.cla_1_to_0 = CrossLocalAttention(dim=dim, heads=self.cross_heads, window_size=window_size)

        if self.cross_shifted_window_attention:
            self.swin_layer_0_to_1 = nn.ModuleList([
                ShiftedCrossLocalAttention(dim=dim, heads=self.cross_heads, window_size=window_size, shift_size=0),
                ShiftedCrossLocalAttention(dim=dim, heads=self.cross_heads, window_size=window_size,
                                           shift_size=window_size // 2)
            ])
            self.swin_layer_1_to_0 = nn.ModuleList([
                ShiftedCrossLocalAttention(dim=dim, heads=self.cross_heads, window_size=window_size, shift_size=0),
                ShiftedCrossLocalAttention(dim=dim, heads=self.cross_heads, window_size=window_size,
                                           shift_size=window_size // 2)
            ])

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=0.02)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.LayerNorm):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)
        elif isinstance(m, nn.Conv2d):
            fan_out = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
            fan_out //= m.groups
            m.weight.data.normal_(0, math.sqrt(2.0 / fan_out))
            if m.bias is not None:
                m.bias.data.zero_()

    def cross_attention_func(self, q, k, v):
        # q, k, v: (B, N, C)
        Q = self.q_proj_ca(q)
        K = self.k_proj_ca(k)
        V = self.v_proj_ca(v)
        attn = torch.matmul(Q, K.transpose(-2, -1)) / (Q.shape[-1] ** 0.5)
        attn = F.softmax(attn, dim=-1)
        out = torch.matmul(attn, V)
        return out

    def forward(
            self,
            x,
            H,
            W,
    ):
        # step1: calculate self-attention in each modality
        B, N, C = x[0].shape
        q = self.q(x)  # [(B,N,C), (B,N,C)]
        q = [
            q_.reshape(B, N, self.num_heads, C // self.num_heads).permute(0, 2, 1, 3)
            for q_ in q
        ]  # [(B,N,num_head,C//num_head), (B,N,num_head,C//num_head)]

        if self.sr_ratio > 1:
            x = [x_.permute(0, 2, 1).reshape(B, C, H, W) for x_ in x]
            x = self.sr(x)
            x = [x_.reshape(B, C, -1).permute(0, 2, 1) for x_ in x]
            x = self.norm(x)
            kv = self.kv(x)  # [(B,N,2C), (B,N,2C)]
            kv = [
                kv_.reshape(B, -1, 2, self.num_heads, C // self.num_heads).permute(
                    2, 0, 3, 1, 4
                )
                for kv_ in kv
            ]  # [(2,B,num_head,N,C//num_head), (2,B,num_head,N,C//num_head)]
        else:
            kv = self.kv(x)  # [(B,N,2C), (B,N,2C)]
            kv = [
                kv_.reshape(B, -1, 2, self.num_heads, C // self.num_heads).permute(
                    2, 0, 3, 1, 4
                )
                for kv_ in kv
            ]  # [(2,B,num_head,N,C//num_head), (2,B,num_head,N,C//num_head)]
        k, v = [kv[0][0], kv[1][0]], [kv[0][1], kv[1][
            1]]  # q: [(B,N,num_head,C//num_head), (B,N,num_head,C//num_head)]   v: [(B,N,num_head,C//num_head), (B,N,num_head,C//num_head)]

        attn = [(q_ @ k_.transpose(-2, -1)) * self.scale for (q_, k_) in
                zip(q, k)]  # [(B, num_heads, N, N), (B, num_heads, N, N)]
        attn = [attn_.softmax(dim=-1) for attn_ in attn]  # [(B, num_heads, N, N), (B, num_heads, N, N)]
        attn = self.attn_drop(attn)  # [(B, num_heads, N, N), (B, num_heads, N, N)]

        x = [
            (attn_ @ v_).transpose(1, 2).reshape(B, N, C)
            for (attn_, v_) in zip(attn, v)
        ]  # [(B,N,C),(B,N,C)]

        if self.cross_attention:
            x0 = x[0]  # (B,N,C)
            x1 = x[1]  # (B,N,C)
            new_x0 = self.cross_attention_func(x0, x1, x1)  # x0->x1
            new_x1 = self.cross_attention_func(x1, x0, x0)  # x1->x0
            x[0] = new_x0
            x[1] = new_x1

        if self.pixel_crossattention:
            # cross-attn per batch
            new_x0 = []
            new_x1 = []
            for bs in range(B):
                ## 1. 0_to_1 cross attn and skip connect
                q = x[0][bs].unsqueeze(0)  # (1,N,C)

                judger_input = torch.cat(
                    [x[0][bs].unsqueeze(0), x[1][bs].unsqueeze(0)], dim=-1
                )  # (1,N,2C)

                relation_score = self.relation_judger(judger_input)  # (1,N,C)

                noise_k = self.k_noise.weight[0] + q
                noise_v = self.v_noise.weight[0] + q

                if self.diffential_att:
                    diff_noise1 = self.diff_0_to_1(x[0][bs].unsqueeze(0) - x[1][bs].unsqueeze(0))
                    diff_noise1_softmax = F.softmax(diff_noise1, dim=-1)
                    k = torch.cat([noise_k, torch.mul(q, diff_noise1_softmax), torch.mul(q, relation_score)],
                                  dim=0)  # (2,N,C)
                    v = torch.cat([noise_v, x[0][bs].unsqueeze(0) - x[1][bs].unsqueeze(0), x[1][bs].unsqueeze(0)],
                                  dim=0)  # (2,N,C)
                else:
                    k = torch.cat([noise_k, torch.mul(q, relation_score)], dim=0)  # (2,N,C)
                    v = torch.cat([noise_v, x[1][bs].unsqueeze(0)], dim=0)  # (2,N,C)

                new_x0.append(x[0][bs] + self.cross_attn_0_to_1(q, k, v)[0].squeeze(0))  # (N,C)

                ## 2. 1_to_0 cross attn and skip connect
                q = x[1][bs].unsqueeze(0)

                judger_input = torch.cat(
                    [x[1][bs].unsqueeze(0), x[0][bs].unsqueeze(0)], dim=-1
                )

                relation_score = self.relation_judger(judger_input)

                noise_k = self.k_noise.weight[1] + q
                noise_v = self.v_noise.weight[1] + q

                if self.diffential_att:
                    diff_noise2 = self.diff_1_to_0(x[1][bs].unsqueeze(0) - x[0][bs].unsqueeze(0))
                    diff_noise2_softmax = F.softmax(diff_noise2, dim=-1)
                    k = torch.cat([noise_k, torch.mul(q, diff_noise2_softmax), torch.mul(q, relation_score)], dim=0)
                    v = torch.cat([noise_v, x[1][bs].unsqueeze(0) - x[0][bs].unsqueeze(0), x[0][bs].unsqueeze(0)],
                                  dim=0)
                else:
                    k = torch.cat([noise_k, torch.mul(q, relation_score)], dim=0)
                    v = torch.cat([noise_v, x[0][bs].unsqueeze(0)], dim=0)

                new_x1.append(x[1][bs] + self.cross_attn_1_to_0(q, k, v)[0].squeeze(0))

            new_x0 = torch.stack(new_x0)  # (B,N,C)
            new_x1 = torch.stack(new_x1)
            x[0] = new_x0
            x[1] = new_x1

        if self.pixel_crossattention_parallel:
            # cross-attn per batch

            x0 = x[0]  # (B,N,C)
            x1 = x[1]  # (B,N,C)
            q = x0  # (B,N,C)

            attn_mask = torch.ones((B, B), dtype=torch.bool, device=q.device)
            indices = torch.arange(B)
            attn_mask[indices, indices] = False

            # 1. 0_to_1 cross attn and skip connect
            judger_input = torch.cat([x0, x1], dim=-1)  # (B,N,2C)
            relation_score = self.relation_judger(judger_input)  # (B,N,C)

            noise_k = self.k_noise.weight[0].unsqueeze(0).unsqueeze(0) + q  # (B,N,C)
            noise_v = self.v_noise.weight[0].unsqueeze(0).unsqueeze(0) + q  # (B,N,C)

            if self.diffential_att:
                diff_noise1 = self.diff_0_to_1(x0 - x1)
                diff_noise1_softmax = F.softmax(diff_noise1, dim=-1)

                if self.scale_factor:
                    scale_factor_0_to_1 = F.softmax(self.scale_factor_0_to_1, dim=0)
                    k = scale_factor_0_to_1[0] * torch.mul(q, diff_noise1_softmax) + noise_k + scale_factor_0_to_1[
                        1] * torch.mul(q, relation_score)
                else:
                    k = torch.mul(q, diff_noise1_softmax) + noise_k + torch.mul(q, relation_score)

                    # k = diff_noise1 + noise_k + torch.mul(q, relation_score)  # (B, N, C)
                v = noise_v + x1  # (B, N, C)
            else:
                k = noise_k + torch.mul(q, relation_score)  # (B, N, C)
                v = noise_v + x1  # (B, N, C)

            if self.cross_attention_in_pixel:
                attn_output_0_to_1, _ = self.cross_attn_0_to_1(q, k, v)
            else:
                attn_output_0_to_1, _ = self.cross_attn_0_to_1(q, k, v, attn_mask=attn_mask)
            new_x0 = x0 + attn_output_0_to_1  # (B, N, C)

            # 2. 1_to_0 cross attn and skip connect
            q = x1  # (B, N, C)

            judger_input = torch.cat([x1, x0], dim=-1)  # (B, N, 2C)
            relation_score = self.relation_judger(judger_input)  # (B, N, C)

            noise_k = self.k_noise.weight[1].unsqueeze(0).unsqueeze(0) + q
            noise_v = self.v_noise.weight[1].unsqueeze(0).unsqueeze(0) + q

            if self.diffential_att:
                diff_noise2 = self.diff_1_to_0(x1 - x0)
                diff_noise2_softmax = F.softmax(diff_noise2, dim=-1)

                if self.scale_factor:
                    scale_factor_1_to_0 = F.softmax(self.scale_factor_1_to_0, dim=0)
                    k = scale_factor_1_to_0[0] * torch.mul(q, diff_noise2_softmax) + noise_k + scale_factor_1_to_0[
                        1] * torch.mul(q, relation_score)
                else:
                    k = torch.mul(q, diff_noise2_softmax) + noise_k + torch.mul(q, relation_score)
                    # k = diff_noise2 + noise_k + torch.mul(q, relation_score)  # (B, N, C)
                v = noise_v + x0  # (B, N, C)
            else:
                k = noise_k + torch.mul(q, relation_score)  # (B, N, C)
                v = noise_v + x0  # (B, N, C)

            if self.cross_attention_in_pixel:
                attn_output_1_to_0, _ = self.cross_attn_1_to_0(q, k, v)
            else:
                attn_output_1_to_0, _ = self.cross_attn_1_to_0(q, k, v, attn_mask=attn_mask)
            new_x1 = x1 + attn_output_1_to_0  # (B, N, C)

            x[0] = new_x0
            x[1] = new_x1

        if self.localattention:
            # local attention
            x0, x1 = x[0], x[1]
            x0 = einops.rearrange(x0, 'b (h w) c -> b c h w', h=H, w=W)
            x1 = einops.rearrange(x1, 'b (h w) c -> b c h w', h=H, w=W)
            out0, _, _ = self.local_attn1(x0)
            out1, _, _ = self.local_attn2(x1)
            out0 = einops.rearrange(out0, 'b c h w -> b (h w) c')
            out1 = einops.rearrange(out1, 'b c h w -> b (h w) c')

            x_new = [out0, out1]
            x = x_new

        if self.shiftwindow_mm:
            x0, x1 = x[0], x[1]
            x0 = einops.rearrange(x0, 'b (h w) c -> b c h w', h=H, w=W)
            x1 = einops.rearrange(x1, 'b (h w) c -> b c h w', h=H, w=W)
            out0, _, _ = self.local_attn1(x0, x1)
            out1, _, _ = self.local_attn2(x1, x0)
            out0 = einops.rearrange(out0, 'b c h w -> b (h w) c')
            out1 = einops.rearrange(out1, 'b c h w -> b (h w) c')

            x_new = [out0, out1]
            x = x_new

        if self.crosslocalattention:
            x0, x1 = x[0], x[1]
            x0 = einops.rearrange(x0, 'b (h w) c -> b c h w', h=H, w=W)
            x1 = einops.rearrange(x1, 'b (h w) c -> b c h w', h=H, w=W)
            out0 = self.cla_0_to_1(x0, x1)
            out1 = self.cla_1_to_0(x1, x0)
            out0 = einops.rearrange(out0, 'b c h w -> b (h w) c')
            out1 = einops.rearrange(out1, 'b c h w -> b (h w) c')

            x_new = [out0, out1]
            x = x_new

        if self.cross_shifted_window_attention:
            x0, x1 = x[0], x[1]
            x0 = einops.rearrange(x0, 'b (h w) c -> b c h w', h=H, w=W)
            x1 = einops.rearrange(x1, 'b (h w) c -> b c h w', h=H, w=W)

            out0 = x0
            for layer in self.swin_layer_0_to_1:
                out0 = layer(out0, x1)

            out1 = x1
            for layer in self.swin_layer_1_to_0:
                out1 = layer(out1, x0)

            out0 = einops.rearrange(out0, 'b c h w -> b (h w) c')
            out1 = einops.rearrange(out1, 'b c h w -> b (h w) c')

            x_new = [out0, out1]
            x = x_new

        x = self.proj(x)
        x = self.proj_drop(x)

        return x