import torch
from torch import nn
import torch.nn.functional as F
import numbers
from einops import rearrange
import math

def to_3d(x):
    return rearrange(x, 'b c h w -> b (h w) c')

def to_4d(x, h, w):
    return rearrange(x, 'b (h w) c -> b c h w', h=h, w=w)

class BiasFree_LayerNorm(nn.Module):
    def __init__(self, normalized_shape):
        super(BiasFree_LayerNorm, self).__init__()
        if isinstance(normalized_shape, numbers.Integral):
            normalized_shape = (normalized_shape,)
        normalized_shape = torch.Size(normalized_shape)

        assert len(normalized_shape) == 1

        self.weight = nn.Parameter(torch.ones(normalized_shape))
        self.normalized_shape = normalized_shape

    def forward(self, x):
        sigma = x.var(-1, keepdim=True, unbiased=False)
        return x / torch.sqrt(sigma + 1e-5) * self.weight


class WithBias_LayerNorm(nn.Module):
    def __init__(self, normalized_shape):
        super(WithBias_LayerNorm, self).__init__()
        if isinstance(normalized_shape, numbers.Integral):
            normalized_shape = (normalized_shape,)
        normalized_shape = torch.Size(normalized_shape)

        assert len(normalized_shape) == 1

        self.weight = nn.Parameter(torch.ones(normalized_shape))
        self.bias = nn.Parameter(torch.zeros(normalized_shape))
        self.normalized_shape = normalized_shape

    def forward(self, x):
        mu = x.mean(-1, keepdim=True)
        sigma = x.var(-1, keepdim=True, unbiased=False)
        return (x - mu) / torch.sqrt(sigma + 1e-5) * self.weight + self.bias



class LayerNorm(nn.Module):
    def __init__(self, dim, LayerNorm_type):
        super(LayerNorm, self).__init__()
        if LayerNorm_type == 'BiasFree':
            self.body = BiasFree_LayerNorm(dim)
        else:
            self.body = WithBias_LayerNorm(dim)

    def forward(self, x):
        h, w = x.shape[-2:]
        return to_4d(self.body(to_3d(x)), h, w)

class FeedForward(nn.Module):
    def __init__(self, dim, ffn_factor, bias):
        super(FeedForward, self).__init__()

        hidden_features = int(dim * ffn_factor)

        self.project_in = nn.Conv2d(dim, hidden_features, kernel_size=1, bias=bias)

        self.project_out = nn.Conv2d(hidden_features, dim, kernel_size=1, bias=bias)

    def forward(self, x):
        x = self.project_in(x)
        x = F.gelu(x)
        x = self.project_out(x)
        return x

class FeatureWiseAffine(nn.Module):
    """特征级仿射变换：基于噪声嵌入动态调整特征，增强噪声适应性"""
    def __init__(self, in_channels, out_channels, use_affine_level=False):
        super(FeatureWiseAffine, self).__init__()
        self.use_affine_level = use_affine_level
        self.noise_func = nn.Sequential(
            nn.Linear(in_channels, out_channels*(1+self.use_affine_level))
        )

    def forward(self, x, noise_embed):
        batch = x.shape[0]
        if self.use_affine_level:
            gamma, beta = self.noise_func(noise_embed).view(
                batch, -1, 1, 1).chunk(2, dim=1)
            x = (1 + gamma) * x + beta
        else:
            x = x + self.noise_func(noise_embed).view(batch, -1, 1, 1)
        return x

class Swish(nn.Module):
    def forward(self, x):
        return x * torch.sigmoid(x)

class Block(nn.Module):
    def __init__(self, dim, dim_out, groups=32, dropout=0):
        super().__init__()
        self.block = nn.Sequential(
            nn.GroupNorm(groups, dim),
            Swish(),
            nn.Dropout(dropout) if dropout != 0 else nn.Identity(),
            nn.Conv2d(dim, dim_out, 3, padding=1)
        )

    def forward(self, x):
        return self.block(x)

class DecodeResnetBlock(nn.Module):
    def __init__(self, dim, dim_out, noise_level_emb_dim=None, dropout=0, use_affine_level=False, norm_groups=32):
        super().__init__()
        if noise_level_emb_dim is not None:
            self.noise_func = FeatureWiseAffine(
                noise_level_emb_dim, dim_out, use_affine_level)

        self.block1 = Block(dim_out, dim_out, groups=norm_groups)
        self.block2 = Block(dim_out, dim_out, groups=norm_groups, dropout=dropout)
        self.res_conv = nn.Conv2d(
            dim_out, dim_out, 1) if dim != dim_out else nn.Identity()

    def forward(self, x,time_emb=None):
        b, c, h, w = x.shape
        h = self.block1(x)
        if time_emb is not None:
            h = self.noise_func(h, time_emb)
        return h + self.res_conv(x)

class Feature_Router(nn.Module):
    def __init__(self, n_embed, top_k):
        super().__init__()
        self.top_k = top_k
        self.pooling = nn.AdaptiveAvgPool2d((1,1))
        self.linear = nn.Linear(n_embed, n_embed)

    def forward(self, x):  # x: B,C,H,W
        B, C = x.shape[:2]
        x = self.pooling(x).view(B, C)  # B,C,1,1
        logits = self.linear(x)  # B,C
        router_logits = F.softmax(logits, dim=-1)
        _, indices = router_logits.topk(self.top_k, dim=-1)  # B,top_k
        return indices

class SingleResnetBlocWithAttn(nn.Module):
    """
        NARB核心模块：噪声感知路由+残差精炼+特征融合
        核心创新：
            1. 噪声感知路由：基于通道统计筛选有效通道，抑制噪声通道；
            2. 动态特征调整：基于噪声嵌入适配不同噪声水平；
            3. 轻量化精炼：仅对筛选后通道精炼，降低计算量；
            4. 残差融合：保留原始特征，避免过度精炼。
        输入：
            x: 含噪声特征 [B, dim, H, W]
            time_emb: 噪声嵌入 [B, noise_embed_dim]
        输出：
            去噪/精炼后特征 [B, dim_out, H, W]（与输入维度一致）
        """
    def __init__(self, dim, dim_out, *, noise_level_emb_dim=True, norm_groups=4, dropout=0, ffn_factor=2.66, \
                 with_attn=False, use_affine_level=False, attn_type=None, topk_ratio=0.25):
        super().__init__()

        self.with_attn = with_attn
        self.decoding = nn.Conv2d(dim, dim_out, kernel_size=1, bias=False)
        if noise_level_emb_dim is not None:
            self.noise_func = FeatureWiseAffine(
                noise_level_emb_dim, dim_out, use_affine_level)
        self.ffn = FeedForward(dim_out, ffn_factor, bias=False)
        self.norm = LayerNorm(dim_out, LayerNorm_type='WithBias')
        if topk_ratio is not None:
            self.use_topk = True
            self.routing = Feature_Router(dim_out, int(topk_ratio * dim_out))
            dim_out = int(topk_ratio * dim_out)

        self.res_block = DecodeResnetBlock(
            dim_out, dim_out, noise_level_emb_dim, norm_groups=norm_groups, dropout=dropout,
            use_affine_level=use_affine_level)

    def forward(self, x, time_emb):

        # x = self.res_block(x, time_emb)
        x = self.decoding(x)  # B,C,H,W
        B, C, H, W = x.shape
        if self.use_topk:
            select_dims = self.routing(x)[:, :, None, None].expand(-1, -1, H, W)  # [B,top_k]
            selected_x = torch.gather(x, dim=1, index=select_dims)
        else:
            selected_x = x
        selected_x = self.res_block(selected_x, time_emb)
        if self.use_topk:
            output = torch.zeros_like(x)  # B,H,W,C
            output = output.scatter(dim=1, index=select_dims, src=output)
        x = x + output
        h = self.noise_func(x, time_emb)
        output = self.ffn(self.norm(h)) + x
        return output


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 64, 32, 32).to(device)
    t = torch.randn(1, 1).to(device)            # time_emb
    model = SingleResnetBlocWithAttn(64, 64).to(device)

    y = model(x, t)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)