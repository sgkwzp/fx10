import torch
import torch.nn as nn


class MaskAttn(nn.Module):
    """
    掩码注意力模块（MaskAttn）：通过动态生成的二进制掩码，对注意力权重进行选择性抑制，增强关键特征
    核心创新：
        1. 动态二进制掩码：随机生成0/∞掩码，模拟特征遮挡，强制模型聚焦有效区域；
        2. 轻量化注意力架构：简化多头注意力为单头，保留QKV核心逻辑，降低计算量；
        3. 残差与归一化融合：残差连接避免梯度消失，LayerNorm稳定训练；
        4. 即插即用设计：输入输出维度一致（BCHW格式），支持无缝替换传统卷积/注意力模块。
    输入：特征图 [B, C, H, W]（B=批次，C=通道数，H/W=高/宽）
    输出：掩码注意力增强特征 [B, C, H, W]（与输入维度完全一致）
    """

    def __init__(self, channels):
        """
        参数初始化：
            channels: 输入/输出通道数（需保持一致，适配残差连接）
        """
        super(MaskAttn, self).__init__()
        self.channels = channels  # 通道数（QKV维度）

        # QKV投影层：线性层将输入特征映射为查询（Q）、键（K）、值（V）
        self.query = nn.Linear(channels, channels)  # Q投影：[B, N, C]→[B, N, C]
        self.key = nn.Linear(channels, channels)  # K投影：[B, N, C]→[B, N, C]
        self.value = nn.Linear(channels, channels)  # V投影：[B, N, C]→[B, N, C]

        self.mask = None  # 掩码缓存（避免重复生成，提升效率）

        # 归一化层：LayerNorm（按通道维度归一化，稳定注意力权重分布）
        self.norm = nn.LayerNorm([channels])

    def forward(self, x):
        """
        前向传播流程（BCHW→BNC→注意力计算→BNC→BCHW）：
            维度转换→QKV生成→注意力分数计算→掩码抑制→权重归一化→V加权→残差融合→归一化→维度恢复
        """
        batch_size, channels, height, width = x.size()  # 解析输入维度

        # 校验通道数一致性（确保输入通道与模块初始化通道匹配）
        if channels != self.channels:
            raise ValueError(f"输入通道数 {channels} 与模块初始化通道数 {self.channels} 不匹配")

        # 步骤1：维度转换（BCHW→BNC，N=H×W，适配注意力计算）
        x_reshaped = x.view(batch_size, channels, height * width).permute(0, 2, 1)  # [B, N, C]

        # 步骤2：生成Q（查询）、K（键）、V（值）
        Q = self.query(x_reshaped)  # [B, N, C]
        K = self.key(x_reshaped)  # [B, N, C]
        V = self.value(x_reshaped)  # [B, N, C]

        # 步骤3：计算注意力分数（QK^T）并缩放（避免数值过大）
        scores = torch.matmul(Q, K.transpose(-2, -1))  # [B, N, N]（注意力分数矩阵）
        scores = scores / (self.channels ** 0.5)  # 缩放因子=√C，缓解梯度消失

        # 步骤4：动态生成二进制掩码（缓存复用，避免重复计算）
        if self.mask is None or self.mask.size(-1) != height * width:
            # 生成二进制掩码（0/1随机分布）：[B, H, W]→[B, N]
            binary_mask = torch.randint(0, 2, (batch_size, height, width), device=x.device)
            binary_mask = binary_mask.view(batch_size, -1)  # [B, N]
            # 掩码处理：1→0（保留），0→-∞（抑制，Softmax后权重趋近于0）
            processed_mask = torch.where(
                binary_mask > 0.5,
                torch.tensor(0.0, device=x.device),
                torch.tensor(-float('inf'), device=x.device)
            )
            # 掩码扩展：[B, N]→[B, N, N]（每个查询对应相同的掩码）
            self.mask = processed_mask.unsqueeze(1).expand(-1, height * width, -1)

        # 步骤5：掩码抑制注意力分数（抑制无效区域）
        scores = scores + self.mask  # [B, N, N]

        # 步骤6：注意力权重归一化（Softmax）
        attention_weights = torch.softmax(scores, dim=-1)  # [B, N, N]（权重和为1）

        # 步骤7：注意力加权V（值）
        attention_output = torch.matmul(attention_weights, V)  # [B, N, C]

        # 步骤8：残差融合（注意力输出 + 原始特征）+ 归一化
        attention_output = attention_output + x_reshaped  # 残差连接，保留原始特征
        attention_output = self.norm(attention_output)  # LayerNorm稳定分布

        # 步骤9：维度恢复（BNC→BCHW）
        return attention_output.view(batch_size, channels, height, width)

if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 64, 32, 32).to(device)
    model = MaskAttn(64)

    model.to(device)
    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("知乎、CSDN：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)