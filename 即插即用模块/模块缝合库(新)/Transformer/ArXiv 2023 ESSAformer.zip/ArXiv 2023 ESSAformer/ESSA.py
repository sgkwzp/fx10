import math
import torch
import torch.nn as nn
import numpy as np

np.random.seed(0)

class Downsample(nn.Sequential):
    """
    特征下采样模块：通过PixelUnshuffle与卷积结合，降低特征图分辨率并保持通道数适配
    支持缩放比例：2^n（如2、4）或3
    """
    def __init__(self, scale, num_feat):
        """
        Args:
            scale (int): 下采样比例
            num_feat (int): 输入特征图通道数
        """
        m = []
        if (scale & (scale - 1)) == 0:  # 若scale为2的幂次（如2、4）
            for _ in range(int(math.log(scale, 2))):
                # PixelUnshuffle：将分辨率降低1/2，通道数增加4倍（如h→h/2，c→4c）
                # 先通过1×1卷积将通道数压缩至1/4，确保下采样后通道数与输入一致
                m.append(nn.Conv2d(num_feat, num_feat // 4, 3, 1, 1))
                m.append(nn.PixelUnshuffle(2))
        elif scale == 3:  # 若scale为3
            # PixelUnshuffle(3)：分辨率降低1/3，通道数增加9倍
            # 1×1卷积将通道数压缩至1/9，确保下采样后通道数一致
            m.append(nn.Conv2d(num_feat, num_feat // 9, 3, 1, 1))
            m.append(nn.PixelUnshuffle(3))
        else:
            raise ValueError(f'scale {scale} is not supported. ' 'Supported scales: 2^n and 3.')
        super(Downsample, self).__init__(*m)

class Upsample(nn.Sequential):
    """
    特征上采样模块：通过PixelShuffle与卷积结合，提升特征图分辨率并保持通道数适配
    结构与Downsample对称，支持相同缩放比例
    """
    def __init__(self, scale, num_feat):
        """
        Args:
            scale (int): 上采样比例
            num_feat (int): 输入特征图通道数
        """
        m = []
        if (scale & (scale - 1)) == 0:  # 若scale为2的幂次
            for _ in range(int(math.log(scale, 2))):
                # 1×1卷积将通道数扩展4倍，配合PixelShuffle(2)提升分辨率2倍（通道数恢复原尺寸）
                m.append(nn.Conv2d(num_feat, 4 * num_feat, 3, 1, 1))
                m.append(nn.PixelShuffle(2))
        elif scale == 3:  # 若scale为3
            # 1×1卷积扩展9倍通道，配合PixelShuffle(3)提升分辨率3倍
            m.append(nn.Conv2d(num_feat, 9 * num_feat, 3, 1, 1))
            m.append(nn.PixelShuffle(3))
        else:
            raise ValueError(f'scale {scale} is not supported. ' 'Supported scales: 2^n and 3.')
        super(Upsample, self).__init__(*m)

class PatchEmbed(nn.Module):
    """
    图像→序列转换模块：将2D特征图展平为1D序列，适配注意力模块的输入格式（注意力需序列维度）
    """
    def __init__(self, ):
        super().__init__()

    def forward(self, x):
        # 维度转换：[b, dim, h, w] → [b, dim, h*w]（展平高宽）→ [b, h*w, dim]（交换通道与序列维度）
        x = x.flatten(2).transpose(1, 2)
        return x

class PatchUnEmbed(nn.Module):
    """
    序列→图像转换模块：将1D序列恢复为2D特征图，适配后续卷积模块的输入格式
    """
    def __init__(self, in_chans=3, embed_dim=96):
        """
        Args:
            in_chans (int): 原始图像通道数（本模块未直接使用，预留扩展）
            embed_dim (int): 特征图通道数（需与输入序列的通道维度一致）
        """
        super().__init__()
        self.in_chans = in_chans
        self.embed_dim = embed_dim

    def forward(self, x, x_size):
        """
        Args:
            x (torch.Tensor): 输入序列，形状 [b, h*w, embed_dim]
            x_size (tuple): 目标特征图高宽 (h, w)
        Returns:
            torch.Tensor: 输出特征图，形状 [b, embed_dim, h, w]
        """
        B, HW, C = x.shape
        # 维度转换：[b, hw, c] → [b, c, hw]（交换序列与通道）→ [b, c, h, w]（恢复高宽）
        x = x.transpose(1, 2).view(B, self.embed_dim, x_size[0], x_size[1])
        return x

class ESSAttn(nn.Module):
    """
    增强型二次相似度注意力（Enhanced Squared Similarity Attention, ESSAttn）
    核心创新：基于“二次相似度”计算注意力权重，替代传统点积注意力，增强对特征差异的敏感度
    """

    def __init__(self, dim):
        """
        Args:
            dim (int): 输入序列的通道维度（Q/K/V的通道数）
        """
        super().__init__()
        self.lnqkv = nn.Linear(dim, dim * 3)  # 线性层：将输入序列映射为Q、K、V（单次线性变换提升效率）
        self.ln = nn.Linear(dim, dim)  # 线性层：对注意力输出进行维度调整与精炼

    def forward(self, x):
        """
        Args:
            x (torch.Tensor): 输入序列，形状 [b, h*w, dim]
        Returns:
            attn (torch.Tensor): 注意力输出序列，形状与输入一致 [b, h*w, dim]
        """
        b, N, C = x.shape  # N = h*w（序列长度），C = dim（通道数）

        # 步骤1：生成Q、K、V
        qkv = self.lnqkv(x)  # 形状：[b, N, 3*C]
        qkv = torch.split(qkv, C, 2)  # 按通道维度拆分：qkv → [Q, K, V]，各形状 [b, N, C]
        q, k, v = qkv[0], qkv[1], qkv[2]

        # 步骤2：特征中心化（消除全局均值偏差，增强相似度计算的准确性）
        a = torch.mean(q, dim=2, keepdim=True)  # Q的通道均值：[b, N, 1]
        q = q - a  # Q中心化：[b, N, C]
        a = torch.mean(k, dim=2, keepdim=True)  # K的通道均值：[b, N, 1]
        k = k - a  # K中心化：[b, N, C]

        # 步骤3：计算二次特征（Q²、K²）与二次相似度
        q2 = torch.pow(q, 2)  # Q的二次特征：[b, N, C]（增强特征差异）
        q2s = torch.sum(q2, dim=2, keepdim=True)  # Q²的通道和：[b, N, 1]（用于归一化）
        k2 = torch.pow(k, 2)  # K的二次特征：[b, N, C]
        k2s = torch.sum(k2, dim=2, keepdim=True)  # K²的通道和：[b, N, 1]（用于归一化）

        # 步骤4：注意力权重计算（双分支融合）
        t1 = v  # 分支1：直接使用V（保留原始特征信息，避免注意力过度抑制）
        # 分支2：二次相似度注意力（归一化Q² → 与归一化K²的转置点积 → 与V点积 → 尺度调整）
        k2_norm = torch.nn.functional.normalize((k2 / (k2s + 1e-7)), dim=-2)  # K²归一化（dim=-2：序列维度）
        q2_norm = torch.nn.functional.normalize((q2 / (q2s + 1e-7)), dim=-1)  # Q²归一化（dim=-1：通道维度）
        t2 = q2_norm @ (k2_norm.transpose(-2, -1) @ v) / math.sqrt(N)  # 二次相似度注意力，除以√N缓解尺度问题

        # 步骤5：双分支融合 + 线性精炼
        attn = t1 + t2  # 特征融合：原始V + 二次相似度注意力结果
        attn = self.ln(attn)  # 线性调整：确保输出维度与输入一致，增强表达能力

        return attn

    def is_same_matrix(self, m1, m2):
        """
        辅助函数：判断两个矩阵是否完全相同（本代码未调用，预留用于矩阵一致性校验）
        Args:
            m1, m2 (list): 待比较的矩阵（二维列表）
        Returns:
            bool: 若完全相同则返回True，否则返回False
        """
        rows, cols = len(m1), len(m1[0])
        for i in range(rows):
            for j in range(cols):
                if m1[i][j] != m2[i][j]:
                    return False
        return True

class Convdown(nn.Module):
    """
    下采样侧特征增强模块：结合注意力（ESSA）与卷积，实现特征压缩与表达能力提升
    核心作用：在网络下采样阶段，通过注意力建模全局依赖，配合卷积进行特征精炼，同时保留残差连接稳定训练
    """

    def __init__(self, dim):
        """
        Args:
            dim (int): 输入/输出特征图的通道数（确保模块输入输出维度一致，便于级联）
        """
        super().__init__()
        self.patch_embed = PatchEmbed()  # 图像→序列转换：将2D特征图展平为1D序列，适配注意力输入
        self.patch_unembed = PatchUnEmbed(embed_dim=dim)  # 序列→图像转换：将1D序列恢复为2D特征图
        # 卷积精炼模块：通过1×1+3×3+1×1卷积组合，实现通道调整与局部特征提取
        self.convd = nn.Sequential(
            nn.Conv2d(dim * 2, dim * 2, 1, 1, 0),  # 1×1卷积：调整通道维度，压缩空间信息
            nn.LeakyReLU(negative_slope=0.2, inplace=True),  # 激活函数：LeakyReLU避免梯度消失，inplace节省内存
            nn.Dropout2d(0.2),  # 2D dropout：抑制过拟合，仅对通道维度随机失活
            nn.Conv2d(dim * 2, dim * 2, 3, 1, 1),  # 3×3卷积：捕捉局部空间关联性（ padding=1确保尺寸不变）
            nn.LeakyReLU(negative_slope=0.2, inplace=True),
            nn.Dropout2d(0.2),
            nn.Conv2d(dim * 2, dim, 1, 1, 0)  # 1×1卷积：将通道数从2×dim压缩回dim，匹配输入维度
        )
        self.attn = ESSAttn(dim)  # ESS注意力模块：建模序列维度的全局依赖
        self.norm = nn.LayerNorm(dim)  # 层归一化：对序列维度（HW）进行归一化，稳定注意力训练
        self.drop = nn.Dropout2d(0.2)  # 2D dropout：对恢复后的2D特征图进行失活，增强泛化性

    def forward(self, x):
        """
        Args:
            x (torch.Tensor): 输入特征图，形状为 [batch_size, dim, height, width]
        Returns:
            torch.Tensor: 输出特征图，形状与输入一致 [batch_size, dim, height, width]
        """
        shortcut = x  # 残差连接：保存原始输入，用于后续特征融合
        x_size = (x.shape[2], x.shape[3])  # 记录输入特征图的高宽，用于序列→图像恢复

        # 步骤1：图像→序列转换 + 注意力建模
        x_embed = self.patch_embed(x)  # 形状：[b, dim, h, w] → [b, h*w, dim]（展平为序列）
        x_embed = self.attn(self.norm(x_embed))  # 先归一化再通过注意力，稳定训练并建模全局依赖

        # 步骤2：序列→图像恢复 + 特征融合
        x = self.drop(self.patch_unembed(x_embed, x_size))  # 恢复为2D特征图并失活，形状：[b, dim, h, w]
        x = torch.cat((x, shortcut), dim=1)  # 通道维度拼接：注意力处理后的特征 + 原始输入（形状：[b, 2*dim, h, w]）

        # 步骤3：卷积精炼 + 残差连接
        x = self.convd(x)  # 卷积处理压缩通道至dim，形状：[b, dim, h, w]
        x = x + shortcut  # 残差融合：卷积精炼后的特征 + 原始输入，缓解梯度消失

        return x


class Convup(nn.Module):
    """
    上采样侧特征增强模块：结构与Convdown对称，适配网络上采样阶段的特征处理需求
    核心作用：在网络上采样阶段，通过注意力与卷积协同，恢复高分辨率特征的细节信息，配合残差连接保证训练稳定
    """

    def __init__(self, dim):
        super().__init__()
        self.patch_embed = PatchEmbed()  # 图像→序列转换
        self.patch_unembed = PatchUnEmbed(embed_dim=dim)  # 序列→图像转换
        # 卷积精炼模块：结构与Convdown的convd完全一致，适配上采样侧特征维度
        self.convu = nn.Sequential(
            nn.Conv2d(dim * 2, dim * 2, 1, 1, 0),
            nn.LeakyReLU(negative_slope=0.2, inplace=True),
            nn.Dropout2d(0.2),
            nn.Conv2d(dim * 2, dim * 2, 3, 1, 1),
            nn.LeakyReLU(negative_slope=0.2, inplace=True),
            nn.Dropout2d(0.2),
            nn.Conv2d(dim * 2, dim, 1, 1, 0)
        )
        self.drop = nn.Dropout2d(0.2)
        self.norm = nn.LayerNorm(dim)
        self.attn = ESSAttn(dim)  # ESS注意力模块：建模全局依赖

    def forward(self, x):
        shortcut = x  # 残差连接
        x_size = (x.shape[2], x.shape[3])  # 记录特征图高宽

        # 图像→序列→注意力→序列→图像：流程与Convdown完全一致
        x_embed = self.patch_embed(x)
        x_embed = self.attn(self.norm(x_embed))
        x = self.drop(self.patch_unembed(x_embed, x_size))

        # 通道拼接 + 卷积精炼 + 残差融合
        x = torch.cat((x, shortcut), dim=1)
        x = self.convu(x)
        x = x + shortcut

        return x


class blockup(nn.Module):
    """
    多轮上采样-下采样循环块：通过“上采样→Convup→下采样→Convdown”的循环，反复精炼特征
    核心作用：模拟“迭代优化”过程，逐步提升特征的分辨率与细节表达，适配超分辨率、图像恢复等任务
    """

    def __init__(self, dim, upscale):
        """
        Args:
            dim (int): 特征图通道数
            upscale (int): 上/下采样比例（支持2^n或3，如2、4、3）
        """
        super(blockup, self).__init__()
        self.convup = Convup(dim)  # 上采样侧特征增强
        self.convdown = Convdown(dim)  # 下采样侧特征增强
        self.convupsample = Upsample(scale=upscale, num_feat=dim)  # 上采样模块：提升特征分辨率
        self.convdownsample = Downsample(scale=upscale, num_feat=dim)  # 下采样模块：降低特征分辨率

    def forward(self, x):
        """
        五轮循环流程：上采样→Convup→下采样残差→Convdown→上采样残差→...，逐步精炼特征
        Args:
            x (torch.Tensor): 输入特征图，形状 [b, dim, h, w]
        Returns:
            x5 (torch.Tensor): 输出特征图，形状 [b, dim, h*upscale^3, w*upscale^3]（经3次上采样）
        """
        # 第1轮：上采样→Convup→下采样残差→Convdown
        xup = self.convupsample(x)  # 上采样：[b, dim, h, w] → [b, dim, h*s, w*s]（s=upscale）
        x1 = self.convup(xup)  # Convup增强：[b, dim, h*s, w*s]
        xdown = self.convdownsample(x1) + x  # 下采样残差：下采样x1后与原始x融合，保留低分辨率信息
        x2 = self.convdown(xdown)  # Convdown增强：[b, dim, h, w]

        # 第2轮：上采样残差→Convup→下采样残差→Convdown
        xup = self.convupsample(x2) + x1  # 上采样残差：上采样x2后与x1融合，保留高分辨率细节
        x3 = self.convup(xup)  # [b, dim, h*s, w*s]
        xdown = self.convdownsample(x3) + x2  # 下采样残差：下采样x3后与x2融合
        x4 = self.convdown(xdown)  # [b, dim, h, w]

        # 第3轮：上采样残差→Convup（最终输出高分辨率特征）
        xup = self.convupsample(x4) + x3  # 上采样残差：上采样x4后与x3融合
        x5 = self.convup(xup)  # [b, dim, h*s, w*s]（最终输出高分辨率特征）

        return x5

class ESSA(nn.Module):
    """
    增强型二次相似度注意力网络（Enhanced Squared Similarity Attention Network, ESSA）
    整体结构：输入卷积→多轮上采样-下采样循环块→输出卷积，适配图像超分辨率、恢复等任务
    """
    def __init__(self, inch, dim, upscale, **kwargs):
        """
        Args:
            inch (int): 输入图像的通道数（如RGB图像为3，医学图像可能为1）
            dim (int): 网络内部特征图的通道数
            upscale (int): 最终上采样比例（如2倍超分辨率）
        """
        super(ESSA, self).__init__()
        self.conv_first = nn.Conv2d(inch, dim, 3, 1, 1)  # 输入卷积：将输入通道数转换为网络内部dim
        self.blockup = blockup(dim=dim, upscale=upscale)  # 核心循环块：多轮特征精炼与上采样
        self.conv_last = nn.Conv2d(dim, inch, 3, 1, 1)  # 输出卷积：将内部dim转换回输入通道数

    def forward(self, x):
        """
        Args:
            x (torch.Tensor): 输入图像，形状 [b, inch, h, w]
        Returns:
            torch.Tensor: 输出图像，形状 [b, inch, h*upscale^3, w*upscale^3]（超分辨率结果）
        """
        x = self.conv_first(x)  # 输入通道调整：[b, inch, h, w] → [b, dim, h, w]
        x = self.blockup(x)  # 核心特征精炼：[b, dim, h, w] → [b, dim, h*s^3, w*s^3]
        x = self.conv_last(x)  # 输出通道恢复：[b, dim, h*s^3, w*s^3] → [b, inch, h*s^3, w*s^3]
        return x

if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    upscale = 2
    height = 32
    width = 32
    x = torch.randn(1, 32, height, width).to(device)
    model = ESSA(inch=32, dim=64, upscale=upscale)

    model.to(device)
    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("知乎、CSDN：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)