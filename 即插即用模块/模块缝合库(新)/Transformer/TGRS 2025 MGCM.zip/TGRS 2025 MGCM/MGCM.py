import torch
import torch.nn as nn
import torch.nn.functional as F
from einops import rearrange


class CrossTransAttention(nn.Module):
    """
    交叉转换注意力模块：单方向跨模态注意力交互，实现一模态对另一模态的引导增强
    核心设计：
        - 深度卷积增强：Q/KV经深度卷积提升局部特征表达
        - 归一化注意力：Q/K归一化，提升注意力计算稳定性
        - 可学习温度因子：自适应调整注意力分布锐度
    Args:
        num_heads: 注意力头数（默认4）
        dim: 输入/输出通道数（默认64）
    """
    def __init__(self, num_heads=4, dim=64):
        super().__init__()
        self.num_heads = num_heads
        bias = True
        self.temperature = nn.Parameter(torch.ones(self.num_heads, 1, 1))
        self.kv = nn.Conv2d(dim, dim * 2, kernel_size=1, bias=bias)
        self.q = nn.Conv2d(dim, dim, kernel_size=1, bias=bias)
        self.kv_dwconv = nn.Conv2d(dim * 2, dim * 2, kernel_size=3, stride=1, padding=1, groups=dim * 2, bias=bias)
        self.q_dwconv = nn.Conv2d(dim, dim, kernel_size=3, stride=1, padding=1, groups=dim * 1, bias=bias)
        self.project_out = nn.Conv2d(dim, dim, kernel_size=1, bias=bias)

    def forward(self, feat_x, feat_y):
        b, c, h, w = feat_x.shape

        q = self.q_dwconv(self.q(feat_x))
        kv = self.kv_dwconv(self.kv(feat_y))
        k, v = kv.chunk(2, dim=1)

        # (B, C, H, W) -> (B, head, head_dim, HW)
        q = rearrange(q, 'b (head c) h w -> b head c (h w)', head=self.num_heads)
        k = rearrange(k, 'b (head c) h w -> b head c (h w)', head=self.num_heads)
        v = rearrange(v, 'b (head c) h w -> b head c (h w)', head=self.num_heads)

        q = F.normalize(q, dim=-1)
        k = F.normalize(k, dim=-1)

        attn = (q @ k.transpose(-2, -1)) * self.temperature
        attn = attn.softmax(dim=-1)

        out = (attn @ v)
        out = rearrange(out, 'b head c (h w) -> b (head c) h w', head=self.num_heads, h=h, w=w)
        out = self.project_out(out)
        return out


class MutCrossAttention(nn.Module):
    """Mutual cross attention: HS->MS and MS->HS."""
    """
    双向交叉注意力模块：实现双模态双向引导（X→Y与Y→X）
    核心设计：复用CrossTransAttention，完成双向跨模态交互
    Args:
        num_heads: 注意力头数（默认4）
        dim: 输入/输出通道数（默认64）
    """
    def __init__(self, num_heads=4, dim=64):
        super().__init__()
        self.mca = CrossTransAttention(num_heads=num_heads, dim=dim)

    def forward(self, feat_hs, feat_ms):
        feat_h2m = self.mca(feat_x=feat_hs, feat_y=feat_ms)
        feat_m2h = self.mca(feat_x=feat_ms, feat_y=feat_hs)
        return feat_h2m, feat_m2h


# Modal Complementary Guidance Module
class MCGM(nn.Module):
    """
    模态引导互补模块（Modality-Guided Complementary Module, MGCM）
    功能：多尺度跨模态互补增强，强化双模态特征协同表达
    核心设计：
        - 多尺度池化：3种池化尺度（8/4/2），捕捉不同尺度跨模态依赖
        - 双向注意力：每层尺度均通过MutCrossAttention实现双向引导
        - 残差融合：跨尺度特征上采样后累加融合，保留原始特征信息
        - GELU激活：非线性增强，提升特征表达能力
    Args:
        dim: 输入/输出通道数
        bias: 卷积是否带偏置（默认False）
    """
    def __init__(self, dim, bias):
        super(MCGM, self).__init__()
        self.in_x = nn.Conv2d(dim, dim, 3, 1, 1, bias=bias)
        self.in_y = nn.Conv2d(dim, dim, 3, 1, 1, bias=bias)

        pool_sizes = [8, 4, 2]
        self.pools_x = nn.ModuleList([nn.AvgPool2d(k, k) for k in pool_sizes])
        self.pools_y = nn.ModuleList([nn.AvgPool2d(k, k) for k in pool_sizes])
        self.convs_x = nn.ModuleList([nn.Conv2d(dim, dim, 3, 1, 1, bias=bias) for _ in pool_sizes])
        self.convs_y = nn.ModuleList([nn.Conv2d(dim, dim, 3, 1, 1, bias=bias) for _ in pool_sizes])
        self.attns = nn.ModuleList([MutCrossAttention(num_heads=4, dim=dim) for _ in pool_sizes])

        self.relu = nn.GELU()
        self.sum_x = nn.Conv2d(dim, dim, 3, 1, 1, bias=bias)
        self.sum_y = nn.Conv2d(dim, dim, 3, 1, 1, bias=bias)

    def forward(self, x, y):
        x_size = x.size()
        res_x = self.in_x(x)
        res_y = self.in_y(y)
        for i in range(len(self.pools_x)):
            if i == 0:
                x_, y_ = self.attns[i](self.convs_x[i](self.pools_x[i](x)), self.convs_y[i](self.pools_y[i](y)))
            else:
                x_, y_ = self.attns[i](self.convs_x[i](self.pools_x[i](x) + x_up),
                                       self.convs_y[i](self.pools_y[i](y) + y_up))
            res_x = torch.add(res_x, F.interpolate(x_, x_size[2:], mode='bilinear', align_corners=True))
            res_y = torch.add(res_y, F.interpolate(y_, x_size[2:], mode='bilinear', align_corners=True))
            if i != len(self.pools_x) - 1:
                x_up = F.interpolate(x_, scale_factor=2, mode='bilinear', align_corners=True)
                y_up = F.interpolate(y_, scale_factor=2, mode='bilinear', align_corners=True)
        out_x = x + self.sum_x(self.relu(res_x))
        out_y = y + self.sum_y(self.relu(res_y))

        return out_x, out_y


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    f_m = torch.randn(1, 64, 32, 32).to(device)
    f_h = torch.randn(1, 64, 32, 32).to(device)
    model = MCGM(64, False).to(device)

    out_fm, out_fh = model(f_m, f_h)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN、小红书：十小大")

    print("输入MSI特征维度：", f_m.shape)
    print("输入HSI特征维度：", f_h.shape)
    print("输出MSI特征维度：", out_fm.shape)
    print("输出HSI特征维度：", out_fh.shape)