import torch
import torch.nn as nn
from einops import rearrange


class Topm_CrossAttention_Restormer(nn.Module):  # 对应CAAPM核心实现
    """
    通道自适应注意力扰动模块（Channel-Adapted Attention Perturbation Module, CAAPM）
    功能：通过Top-K稀疏注意力筛选关键通道关联，结合可学习扰动权重，强化有效注意力特征
    核心设计：
        - 稀疏注意力机制：仅保留Top-90%的高相似度注意力，抑制冗余关联，提升计算效率
        - 通道自适应增强：Q/K独立通过深度卷积增强，强化通道特异性特征
        - 可学习扰动权重：通过attn4参数动态调整稀疏注意力的贡献度，适配不同任务
        - 归一化优化：Q/K标准化提升注意力计算稳定性，避免数值偏差
    Args:
        dim: 输入/输出特征通道数
        num_heads: 注意力头数（需整除dim）
        bias: 卷积层是否带偏置
    """

    def __init__(self, dim, num_heads, bias):
        super(Topm_CrossAttention_Restormer, self).__init__()
        self.num_heads = num_heads
        self.temperature = nn.Parameter(torch.ones(num_heads, 1, 1))  # 注意力温度参数（可学习）

        # Q/K/V生成与增强（深度卷积轻量化设计）
        self.kv = nn.Conv2d(dim, dim * 2, kernel_size=1, bias=bias)  # 生成K/V（1×1卷积）
        self.kv_dwconv = nn.Conv2d(dim * 2, dim * 2, kernel_size=3, stride=1, padding=1, groups=dim * 2,
                                   bias=bias)  # K/V深度卷积增强
        self.q = nn.Conv2d(dim, dim, kernel_size=1, bias=bias)  # 生成Q（1×1卷积）
        self.q_dwconv = nn.Conv2d(dim, dim, kernel_size=3, stride=1, padding=1, groups=dim, bias=bias)  # Q深度卷积增强

        self.project_out = nn.Conv2d(dim, dim, kernel_size=1, bias=bias)  # 输出投影层
        self.attn_drop = nn.Dropout(0.)  # 注意力Dropout（当前禁用）
        self.attn4 = torch.nn.Parameter(torch.tensor([0.2]), requires_grad=True)  # 可学习扰动权重

    def forward(self, x_q, x_kv):
        """
        前向传播：Q/K/V生成→特征增强→稀疏注意力→扰动融合→输出
        Args:
            x_q: 查询特征（Query），shape=[b, dim, h, w]
            x_kv: 键值特征（Key/Value），shape=[b, dim, h, w]
        Returns:
            注意力扰动增强特征，shape=[b, dim, h, w]（与输入维度一致）
        """
        b, c, h, w = x_q.shape

        # 1. Q/K/V生成与深度卷积增强
        q = self.q_dwconv(self.q(x_q))  # Q生成→深度卷积增强：[b, dim, h, w]
        kv = self.kv_dwconv(self.kv(x_kv))  # K/V生成→深度卷积增强：[b, 2×dim, h, w]
        k, v = kv.chunk(2, dim=1)  # 拆分K/V：各[b, dim, h, w]

        # 2. 多头维度调整与归一化
        # 维度重组：[b, dim, h, w]→[b, num_heads, c_per_head, h×w]
        q = rearrange(q, 'b (head c) h w -> b head c (h w)', head=self.num_heads)
        k = rearrange(k, 'b (head c) h w -> b head c (h w)', head=self.num_heads)
        v = rearrange(v, 'b (head c) h w -> b head c (h w)', head=self.num_heads)
        # Q/K标准化：提升注意力计算稳定性
        q = torch.nn.functional.normalize(q, dim=-1)
        k = torch.nn.functional.normalize(k, dim=-1)

        # 3. 稀疏注意力计算（Top-K筛选）
        _, _, C, _ = q.shape
        # 初始化注意力掩码（全0）
        mask4 = torch.zeros(b, self.num_heads, C, C, device=x_q.device, requires_grad=False)
        # 计算注意力得分：Q@K^T × 温度参数
        attn = (q @ k.transpose(-2, -1)) * self.temperature
        # 筛选Top-90%高得分注意力索引
        index = torch.topk(attn, k=int(C * 9 / 10), dim=-1, largest=True)[1]
        # 掩码赋值：Top-K位置设为1，其余为0
        mask4.scatter_(-1, index, 1.)
        # 应用掩码：保留Top-K注意力，其余设为-∞（Softmax后趋近于0）
        attn4 = torch.where(mask4 > 0, attn, torch.full_like(attn, float('-inf')))
        attn4 = attn4.softmax(dim=-1)  # 注意力权重归一化
        attn4 = self.attn_drop(attn4)  # Dropout（当前禁用）

        # 4. 注意力加权与扰动融合
        out4 = (attn4 @ v)  # 注意力加权V：[b, num_heads, c_per_head, h×w]
        out = out4 * self.attn4  # 可学习扰动权重调制：增强有效注意力贡献

        # 5. 维度恢复与输出投影
        out = rearrange(out, 'b head c (h w) -> b (head c) h w', head=self.num_heads, h=h, w=w)  # 重组为空间格式
        out = self.project_out(out)  # 1×1卷积投影：[b, dim, h, w]
        return out


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    q = torch.randn(1, 64, 32, 32).to(device)
    kv = torch.randn(1, 64, 32, 32).to(device)
    model = Topm_CrossAttention_Restormer(64, 4, False).to(device)

    y = model(q, kv)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN、小红书：十小大")

    print("输入特征维度：", q.shape)
    print("输出特征维度：", y.shape)