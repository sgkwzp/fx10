import torch
import torch.nn as nn
import torch.nn.functional as F
import math
from model import wavelet   # wavelet的实现见源码，太长无法在公众号完整展示


class convbnrelu(nn.Module):
    def __init__(self, in_channel, out_channel, k=3, s=1, p=1, g=1, d=1, bias=False, bn=True, relu=True):
        super(convbnrelu, self).__init__()
        conv = [nn.Conv2d(in_channel, out_channel, k, s, p, dilation=d, groups=g, bias=bias)]
        if bn:
            conv.append(nn.BatchNorm2d(out_channel))
        if relu:
            conv.append(nn.ReLU(inplace=True))
        self.conv = nn.Sequential(*conv)

    def forward(self, x):
        return self.conv(x)


class DSConv3x3(nn.Module):
    def __init__(self, in_channel, out_channel, stride=1, dilation=1, relu=True):
        super(DSConv3x3, self).__init__()
        self.conv = nn.Sequential(
            convbnrelu(in_channel, in_channel, k=3, s=stride, p=dilation, d=dilation, g=in_channel),
            convbnrelu(in_channel, out_channel, k=1, s=1, p=0, relu=relu),
        )

    def forward(self, x):
        return self.conv(x)


class MSCW(nn.Module):
    def __init__(self, d_model=64):
        super(MSCW, self).__init__()
        self.conv = nn.Sequential(
            nn.Linear(d_model, d_model * 2),
            nn.ReLU(),
        )
        self.local_attn = nn.Sequential(
            nn.Linear(d_model, d_model),
            nn.ReLU(),
            nn.Linear(d_model, d_model),
        )
        self.global_attn = nn.Sequential(
            nn.Linear(d_model, d_model),
            nn.ReLU(),
            nn.Linear(d_model, d_model),
        )
        self.linear = nn.Linear(d_model,d_model)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        pool = torch.mean(x, dim=1, keepdim=True)
        attn = self.local_attn(x) + self.global_attn(pool)
        attn = self.sigmoid(attn)
        return attn


class MultiheadAttention(nn.Module):
    """
    D2T
    功能：通过小波频域分解增强注意力，并结合原型引导注意力，提升特征表达
    核心设计：
        - 路径1：小波频域分解→频域增强→多头自注意力，强化频域细节
        - 路径2：深度可分离卷积→原型生成→多尺度通道加权，强化全局一致性
        - 双路径融合：两条路径特征相加，兼顾频域细节与全局依赖
        - 层归一化：每个路径后插入LayerNorm，提升训练稳定性
    """
    def __init__(self, d_model, h, dropout=0.0):
        "Take in model size and number of heads."
        super(MultiheadAttention, self).__init__()
        assert d_model % h == 0
        # We assume d_v always equals d_k
        self.d_k = d_model // h
        self.h = h

        self.norm1 = nn.LayerNorm(d_model)

        self.pool = wavelet.WavePool(d_model)
        self.self_attn1 = nn.MultiheadAttention(d_model, h, dropout=dropout, batch_first=True)
        self.mscw1 = MSCW(d_model=d_model)

        self.proto_size = 16
        self.conv3x3 = DSConv3x3(d_model, d_model)
        self.Mheads = nn.Linear(d_model, self.proto_size, bias=False)
        self.mscw2 = MSCW(d_model=d_model)
        self.norm2 = nn.LayerNorm(d_model)

    def forward(self, query, key, value, attn_mask=None):

        query = query.transpose(0, 1)
        key = key.transpose(0, 1)
        value = value.transpose(0, 1)
        b, n1, c = value.size()
        hw = int(math.sqrt(n1))

        feat = key.transpose(1, 2).view(b, c, hw, hw)
        #
        LL, HL, LH, HH = self.pool(feat)
        high_fre = HL + LH + HH
        low_fre = LL
        high_fre = high_fre.flatten(2).transpose(1, 2)
        low_fre = low_fre.flatten(2).transpose(1, 2)
        wei = self.mscw1(high_fre+low_fre)

        fre = wei*high_fre+low_fre
        query1 =query
        x1 = self.self_attn1(query=query1, key=fre, value=fre, attn_mask=None)[0]
        x1 = self.norm1(x1+query1)

        # channel attention
        feat = self.conv3x3(feat).flatten(2).transpose(1, 2)
        multi_heads_weights = self.Mheads(feat)
        multi_heads_weights = multi_heads_weights.view((b, n1, self.proto_size))
        multi_heads_weights = F.softmax(multi_heads_weights, dim=1)
        protos = multi_heads_weights.transpose(-1, -2) @ key
        query2 = query

        attn = self.mscw2(protos+query2)
        x2 = query2 * attn + query2
        x2 = self.norm2(x2)

        x = x1+x2

        return x.transpose(0, 1)


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 64*64, 32).to(device)
    model = MultiheadAttention(32, 4)

    model.to(device)
    y = model(x,x,x)

    print("微信公众号：十小大的底层视觉工坊")
    print("知乎、CSDN：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)