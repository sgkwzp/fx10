import torch
import torch.nn as nn

def build_act_layer(act_type):
    """构建激活函数层，支持三种常用激活函数的灵活切换
    Args:
        act_type (str/None): 激活函数类型，可选值为 'GELU'、'ReLU'、'SiLU'，为 None 时返回恒等映射
    Returns:
        nn.Module: 对应的激活函数层
    """
    if act_type is None:
        return nn.Identity()  # 恒等映射，不改变输入特征
    # 确保输入的激活函数类型合法
    assert act_type in ['GELU', 'ReLU', 'SiLU'], f"不支持的激活函数类型: {act_type}"
    # 根据类型返回对应激活函数
    if act_type == 'SiLU':
        return nn.SiLU()  # Sigmoid加权线性单元，常用于Transformer类模型
    elif act_type == 'ReLU':
        return nn.ReLU()  # 整流线性单元，缓解梯度消失，计算高效
    else:  # act_type == 'GELU'
        return nn.GELU()  # Gaussian Error Linear Units，更平滑的激活，适合深度学习模型

class ElementScale(nn.Module):
    """可学习的逐元素缩放模块，对输入特征的每个通道进行独立缩放
    作用：通过可学习参数动态调整通道重要性，增强模型对关键特征的捕捉能力
    Args:
        embed_dims (int): 输入特征的通道数
        init_value (float): 缩放参数的初始值，默认0.0（初始不改变输入）
        requires_grad (bool): 是否允许参数更新，默认True（可学习）
    """
    def __init__(self, embed_dims, init_value=0., requires_grad=True):
        super(ElementScale, self).__init__()
        # 定义可学习缩放参数：形状为 (1, embed_dims, 1, 1)，适配4D特征图（B, C, H, W）
        self.scale = nn.Parameter(
            init_value * torch.ones((1, embed_dims, 1, 1)),
            requires_grad=requires_grad
        )

    def forward(self, x):
        # 逐元素相乘：对每个通道的所有像素应用相同缩放因子
        return x * self.scale


class ChannelAggregationFFN(nn.Module):
    """带通道聚合机制的前馈网络（FFN）实现
    核心逻辑：通过「1×1卷积升维→深度可分离卷积提取局部特征→通道聚合优化特征→1×1卷积降维」的流程，
    在传统FFN基础上增强通道间信息交互，提升特征表达能力
    Args:
        embed_dims (int): 输入/输出特征的通道数（与注意力模块维度保持一致）
        feedforward_channels (int): FFN隐藏层的通道数（通常为embed_dims的2-4倍）
        kernel_size (int): 深度可分离卷积的核大小，默认3（平衡局部特征捕捉与计算量）
        act_type (str): 激活函数类型，默认'GELU'
        ffn_drop (float): FFN中的Dropout概率，默认0.0（无正则化）
    """
    def __init__(self,
                 embed_dims,
                 feedforward_channels,
                 kernel_size=3,
                 act_type='GELU',
                 ffn_drop=0.):
        super(ChannelAggregationFFN, self).__init__()
        self.embed_dims = embed_dims  # 输入/输出通道数
        self.feedforward_channels = feedforward_channels  # 隐藏层通道数

        # 第一步：1×1卷积升维（通道数从embed_dims→feedforward_channels）
        # 作用：扩展特征维度，为后续局部特征提取提供更丰富的表达空间
        self.fc1 = nn.Conv2d(
            in_channels=embed_dims,
            out_channels=self.feedforward_channels,
            kernel_size=1
        )

        # 第二步：深度可分离卷积（DWConv）
        # 作用：在升维后的特征上提取局部空间特征，groups=feedforward_channels实现通道独立卷积
        self.dwconv = nn.Conv2d(
            in_channels=self.feedforward_channels,
            out_channels=self.feedforward_channels,
            kernel_size=kernel_size,
            stride=1,
            padding=kernel_size // 2,  #  SAME padding，保持特征图尺寸不变
            bias=True,
            groups=self.feedforward_channels  # 深度可分离：每个通道单独卷积，降低计算量
        )

        # 激活函数层（根据配置选择）
        self.act = build_act_layer(act_type)

        # 第四步：1×1卷积降维（通道数从feedforward_channels→embed_dims）
        # 作用：将优化后的特征映射回原始维度，适配后续网络结构
        self.fc2 = nn.Conv2d(
            in_channels=feedforward_channels,
            out_channels=embed_dims,
            kernel_size=1
        )

        # Dropout层：防止过拟合，在激活函数后和输出前应用
        self.drop = nn.Dropout(ffn_drop)

        # 通道聚合核心：1×1卷积将多通道特征压缩为单通道（通道全局信息提取）
        self.decompose = nn.Conv2d(
            in_channels=self.feedforward_channels,
            out_channels=1,  # 输出1通道，代表所有通道的全局聚合信息
            kernel_size=1
        )

        # 通道聚合的缩放模块：动态调整聚合信息的权重
        self.sigma = ElementScale(
            self.feedforward_channels,
            init_value=1e-5,  # 初始权重极小，避免初期过度影响特征
            requires_grad=True
        )

        # 通道聚合过程中的激活函数
        self.decompose_act = build_act_layer(act_type)

    def feat_decompose(self, x):
        """通道聚合核心函数：通过「全局信息提取→残差优化」增强通道间关联性
        Args:
            x (torch.Tensor): 输入特征，形状为 (B, C, H, W)，C=feedforward_channels
        Returns:
            torch.Tensor: 通道聚合优化后的特征，形状保持 (B, C, H, W)
        """
        # 步骤1：提取通道全局信息：多通道→单通道（B, C, H, W）→（B, 1, H, W）
        # decompose(x) 输出单通道全局特征，decompose_act 引入非线性
        global_feat = self.decompose_act(self.decompose(x))
        # 步骤2：残差优化：原始特征 - 全局特征（突出通道特异性），再通过sigma动态缩放
        # 最终与原始特征相加，实现「全局信息约束下的通道特异性增强」
        x = x + self.sigma(x - global_feat)
        return x

    def forward(self, x):
        """前馈网络完整前向传播流程
        Args:
            x (torch.Tensor): 输入特征，形状为 (B, embed_dims, H, W)
        Returns:
            torch.Tensor: 输出特征，形状保持 (B, embed_dims, H, W)
        """
        # 第一阶段：升维与局部特征提取
        x = self.fc1(x)          # 1×1卷积升维：(B, C_in, H, W)→(B, C_hid, H, W)
        x = self.dwconv(x)       # 深度可分离卷积：提取局部空间特征
        x = self.act(x)          # 激活函数：引入非线性
        x = self.drop(x)         # Dropout：正则化，防止过拟合

        # 第二阶段：通道聚合与降维输出
        x = self.feat_decompose(x)  # 通道聚合：优化通道间信息交互
        x = self.fc2(x)             # 1×1卷积降维：(B, C_hid, H, W)→(B, C_in, H, W)
        x = self.drop(x)            # Dropout：输出前正则化
        return x

if __name__ == '__main__':

    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    x = torch.randn(1, 64, 64, 64).to(device)
    ca = ChannelAggregationFFN(64, 128).to(device)
    y = ca(x)
    print("微信公众号：十小大的底层视觉工坊")
    print("知乎、CSDN：十小大")
    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)