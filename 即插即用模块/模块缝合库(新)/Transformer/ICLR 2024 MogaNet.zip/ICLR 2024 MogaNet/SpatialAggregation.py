import torch
import torch.nn as nn
import torch.nn.functional as F

def build_act_layer(act_type):
    """构建激活函数层，支持三种常用激活函数的灵活切换
    Args:
        act_type (str/None): 激活函数类型，可选 'GELU'、'ReLU'、'SiLU'，为 None 时返回恒等映射
    Returns:
        nn.Module: 对应的激活函数层
    """
    if act_type is None:
        return nn.Identity()  # 恒等映射，不改变输入特征
    assert act_type in ['GELU', 'ReLU', 'SiLU'], f"不支持的激活函数类型: {act_type}"
    if act_type == 'SiLU':
        return nn.SiLU()  # 适用于Transformer类模型的平滑激活
    elif act_type == 'ReLU':
        return nn.ReLU()  # 计算高效，缓解梯度消失
    else:  # act_type == 'GELU'
        return nn.GELU()  # 高斯误差线性单元，适合深度学习模型的非线性拟合

class ElementScale(nn.Module):
    """可学习的逐元素缩放模块，对输入特征的每个通道进行独立权重调整
    作用：动态平衡不同通道特征的重要性，增强模型对关键信息的捕捉能力
    Args:
        embed_dims (int): 输入特征的通道数
        init_value (float): 缩放参数初始值（默认0.0，初始不干扰特征）
        requires_grad (bool): 是否允许参数更新（默认True，支持端到端学习）
    """
    def __init__(self, embed_dims, init_value=0., requires_grad=True):
        super(ElementScale, self).__init__()
        # 缩放参数形状 (1, embed_dims, 1, 1)，适配4D特征图 (B, C, H, W)
        self.scale = nn.Parameter(
            init_value * torch.ones((1, embed_dims, 1, 1)),
            requires_grad=requires_grad
        )

    def forward(self, x):
        return x * self.scale  # 逐通道应用可学习缩放因子

class MultiOrderDWConv(nn.Module):
    """多阶深度可分离卷积模块：通过通道拆分与不同膨胀率的深度卷积，捕捉多尺度空间特征
    核心逻辑：将输入通道按比例拆分，对不同通道组应用不同核大小、膨胀率的深度卷积，
    实现“小计算量+大感受野”的多尺度特征提取
    Args:
        embed_dims (int): 输入/输出特征通道数
        dw_dilation (list): 三个深度卷积层的膨胀率（默认[1,2,3]，对应不同感受野）
        channel_split (list): 通道拆分比例（默认[1,3,4]，总和需整除embed_dims）
    """
    def __init__(self,
                 embed_dims,
                 dw_dilation=[1, 2, 3],
                 channel_split=[1, 3, 4],
                ):
        super(MultiOrderDWConv, self).__init__()
        # 计算通道拆分的比例系数（归一化到0-1）
        self.split_ratio = [i / sum(channel_split) for i in channel_split]
        # 计算各通道组的具体数量
        self.embed_dims_1 = int(self.split_ratio[1] * embed_dims)
        self.embed_dims_2 = int(self.split_ratio[2] * embed_dims)
        self.embed_dims_0 = embed_dims - self.embed_dims_1 - self.embed_dims_2
        self.embed_dims = embed_dims

        # 输入合法性校验
        assert len(dw_dilation) == len(channel_split) == 3, "膨胀率与通道拆分需各含3个元素"
        assert 1 <= min(dw_dilation) and max(dw_dilation) <= 3, "膨胀率需在1-3之间"
        assert embed_dims % sum(channel_split) == 0, "通道数需能被拆分比例总和整除"

        # 1. 基础深度卷积（5×5核，膨胀率dw_dilation[0]，作用于全部通道）
        self.DW_conv0 = nn.Conv2d(
            in_channels=self.embed_dims,
            out_channels=self.embed_dims,
            kernel_size=5,
            padding=(1 + 4 * dw_dilation[0]) // 2,  # SAME padding，保持特征尺寸
            groups=self.embed_dims,  # 深度卷积：每个通道独立卷积
            stride=1,
            dilation=dw_dilation[0],
        )

        # 2. 第一组通道深度卷积（5×5核，膨胀率dw_dilation[1]，作用于中间通道组）
        self.DW_conv1 = nn.Conv2d(
            in_channels=self.embed_dims_1,
            out_channels=self.embed_dims_1,
            kernel_size=5,
            padding=(1 + 4 * dw_dilation[1]) // 2,
            groups=self.embed_dims_1,
            stride=1,
            dilation=dw_dilation[1],
        )

        # 3. 第二组通道深度卷积（7×7核，膨胀率dw_dilation[2]，作用于最后通道组）
        self.DW_conv2 = nn.Conv2d(
            in_channels=self.embed_dims_2,
            out_channels=self.embed_dims_2,
            kernel_size=7,
            padding=(1 + 6 * dw_dilation[2]) // 2,  # 适配7×7核的SAME padding
            groups=self.embed_dims_2,
            stride=1,
            dilation=dw_dilation[2],
        )

        # 点卷积（1×1）：融合多阶深度卷积特征，恢复通道交互
        self.PW_conv = nn.Conv2d(
            in_channels=embed_dims,
            out_channels=embed_dims,
            kernel_size=1
        )

    def forward(self, x):
        # 步骤1：基础深度卷积提取全局特征
        x_0 = self.DW_conv0(x)
        # 步骤2：通道拆分并应用对应深度卷积
        x_1 = self.DW_conv1(x_0[:, self.embed_dims_0: self.embed_dims_0+self.embed_dims_1, ...])  # 中间通道组
        x_2 = self.DW_conv2(x_0[:, self.embed_dims-self.embed_dims_2:, ...])  # 最后通道组
        # 步骤3：拼接三组特征，通过点卷积融合
        x = torch.cat([x_0[:, :self.embed_dims_0, ...], x_1, x_2], dim=1)  # 第一组直接使用x_0结果
        x = self.PW_conv(x)
        return x


class MultiOrderGatedAggregation(nn.Module):
    """多阶门控聚合空间模块（MOGA）：结合多尺度特征提取与门控机制，增强空间注意力
    核心逻辑：通过“特征分解→多阶卷积→门控融合→残差连接”，实现空间信息的精细化建模，
    同时通过门控机制动态筛选有效特征
    Args:
        embed_dims (int): 输入/输出特征通道数
        attn_dw_dilation (list): 多阶深度卷积的膨胀率（默认[1,2,3]）
        attn_channel_split (list): 通道拆分比例（默认[1,3,4]）
        attn_act_type (str): 激活函数类型（默认'SiLU'，适配门控机制）
        attn_force_fp32 (bool): 是否强制用FP32精度计算门控（默认False，平衡精度与速度）
    """
    def __init__(self,
                 embed_dims,
                 attn_dw_dilation=[1, 2, 3],
                 attn_channel_split=[1, 3, 4],
                 attn_act_type='SiLU',
                 attn_force_fp32=False,
                ):
        super(MultiOrderGatedAggregation, self).__init__()
        self.embed_dims = embed_dims
        self.attn_force_fp32 = attn_force_fp32  # 用于高精度场景（如医疗图像）

        # 1×1卷积：特征分解前的线性变换，调整通道分布
        self.proj_1 = nn.Conv2d(
            in_channels=embed_dims,
            out_channels=embed_dims,
            kernel_size=1
        )

        # 门控分支：生成特征筛选权重（1×1卷积适配通道数）
        self.gate = nn.Conv2d(
            in_channels=embed_dims,
            out_channels=embed_dims,
            kernel_size=1
        )

        # 价值分支：多阶深度卷积提取多尺度空间特征
        self.value = MultiOrderDWConv(
            embed_dims=embed_dims,
            dw_dilation=attn_dw_dilation,
            channel_split=attn_channel_split,
        )

        # 1×1卷积：门控融合后的特征投影，恢复原始维度
        self.proj_2 = nn.Conv2d(
            in_channels=embed_dims,
            out_channels=embed_dims,
            kernel_size=1
        )

        # 激活函数：分别用于价值分支与门控分支
        self.act_value = build_act_layer(attn_act_type)
        self.act_gate = build_act_layer(attn_act_type)

        # 特征分解的缩放模块：平衡全局与局部特征
        self.sigma = ElementScale(
            embed_dims, init_value=1e-5, requires_grad=True
        )

    def feat_decompose(self, x):
        """特征分解函数：通过全局平均池化提取全局特征，结合残差与缩放实现特征优化
        Args:
            x (torch.Tensor): 输入特征 (B, C, H, W)
        Returns:
            torch.Tensor: 分解优化后的特征 (B, C, H, W)
        """
        x = self.proj_1(x)  # 线性变换调整特征分布
        x_d = F.adaptive_avg_pool2d(x, output_size=1)  # 全局平均池化（B,C,H,W）→（B,C,1,1）
        # 残差优化：原始特征 + 缩放后的（原始特征 - 全局特征），突出局部特异性
        x = x + self.sigma(x - x_d)
        x = self.act_value(x)  # 激活函数引入非线性
        return x

    def forward_gating(self, g, v):
        """高精度门控融合：强制FP32计算，避免低精度导致的特征失真
        Args:
            g (torch.Tensor): 门控特征 (B, C, H, W)
            v (torch.Tensor): 价值特征 (B, C, H, W)
        Returns:
            torch.Tensor: 融合后特征 (B, C, H, W)
        """
        with torch.autocast(device_type='cuda', enabled=False):  # 禁用自动混合精度
            g = g.to(torch.float32)
            v = v.to(torch.float32)
            return self.proj_2(self.act_gate(g) * self.act_gate(v))  # 门控加权融合

    def forward(self, x):
        shortcut = x.clone()  # 残差连接：保存原始输入
        # 步骤1：特征分解与优化
        x = self.feat_decompose(x)
        # 步骤2：门控分支与价值分支计算
        g = self.gate(x)  # 生成门控权重特征
        v = self.value(x)  # 提取多尺度价值特征
        # 步骤3：门控融合（根据精度需求选择计算模式）
        if not self.attn_force_fp32:
            x = self.proj_2(self.act_gate(g) * self.act_gate(v))
        else:
            x = self.forward_gating(self.act_gate(g), self.act_gate(v))
        # 步骤4：残差连接，稳定训练
        x = x + shortcut
        return x

if __name__ == '__main__':

    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    x = torch.randn(1, 64, 64, 64).to(device)
    Moga = MultiOrderGatedAggregation(64).to(device)
    y = Moga(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("知乎、CSDN：十小大")
    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)