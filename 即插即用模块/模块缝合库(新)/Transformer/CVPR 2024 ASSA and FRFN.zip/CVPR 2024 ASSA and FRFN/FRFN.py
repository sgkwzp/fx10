import torch
import torch.nn as nn
from einops import rearrange
import math


class FRFN(nn.Module):
    """
    特征精炼前馈网络（FRFN）：Transformer架构中的高效前馈模块
    核心创新：
        1. 部分通道精炼：仅对部分通道进行卷积增强，平衡效率与精度；
        2. 门控融合机制：深度卷积特征与线性层特征逐元素乘法，动态筛选有效信息；
        3. 序列-空间灵活转换：适配Transformer的序列特征与卷积的空间特征；
        4. 轻量化设计：深度可分离卷积+线性层，计算量低，适配高效需求。
    输入：
        x: 序列特征 [B, HW, C]（HW=H×W，序列长度=空间像素总数）
    输出：
        精炼后特征 [B, HW, C]（与输入维度完全一致）
    Args:
        dim: 输入/输出通道数
        hidden_dim: 中间层通道数（门控机制中双分支的通道数）
        act_layer: 激活函数类型（默认GELU）
        drop: Dropout概率（当前未启用）
        use_eca: 是否启用ECA注意力（当前未启用）
    """

    def __init__(self, dim=32, hidden_dim=128, act_layer=nn.GELU, drop=0., use_eca=False):
        super().__init__()
        # 线性层1：升维并拆分双分支（用于门控）
        self.linear1 = nn.Sequential(
            nn.Linear(dim, hidden_dim * 2),  # 输出维度=2×hidden_dim，拆分后各为hidden_dim
            act_layer()  # 激活函数增强非线性
        )
        # 深度可分离卷积：空间特征精炼（groups=hidden_dim，深度卷积）
        self.dwconv = nn.Sequential(
            nn.Conv2d(hidden_dim, hidden_dim, groups=hidden_dim, kernel_size=3, stride=1, padding=1),
            act_layer()  # 激活函数
        )
        # 线性层2：降维恢复输入通道数
        self.linear2 = nn.Sequential(nn.Linear(hidden_dim, dim))

        self.dim = dim
        self.hidden_dim = hidden_dim
        # 通道拆分配置：1/4通道用于卷积精炼，3/4通道直接保留
        self.dim_conv = self.dim // 4
        self.dim_untouched = self.dim - self.dim_conv
        # 部分通道精炼卷积：仅对1/4通道进行3×3卷积增强
        self.partial_conv3 = nn.Conv2d(self.dim_conv, self.dim_conv, 3, 1, 1, bias=False)

    def forward(self, x):
        """
        前向传播流程：部分通道精炼→序列-空间转换→门控融合→降维输出
        """
        bs, hw, c = x.size()  # 解析维度：批次、序列长度（H×W）、通道数
        hh = int(math.sqrt(hw))  # 恢复空间高度（H=W=√HW）

        # 步骤1：部分通道精炼（仅1/4通道卷积增强）
        # 序列→空间：[B, HW, C]→[B, C, H, W]
        x_spatial = rearrange(x, 'b (h w) c -> b c h w', h=hh, w=hh)
        # 通道拆分：1/4通道（conv）用于卷积，3/4通道（untouched）直接保留
        x1, x2 = torch.split(x_spatial, [self.dim_conv, self.dim_untouched], dim=1)
        x1 = self.partial_conv3(x1)  # 1/4通道卷积精炼
        # 通道拼接：恢复原始通道数
        x_refined = torch.cat((x1, x2), 1)
        # 空间→序列：[B, C, H, W]→[B, HW, C]
        x = rearrange(x_refined, 'b c h w -> b (h w) c', h=hh, w=hh)

        # 步骤2：升维与门控分支拆分
        x = self.linear1(x)  # [B, HW, C]→[B, HW, 2×hidden_dim]
        x1_gate, x2_gate = x.chunk(2, dim=-1)  # 拆分双分支：各为[B, HW, hidden_dim]

        # 步骤3：深度卷积精炼与门控融合
        # 序列→空间：x1_gate转为空间格式，适配卷积
        x1_gate_spatial = rearrange(x1_gate, 'b (h w) c -> b c h w', h=hh, w=hh)
        x1_gate_refined = self.dwconv(x1_gate_spatial)  # 深度卷积空间精炼
        # 空间→序列：恢复序列格式
        x1_gate_seq = rearrange(x1_gate_refined, 'b c h w -> b (h w) c', h=hh, w=hh)
        x_gated = x1_gate_seq * x2_gate  # 门控融合：逐元素乘法，筛选有效特征

        # 步骤4：降维输出
        x_out = self.linear2(x_gated)  # [B, HW, hidden_dim]→[B, HW, C]

        return x_out

if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 32*32, 64).to(device)
    model = FRFN(64, 64).to(device)

    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)


'''
# bchw

import torch
import torch.nn as nn
from einops import rearrange
import math

class FRFN(nn.Module):
    """
    特征精炼前馈网络（FRFN）：输入输出均为BCHW格式，适配CNN/Transformer混合架构
    核心创新：
        1. 部分通道精炼：仅对1/4通道卷积增强，平衡效率与精度；
        2. 门控融合机制：动态筛选有效特征，抑制冗余；
        3. 轻量化设计：深度可分离卷积+线性层，计算量低；
        4. 即插即用：输入输出维度一致，可直接嵌入CNN/Transformer架构。
    输入：特征图 [B, C, H, W]
    输出：精炼后特征 [B, C, H, W]（与输入维度完全一致）
    Args:
        dim: 输入/输出通道数
        hidden_dim: 中间层通道数（门控机制双分支通道数）
        act_layer: 激活函数类型（默认GELU）
        drop: Dropout概率（当前未启用）
        use_eca: 是否启用ECA注意力（当前未启用）
    """
    def __init__(self, dim=32, hidden_dim=128, act_layer=nn.GELU, drop=0., use_eca=False):
        super().__init__()
        # 线性层1：升维并拆分双分支（输入BCHW需先展平为序列）
        self.linear1 = nn.Sequential(
            nn.Linear(dim, hidden_dim * 2),  # 输出=2×hidden_dim，拆分双分支
            act_layer()
        )
        # 深度可分离卷积：空间特征精炼
        self.dwconv = nn.Sequential(
            nn.Conv2d(hidden_dim, hidden_dim, groups=hidden_dim, kernel_size=3, stride=1, padding=1),
            act_layer()
        )
        # 线性层2：降维恢复输入通道数
        self.linear2 = nn.Sequential(nn.Linear(hidden_dim, dim))
        
        self.dim = dim
        self.hidden_dim = hidden_dim
        # 通道拆分配置：1/4通道卷积精炼，3/4通道直接保留
        self.dim_conv = self.dim // 4
        self.dim_untouched = self.dim - self.dim_conv
        # 部分通道精炼卷积
        self.partial_conv3 = nn.Conv2d(self.dim_conv, self.dim_conv, 3, 1, 1, bias=False)

    def forward(self, x):
        """
        前向传播流程（输入输出均为BCHW）：
        部分通道精炼 → 展平序列 → 门控融合 → 重塑回BCHW
        """
        B, C, H, W = x.size()  # 解析输入维度：Batch, Channels, Height, Width
        HW = H * W  # 序列长度

        # 步骤1：部分通道精炼（仅1/4通道卷积增强）
        x1, x2 = torch.split(x, [self.dim_conv, self.dim_untouched], dim=1)  # 通道拆分
        x1 = self.partial_conv3(x1)  # 1/4通道卷积精炼
        x_refined = torch.cat((x1, x2), 1)  # 通道拼接恢复维度

        # 步骤2：展平为序列（BCHW → B×HW×C），适配线性层
        x_seq = rearrange(x_refined, 'b c h w -> b (h w) c')  # [B, HW, C]

        # 步骤3：升维与门控分支拆分
        x_seq = self.linear1(x_seq)  # [B, HW, C] → [B, HW, 2×hidden_dim]
        x1_gate, x2_gate = x_seq.chunk(2, dim=-1)  # 拆分双分支：各[B, HW, hidden_dim]

        # 步骤4：深度卷积精炼与门控融合
        # 序列 → BCHW：适配卷积
        x1_gate_bchw = rearrange(x1_gate, 'b (h w) c -> b c h w', h=H, w=W)
        x1_gate_refined = self.dwconv(x1_gate_bchw)  # 深度卷积空间精炼
        # BCHW → 序列：恢复适配门控
        x1_gate_seq = rearrange(x1_gate_refined, 'b c h w -> b (h w) c')
        x_gated = x1_gate_seq * x2_gate  # 门控融合：动态筛选

        # 步骤5：降维与重塑回BCHW
        x_out_seq = self.linear2(x_gated)  # [B, HW, hidden_dim] → [B, HW, C]
        x_out = rearrange(x_out_seq, 'b (h w) c -> b c h w', h=H, w=W)  # [B, C, H, W]

        return x_out

if __name__ == "__main__":
    # 设备配置：优先GPU（cuda:0），无GPU则用CPU
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    # 模拟输入：BCHW格式（批次1，通道64，高32，宽32）
    x = torch.randn(1, 64, 32, 32).to(device)
    
    # 初始化FRFN模块：输入通道64，中间通道64
    model = FRFN(64, 64).to(device)
    
    # 前向传播
    y = model(x)
    
    # 打印信息：验证输入输出维度一致性（均为BCHW）
    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN：十小大")
    print("输入特征维度（BCHW）：", x.shape)  # 输出：torch.Size([1, 64, 32, 32])
    print("输出特征维度（BCHW）：", y.shape)  # 输出：torch.Size([1, 64, 32, 32])
'''