import torch
import torch.nn as nn
from timm.models.layers import trunc_normal_
from einops import repeat


class LinearProjection(nn.Module):
    """
    线性投影模块：生成Q（查询）、K（键）、V（值），支持跨特征KV输入
    核心作用：统一处理QKV生成，支持KV来自外部特征（attn_kv）或自身（x）
    输入：
        x: 主特征 [B, N, C]（生成Q）
        attn_kv: 可选外部特征 [B, N_kv, C]（生成K/V，默认=None时用x生成）
    输出：
        q: 查询 [B, num_heads, N, C//num_heads]
        k: 键 [B, num_heads, N_kv, C//num_heads]
        v: 值 [B, num_heads, N_kv, C//num_heads]
    """
    def __init__(self, dim, heads = 8, dim_head = 64, dropout = 0., bias=True):
        super().__init__()
        inner_dim = dim_head *  heads
        self.heads = heads
        self.to_q = nn.Linear(dim, inner_dim, bias = bias)
        self.to_kv = nn.Linear(dim, inner_dim * 2, bias = bias)
        self.dim = dim
        self.inner_dim = inner_dim

    def forward(self, x, attn_kv=None):
        B_, N, C = x.shape
        if attn_kv is not None:
            attn_kv = attn_kv.unsqueeze(0).repeat(B_,1,1)
        else:
            attn_kv = x
        N_kv = attn_kv.size(1)
        q = self.to_q(x).reshape(B_, N, 1, self.heads, C // self.heads).permute(2, 0, 3, 1, 4)
        kv = self.to_kv(attn_kv).reshape(B_, N_kv, 2, self.heads, C // self.heads).permute(2, 0, 3, 1, 4)
        q = q[0]
        k, v = kv[0], kv[1]
        return q,k,v


class WindowAttention_sparse(nn.Module):
    """
    自适应稀疏自注意力模块（ASSA）：核心模块，融合稀疏与密集注意力权重
    核心创新：
        1. 双权重融合：softmax密集权重+ReLU稀疏权重，自适应平衡全局关联与局部稀疏；
        2. 可学习权重系数：动态调整双权重贡献比例；
        3. 窗口相对位置偏置：提升窗口内位置敏感性；
        4. 灵活KV输入：支持KV来自外部特征，适配跨特征注意力。
    输入：
        x: 输入特征 [B, N, C]（N=win_size[0]×win_size[1]）
        attn_kv: 可选外部KV特征 [B, N_kv, C]（默认=None）
        mask: 窗口注意力掩码 [nW, N, N]（nW=窗口数，可选）
    输出：
        增强后特征 [B, N, C]（与输入维度一致）
    Args:
        dim: 输入通道数
        win_size: 窗口尺寸 (Wh, Ww)
        num_heads: 注意力头数
        token_projection: 投影方式（仅支持'linear'）
        qkv_bias: QKV投影是否加偏置
        qk_scale: 注意力缩放因子（默认=head_dim^-0.5）
        attn_drop: 注意力Dropout概率
        proj_drop: 输出投影Dropout概率
    """

    def __init__(self, dim, win_size, num_heads, token_projection='linear', qkv_bias=True, qk_scale=None, attn_drop=0.,
                 proj_drop=0.):
        super().__init__()
        self.dim = dim
        self.win_size = win_size  # 窗口尺寸 (Wh, Ww)
        self.num_heads = num_heads
        head_dim = dim // num_heads  # 单头维度
        self.scale = qk_scale or head_dim ** -0.5  # 注意力缩放因子

        # 相对位置偏置表：覆盖窗口内所有像素对的相对位置
        self.relative_position_bias_table = nn.Parameter(
            torch.zeros((2 * win_size[0] - 1) * (2 * win_size[1] - 1), num_heads)
        )
        # 生成窗口内像素对的相对位置索引
        coords_h = torch.arange(self.win_size[0])
        coords_w = torch.arange(self.win_size[1])
        coords = torch.stack(torch.meshgrid([coords_h, coords_w]))  # [2, Wh, Ww]
        coords_flatten = torch.flatten(coords, 1)  # [2, Wh×Ww]
        relative_coords = coords_flatten[:, :, None] - coords_flatten[:, None, :]  # [2, Wh×Ww, Wh×Ww]
        relative_coords = relative_coords.permute(1, 2, 0).contiguous()  # [Wh×Ww, Wh×Ww, 2]
        # 偏移坐标至非负范围
        relative_coords[:, :, 0] += self.win_size[0] - 1
        relative_coords[:, :, 1] += self.win_size[1] - 1
        relative_coords[:, :, 0] *= 2 * self.win_size[1] - 1
        relative_position_index = relative_coords.sum(-1)  # [Wh×Ww, Wh×Ww]
        self.register_buffer("relative_position_index", relative_position_index)

        # 初始化相对位置偏置
        trunc_normal_(self.relative_position_bias_table, std=.02)

        # QKV生成模块
        if token_projection == 'linear':
            self.qkv = LinearProjection(dim, num_heads, dim // num_heads, bias=qkv_bias)
        else:
            raise Exception("Projection error! Only 'linear' is supported.")
        self.token_projection = token_projection

        # 正则化层
        self.attn_drop = nn.Dropout(attn_drop)
        self.proj = nn.Linear(dim, dim)  # 输出投影
        self.proj_drop = nn.Dropout(proj_drop)

        # 激活函数与自适应权重
        self.softmax = nn.Softmax(dim=-1)  # 密集权重归一化
        self.relu = nn.ReLU()  # 稀疏权重激活
        self.w = nn.Parameter(torch.ones(2))  # 双权重融合系数（可学习）

    def forward(self, x, attn_kv=None, mask=None):
        """
        前向传播流程：QKV生成→注意力计算→相对位置偏置→双权重融合→投影输出
        """
        B_, N, C = x.shape  # B_=批次，N=窗口内像素数，C=通道数

        # 步骤1：生成QKV
        q, k, v = self.qkv(x, attn_kv)  # q:[B, num_heads, N, head_dim]；k/v:[B, num_heads, N_kv, head_dim]
        q = q * self.scale  # 注意力缩放

        # 步骤2：计算注意力分数
        attn = (q @ k.transpose(-2, -1))  # [B, num_heads, N, N_kv]

        # 步骤3：添加相对位置偏置（适配KV维度）
        relative_position_bias = self.relative_position_bias_table[self.relative_position_index.view(-1)].view(
            self.win_size[0] * self.win_size[1], self.win_size[0] * self.win_size[1], -1
        )  # [Wh×Ww, Wh×Ww, num_heads]
        relative_position_bias = relative_position_bias.permute(2, 0, 1).contiguous()  # [num_heads, Wh×Ww, Wh×Ww]
        ratio = attn.size(-1) // relative_position_bias.size(-1)  # KV维度与偏置维度的比例
        relative_position_bias = repeat(relative_position_bias, 'nH l c -> nH l (c d)', d=ratio)  # 扩展偏置适配KV维度
        attn = attn + relative_position_bias.unsqueeze(0)  # 广播至批次维度

        # 步骤4：添加掩码（可选）与生成双权重
        if mask is not None:
            nW = mask.shape[0]  # 窗口数
            mask = repeat(mask, 'nW m n -> nW m (n d)', d=ratio)  # 扩展掩码适配KV维度
            attn = attn.view(B_ // nW, nW, self.num_heads, N, N * ratio) + mask.unsqueeze(1).unsqueeze(0)
            attn = attn.view(-1, self.num_heads, N, N * ratio)
            attn0 = self.softmax(attn)  # 密集注意力权重（softmax归一化）
            attn1 = self.relu(attn) ** 2  # 稀疏注意力权重（ReLU+平方增强稀疏性）
        else:
            attn0 = self.softmax(attn)
            attn1 = self.relu(attn) ** 2

        # 步骤5：自适应融合双权重（softmax归一化系数）
        w1 = torch.exp(self.w[0]) / torch.sum(torch.exp(self.w))  # 密集权重系数
        w2 = torch.exp(self.w[1]) / torch.sum(torch.exp(self.w))  # 稀疏权重系数
        attn = attn0 * w1 + attn1 * w2  # 融合注意力权重

        # 步骤6：注意力加权与输出投影
        attn = self.attn_drop(attn)
        x = (attn @ v).transpose(1, 2).reshape(B_, N, C)  # 多头融合
        x = self.proj(x)  # 线性投影
        x = self.proj_drop(x)

        return x

    def extra_repr(self) -> str:
        return f'dim={self.dim}, win_size={self.win_size}, num_heads={self.num_heads}'

if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 8*8, 64).to(device)
    model = WindowAttention_sparse(64, (8, 8), 4).to(device)

    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)