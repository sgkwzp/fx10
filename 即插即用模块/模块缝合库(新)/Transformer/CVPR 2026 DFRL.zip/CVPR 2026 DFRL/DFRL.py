import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from timm.layers import DropPath, to_2tuple, trunc_normal_
from einops import rearrange
from basicsr.utils.registry import ARCH_REGISTRY
from torch.nn.attention import SDPBackend, sdpa_kernel


class HedgehogFeatureMap(nn.Module):

    r"""
    Hedgehog feature map as introduced in
    `The Hedgehog & the Porcupine: Expressive Linear Attentions with Softmax Mimicry <https://arxiv.org/abs/2402.04347>`_
    """

    def __init__(
        self,
        head_dim: int
    ):
        super().__init__()
        # Trainable map
        self.layer = nn.Linear(head_dim, head_dim)
        self.init_weights_()

    def init_weights_(self):
        """Initialize trainable map as identity"""
        with torch.no_grad():
            identity = torch.eye(*self.layer.weight.shape[-2:], dtype=torch.float)
            self.layer.weight.copy_(identity.to(self.layer.weight))
        nn.init.zeros_(self.layer.bias)

    def forward(self, x: torch.Tensor):
        x = self.layer(x)  # shape b, h, l, d
        return torch.cat([2*x, -2*x], dim=-1).softmax(-1)


class RotaryEmbedding(nn.Module):
    def __init__(
        self,
        *,
        d_model: int,
        n_heads: int,
        rope_theta: float           = 10_000.0,
        max_sequence_length: int    = 8192,
        fope: bool                  = False,     # filter out too-high freqs if True
    ):
        super().__init__()
        # store hyper-params exactly once
        self.d_model             = d_model
        self.n_heads             = n_heads
        self.rope_theta          = rope_theta
        self.max_sequence_length = max_sequence_length
        self.fope                = fope

        # per-head dimension
        self.dim       = d_model // n_heads
        self.inv_freq  = self.get_inv_freq(self.dim)

    # --------------------------------------------------------------------- helpers
    def get_inv_freq(self, dim: int) -> torch.Tensor:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        inv_freq = 1.0 / (
            self.rope_theta
            ** (torch.arange(0, dim, 2, device=device, dtype=torch.float) / dim)
        )
        if self.fope:                                   # optional FOPE trimming
            inv_freq[inv_freq < 2 * torch.pi / self.max_sequence_length] = 0
            inv_freq = inv_freq[inv_freq != 0.0]
        return inv_freq[None, :] # shape: (1, dim//2)

    # --------------------------------------------------------------------- rotary core
    def get_rotary_embedding(self, seq_len: int):
        device = self.inv_freq.device
        with torch.autocast(device.type, enabled=False):
            seq   = torch.arange(seq_len, device=device, dtype=torch.float)
            freqs = torch.einsum("t,hd -> htd", seq, self.inv_freq)     # [L, D/2]

            if self.fope:
                positions = freqs.unsqueeze(0)                        # [1,L,D/2]
            else:                                                     # duplicate
                positions = torch.cat((freqs, freqs), dim=-1).unsqueeze(0)
            return positions.sin(), positions.cos()

    @staticmethod
    def rotate_half(x):
        B, nh, T, hs = x.size()
        x = x.view(B, nh, T, 2, hs // 2)
        x1, x2 = x.unbind(dim=-2)
        return torch.cat((-x2, x1), dim=-1)

    def apply_rotary_pos_emb(self, pos_sin, pos_cos, t):
        return ((t * pos_cos) - (self.rotate_half(t) * pos_sin)).to(t.dtype)

    # --------------------------------------------------------------------- forward
    def forward(self, x, all_len):
        """
        Parameters
        ----------
        x       : [B, n_heads, T, head_dim]
        all_len : full sequence length in the current context/window
        """
        with torch.autocast(x.device.type, enabled=False):
            x_len = x.shape[-2]
            pos_sin, pos_cos = self.get_rotary_embedding(all_len)
            pos_sin, pos_cos = pos_sin.type_as(x), pos_cos.type_as(x)

            x = self.apply_rotary_pos_embed(
                pos_sin[..., all_len - x_len : all_len, :],
                pos_cos[..., all_len - x_len : all_len, :],
                x,
            )
            return x


# ---------------------------------------------------------------------------
# Fourier Embedding (hyper-parameter version of the sample) -----------------
# ---------------------------------------------------------------------------
class FourierEmbedding(RotaryEmbedding):
    """
    RotaryEmbedding + learnable Fourier mixing.

    Setting `learnable=True` makes the sin/cos coefficient tensors trainable.
    """

    def __init__(
            self,
            *,
            d_model: int,
            n_heads: int,
            # rotary hyper-params
            rope_theta: float = 10_000,
            max_sequence_length: int = 4096,
            fope: bool = True,
            # fourier-specific
            rope_fourier_init_norm_gain: float = 0.3,
            learnable: bool = True,
    ):
        super().__init__(
            d_model=d_model,
            n_heads=n_heads,
            rope_theta=rope_theta,
            max_sequence_length=max_sequence_length,
            fope=fope,
        )

        self.head_dim = d_model // n_heads
        self.input_dim = self.inv_freq.size(-1)
        self.output_dim = self.input_dim if self.input_dim <= self.head_dim // 4 else self.head_dim // 4

        # sin & cos coefficient tensors ( n_heads × in_dim × out_dim )
        self.sin_coef = nn.Parameter(
            torch.randn(n_heads, self.input_dim, self.output_dim),
            requires_grad=learnable,
        )
        self.cos_coef = nn.Parameter(
            torch.randn(n_heads, self.input_dim, self.output_dim),
            requires_grad=learnable,
        )

        # Xavier init with given gain
        torch.nn.init.xavier_normal_(self.sin_coef, gain=rope_fourier_init_norm_gain)
        torch.nn.init.xavier_normal_(self.cos_coef, gain=rope_fourier_init_norm_gain)

        with torch.no_grad():
            # add identity so first iteration reproduces classic RoPE
            if self.input_dim == self.output_dim:
                self.sin_coef += torch.eye(self.input_dim, device=self.sin_coef.device)
                self.cos_coef += torch.eye(self.input_dim, device=self.cos_coef.device)
            else:
                self.sin_coef += self.get_step_eye(self.sin_coef)
                self.cos_coef += self.get_step_eye(self.cos_coef)

    def get_step_eye(self, _param):
        _param = torch.zeros_like(_param)

        step = math.ceil(self.input_dim / self.output_dim)
        for i in range(self.output_dim):
            if i * step < self.input_dim:
                _param[..., i * step, i] = 1.0

        return _param

    # --------------------------------------------------------------------- override mix
    def apply_rotary_pos_embed(self, pos_sin, pos_cos, t):
        # Fourier mix (ℓ1-normalized along in_dim, exactly like the sample)
        fourier_sin = torch.einsum(
            "bhtD, hDd -> bhtd",
            pos_sin,
            self.sin_coef / self.sin_coef.sum(dim=-2, keepdim=True),
        )
        fourier_cos = torch.einsum(
            "bhtD, hDd -> bhtd",
            pos_cos,
            self.cos_coef / self.cos_coef.sum(dim=-2, keepdim=True),
        )

        # pad back to head_dim // 2 if we reduced dimensionality
        fourier_sin = F.pad(
            fourier_sin,
            pad=(0, self.dim // 2 - fourier_sin.size(-1)),
            mode="constant",
            value=1,
        )
        fourier_cos = F.pad(
            fourier_cos,
            pad=(0, self.dim // 2 - fourier_cos.size(-1)),
            mode="constant",
            value=1,
        )

        # duplicate to full D and call base apply
        fourier_sin = torch.cat((fourier_sin, fourier_sin), dim=-1)
        fourier_cos = torch.cat((fourier_cos, fourier_cos), dim=-1)
        return super().apply_rotary_pos_emb(fourier_sin, fourier_cos, t)


class DFRL(nn.Module):
    r""" Linear Attention with LePE and RoPE.

    Args:
        dim (int): Number of input channels.
        num_heads (int): Number of attention heads.
        qkv_bias (bool, optional):  If True, add a learnable bias to query, key, value. Default: True
    """

    def __init__(self, dim, input_resolution, num_heads, attn_drop=0., qkv_bias=True, proj_drop=0., **kwargs):
        super().__init__()
        self.dim = dim
        self.input_resolution = input_resolution
        self.num_heads = num_heads
        self.attn_drop = nn.Dropout(attn_drop)
        self.eps = 1e-6
        self.head_dim = dim // 2 // num_heads
        self.after_taylor_dim = (self.head_dim + 1) * (self.head_dim + 2) // 2
        self.after_taylor_dim = self.after_taylor_dim if self.after_taylor_dim % 2 == 0 else self.after_taylor_dim + 2

        self.v = nn.Linear(dim, dim // 2)

        # self.elu = nn.ELU()
        self.ln_q = HedgehogFeatureMap(self.head_dim)
        self.ln_k = HedgehogFeatureMap(self.head_dim)

        # self.ln_q = TaylorFeatureMap(self.head_dim)
        # self.ln_k = TaylorFeatureMap(self.head_dim)

        self.scale = self.head_dim ** (-0.5)
        # self.dwc = nn.Conv2d(in_channels=self.head_dim // 2, out_channels=self.head_dim // 2, kernel_size=3,
        #                     groups=self.head_dim // 2, padding=3 // 2)
        self.lepe = self.dwc = nn.Conv2d(
            in_channels=dim // 2,
            out_channels=dim // 2,
            kernel_size=3, padding=1,
            groups=dim // 2
        )

        self.proj = nn.Linear(dim, dim)

        self.temperature = nn.Parameter(torch.ones(dim // 2, 1))
        self.proj_drop = nn.Dropout(proj_drop)

        self.pos_emb = FourierEmbedding(d_model=self.head_dim * 2 * self.num_heads,
                                        n_heads=self.num_heads,
                                        learnable=True,  # make coefficients trainable
                                        rope_fourier_init_norm_gain=0.5)

    def spatial_brand(self, q, k, v, x_size):
        b, n, c = v.shape
        h, w = x_size

        shortcut = v.clone()

        num_heads = self.num_heads
        head_dim = c // num_heads
        q, k, v = [t.view(b, n, num_heads, head_dim).transpose(1, 2) for t in (q, k, v)]
        oq, ok = q, k

        q = self.ln_q(q)
        k = self.ln_k(k)

        q_fope = self.pos_emb(q, n)
        k_fope = self.pos_emb(k, n)

        # Test local monotonicity
        # self.test_local_monotonicity(oq, ok)

        z = 1.0 / (q @ k.mean(dim=-2, keepdim=True).transpose(-2, -1) + self.eps)
        kv = (k_fope.transpose(-2, -1) * (n ** -0.5)) @ (v * (n ** -0.5))
        x = q_fope @ kv * z

        x = x.transpose(1, 2).reshape(b, n, c)
        v_img = v.transpose(-1, -2).reshape(b, head_dim * num_heads, h, w)
        gate = self.lepe(v_img).reshape(b, c, n).permute(0, 2, 1) + x
        return gate

    def channel_brand(self, _q, _k, _v):
        B, L, C = _q.shape

        q, k, v = map(lambda t: rearrange(t, 'b l c -> b c l'), (_q, _k, _v))

        q = F.normalize(q, dim=-1)
        k = F.normalize(k, dim=-1)

        attn = (q @ k.transpose(-2, -1)) * self.temperature
        attn = attn.softmax(dim=-1)
        out = (attn @ v)

        return out.transpose(-1, -2)

    def forward(self, x, share_qk, x_size):
        """
        Args:
            x: input features with shape of (B, N, C)
        """
        b, n, c = x.shape
        h, w = x_size
        q, k = share_qk

        v = self.v(x)

        x_spatial_1 = self.spatial_brand(q, k, v, x_size)

        x_channel_1 = self.channel_brand(q, k, v)

        out = torch.cat([x_spatial_1, x_channel_1], dim=-1)

        out = self.proj_drop(self.proj(out))

        return out



if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    dim = 64               # 输入通道数
    input_resolution = (32, 32)  # 输入空间分辨率 (H, W)
    num_heads = 8          # 注意力头数（64//2 /8 =4，head_dim=4，满足整除）
    batch_size = 1         # 批次大小
    H, W = input_resolution
    N = H * W              # 序列长度（空间维度展平后）

    model = DFRL(
        dim=dim,
        input_resolution=input_resolution,
        num_heads=num_heads,
        attn_drop=0.,
        proj_drop=0.
    ).to(device)

    # x: (B, N, C) → (1, 32*32, 64)
    x = torch.randn(batch_size, N, dim).to(device)
    # share_qk: (q, k) → 每个的形状是 (B, N, dim//2) = (1, 1024, 32)
    q = torch.randn(batch_size, N, dim//2).to(device)
    k = torch.randn(batch_size, N, dim//2).to(device)
    share_qk = (q, k)
    # x_size: 空间分辨率 (H, W)
    x_size = input_resolution

    with torch.no_grad():  # 推理阶段禁用梯度，加速计算
        y = model(x, share_qk, x_size)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("小红书：十小大，主页获取往期全部即插即用代码，200+大合集")

    print("输入特征维度 (x):", x.shape)       # 预期: (1, 1024, 64)
    print("Q/K 特征维度 (q/k):", q.shape)    # 预期: (1, 1024, 32)
    print("输出特征维度 (y):", y.shape)       # 预期: (1, 1024, 64)