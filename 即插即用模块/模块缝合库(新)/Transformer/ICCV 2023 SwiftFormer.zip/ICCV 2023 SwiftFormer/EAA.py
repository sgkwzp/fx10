import torch
import torch.nn as nn
import einops

class EfficientAdditiveAttnetion(nn.Module):
    """
    高效加性注意力模块（适配SwiftFormer）
    核心功能：以线性复杂度替代传统自注意力的二次矩阵乘法，降低计算成本
    输入维度：[B, N, D]，其中B=批次大小，N=令牌数量（如图像补丁数），D=输入特征维度
    输出维度：[B, N, D']，其中D'=token_dim（最终输出特征维度）
    论文对应：ICCV 2023 SwiftFormer 中的核心注意力模块
    """

    def __init__(self, in_dims=512, token_dim=256, num_heads=2):
        super().__init__()
        # 1. 线性投影层：将输入特征分别映射为查询（Q）和键（K）
        # 输出维度：[B, N, token_dim * num_heads]（多头部特征拼接）
        self.to_query = nn.Linear(in_dims, token_dim * num_heads)  # Q投影：D→token_dim×num_heads
        self.to_key = nn.Linear(in_dims, token_dim * num_heads)  # K投影：D→token_dim×num_heads

        # 2. 可学习权重向量：用于计算查询的全局注意力权重，维度与Q/K输出一致
        self.w_g = nn.Parameter(torch.randn(token_dim * num_heads, 1))  # [token_dim×num_heads, 1]

        # 3. 缩放因子：缓解梯度消失，与传统自注意力的√d缩放逻辑一致（d=token_dim）
        self.scale_factor = token_dim ** -0.5

        # 4. 线性变换层：用于全局上下文与键的交互增强
        self.Proj = nn.Linear(token_dim * num_heads, token_dim * num_heads)  # 维度保持不变

        # 5. 最终投影层：将多头部特征压缩为目标维度token_dim
        self.final = nn.Linear(token_dim * num_heads, token_dim)

    def forward(self, x):
        # 步骤1：生成查询（Q）和键（K）
        query = self.to_query(x)  # [B, N, token_dim×num_heads]
        key = self.to_key(x)  # [B, N, token_dim×num_heads]

        # 步骤2：特征归一化（L2归一化）：增强数值稳定性，避免大值主导注意力
        query = torch.nn.functional.normalize(query, dim=-1)  # 对最后一维（特征维度）归一化
        key = torch.nn.functional.normalize(key, dim=-1)  # 同query

        # 步骤3：计算查询注意力权重（全局重要性评分）
        # Q与w_g矩阵乘法：[B,N,D] × [D,1] → [B,N,1]，D=token_dim×num_heads
        query_weight = query @ self.w_g
        # 缩放权重：缓解权重数值过大/过小问题
        A = query_weight * self.scale_factor
        # 对令牌维度（N）归一化：确保注意力权重总和为1，符合概率分布逻辑
        A = torch.nn.functional.normalize(A, dim=1)  # [B,N,1]

        # 步骤4：生成全局查询向量（G）：按注意力权重对Q加权求和
        # A*query：[B,N,1] × [B,N,D] → [B,N,D]（广播乘法）
        # 沿令牌维度求和：[B,N,D] → [B,D]，得到全局上下文
        G = torch.sum(A * query, dim=1)
        # 广播全局向量至与K同维度：[B,D] → [B,N,D]（每个令牌共享同一全局上下文）
        G = einops.repeat(G, "b d -> b repeat d", repeat=key.shape[1])

        # 步骤5：全局上下文与键交互 + 残差连接（与Q相加）
        # G*key：全局上下文与局部键特征逐元素乘法（线性复杂度交互）
        # Proj：增强交互特征的表达能力
        # +query：残差连接，避免梯度消失，保留原始查询信息
        out = self.Proj(G * key) + query  # [B,N,D]

        # 步骤6：最终特征压缩：多头部特征→目标维度token_dim
        out = self.final(out)  # [B,N,token_dim]

        return out

if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    x = torch.randn(1, 32 * 32, 64).to(device)
    model = EfficientAdditiveAttnetion(64, 64, 4)
    model.to(device)
    y = model(x)
    print("微信公众号：十小大的底层视觉工坊")
    print("知乎、CSDN：十小大")
    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)