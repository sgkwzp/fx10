import torch
import torch.nn as nn
import torch.nn.functional as F
import math

class DDI(nn.Module):
    """
    双依赖交互模块（Dual Dependency Interaction, DDI）
    核心设计：通过“分块时序处理+历史依赖聚合+残差融合+可选前馈增强”，
    建模时序数据的局部与全局依赖，适配序列预测任务（如时间序列回归、信号分析）
    """

    def __init__(self, input_shape, dropout=0.2, patch=12, alpha=0.0, layernorm=True):
        """
        Args:
            input_shape (tuple): 输入时序数据的形状，格式为 (seq_len, feature_num)
                                 （seq_len=序列长度，feature_num=每个时序步的特征数量）
            dropout (float): Dropout概率（默认0.2，用于抑制过拟合）
            patch (int): 时序分块大小（默认12，将长序列拆分为多个patch处理，降低复杂度）
            alpha (float): 前馈增强分支的权重（默认0.0，α>0时启用前馈网络，增强非线性表达）
            layernorm (bool): 是否启用输入全局归一化（默认True，使用BatchNorm1d稳定输入分布）
        """
        super(DDI, self).__init__()
        self.input_shape = input_shape  # 保存输入形状（seq_len, feature_num）
        self.alpha = alpha  # 保存前馈分支权重
        self.patch = patch  # 保存时序分块大小
        self.layernorm = layernorm  # 保存是否启用全局归一化

        # 可选前馈网络块（FFN）：α>0时启用，用于增强特征非线性表达
        if alpha > 0.0:
            # 计算前馈网络中间层维度：取大于等于feature_num的最小2的幂（如feature_num=10→16）
            # 目的是通过2的幂维度提升计算效率（GPU对2的幂维度优化更好）
            self.ff_dim = 2 ** math.ceil(math.log2(self.input_shape[-1]))
            self.fc_block = nn.Sequential(
                nn.Linear(self.input_shape[-1], self.ff_dim),  # 特征扩展：feature_num→ff_dim
                nn.GELU(),  # 激活函数：GELU相比ReLU更平滑，缓解梯度消失
                nn.Dropout(dropout),  # 随机失活：抑制过拟合
                nn.Linear(self.ff_dim, self.input_shape[-1]),  # 特征压缩：ff_dim→feature_num
                nn.GELU(),  # 二次激活：进一步增强非线性
                nn.Dropout(dropout),  # 二次失活：提升泛化性
            )

        self.n_history = 1  # 历史依赖窗口数（固定为1，即仅使用前1个patch的历史信息）
        # 全局归一化层：对输入序列的所有元素（feature_num×seq_len）进行批归一化（若启用）
        if self.layernorm:
            self.norm = nn.BatchNorm1d(self.input_shape[0] * self.input_shape[-1])

        # 历史依赖聚合的归一化层：对历史窗口（n_history×patch×feature_num）进行批归一化
        self.norm1 = nn.BatchNorm1d(self.n_history * patch * self.input_shape[-1])
        # 前馈分支的归一化层：对当前patch特征（patch×feature_num）进行批归一化（若启用前馈）
        if self.alpha > 0.0:
            self.norm2 = nn.BatchNorm1d(self.patch * self.input_shape[-1])

        # 历史依赖聚合层：将n_history×patch维度的历史信息聚合为patch维度（时序维度压缩）
        self.agg = nn.Linear(self.n_history * self.patch, self.patch)
        self.dropout_t = nn.Dropout(dropout)  # 时序维度的Dropout层

    def forward(self, x):
        """
        DDI前向传播流程：全局归一化→初始化输出→分块时序处理（历史依赖聚合+残差融合+前馈增强）→输出完整序列
        Args:
            x (torch.Tensor): 输入时序数据，形状为 [batch_size, feature_num, seq_len]
                             （代码示例中为[16, 10, 48]，即16个样本、10维特征、48步序列）
        Returns:
            torch.Tensor: 输出时序数据，形状与输入完全一致 [batch_size, feature_num, seq_len]，
                          支持模块级联到时序预测网络中
        """
        # 步骤1：输入全局归一化（若启用）
        if self.layernorm:
            # 维度转换：[b, feature_num, seq_len] → [b, feature_num×seq_len]（展平时序与特征维度）
            # 归一化后恢复原形状：[b, feature_num×seq_len] → [b, feature_num, seq_len]
            x = self.norm(torch.flatten(x, 1, -1)).reshape(x.shape)

        # 步骤2：初始化输出张量（与输入同形状，用于逐块填充结果）
        output = torch.zeros_like(x)
        # 填充初始窗口（前n_history×patch步）：直接复制输入的前patch步（无历史信息可聚合）
        output[:, :, :self.n_history * self.patch] = x[:, :, :self.n_history * self.patch].clone()

        # 步骤3：逐块处理剩余时序（从第n_history×patch步开始，每patch步为一个块）
        for i in range(self.n_history * self.patch, self.input_shape[0], self.patch):
            # 3.1 提取历史依赖窗口：取输出中前n_history×patch步的历史特征（避免使用未来信息，符合时序预测逻辑）
            input_hist = output[:, :, i - self.n_history * self.patch: i]  # 形状：[b, feature_num, n_history×patch]

            # 3.2 历史窗口归一化：展平后归一化，再恢复形状
            input_hist = self.norm1(torch.flatten(input_hist, 1, -1)).reshape(input_hist.shape)

            # 3.3 历史依赖聚合：将n_history×patch的时序维度压缩为patch（通过线性层+GELU+Dropout）
            # 维度转换：[b, feature_num, n_history×patch] → [b, feature_num, patch]
            input_agg = F.gelu(self.agg(input_hist))
            input_agg = self.dropout_t(input_agg)  # 时序维度失活

            # 3.4 残差融合：当前patch的输入特征 + 聚合后的历史特征（捕捉时序依赖）
            # 提取当前patch的输入特征：x[:, :, i:i+patch]（形状：[b, feature_num, patch]）
            tmp_res = input_agg + x[:, :, i: i + self.patch]
            res = tmp_res  # 残差融合结果（基础输出）

            # 3.5 可选前馈增强：若α>0，通过FFN增强当前patch特征，再与残差结果融合
            if self.alpha > 0.0:
                # 前馈分支输入归一化：展平当前patch特征→归一化→恢复形状
                tmp_ff = self.norm2(torch.flatten(tmp_res, 1, -1)).reshape(tmp_res.shape)
                # 维度转换：[b, feature_num, patch] → [b, patch, feature_num]（适配FFN的输入格式）
                tmp_ff = torch.transpose(tmp_ff, 1, 2)
                # 前馈网络处理：增强非线性特征
                tmp_ff = self.fc_block(tmp_ff)
                # 维度恢复：[b, patch, feature_num] → [b, feature_num, patch]
                tmp_ff = torch.transpose(tmp_ff, 1, 2)
                # 前馈结果与残差结果融合：res + α×tmp_ff（α控制前馈分支的贡献度）
                res = res + self.alpha * tmp_ff

            # 3.6 填充当前patch的输出结果
            output[:, :, i: i + self.patch] = res

        # 输出完整时序数据（与输入形状一致）
        return output

if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    input_shape = (48, 10) # 假设序列长度=48，特征数量=10
    dropout = 0.2
    patch = 12
    alpha = 0.1
    layernorm = True

    model = DDI(input_shape=input_shape, dropout=dropout, patch=patch, alpha=alpha, layernorm=layernorm)

    batch_size = 16
    x = torch.randn(batch_size, input_shape[1], input_shape[0]).to(device) # 序列：[b, c, seq_len]

    model.to(device)
    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("知乎、CSDN：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)