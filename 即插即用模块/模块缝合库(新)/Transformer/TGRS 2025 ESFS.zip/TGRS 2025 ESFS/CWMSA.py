# 压缩窗口多头自注意力模块（Condensed Window Multihead Self-Attention, CW-MSA）
# 核心设计：通过“窗口特征压缩→压缩特征增强→跨尺度注意力计算→特征还原”的流程，
# 在保持窗口注意力局部依赖捕捉能力的同时，通过特征压缩降低计算成本，
# 适配大窗口或高分辨率场景，平衡注意力性能与效率

import torch
import torch.nn as nn
import math
from timm.models.layers import trunc_normal_


class CondensedWindowAttention(nn.Module):
    """
    压缩窗口多头自注意力模块（Condensed Window Multihead Self-Attention, CW-MSA）
    功能：压缩窗口特征维度，降低注意力计算复杂度，同时保留局部依赖捕捉能力
    核心设计：
        - 多轮特征压缩：通过步长为2的分组卷积，逐步压缩窗口特征的空间尺寸
        - 压缩特征增强：深度卷积+点卷积强化压缩后的特征表达，避免信息丢失
        - 跨尺度注意力：Query来自原始窗口特征，Key/Value来自压缩特征，实现高效注意力计算
        - 相对位置偏置：适配压缩窗口的位置编码，提升注意力准确性
        - 通道增强：整合通道注意力（CA）与卷积位置编码（CPE），强化特征表达
    Args:
        dim: 输入/输出通道数
        window_size: 原始窗口尺寸（Wh, Ww）
        num_heads: 注意力头数
        qkv_bias: Q/KV是否带偏置（默认True）
        qk_scale: 注意力缩放因子（默认None，自动计算head_dim**-0.5）
        attn_drop: 注意力权重dropout概率（默认0.0）
        proj_drop: 输出dropout概率（默认0.0）
        _time: 特征压缩轮数（默认2，每轮压缩为1/2，最终压缩为1/2^_time）
    """

    def __init__(self, dim, window_size, num_heads, qkv_bias=True, qk_scale=None, attn_drop=0., proj_drop=0., _time=2):
        super().__init__()
        self.dim = dim
        self.window_size = window_size  # 原始窗口尺寸（Wh, Ww）
        self.num_heads = num_heads
        head_dim = dim // num_heads
        self.scale = qk_scale or head_dim ** -0.5  # 注意力缩放因子

        # 特征压缩配置
        self._time = _time  # 压缩轮数
        self._scale = 2 ** self._time  # 总压缩比例（2^_time）
        self.compressd_window_size = (window_size[0] // self._scale, window_size[1] // self._scale)  # 压缩后窗口尺寸

        # 相对位置偏置表（适配压缩窗口）
        self.relative_position_bias_table = nn.Parameter(
            torch.zeros((2 * self.compressd_window_size[0] - 1) * (2 * self.compressd_window_size[1] - 1), num_heads)
        )  # 形状：(2Wh'-1)*(2Ww'-1), nH（Wh'/Ww'为压缩后窗口尺寸）

        # 计算压缩窗口的相对位置索引，并扩展至原始窗口尺寸
        coords_h = torch.arange(self.compressd_window_size[0])
        coords_w = torch.arange(self.compressd_window_size[1])
        coords = torch.stack(torch.meshgrid([coords_h, coords_w]))  # 2, Wh', Ww'
        coords_flatten = torch.flatten(coords, 1)  # 2, Wh'*Ww'
        relative_coords = coords_flatten[:, :, None] - coords_flatten[:, None, :]  # 2, Wh'*Ww', Wh'*Ww'
        relative_coords = relative_coords.permute(1, 2, 0).contiguous()  # Wh'*Ww', Wh'*Ww', 2
        # 位置索引偏移至非负
        relative_coords[:, :, 0] += self.compressd_window_size[0] - 1
        relative_coords[:, :, 1] += self.compressd_window_size[1] - 1
        relative_coords[:, :, 0] *= 2 * self.compressd_window_size[1] - 1
        aligned_relative_position_index = relative_coords.sum(-1)  # Wh'*Ww', Wh'*Ww'
        # 扩展索引至原始窗口尺寸（适配压缩比例）
        aligned_relative_position_index = aligned_relative_position_index.reshape(
            self.compressd_window_size[0], self.compressd_window_size[1], 1, 1,
            self.compressd_window_size[0] * self.compressd_window_size[1]
        ).repeat(1, 1, self._scale, self._scale, 1).permute(0, 2, 1, 3, 4).reshape(
            (self._scale ** 2) * self.compressd_window_size[0] * self.compressd_window_size[1],
            self.compressd_window_size[0] * self.compressd_window_size[1]
        )  # 形状：(Wh*Ww), (Wh'*Ww')（原始窗口像素数×压缩窗口像素数）
        self.register_buffer('aligned_relative_position_index', aligned_relative_position_index)

        # 特征压缩网络（多轮分组卷积）
        self.reduction1 = nn.Conv2d(dim, dim, kernel_size=2, stride=2, groups=dim)  # 单轮压缩（步长2）
        # 压缩特征增强（深度卷积+点卷积）
        self.dwconv = nn.Conv2d(dim, dim, kernel_size=3, stride=1, padding=1, groups=dim)
        self.pwconv = nn.Conv2d(dim, dim, kernel_size=1, stride=1)
        self.norm_act = nn.Sequential(nn.LayerNorm(dim), nn.GELU())  # 归一化+激活

        # 通道注意力（CA）：生成Q/KV
        self.q_ca = nn.Linear(dim, dim, bias=qkv_bias)  # Query生成（原始特征）
        self.kv_ca = nn.Linear(dim, dim * 2, bias=qkv_bias)  # Key/Value生成（压缩特征）

        # 卷积位置编码（CPE）：强化空间位置信息
        self.cpe = nn.Conv2d(dim, dim, kernel_size=3, stride=1, padding=1, groups=dim)

        # Dropout与输出投影
        self.attn_drop = nn.Dropout(attn_drop)
        self.proj = nn.Linear(dim, dim)
        self.project_out = nn.Conv2d(dim, dim, kernel_size=1, bias=qkv_bias)  # 特征还原投影
        self.proj_drop = nn.Dropout(proj_drop)

        # 参数初始化
        trunc_normal_(self.relative_position_bias_table, std=.02)
        self.softmax = nn.Softmax(dim=-1)

    def forward(self, x, mask=None):
        """
        前向传播：特征格式转换→多轮压缩→压缩特征增强→QKV生成→注意力计算→特征还原
        Args:
            x: 输入特征，shape=[num_windows×B, N, C]（N=Wh×Ww，窗口内像素数）
            mask: 注意力掩码（可选），shape=[num_windows, Wh×Ww, Wh×Ww]
        Returns:
            注意力增强特征，shape=[num_windows×B, N, C]（与输入维度一致）
        """
        B_, N, C = x.shape
        H = W = int(math.sqrt(N))  # 原始窗口的空间尺寸（H=Wh, W=Ww）

        # 1. 特征格式转换：[B', N, C]→[B', C, H, W]（适配卷积操作）
        _x = x.view(B_, H, W, C).permute(0, 3, 1, 2).contiguous()

        # 2. 多轮特征压缩（每轮步长2，分组卷积）
        for _ in range(self._time):
            _x = self.reduction1(_x)  # 最终尺寸：[B', C, H//2^_time, W//2^_time]

        # 3. 压缩特征增强：深度卷积→点卷积→归一化激活
        _x = self.pwconv(self.dwconv(_x)).reshape(B_, C, -1).permute(0, 2, 1).contiguous()  # [B', N', C]（N'=Wh'×Ww'）
        _x = self.norm_act(_x)

        # 4. QKV生成：Query来自原始特征，Key/Value来自压缩特征
        q = self.q_ca(x).reshape(B_, N, self.num_heads, C // self.num_heads).permute(0, 2, 1,
                                                                                     3)  # [B', nH, N, head_dim]
        kv = self.kv_ca(_x).reshape(B_, -1, 2, self.num_heads, C // self.num_heads).permute(2, 0, 3, 1, 4)
        k, v = kv[0], kv[1]  # [B', nH, N', head_dim]

        # 5. 注意力计算
        q = q * self.scale  # 缩放
        attn = (q @ k.transpose(-2, -1))  # [B', nH, N, N']（跨尺度注意力分数）

        # 加入相对位置偏置
        relative_position_bias = self.relative_position_bias_table[self.aligned_relative_position_index.view(-1)].view(
            N, -1, self.num_heads
        ).permute(2, 0, 1).contiguous()  # [nH, N, N']
        attn = attn + relative_position_bias.unsqueeze(0)

        # 应用掩码（可选）
        if mask is not None:
            nW = mask.shape[0]
            attn = attn.view(B_ // nW, nW, self.num_heads, N, -1)
            mask = mask.unsqueeze(1).unsqueeze(0)  # [1, nW, 1, N, N']（适配压缩后维度）
            attn = attn + mask
            attn = attn.view(-1, self.num_heads, N, -1)
            attn = self.softmax(attn)
        else:
            attn = self.softmax(attn)

        attn = self.attn_drop(attn)

        # 6. 价值加权与特征还原
        x = (attn @ v).transpose(1, 2).reshape(B_, C, N).view(B_, C, H, W)  # [B', C, H, W]
        x = self.project_out(x).view(B_, C, N).permute(0, 2, 1)  # [B', N, C]（还原为输入格式）
        x = self.proj_drop(x)

        return x

    def extra_repr(self) -> str:
        return f'dim={self.dim}, window_size={self.window_size}, num_heads={self.num_heads}'

    def flops(self, N):
        """计算单窗口注意力的浮点运算量（FLOPs）"""
        flops = 0
        # QKV生成
        flops += N * self.dim * 3 * self.dim
        # 注意力分数计算
        flops += self.num_heads * N * (self.dim // self.num_heads) * (N // (self._scale ** 2))
        # 价值加权
        flops += self.num_heads * N * (N // (self._scale ** 2)) * (self.dim // self.num_heads)
        # 输出投影
        flops += N * self.dim * self.dim
        return flops


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 8*8, 128).to(device)
    model = CondensedWindowAttention(128, (8, 8), 4).to(device)

    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN、小红书：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)