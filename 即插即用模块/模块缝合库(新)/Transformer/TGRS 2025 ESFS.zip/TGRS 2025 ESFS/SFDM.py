import torch
import torch.nn as nn
from timm.models.layers import DropPath
import math


class FreqMLP(nn.Module):
    """
    频率MLP模块：频域分组线性增强，强化频率特征交互
    Args:
        dim: 输入/输出通道数
        num_groups: 分组数
    """
    def __init__(self, dim, num_groups):
        super(FreqMLP, self).__init__()
        self.conv1 = nn.Sequential(
            nn.Conv2d(dim, dim // 2, 1, 1, 0),
            nn.LeakyReLU(negative_slope=0.2, inplace=True)
        )
        self.conv2 = torch.nn.Conv2d(dim // 2, dim, 1, 1, 0)
        self.group_linear1 = GroupLinear(dim, dim, num_groups)
        self.gelu = nn.GELU()
        self.group_linear2 = GroupLinear(dim, dim, num_groups)
        self.fft_norm = 'ortho'

    def forward(self, x):
        x = self.conv1(x)
        batch, c, h, w = x.shape
        fft_dim = (-2, -1)
        ffted = torch.fft.rfftn(x, dim=fft_dim,
                                norm=self.fft_norm)  # (batch, c, h, w/2+1, 2) 将输入张量进行实部和虚部的傅里叶变换，得到复数表示的频率域数据ffted
        ffted = torch.stack((ffted.real, ffted.imag), dim=-1)  # 将频率域数据的实部和虚部分别堆叠起来
        ffted = ffted.permute(0, 1, 4, 2, 3).contiguous()  # (batch, c, 2, h, w/2+1)
        ffted = ffted.view((batch, -1,) + ffted.size()[3:])  # 将堆叠后的数据拉平 (batch, c*2, h, w/2+1)
        ffted = ffted.view(batch, -1, h * (w // 2 + 1)).permute(0, 2, 1).contiguous()  # (batch, h*(w/2+1), c*2)

        ffted = self.group_linear1(ffted)
        ffted = self.gelu(ffted)
        ffted = self.group_linear2(ffted)

        ffted = ffted.permute(0, 2, 1).contiguous()  # (batch, c*2, h*(w/2+1))
        ffted = ffted.view(batch, c * 2, h, w // 2 + 1)  # (batch, c*2, h, w/2+1)

        ffted = ffted.view(batch, c, 2, h, w // 2 + 1)
        ffted = ffted.permute(0, 1, 3, 4, 2).contiguous()  # (batch, c, h, w/2+1, 2)
        ffted = torch.complex(ffted[..., 0], ffted[..., 1])  # (batch, c, h, w/2+1)
        ifft_shape_slice = x.shape[-2:]
        output = torch.fft.irfftn(ffted, s=ifft_shape_slice, dim=fft_dim, norm=self.fft_norm)
        output = self.conv2(output)
        return output


class GroupLinear(nn.Module):
    def __init__(self, in_features, out_features, num_groups):
        super(GroupLinear, self).__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.num_groups = num_groups
        self.weight = nn.Parameter(torch.Tensor(num_groups, in_features // num_groups, out_features // num_groups))
        self.bias = nn.Parameter(torch.Tensor(num_groups, out_features // num_groups))
        self.reset_parameters()

    def reset_parameters(self):
        # 使用 Kaiming (He) 初始化
        nn.init.kaiming_uniform_(self.weight, a=math.sqrt(5))

        # 使用统一的偏置初始化
        fan_in = self.in_features // self.num_groups
        bound = 1 / math.sqrt(fan_in)
        nn.init.uniform_(self.bias, -bound, bound)

    def forward(self, x):
        B, N, C = x.shape
        G = self.num_groups
        x = x.view(B, N, G, C // G)
        x = torch.einsum('b n g c, g c o -> b n g o', x, self.weight)
        x = x + self.bias.view(1, 1, G, -1)
        x = x.reshape(B, N, -1)
        return x


class ResB(nn.Module):
    def __init__(self, embed_dim, red=4):
        super(ResB, self).__init__()
        self.body = nn.Sequential(
            nn.Conv2d(embed_dim, embed_dim // red, 3, 1, 1, groups=embed_dim // red),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Conv2d(embed_dim // red, embed_dim, 3, 1, 1, groups=embed_dim // red),
        )
    def forward(self, x):
        out = self.body(x)
        return out


class SFB(nn.Module):
    """
    频谱特征块（Spectral Feature Block）：层归一化→频谱变换→维度还原
    Args:
        embed_dim: 输入/输出通道数
        drop_path: DropPath概率（默认0.）
    """
    def __init__(self, embed_dim, drop_path=0.):
        super(SFB, self).__init__()
        self.F = SpectralTransform(embed_dim)

        norm_layer=nn.LayerNorm
        self.norm1 = norm_layer(embed_dim)
    def __call__(self, x, x_size):
        H, W = x_size
        B, L, C = x.shape
        x = self.norm1(x)
        x = x.view(B, H, W, C).permute(0, 3, 1, 2)
        out = self.F(x)
        out = out.permute(0, 2, 3, 1).contiguous().view(B, L, C)
        return out


class SpectralTransform(nn.Module):
    """
    频谱变换模块：通道压缩→傅里叶单元增强→通道恢复
    Args:
        embed_dim: 输入/输出通道数
    """
    def __init__(self, embed_dim):
        # bn_layer not used

        super(SpectralTransform, self).__init__()

        self.conv1 = nn.Sequential(
            nn.Conv2d(embed_dim, embed_dim // 2, 1, 1, 0),
            nn.LeakyReLU(negative_slope=0.2, inplace=True)
        )
        self.fu = FourierUnit(embed_dim // 2)

        self.conv2 = torch.nn.Conv2d(embed_dim // 2, embed_dim, 1, 1, 0)

    def forward(self, x):
        x = self.conv1(x)
        output = self.fu(x)
        output = self.conv2(x + output)
        return output


class FourierUnit(nn.Module):
    """
    傅里叶单元：选择性优化频域幅值与相位，核心频域增强组件
    核心设计：
        - 幅值-相位分离优化：分别用1×1/3×3卷积增强，针对性提升频域表达
        - 频率注意力：基于全局池化生成注意力掩码，选择性强化关键频率
        - 频域乘法融合：注意力掩码与优化后频域特征加权，实现选择性增强
    Args:
        embed_dim: 输入通道数
        fft_norm: FFT归一化方式（默认'ortho'）
        squeeze_factor: 注意力通道压缩比例（默认2）
    """
    def __init__(self, embed_dim, fft_norm='ortho', squeeze_factor=2):
        super(FourierUnit, self).__init__()
        self.conv_layer = nn.Conv2d(embed_dim * 2, embed_dim * 2, kernel_size=1)
        self.relu = nn.LeakyReLU(negative_slope=0.2, inplace=True)

        self.amplitude_pool = nn.AdaptiveMaxPool2d(1)
        self.phase_pool = nn.AdaptiveAvgPool2d(1)
        self.attention = nn.Sequential(
            nn.Conv2d(embed_dim * 2, embed_dim * 2 // squeeze_factor, 1, padding=0),
            nn.ReLU(inplace=True),
            nn.Conv2d(embed_dim * 2 // squeeze_factor, embed_dim * 2, 1, padding=0),
            nn.Sigmoid())

        # 1x1卷积用于幅值处理
        self.amplitude_conv = nn.Sequential(
            nn.Conv2d(embed_dim, embed_dim, 1),
            nn.LeakyReLU(negative_slope=0.2, inplace=True),
        )

        # 3x3卷积用于相位处理
        self.phase_conv = nn.Sequential(
            nn.Conv2d(embed_dim, embed_dim, 3, padding=1),
            nn.LeakyReLU(negative_slope=0.2, inplace=True),
        )

        self.dim = embed_dim
        self.fft_norm = fft_norm

    def forward(self, x):
        batch, c, h, w = x.shape
        # device = x.device
        fft_dim = (-2, -1)

        # 进行傅里叶变换
        ffted = torch.fft.rfftn(x, dim=fft_dim,
                                norm=self.fft_norm)  # (batch, c, h, w/2+1, 2) 将输入张量进行实部和虚部的傅里叶变换，得到复数表示的频率域数据ffted
        amplitude = torch.abs(ffted)
        phase = torch.angle(ffted)
        amplitude1 = self.amplitude_pool(amplitude)
        phase1 = self.phase_pool(phase)
        # 重构复数表示
        filter = torch.polar(amplitude1, phase1)
        filter = torch.stack((filter.real, filter.imag), dim=-1)  # 将频率域数据的实部和虚部分别堆叠起来
        filter = filter.permute(0, 1, 4, 2, 3).contiguous()  # (batch, c, 2, h, w/2+1)
        filter = filter.view((batch, -1,) + filter.size()[3:])  # 将堆叠后的数据拉平 (batch, c*2, h, w/2+1)
        filter = self.attention(filter)
        filter = filter.view((batch, -1, 2,) + filter.size()[2:]).permute(0, 1, 3, 4,
                                                                          2).contiguous()  # (batch,c, t, h, w/2+1, 2)
        filter = torch.complex(filter[..., 0], filter[..., 1])
        # 对幅值和相位进行卷积处理
        amplitude = amplitude + self.amplitude_conv(amplitude)
        phase = phase + self.phase_conv(phase)
        # 重构复数表示
        ffted = torch.polar(amplitude, phase)
        ffted = ffted * filter
        ffted = torch.stack((ffted.real, ffted.imag), dim=-1)  # 将频率域数据的实部和虚部分别堆叠起来
        ffted = ffted.permute(0, 1, 4, 2, 3).contiguous()  # (batch, c, 2, h, w/2+1)
        ffted = ffted.view((batch, -1,) + ffted.size()[3:])  # 将堆叠后的数据拉平 (batch, c*2, h, w/2+1)
        ffted = self.conv_layer(ffted)  # (batch, c*2, h, w/2+1)
        ffted = self.relu(ffted)
        ffted = ffted.view((batch, -1, 2,) + ffted.size()[2:]).permute(0, 1, 3, 4,
                                                                       2).contiguous()  # (batch,c, t, h, w/2+1, 2)
        ffted = torch.complex(ffted[..., 0], ffted[..., 1])

        # 进行逆傅里叶变换
        ifft_shape_slice = x.shape[-2:]
        output = torch.fft.irfftn(ffted, s=ifft_shape_slice, dim=fft_dim, norm=self.fft_norm)

        return output


class SFDM(nn.Module):
    r""" SFDM.

    Args:
        dim (int): Number of input channels.
        input_resolution (tuple[int]): Input resulotion.
        num_heads (int): Number of attention heads.
        window_size (int): Window size.
        shift_size (int): Shift size for SW-MSA.
        mlp_ratio (float): Ratio of mlp hidden dim to embedding dim.
        qkv_bias (bool, optional): If True, add a learnable bias to query, key, value. Default: True
        qk_scale (float | None, optional): Override default qk scale of head_dim ** -0.5 if set.
        drop (float, optional): Dropout rate. Default: 0.0
        attn_drop (float, optional): Attention dropout rate. Default: 0.0
        drop_path (float, optional): Stochastic depth rate. Default: 0.0
        act_layer (nn.Module, optional): Activation layer. Default: nn.GELU
        norm_layer (nn.Module, optional): Normalization layer.  Default: nn.LayerNorm
    """
    """
    选择性频率分解模块（Selective Frequency Decomposition Module, SFDM）
    功能：空间残差增强+频谱选择性增强+特征融合，实现频域-空域协同优化
    核心设计：
        - 双路径增强：空间残差路径强化局部细节，频谱路径选择性优化频域信息
        - 残差融合：频谱增强特征与原始特征残差连接，保留基础信息
        - 特征聚合：双路径特征拼接→1×1卷积融合，输出最终特征
    Args:
        dim: 输入/输出通道数
        drop_path: DropPath概率（默认0.）
    """
    def __init__(self, dim, drop_path=0.):
        super().__init__()
        norm_layer = nn.LayerNorm
        self.dim = dim
        self.SFB = SFB(dim)
        self.res2 = ResB(dim)

        self.norm2 = norm_layer(dim)
        self.fusion = nn.Conv2d(dim * 2, dim, 1, 1, 0)
        self.ffn = FreqMLP(dim=dim, num_groups=3)
        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()

    def forward(self, x, x_size):
        H, W = x_size
        B, L, C = x.shape
        # assert L == H * W, "input feature has wrong size"
        shortcut = x
        # 残差
        x = x.view(B, H, W, C).permute(0, 3, 1, 2)
        s = self.res2(x)
        # SFB
        x = x.permute(0, 2, 3, 1).contiguous().view(B, L, C)
        f = self.SFB(x, x_size)
        f = shortcut + self.drop_path(f)
        f = f.view(B, H, W, C).permute(0, 3, 1, 2)
        # fusion
        out = torch.cat([f, s], dim=1)
        out = self.fusion(out)
        out = out.permute(0, 2, 3, 1).contiguous().view(B, L, C)
        return out


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 32*32, 64).to(device)
    x_size = (32, 32)
    model = SFDM(64).to(device)

    y = model(x, x_size)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN、小红书：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)