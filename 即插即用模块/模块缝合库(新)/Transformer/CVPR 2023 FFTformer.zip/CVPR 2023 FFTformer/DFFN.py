import torch
import torch.nn as nn
import torch.nn.functional as F
from einops import rearrange


class DFFN(nn.Module):
    """
    频率域前馈网络（Frequency-Domain Feed-Forward Network, DFFN）
    核心设计：将频率域变换融入前馈网络，在提升特征表达能力的同时保持计算效率，
    适配图像恢复任务中编码器与解码器的特征处理需求
    """

    def __init__(self, dim, ffn_expansion_factor, bias):
        """
        初始化DFFN模块参数

        Args:
            dim (int): 输入特征图的通道数（需与上游模块输出通道一致，如代码示例中为64）
            ffn_expansion_factor (int/float): 通道扩展因子，控制中间层通道数（如2表示扩展为2×dim）
            bias (bool): 卷积层是否使用偏置参数（默认False，减少参数冗余并降低过拟合风险）
        """
        super(DFFN, self).__init__()
        # 计算中间层（隐藏层）通道数：通过扩展因子放大输入通道数，增强特征表达能力
        hidden_features = int(dim * ffn_expansion_factor)
        # 特征图分块大小：固定为8×8，在局部块内进行频率域变换，平衡计算效率与依赖建模范围
        self.patch_size = 8
        # 记录输入通道数，用于后续维度校验（非强制，仅为调试便利）
        self.dim = dim

        # 1×1卷积：将输入通道数从dim扩展到2×hidden_features，为后续分路处理做准备
        # 作用：压缩空间维度信息，聚焦通道维度的特征变换，避免初始维度对频率域计算的干扰
        self.project_in = nn.Conv2d(dim, hidden_features * 2, kernel_size=1, bias=bias)

        # 深度可分离3×3卷积：对扩展后的特征进行局部空间信息提取
        # 特点：groups=hidden_features*2，确保每个通道独立卷积，减少参数量（参数数仅为普通Conv2d的1/(hidden_features*2)）
        # 作用：捕捉局部空间关联性，补充频率域变换可能丢失的细节信息
        self.dwconv = nn.Conv2d(hidden_features * 2, hidden_features * 2, kernel_size=3,
                                stride=1, padding=1, groups=hidden_features * 2, bias=bias)

        # 频率域权重参数：可学习的复数权重矩阵，用于在频率域对特征进行增强/抑制
        # 维度说明：[hidden_features*2, 1, 1, patch_size, patch_size//2+1]
        # - hidden_features*2：对应输入特征通道数，确保逐通道频率域调整
        # - 1,1：适配分块后的特征图空间维度（h/w方向）
        # - patch_size：分块高度（8），与irfft2输出尺寸匹配
        # - patch_size//2+1：实值FFT（rfft2）的频率域维度（实部+虚部压缩表示）
        self.fft = nn.Parameter(torch.ones((hidden_features * 2, 1, 1, self.patch_size, self.patch_size // 2 + 1)))

        # 1×1卷积：将处理后的特征通道数从hidden_features压缩回原始dim，确保模块输入输出维度一致
        # 作用：降低维度冗余，使DFFN可灵活级联到网络中（如编码器的多层堆叠）
        self.project_out = nn.Conv2d(hidden_features, dim, kernel_size=1, bias=bias)

    def forward(self, x):
        """
        DFFN前向传播流程：通道扩展→特征分块→频率域增强→空间域恢复→局部特征提取→激活融合→通道压缩

        Args:
            x (torch.Tensor): 输入特征图，形状为 [batch_size, dim, height, width]
                             （代码示例中为[1, 64, 32, 32]，即1个样本、64通道、32×32分辨率）
        Returns:
            torch.Tensor: 输出特征图，形状与输入完全一致 [batch_size, dim, height, width]，
                          确保模块可无缝级联
        """
        # 步骤1：通道扩展（dim → 2×hidden_features）
        # 通过1×1卷积将输入通道数放大，为后续频率域处理和分路融合提供足够特征维度
        x = self.project_in(x)  # 形状变化：[b, dim, h, w] → [b, 2*h_f, h, w]（h_f=hidden_features）

        # 步骤2：特征图分块（Patch Folding）
        # 将特征图按8×8大小拆分为局部块，便于在小范围内部进行频率域变换（降低计算复杂度）
        # 维度重排规则：(h, w) → (h//8, 8, w//8, 8) → (h//8, w//8, 8, 8)
        # 形状变化：[b, 2*h_f, h, w] → [b, 2*h_f, h//8, w//8, 8, 8]
        x_patch = rearrange(x, 'b c (h patch1) (w patch2) -> b c h w patch1 patch2',
                            patch1=self.patch_size, patch2=self.patch_size)

        # 步骤3：频率域特征增强（核心步骤）
        # 3.1 实值二维快速傅里叶变换（rfft2）：将空间域分块特征转换到频率域
        # 优势：仅计算正频率部分，比完整FFT减少50%计算量和内存占用
        # 形状变化：[b, 2*h_f, h//8, w//8, 8, 8] → [b, 2*h_f, h//8, w//8, 8, 5]（5=8//2+1）
        x_patch_fft = torch.fft.rfft2(x_patch.float())  # 转为float避免低精度数值误差

        # 3.2 频率域权重调制：通过可学习参数对不同频率成分进行增强或抑制
        # 作用：让模型自主学习“哪些频率成分对任务更重要”（如去模糊任务中抑制模糊相关频率）
        # 形状不变：[b, 2*h_f, h//8, w//8, 8, 5]
        x_patch_fft = x_patch_fft * self.fft

        # 3.3 逆实值二维快速傅里叶变换（irfft2）：将频率域特征转回空间域
        # s=(8,8)确保输出尺寸与原始分块一致，避免维度不匹配
        # 形状变化：[b, 2*h_f, h//8, w//8, 8, 5] → [b, 2*h_f, h//8, w//8, 8, 8]
        x_patch = torch.fft.irfft2(x_patch_fft, s=(self.patch_size, self.patch_size))

        # 步骤4：分块重组（Patch Unfolding）
        # 将处理后的8×8分块重新拼接为完整特征图，恢复原始空间分辨率
        # 形状变化：[b, 2*h_f, h//8, w//8, 8, 8] → [b, 2*h_f, h, w]
        x = rearrange(x_patch, 'b c h w patch1 patch2 -> b c (h patch1) (w patch2)',
                      patch1=self.patch_size, patch2=self.patch_size)

        # 步骤5：局部空间特征提取与激活融合
        # 5.1 深度可分离卷积：捕捉局部空间关联性（如边缘、纹理等细节）
        # 形状不变：[b, 2*h_f, h, w]
        x = self.dwconv(x)

        # 5.2 通道分路：将2×hidden_features通道拆分为两个独立分支（各hidden_features通道）
        # 作用：通过分路实现不同特征的差异化处理，增强非线性表达
        # 形状变化：[b, 2*h_f, h, w] → [b, h_f, h, w]（x1）和 [b, h_f, h, w]（x2）
        x1, x2 = x.chunk(2, dim=1)

        # 5.3 GELU激活融合：x1通过GELU激活引入非线性，再与x2逐元素相乘
        # 优势：GELU相比ReLU更平滑，避免梯度消失；逐元素相乘实现特征交互，增强表达能力
        # 形状不变：[b, h_f, h, w]
        x = F.gelu(x1) * x2

        # 步骤6：通道压缩（hidden_features → dim）
        # 通过1×1卷积将通道数恢复为原始dim，确保模块输入输出维度一致，便于级联
        # 形状变化：[b, h_f, h, w] → [b, dim, h, w]
        x = self.project_out(x)

        return x

if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 64, 32, 32).to(device)
    model = DFFN(64, 2, False)

    model.to(device)
    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("知乎、CSDN：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)