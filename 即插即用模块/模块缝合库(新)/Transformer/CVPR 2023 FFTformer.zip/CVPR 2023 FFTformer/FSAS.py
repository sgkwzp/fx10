import torch
import torch.nn as nn

from einops import rearrange
import numbers

def to_3d(x):
    return rearrange(x, 'b c h w -> b (h w) c')


def to_4d(x, h, w):
    return rearrange(x, 'b (h w) c -> b c h w', h=h, w=w)


class BiasFree_LayerNorm(nn.Module):
    def __init__(self, normalized_shape):
        super(BiasFree_LayerNorm, self).__init__()
        if isinstance(normalized_shape, numbers.Integral):
            normalized_shape = (normalized_shape,)
        normalized_shape = torch.Size(normalized_shape)

        assert len(normalized_shape) == 1

        self.weight = nn.Parameter(torch.ones(normalized_shape))
        self.normalized_shape = normalized_shape

    def forward(self, x):
        sigma = x.var(-1, keepdim=True, unbiased=False)
        return x / torch.sqrt(sigma + 1e-5) * self.weight


class WithBias_LayerNorm(nn.Module):
    def __init__(self, normalized_shape):
        super(WithBias_LayerNorm, self).__init__()
        if isinstance(normalized_shape, numbers.Integral):
            normalized_shape = (normalized_shape,)
        normalized_shape = torch.Size(normalized_shape)

        assert len(normalized_shape) == 1

        self.weight = nn.Parameter(torch.ones(normalized_shape))
        self.bias = nn.Parameter(torch.zeros(normalized_shape))
        self.normalized_shape = normalized_shape

    def forward(self, x):
        mu = x.mean(-1, keepdim=True)
        sigma = x.var(-1, keepdim=True, unbiased=False)
        return (x - mu) / torch.sqrt(sigma + 1e-5) * self.weight + self.bias


class LayerNorm(nn.Module):
    def __init__(self, dim, LayerNorm_type):
        super(LayerNorm, self).__init__()
        if LayerNorm_type == 'BiasFree':
            self.body = BiasFree_LayerNorm(dim)
        else:
            self.body = WithBias_LayerNorm(dim)

    def forward(self, x):
        h, w = x.shape[-2:]
        return to_4d(self.body(to_3d(x)), h, w)


class FSAS(nn.Module):
    """
    频率域自注意力模块（Frequency-Domain Self-Attention, FSAS）
    核心思想：在频率域计算注意力，替代传统空间域自注意力，提升长距离依赖建模效率
    """

    def __init__(self, dim, bias=False):
        """
        Args:
            dim (int): 输入特征图的通道数（如代码示例中为64）
            bias (bool): 卷积层是否使用偏置（默认False，减少参数并避免过拟合）
        """
        super(FSAS, self).__init__()
        # 1×1卷积：将输入通道数从dim扩展到6×dim，用于生成Q、K、V（各占2×dim）
        self.to_hidden = nn.Conv2d(dim, dim * 6, kernel_size=1, bias=bias)
        # 深度可分离3×3卷积：对扩展后的特征进行局部特征提取（groups=dim*6确保逐通道卷积）
        self.to_hidden_dw = nn.Conv2d(dim * 6, dim * 6, kernel_size=3, stride=1,
                                      padding=1, groups=dim * 6, bias=bias)
        # 1×1卷积：将输出通道数从2×dim压缩回dim，恢复原通道维度
        self.project_out = nn.Conv2d(dim * 2, dim, kernel_size=1, bias=bias)
        # 带偏置LayerNorm：对频率域计算后的特征进行归一化，稳定训练
        self.norm = LayerNorm(dim * 2, LayerNorm_type='WithBias')
        # patch大小：将特征图划分为8×8的局部块，在块内计算频率域注意力
        self.patch_size = 8

    def forward(self, x):
        """
        FSAS前向传播流程：特征扩展→局部提取→Q/K/V拆分→频率域注意力→特征恢复
        Args:
            x (torch.Tensor): 输入特征图，形状为 [b, dim, h, w]（如代码示例中为[1,64,32,32]）
        Returns:
            torch.Tensor: 输出特征图，形状与输入一致 [b, dim, h, w]
        """
        # 步骤1：特征通道扩展（dim → 6×dim）
        hidden = self.to_hidden(x)  # 形状：[b, 6×dim, h, w]

        # 步骤2：局部特征提取（深度可分离卷积）
        hidden_dw = self.to_hidden_dw(hidden)  # 形状不变：[b, 6×dim, h, w]

        # 步骤3：拆分Q、K、V（各占2×dim通道）
        q, k, v = hidden_dw.chunk(3, dim=1)  # 各形状：[b, 2×dim, h, w]

        # 步骤4：将Q/K拆分为8×8的patch（便于局部频率域计算）
        # 形状变化：[b, 2×dim, h, w] → [b, 2×dim, h/patch1, w/patch2, patch1, patch2]
        q_patch = rearrange(q, 'b c (h patch1) (w patch2) -> b c h w patch1 patch2',
                            patch1=self.patch_size, patch2=self.patch_size)
        k_patch = rearrange(k, 'b c (h patch1) (w patch2) -> b c h w patch1 patch2',
                            patch1=self.patch_size, patch2=self.patch_size)

        # 步骤5：频率域注意力计算（核心步骤）
        # 2.1 二维实值快速傅里叶变换（RFFT2）：将Q/K从空间域转换到频率域
        q_fft = torch.fft.rfft2(q_patch.float())  # 频率域Q，形状：[b, 2×dim, h/patch1, w/patch2, patch1, patch2//2+1]
        k_fft = torch.fft.rfft2(k_patch.float())  # 频率域K，形状同上
        # 2.2 频率域元素乘法：替代传统空间域注意力的点积（计算效率更高）
        out_fft = q_fft * k_fft  # 频率域注意力权重
        # 2.3 逆二维实值快速傅里叶变换（IRFFT2）：将结果从频率域转回空间域
        out = torch.fft.irfft2(out_fft, s=(
        self.patch_size, self.patch_size))  # 形状：[b, 2×dim, h/patch1, w/patch2, patch1, patch2]

        # 步骤6：patch重组（恢复原特征图尺寸）
        out = rearrange(out, 'b c h w patch1 patch2 -> b c (h patch1) (w patch2)',
                        patch1=self.patch_size, patch2=self.patch_size)  # 形状：[b, 2×dim, h, w]

        # 步骤7：归一化与特征融合
        out_norm = self.norm(out)  # 对2×dim通道特征归一化
        output = v * out_norm  # 元素乘法：V与频率域注意力结果融合（形状不变）

        # 步骤8：通道压缩（2×dim → dim），输出最终特征
        output = self.project_out(output)  # 形状：[b, dim, h, w]
        return output

if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 64, 32, 32).to(device)
    model = FSAS(64)

    model.to(device)
    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("知乎、CSDN：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)