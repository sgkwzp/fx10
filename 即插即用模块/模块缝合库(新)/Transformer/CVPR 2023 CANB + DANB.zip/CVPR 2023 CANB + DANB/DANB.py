# 双自适应神经块（Dual Adaptive Neural Block, DANB）
# 核心设计：基于分组卷积的双分支自适应特征融合，通过GELU激活的特征变换与Sigmoid激活的动态加权，
# 实现轻量化的特征增强，兼顾表达能力与计算效率

import torch
import torch.nn as nn
import torch.nn.functional as F

# 属于前馈网络
class DualAdaptiveNeuralBlock(nn.Module):
    """
    双自适应神经块（DANB）
    功能：通过双分支结构实现特征的自适应变换与加权融合，增强特征表达能力
    核心设计：
        - 分组卷积双分支生成：1×1卷积降维+7×7分组卷积升维，拆分出特征变换分支与动态加权分支
        - 双激活函数协同：GELU实现非线性特征变换，Sigmoid生成自适应权重
        - 轻量化架构：无复杂注意力计算，仅通过卷积与元素运算实现自适应增强
    """

    def __init__(self, embed_dim):
        super(DualAdaptiveNeuralBlock, self).__init__()
        self.embed_dim = embed_dim  # 输入/输出特征通道数

        # 分组卷积模块：生成双分支特征（特征变换分支+动态加权分支）
        self.group_conv = nn.Sequential(
            nn.Conv2d(embed_dim, embed_dim, 1),  # 1×1卷积：通道维度调整，降低后续计算量
            # 7×7分组卷积：升维至2×embed_dim，groups=embed_dim确保每个通道独立生成双分支
            nn.Conv2d(embed_dim, embed_dim * 2, 7, 1, 3, groups=embed_dim)
        )

        # 后处理1×1卷积：融合双分支特征后，投影回原通道数
        self.post_conv = nn.Conv2d(embed_dim, embed_dim, 1)

    def forward(self, x):
        """
        前向传播：DANB完整自适应特征增强流程
        Args:
            x: 输入特征，shape=[B, C, H, W]（B=批量，C=通道，H=高度，W=宽度）
        Returns:
            x_: 自适应增强后的特征，shape=[B, C, H, W]（与输入维度一致）
        """
        B, C, H, W = x.size()

        # 1. 双分支特征生成：分组卷积生成2倍通道数特征
        x_conv = self.group_conv(x)  # [B, C, H, W] → [B, 2C, H, W]
        # 维度调整+拆分双分支：[B, 2C, H, W] → [B, C, 2, H, W] → 拆分x0（特征变换分支）、x1（权重分支）
        x0, x1 = x_conv.view(B, C, 2, H, W).chunk(2, dim=2)

        # 2. 双分支自适应融合：特征变换×动态权重
        x0 = x0.squeeze(2)  # 移除多余维度→[B, C, H, W]（特征变换分支）
        x1 = x1.squeeze(2)  # 移除多余维度→[B, C, H, W]（权重分支）
        x_fuse = F.gelu(x0) * torch.sigmoid(x1)  # GELU非线性变换 + Sigmoid动态加权

        # 3. 特征投影：1×1卷积恢复原通道数，输出增强特征
        x_ = self.post_conv(x_fuse)  # [B, C, H, W]
        return x_

if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 64, 32, 32).to(device)
    model = DualAdaptiveNeuralBlock(64).to(device)

    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN、小红书：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)