# 浓缩注意力神经块（Condensed Attention Neural Block, CANB）
# 核心设计：通过通道-空间维度压缩、分组注意力建模、维度恢复的全流程，
# 在大幅降低计算量的同时，高效捕捉通道与空间双重注意力信息，实现轻量化增强

import torch
import torch.nn as nn
import torch.nn.functional as F


# -------------------------------------------------------------------#
class ChannelAttention(nn.Module):
    """
    分组式通道注意力模块
    功能：在压缩后的特征空间中，通过分组QKV投影和注意力计算，捕捉通道间依赖关系
    核心设计：
        - 分组卷积生成QKV：避免全连接层的高参数量，保持通道独立性
        - 多头部注意力：并行建模不同通道组的关联，提升表达能力
        - 可学习温度参数：自适应调节注意力权重分布，增强灵活性
    """

    def __init__(self, embed_dim, num_chans, expan_att_chans):
        super(ChannelAttention, self).__init__()
        self.expan_att_chans = expan_att_chans  # 注意力通道扩展系数
        self.num_heads = int(num_chans * expan_att_chans)  # 注意力头数（分组数×扩展系数）
        self.t = nn.Parameter(torch.ones(1, self.num_heads, 1, 1))  # 每个头的可学习温度参数

        # 分组1×1卷积：生成QKV三分支（输入维度→3×扩展系数×输入维度），groups=embed_dim确保通道分组独立
        self.group_qkv = nn.Conv2d(embed_dim, embed_dim * expan_att_chans * 3, 1, groups=embed_dim)
        # 分组1×1卷积：将扩展后的注意力特征投影回原维度
        self.group_fus = nn.Conv2d(embed_dim * expan_att_chans, embed_dim, 1, groups=embed_dim)

    def forward(self, x):
        """
        前向传播：分组通道注意力计算
        Args:
            x: 输入特征，shape=[B, C, H, W]（B=批量，C=通道，H=高度，W=宽度）
        Returns:
            x_: 通道注意力增强后的特征，shape=[B, C, H, W]
        """
        B, C, H, W = x.size()
        # 1. QKV生成与拆分：分组卷积→维度调整→拆分三分支
        qkv = self.group_qkv(x)  # [B, C×expan×3, H, W]
        qkv = qkv.view(B, C, self.expan_att_chans * 3, H, W).transpose(1, 2).contiguous()  # [B, expan×3, C, H, W]
        q, k, v = qkv.chunk(3, dim=1)  # 拆分Q、K、V，各为[B, expan, C, H, W]

        # 2. 维度重塑：适配多头注意力计算
        C_exp = self.expan_att_chans * C  # 扩展后的总通道数
        q = q.view(B, self.num_heads, C_exp // self.num_heads, H * W)  # [B, num_heads, C_per_head, HW]
        k = k.view(B, self.num_heads, C_exp // self.num_heads, H * W)  # [B, num_heads, C_per_head, HW]
        v = v.view(B, self.num_heads, C_exp // self.num_heads, H * W)  # [B, num_heads, C_per_head, HW]

        # 3. 注意力计算：归一化→得分计算→Softmax→加权求和
        q, k = F.normalize(q, dim=-1), F.normalize(k, dim=-1)  # 沿HW维度归一化
        attn = q @ k.transpose(-2, -1) * self.t  # 注意力得分 = Q@K^T × 温度参数 → [B, num_heads, C_per_head, C_per_head]
        x_ = attn.softmax(dim=-1) @ v  # 权重×V → [B, num_heads, C_per_head, HW]

        # 4. 维度恢复与投影：重塑→分组融合→输出
        x_ = x_.view(B, self.expan_att_chans, C, H, W).transpose(1, 2).flatten(1, 2).contiguous()  # [B, C×expan, H, W]
        x_ = self.group_fus(x_)  # 分组卷积投影回原通道数→[B, C, H, W]
        return x_


class SpatialAttention(nn.Module):
    """
    分组式空间注意力模块
    功能：在压缩后的特征空间中，通过分组QKV投影和注意力计算，捕捉空间位置间依赖关系
    核心设计：与通道注意力共享网络结构，仅调整归一化维度和注意力计算维度，实现空间关联建模
    """

    def __init__(self, embed_dim, num_chans, expan_att_chans):
        super(SpatialAttention, self).__init__()
        self.expan_att_chans = expan_att_chans  # 注意力通道扩展系数
        self.num_heads = int(num_chans * expan_att_chans)  # 注意力头数
        self.t = nn.Parameter(torch.ones(1, self.num_heads, 1, 1))  # 可学习温度参数

        # 与通道注意力共享相同的分组卷积结构（参数独立）
        self.group_qkv = nn.Conv2d(embed_dim, embed_dim * expan_att_chans * 3, 1, groups=embed_dim)
        self.group_fus = nn.Conv2d(embed_dim * expan_att_chans, embed_dim, 1, groups=embed_dim)

    def forward(self, x):
        """
        前向传播：分组空间注意力计算
        Args:
            x: 输入特征，shape=[B, C, H, W]
        Returns:
            x_: 空间注意力增强后的特征，shape=[B, C, H, W]
        """
        B, C, H, W = x.size()
        # 1. QKV生成与拆分（与通道注意力完全一致）
        qkv = self.group_qkv(x)
        qkv = qkv.view(B, C, self.expan_att_chans * 3, H, W).transpose(1, 2).contiguous()
        q, k, v = qkv.chunk(3, dim=1)

        # 2. 维度重塑（与通道注意力一致）
        C_exp = self.expan_att_chans * C
        q = q.view(B, self.num_heads, C_exp // self.num_heads, H * W)
        k = k.view(B, self.num_heads, C_exp // self.num_heads, H * W)
        v = v.view(B, self.num_heads, C_exp // self.num_heads, H * W)

        # 3. 注意力计算：调整归一化维度和计算维度，适配空间建模
        q, k = F.normalize(q, dim=-2), F.normalize(k, dim=-2)  # 沿通道维度归一化（区别于通道注意力）
        attn = q.transpose(-2, -1) @ k * self.t  # 注意力得分 = Q^T@K × 温度参数 → [B, num_heads, HW, HW]
        x_ = attn.softmax(dim=-1) @ v.transpose(-2, -1)  # 权重×V^T → [B, num_heads, HW, C_per_head]
        x_ = x_.transpose(-2, -1).contiguous()  # 恢复维度→[B, num_heads, C_per_head, HW]

        # 4. 维度恢复与投影（与通道注意力完全一致）
        x_ = x_.view(B, self.expan_att_chans, C, H, W).transpose(1, 2).flatten(1, 2).contiguous()
        x_ = self.group_fus(x_)
        return x_


class CondensedAttentionNeuralBlock(nn.Module):
    """
    浓缩注意力神经块（CANB）
    功能：整合通道-空间压缩、分组注意力、维度恢复，实现轻量化双重注意力增强
    核心设计：
        - 通道-空间联合压缩：通过1×1卷积+分组卷积下采样，大幅降低特征维度和计算量
        - 分组注意力串行建模：先通道注意力（筛选关键通道），后空间注意力（捕捉位置关联）
        - 维度重排适配分组：通过索引重组，确保注意力计算在分组内高效进行
        - 可逆维度恢复：通过分组卷积+PixelShuffle，精准恢复原始特征维度
    """

    def __init__(self, embed_dim, squeezes, shuffle, expan_att_chans):
        super(CondensedAttentionNeuralBlock, self).__init__()
        self.embed_dim = embed_dim  # 输入/输出特征通道数
        self.squeezes = squeezes  # 双重压缩系数：(通道压缩系数, 空间压缩后再压缩系数)
        self.shuffle = shuffle  # PixelShuffle上采样系数

        # 计算压缩后的中间维度
        sque_ch_dim = embed_dim // squeezes[0]  # 通道压缩后维度（embed_dim / 通道压缩系数）
        shuf_sp_dim = int(sque_ch_dim * (shuffle ** 2))  # PixelShuffle上采样后的中间维度
        sque_sp_dim = shuf_sp_dim // squeezes[1]  # 空间压缩+二次压缩后的最终中间维度

        self.sque_ch_dim = sque_ch_dim  # 通道压缩后维度（用于分组）
        self.shuf_sp_dim = shuf_sp_dim  # 上采样中间维度
        self.sque_sp_dim = sque_sp_dim  # 最终中间维度（注意力计算的输入维度）

        # 1. 通道-空间联合压缩模块：1×1卷积（通道压缩）→ 分组卷积（空间下采样+二次压缩）
        self.ch_sp_squeeze = nn.Sequential(
            nn.Conv2d(embed_dim, sque_ch_dim, 1),  # 通道压缩：embed_dim → sque_ch_dim
            nn.Conv2d(sque_ch_dim, sque_sp_dim, shuffle, shuffle, groups=sque_ch_dim)
            # 空间下采样（步长=shuffle）+ 分组卷积，输出sque_sp_dim
        )

        # 2. 双重注意力模块：通道注意力→空间注意力（串行执行）
        self.channel_attention = ChannelAttention(sque_sp_dim, sque_ch_dim, expan_att_chans)
        self.spatial_attention = SpatialAttention(sque_sp_dim, sque_ch_dim, expan_att_chans)

        # 3. 空间-通道联合恢复模块：分组卷积（维度扩展）→ PixelShuffle（空间上采样）→ 1×1卷积（通道恢复）
        self.sp_ch_unsqueeze = nn.Sequential(
            nn.Conv2d(sque_sp_dim, shuf_sp_dim, 1, groups=sque_ch_dim),  # 分组卷积扩展维度：sque_sp_dim → shuf_sp_dim
            nn.PixelShuffle(shuffle),  # 空间上采样：H/shuffle → H，通道数→shuf_sp_dim/(shuffle²)=sque_ch_dim
            nn.Conv2d(sque_ch_dim, embed_dim, 1)  # 通道恢复：sque_ch_dim → embed_dim
        )

    def forward(self, x):
        """
        前向传播：CANB完整流程（压缩→分组重排→注意力→恢复）
        Args:
            x: 输入特征，shape=[B, embed_dim, H, W]
        Returns:
            x: 注意力增强后的特征，shape=[B, embed_dim, H, W]
        """
        # 1. 通道-空间联合压缩：[B, embed_dim, H, W] → [B, sque_sp_dim, H/shuffle, W/shuffle]
        x = self.ch_sp_squeeze(x)

        # 2. 分组索引重组（适配通道注意力计算）
        group_num = self.sque_ch_dim  # 分组数=通道压缩后维度
        each_group = self.sque_sp_dim // self.sque_ch_dim  # 每个分组的通道数
        idx = [i + j * group_num for i in range(group_num) for j in range(each_group)]  # 分组索引：按组聚集通道
        x = x[:, idx, :, :]  # [B, sque_sp_dim, H/shuffle, W/shuffle] → 分组后的特征

        # 3. 通道注意力计算：捕捉通道依赖→[B, sque_sp_dim, H/shuffle, W/shuffle]
        x = self.channel_attention(x)

        # 4. 分组索引反重组（适配空间注意力计算）
        nidx = [i + j * each_group for i in range(each_group) for j in range(group_num)]  # 反重组索引：调整通道顺序
        x = x[:, nidx, :, :]  # 调整后的特征，适配空间注意力分组

        # 5. 空间注意力计算：捕捉位置依赖→[B, sque_sp_dim, H/shuffle, W/shuffle]
        x = self.spatial_attention(x)

        # 6. 空间-通道联合恢复：[B, sque_sp_dim, H/shuffle, W/shuffle] → [B, embed_dim, H, W]
        x = self.sp_ch_unsqueeze(x)
        return x


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    embed_dim, squeezes, shuffle, expan_att_chans = 64, (4, 8), 16, 4

    x = torch.randn(1, 64, 32, 32).to(device)
    model = CondensedAttentionNeuralBlock(embed_dim, squeezes, shuffle, expan_att_chans).to(device)

    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN、小红书：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)