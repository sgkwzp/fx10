import torch
from torch import nn
from torch.nn import Dropout, Softmax
from einops import rearrange, repeat

# 全局交叉注意力模块：在整个特征图尺度上实现标记样本与未标记样本的交互
class Cross_Attention_Global(nn.Module):
    def __init__(self, num_heads, embedding_channels, attention_dropout_rate):
        super().__init__()
        self.KV_size = embedding_channels * num_heads
        self.num_heads = num_heads
        self.attention_head_size = embedding_channels

        # 保持原有的线性变换层
        self.q = nn.Linear(embedding_channels, embedding_channels * self.num_heads, bias=False)
        self.k = nn.Linear(embedding_channels, embedding_channels * self.num_heads, bias=False)
        self.v = nn.Linear(embedding_channels, embedding_channels * self.num_heads, bias=False)
        self.psi = nn.InstanceNorm2d(1)
        self.softmax = Softmax(dim=3)
        self.out = nn.Linear(embedding_channels * self.num_heads, embedding_channels, bias=False)
        self.attn_dropout = Dropout(attention_dropout_rate)
        self.proj_dropout = Dropout(attention_dropout_rate)

    def multi_head_rep(self, x):
        """将特征转换为多头表示"""
        new_x_shape = x.size()[:-1] + (self.num_heads, self.attention_head_size)
        x = x.view(*new_x_shape)
        return x.permute(0, 2, 1, 3)  # (b, num_heads, hw, embedding_channels)

    def forward(self, emb, pred_type):
        # 输入维度: (b, c, h, w)
        b, c, h, w = emb.shape
        # 空间维度展平: (b, c, h*w) -> 转置为 (b, h*w, c) 适应线性层
        emb_flat = rearrange(emb, 'b c h w -> b (h w) c')

        if pred_type == "labeled":
            # 分割标记和未标记样本
            emb_l, emb_u = torch.split(emb_flat, emb_flat.size(0) // 2, dim=0)
            _, N, C = emb_u.size()

            # 计算查询、键、值 (未标记 -> 标记)
            q_u2l = self.q(emb_u.detach())
            k_u2l = self.k(emb_l)
            v_u2l = self.v(emb_l)

            batch_size = q_u2l.size(0)
            # 重排键和值并复制
            k_u2l = rearrange(k_u2l, 'b n c -> n (b c)')
            v_u2l = rearrange(v_u2l, 'b n c -> n (b c)')
            k_u2l = repeat(k_u2l, 'n bc -> r n bc', r=batch_size)
            v_u2l = repeat(v_u2l, 'n bc -> r n bc', r=batch_size)

            # 调整维度以进行矩阵乘法
            q_u2l = q_u2l.unsqueeze(1).transpose(-1, -2)
            k_u2l = k_u2l.unsqueeze(1)
            v_u2l = v_u2l.unsqueeze(1).transpose(-1, -2)

            # 计算注意力并应用dropout和softmax
            cross_attn_u2l = torch.matmul(q_u2l, k_u2l)
            cross_attn_u2l = self.attn_dropout(self.softmax(self.psi(cross_attn_u2l)))
            cross_attn_u2l = torch.matmul(cross_attn_u2l, v_u2l)

            # 重排并通过输出层
            cross_attn_u2l = cross_attn_u2l.permute(0, 3, 2, 1).contiguous()
            new_shape_u2l = cross_attn_u2l.size()[:-2] + (self.KV_size,)
            cross_attn_u2l = cross_attn_u2l.view(*new_shape_u2l)
            out_u2l = self.out(cross_attn_u2l)
            out_u2l = self.proj_dropout(out_u2l)

            # 计算查询、键、值 (标记 -> 未标记)
            q_l2u = self.q(emb_l)
            k_l2u = self.k(emb_u.detach())
            v_l2u = self.v(emb_u.detach())

            # 重排键和值并复制
            k_l2u = rearrange(k_l2u, 'b n c -> n (b c)')
            v_l2u = rearrange(v_l2u, 'b n c -> n (b c)')
            k_l2u = repeat(k_l2u, 'n bc -> r n bc', r=batch_size)
            v_l2u = repeat(v_l2u, 'n bc -> r n bc', r=batch_size)

            # 调整维度以进行矩阵乘法
            q_l2u = q_l2u.unsqueeze(1).transpose(-1, -2)
            k_l2u = k_l2u.unsqueeze(1)
            v_l2u = v_l2u.unsqueeze(1).transpose(-1, -2)

            # 计算注意力并应用dropout和softmax
            cross_attn_l2u = torch.matmul(q_l2u, k_l2u)
            cross_attn_l2u = self.attn_dropout(self.softmax(self.psi(cross_attn_l2u)))
            cross_attn_l2u = torch.matmul(cross_attn_l2u, v_l2u)

            # 重排并通过输出层
            cross_attn_l2u = cross_attn_l2u.permute(0, 3, 2, 1).contiguous()
            new_shape_l2u = cross_attn_l2u.size()[:-2] + (self.KV_size,)
            cross_attn_l2u = cross_attn_l2u.view(*new_shape_l2u)
            out_l2u = self.out(cross_attn_l2u)
            out_l2u = self.proj_dropout(out_l2u)

            # 拼接结果并恢复空间维度
            out = torch.cat([out_l2u, out_u2l], dim=0)
            # 从 (b, h*w, c) 恢复为 (b, c, h, w)
            return rearrange(out, 'b (h w) c -> b c h w', h=h, w=w)

        if pred_type == "unlabeled":
            # 分割标记和未标记样本
            emb_l, emb_u = torch.split(emb_flat, emb_flat.size(0) // 2, dim=0)
            _, N, C = emb_u.size()

            # 计算自注意力
            q = self.q(emb_flat)
            k = self.k(emb_flat)
            v = self.v(emb_flat)

            # 转换为多头表示
            mh_q = self.multi_head_rep(q).transpose(-1, -2)
            mh_k = self.multi_head_rep(k)
            mh_v = self.multi_head_rep(v).transpose(-1, -2)

            # 计算注意力
            self_attn = torch.matmul(mh_q, mh_k)
            self_attn = self.attn_dropout(self.softmax(self.psi(self_attn)))
            self_attn = torch.matmul(self_attn, mh_v)

            # 重排并通过输出层
            self_attn = self_attn.permute(0, 3, 2, 1).contiguous()
            new_shape = self_attn.size()[:-2] + (self.KV_size,)
            self_attn = self_attn.view(*new_shape)
            out = self.out(self_attn)
            out = self.proj_dropout(out)

            # 恢复空间维度
            return rearrange(out, 'b (h w) c -> b c h w', h=h, w=w)

# 局部交叉注意力模块：在补丁(patch)尺度上实现交互（限制注意力范围）
class Cross_Attention_Local(nn.Module):
    def __init__(self, num_heads, embedding_channels, attention_dropout_rate, patch_size=(2, 2)):
        super().__init__()
        self.KV_size = embedding_channels * num_heads
        self.patch_size = patch_size  # 2D补丁大小 (ph, pw)
        self.embedding_channels = embedding_channels
        self.num_heads = num_heads
        self.attention_head_size = embedding_channels

        # 保持原有的线性变换层
        self.q = nn.Linear(embedding_channels, embedding_channels * self.num_heads, bias=False)
        self.k = nn.Linear(embedding_channels, embedding_channels * self.num_heads, bias=False)
        self.v = nn.Linear(embedding_channels, embedding_channels * self.num_heads, bias=False)
        self.psi = nn.InstanceNorm2d(1)
        self.softmax = Softmax(dim=3)
        self.out = nn.Linear(embedding_channels * self.num_heads, embedding_channels, bias=False)
        self.attn_dropout = Dropout(attention_dropout_rate)
        self.proj_dropout = Dropout(attention_dropout_rate)

    def multi_head_rep(self, x):
        """将特征转换为多头表示"""
        new_x_shape = x.size()[:-1] + (self.num_heads, self.attention_head_size)
        x = x.view(*new_x_shape)
        return x.permute(0, 2, 1, 3)  # (b, num_heads, hw, embedding_channels)

    def forward(self, emb, pred_type):
        # 输入维度: (b, c, h, w) 2D输入
        b, c, h, w = emb.shape
        ph, pw = self.patch_size  # 2D补丁高度和宽度

        # 分割空间维度为补丁并展平: (b, c, h, w) -> (b, (h/ph * w/pw), (ph * pw), c)
        # 确保h和w能被补丁大小整除
        emb_patched = rearrange(
            emb,
            'b c (h ph) (w pw) -> b (h w) (ph pw) c',
            ph=ph, pw=pw, h=h // ph, w=w // pw
        )
        # 转换为 (total_patches, patches_per_group, c) 适应线性层
        emb_flat = rearrange(emb_patched, 'b n p c -> (b n) p c')

        # 后续逻辑与Global模块类似，但注意力计算限制在每个补丁内部
        # （仅在局部补丁内计算Q/K/V交互，减少计算量并聚焦局部特征）

        if pred_type == "labeled":
            # 分割标记和未标记样本
            emb_l, emb_u = torch.split(emb_flat, emb_flat.size(0) // 2, dim=0)
            _, N, C = emb_u.size()

            # 计算查询、键、值 (未标记 -> 标记)
            q_u2l = self.q(emb_u.detach())
            k_u2l = self.k(emb_l)
            v_u2l = self.v(emb_l)

            # 重排和复制操作
            k_u2l = rearrange(k_u2l, 'b n c -> n (b c)')
            v_u2l = rearrange(v_u2l, 'b n c -> n (b c)')
            k_u2l = repeat(k_u2l, 'n bc -> r n bc', r=2)
            v_u2l = repeat(v_u2l, 'n bc -> r n bc', r=2)

            # 调整维度以进行局部注意力计算
            mh_q_u2l = rearrange(
                q_u2l,
                '(b h w) (ph pw) (c heads) -> (b h w) (c heads) (ph pw)',
                ph=ph, pw=pw, b=b // 2, h=h // ph, w=w // pw,
                c=self.embedding_channels, heads=self.num_heads
            ).unsqueeze(1)

            mh_k_u2l = rearrange(
                k_u2l,
                'r (ph pw) (b h w c heads) -> (r h w)(ph pw)(b c heads)',
                r=2, ph=ph, pw=pw, b=b // 2, h=h // ph, w=w // pw,
                c=self.embedding_channels, heads=self.num_heads
            ).unsqueeze(1)

            mh_v_u2l = rearrange(
                v_u2l,
                'r (ph pw) (b h w c heads) -> (r h w) (b c heads) (ph pw)',
                r=2, ph=ph, pw=pw, b=b // 2, h=h // ph, w=w // pw,
                c=self.embedding_channels, heads=self.num_heads
            ).unsqueeze(1)

            # 计算注意力
            self_attn_u2l = torch.matmul(mh_q_u2l, mh_k_u2l)
            self_attn_u2l = self.attn_dropout(self.softmax(self.psi(self_attn_u2l)))
            self_attn_u2l = torch.matmul(self_attn_u2l, mh_v_u2l)

            # 重排并通过输出层
            self_attn_u2l = rearrange(
                self_attn_u2l.squeeze(1),
                '(b h w) (c heads) (ph pw) -> b (h ph w pw) (c heads)',
                ph=ph, pw=pw, b=b // 2, h=h // ph, w=w // pw,
                c=self.embedding_channels, heads=self.num_heads
            )
            out_u2l = self.out(self_attn_u2l)
            out_u2l = self.proj_dropout(out_u2l)

            # 计算查询、键、值 (标记 -> 未标记)
            q_l2u = self.q(emb_l)
            k_l2u = self.k(emb_u.detach())
            v_l2u = self.v(emb_u.detach())

            # 重排和复制操作
            k_l2u = rearrange(k_l2u, 'b n c -> n (b c)')
            v_l2u = rearrange(v_l2u, 'b n c -> n (b c)')
            k_l2u = repeat(k_l2u, 'n bc -> r n bc', r=2)
            v_l2u = repeat(v_l2u, 'n bc -> r n bc', r=2)

            # 调整维度以进行局部注意力计算
            mh_q_l2u = rearrange(
                q_l2u,
                '(b h w) (ph pw) (c heads) -> (b h w) (c heads) (ph pw)',
                ph=ph, pw=pw, b=b // 2, h=h // ph, w=w // pw,
                c=self.embedding_channels, heads=self.num_heads
            ).unsqueeze(1)

            mh_k_l2u = rearrange(
                k_l2u,
                'r (ph pw) (b h w c heads) -> (r h w)(ph pw)(b c heads)',
                r=2, ph=ph, pw=pw, b=b // 2, h=h // ph, w=w // pw,
                c=self.embedding_channels, heads=self.num_heads
            ).unsqueeze(1)

            mh_v_l2u = rearrange(
                v_l2u,
                'r (ph pw) (b h w c heads) -> (r h w) (b c heads) (ph pw)',
                r=2, ph=ph, pw=pw, b=b // 2, h=h // ph, w=w // pw,
                c=self.embedding_channels, heads=self.num_heads
            ).unsqueeze(1)

            # 计算注意力
            self_attn_l2u = torch.matmul(mh_q_l2u, mh_k_l2u)
            self_attn_l2u = self.attn_dropout(self.softmax(self.psi(self_attn_l2u)))
            self_attn_l2u = torch.matmul(self_attn_l2u, mh_v_l2u)

            # 重排并通过输出层
            self_attn_l2u = rearrange(
                self_attn_l2u.squeeze(1),
                '(b h w) (c heads) (ph pw) -> b (h ph w pw) (c heads)',
                ph=ph, pw=pw, b=b // 2, h=h // ph, w=w // pw,
                c=self.embedding_channels, heads=self.num_heads
            )
            out_l2u = self.out(self_attn_l2u)
            out_l2u = self.proj_dropout(out_l2u)

            # 拼接结果并恢复空间维度
            out = torch.cat([out_l2u, out_u2l], dim=0)
            return rearrange(out, 'b (h w) c -> b c h w', h=h, w=w)

        if pred_type == "unlabeled":
            # 分割标记和未标记样本
            emb_l, emb_u = torch.split(emb_flat, emb_flat.size(0) // 2, dim=0)
            _, N, C = emb_u.size()

            # 计算自注意力
            q = self.q(emb_flat)
            k = self.k(emb_flat)
            v = self.v(emb_flat)

            # 调整维度以进行局部注意力计算
            mh_q = rearrange(
                q,
                '(b h w) (ph pw) (c heads) -> (b h w) heads c (ph pw)',
                ph=ph, pw=pw, h=h // ph, w=w // pw,
                c=self.embedding_channels, heads=self.num_heads
            )

            mh_k = rearrange(
                k,
                '(b h w) (ph pw) (c heads) -> (b h w) heads (ph pw) c',
                ph=ph, pw=pw, h=h // ph, w=w // pw,
                c=self.embedding_channels, heads=self.num_heads
            )

            mh_v = rearrange(
                v,
                '(b h w) (ph pw) (c heads) -> (b h w) heads c (ph pw)',
                ph=ph, pw=pw, h=h // ph, w=w // pw,
                c=self.embedding_channels, heads=self.num_heads
            )

            # 计算注意力
            self_attn = torch.matmul(mh_q, mh_k)
            self_attn = self.attn_dropout(self.softmax(self.psi(self_attn)))
            self_attn = torch.matmul(self_attn, mh_v)

            # 重排并通过输出层
            self_attn = rearrange(
                self_attn,
                '(b h w) heads c (ph pw) -> b (h ph w pw) (c heads)',
                ph=ph, pw=pw, b=b, h=h // ph, w=w // pw,
                c=self.embedding_channels, heads=self.num_heads
            )
            out = self.out(self_attn)
            out = self.proj_dropout(out)

            # 恢复空间维度
            return rearrange(out, 'b (h w) c -> b c h w', h=h, w=w)

if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    print("微信公众号：十小大的底层视觉工坊")
    print("知乎、CSDN：十小大")

    # global
    x_global = torch.randn(4, 64, 32, 32).to(device)  # (b, c, h, w)
    model_global = Cross_Attention_Global(num_heads=8, embedding_channels=64, attention_dropout_rate=0.1)
    model_global.to(device)
    y_global = model_global(x_global, 'labeled')
    print("Global注意力输入维度:", x_global.shape)
    print("Global注意力输出维度:", y_global.shape)

    # local
    x_local = torch.randn(4, 64, 32, 32).to(device)  # (b, c, h, w)
    model_local = Cross_Attention_Local(num_heads=8, embedding_channels=64, attention_dropout_rate=0.1)
    model_local.to(device)
    y_local = model_local(x_local, 'labeled')
    print("local注意力输入维度:", x_local.shape)
    print("local注意力输出维度:", y_local.shape)