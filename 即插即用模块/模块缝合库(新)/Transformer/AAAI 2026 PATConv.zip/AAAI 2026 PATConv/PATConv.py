# 部分注意力（Partial Attention,PAT）三大核心模块
# 核心设计：通过“通道部分注意力（PAT_ch）、空间部分注意力（PAT_sp）、尺度特征注意力（PAT_sf）”的分工协作，
# 分别优化通道分布、空间位置、尺度关联三大维度，在降低计算量的同时实现精准特征增强

import torch
import torch.nn as nn
from irpe import build_rpe


# PAT_ch
class SRM(nn.Module):
    """
    风格感知通道部分注意力模块（PAT_ch）
    功能：基于特征的统计分布（均值+标准差）生成通道注意力权重，自适应增强关键通道
    核心设计：
        - 统计特征建模：通过均值和标准差捕捉通道的全局分布信息（风格特征）
        - 轻量化通道映射：1×2卷积融合统计特征，避免全连接层的高参数量
        - 硬Sigmoid激活：精准筛选关键通道，抑制冗余信息
    """
    def __init__(self, channel):
        super().__init__()
        self.cfc1 = nn.Conv2d(channel, channel, kernel_size=(1,2), bias=False)
        #self.cfc2 = nn.Conv2d(channel, channel, kernel_size=1, bias=False)
        self.bn = nn.BatchNorm2d(channel)
        self.sigmoid = nn.Hardsigmoid()

    def forward(self, x):
        b, c, h, w = x.shape
        # style pooling
        mean = x.reshape(b, c, -1).mean(-1).view(b,c,1,1)
        std = x.reshape(b, c, -1).std(-1).view(b,c,1,1)
        #max_value = torch.max(x.reshape(b, c, -1), -1)[0].view(b,c,1,1)
        u = torch.cat([mean, std], dim=-1)
        # style integration
        z = self.cfc1(u)
        #z = self.act(z)
        #z = self.cfc2(z)
        z = self.bn(z)
        g = self.sigmoid(z)
        g = g.reshape(b, c, 1, 1)
        return x * g.expand_as(x)


# PAT_sp
class partial_spatial_attn_layer_reverse(nn.Module):
    """
    部分空间注意力模块（PAT_sp）
    功能：拆分特征通道为“空间注意力分支”和“普通卷积分支”，仅对部分通道计算空间注意力，兼顾效率与效果
    核心设计：
        - 通道部分参与：仅让未触碰通道（dim_untouched）计算空间注意力，降低计算量
        - 双分支并行处理：注意力分支强化空间关联，卷积分支保留基础特征
        - 硬Sigmoid激活：生成空间权重，精准定位关键区域
    """
    def __init__(self, dim, n_head, partial=0.5):
        super().__init__()
        self.dim = dim
        self.dim_conv = int(partial * dim)
        self.dim_untouched = dim - self.dim_conv
        self.nhead = n_head
        self.conv = nn.Conv2d(self.dim_conv, self.dim_conv, 1, bias=False)
        self.conv_attn = nn.Conv2d(self.dim_untouched, n_head, 1, bias=False)
        self.norm = nn.BatchNorm2d(self.dim_untouched)
        self.norm2 = nn.BatchNorm2d(self.dim_conv)
        #self.act2 = nn.GELU()
        self.act = nn.Hardsigmoid()

    def forward(self, x):
        b, c, h, w = x.shape
        x1, x2 = torch.split(x, [self.dim_untouched, self.dim_conv], 1)
        weight =self.act(self.conv_attn(x1))
        x1 = x1 * weight
        x1 = self.norm(x1)
        #x2 = self.act2(x2)
        x2 = self.norm2(x2)
        x2 = self.conv(x2)
        x = torch.cat((x1, x2), 1)
        return x


# PAT_sf
class RPEAttention(nn.Module):
    '''
    相对位置编码注意力模块（PAT_sf：尺度特征注意力）
    功能：结合相对位置编码（RPE）的多头自注意力，捕捉不同尺度下的长距离空间依赖
    核心设计：
        - 相对位置编码：精准建模像素间的相对位置关系，适配多尺度特征
        - 多头注意力：并行捕捉不同尺度的特征关联
        - 完整QKV流程：标准自注意力架构，保证特征表达能力
    '''
    def __init__(self, dim, num_heads=8, qkv_bias=False, qk_scale=None, attn_drop=0.0, proj_drop=0.0, rpe_config=None):
        super().__init__()
        self.num_heads = num_heads
        head_dim = dim // num_heads
        # NOTE scale factor was wrong in my original version, can set manually to be compat with prev weights
        self.scale = qk_scale or head_dim ** -0.5

        self.qkv = nn.Linear(dim, dim * 3, bias=qkv_bias)
        self.attn_drop = nn.Dropout(attn_drop)
        self.proj = nn.Linear(dim, dim)
        self.proj_drop = nn.Dropout(proj_drop)

        # image relative position encoding
        self.rpe_q, self.rpe_k, self.rpe_v = build_rpe(rpe_config, head_dim=head_dim, num_heads=num_heads)

    def forward(self, x):
        B, C, h, w = x.shape
        x = x.view(B, C, h*w).transpose(1,2)
        B, N, C = x.shape
        qkv = self.qkv(x).reshape(B, N, 3, self.num_heads, C // self.num_heads).permute(2, 0, 3, 1, 4)
        q, k, v = qkv[0], qkv[1], qkv[2]   # make torchscript happy (cannot use tensor as tuple)

        q *= self.scale

        attn = (q @ k.transpose(-2, -1))

        # image relative position on keys
        if self.rpe_k is not None:
            #attn += self.rpe_k(q)
            attn += self.rpe_k(q, h, w)
        # image relative position on queries
        if self.rpe_q is not None:
            attn += self.rpe_q(k * self.scale).transpose(2, 3)

        attn = attn.softmax(dim=-1)
        attn = self.attn_drop(attn)

        out = attn @ v

        # image relative position on values
        if self.rpe_v is not None:
            out += self.rpe_v(attn)

        x = out.transpose(1, 2).reshape(B, N, C)
        x = self.proj(x)
        x = self.proj_drop(x)
        x = x.transpose(1,2).view(B, C, h, w)
        return x


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(2, 64, 32, 32).to(device)

    model1 = SRM(64).to(device)
    model2 = partial_spatial_attn_layer_reverse(64, 32).to(device)
    model3 = RPEAttention(64, 4).to(device)

    y1 = model1(x)
    y2 = model2(x)
    y3 = model3(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN、小红书：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y1.shape)