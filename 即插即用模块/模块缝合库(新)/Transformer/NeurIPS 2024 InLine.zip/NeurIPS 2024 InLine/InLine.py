import torch
import torch.nn as nn
import torch.nn.functional as F


# class InLineAttention(nn.Module):
#     """
#     内射线性注意力模块（Injective Linear Attention, InLine）
#     核心设计：
#         - 线性注意力简化：通过K/V预融合替代传统QKV三方交互，将复杂度从O(N²)降至O(N)
#         - 残差卷积增强：引入1×1分组卷积+GELU的残差分支，强化局部特征，弥补线性注意力局部细节捕捉不足
#         - 自适应尺度调节：通过自适应性因子平衡注意力与残差的贡献，提升训练稳定性
#         - 窗口适配设计：支持窗口化输入，适配高分辨率特征处理
#     Args:
#         dim: 输入/输出特征通道数
#         num_heads: 注意力头数（需整除dim）
#         qkv_bias: QKV线性层是否带偏置
#         attn_drop: 注意力 dropout 概率
#         proj_drop: 输出投影 dropout 概率
#         window: 窗口大小（适配窗口化输入场景）
#     """
#
#     def __init__(self, dim, num_heads=8, qkv_bias=False, attn_drop=0., proj_drop=0.,
#                  window=14, **kwargs):
#         super().__init__()
#         self.dim = dim
#         self.num_heads = num_heads
#         self.head_dim = dim // num_heads
#         self.scale = self.head_dim ** -0.5  # 注意力缩放因子
#         self.window = window  # 窗口大小
#
#         # QKV生成：单线性层输出3×dim，替代传统三个独立线性层
#         self.qkv = nn.Linear(dim, dim * 3, bias=qkv_bias)
#         self.attn_drop = nn.Dropout(attn_drop)  # 注意力 dropout
#         self.proj = nn.Linear(dim, dim)  # 输出投影层
#         self.proj_drop = nn.Dropout(proj_drop)  # 输出 dropout
#         self.softmax = nn.Softmax(dim=-1)
#
#         # 残差卷积分支：强化局部特征，分组卷积轻量化设计
#         self.residual = nn.Sequential(
#             nn.Conv1d(dim, dim, kernel_size=1, groups=num_heads),  # 分组1×1卷积
#             nn.GELU(),  # 非线性激活
#             nn.Conv1d(dim, dim * 9, kernel_size=1, groups=num_heads)  # 生成3×3卷积核参数
#         )
#
#     def forward(self, x):
#         """
#         前向传播：QKV生成→线性注意力计算→残差卷积增强→输出投影
#         Args:
#             x: 输入特征，shape=[num_windows×B, N, C]（窗口化输入，N=window×window）
#         Returns:
#             增强后的特征，shape=[num_windows×B, N, C]（与输入维度一致）
#         """
#         b, n, c = x.shape  # b=批量（含窗口数），n=每个窗口的token数，c=通道数
#         h = w = int(n ** 0.5)  # 假设token数为正方形窗口（n=h×w）
#         num_heads = self.num_heads
#         head_dim = self.head_dim
#
#         # 1. QKV生成与拆分
#         qkv = self.qkv(x).reshape(b, n, 3, c).permute(2, 0, 1, 3)  # [3, b, n, c]
#         q, k, v = qkv[0], qkv[1], qkv[2]  # 拆分Q、K、V：各[b, n, c]
#
#         # 2. 多头注意力维度调整
#         q = q.reshape(b, n, num_heads, head_dim).permute(0, 2, 1, 3)  # [b, heads, n, head_dim]
#         k = k.reshape(b, n, num_heads, head_dim).permute(0, 2, 1, 3)
#         v = v.reshape(b, n, num_heads, head_dim).permute(0, 2, 1, 3)
#
#         # 3. 生成残差卷积核：基于全局均值特征
#         res_weight = self.residual(x.mean(dim=1).unsqueeze(dim=-1)).reshape(b * c, 1, 3, 3)  # [b×c, 1, 3, 3]
#
#         # 4. 线性注意力计算（K/V预融合，降低复杂度）
#         # 尺度平衡：拆分缩放因子，避免数值不稳定
#         kv = (k.transpose(-2, -1) * (self.scale / n) ** 0.5) @ (
#                     v * (self.scale / n) ** 0.5)  # [b, heads, head_dim, head_dim]
#
#         # 注意力输出 = Q×KV + 偏置项（平衡全局与局部）
#         # 除法改为减法，原始是1 / (q @ k.mean(dim=-2, keepdim=True).transpose(-2, -1))
#         x_attn = q @ kv + (1 - q @ k.mean(dim=2, keepdim=True).transpose(-2, -1) * self.scale) * v.mean(dim=2, keepdim=True)
#
#         # 5. 维度恢复：多头→单头
#         x = x_attn.transpose(1, 2).reshape(b, n, c)  # [b, n, c]
#
#         # 6. 残差卷积增强：处理除第一个token外的特征（适配窗口化局部增强）
#         hw = n - 1  # 待增强的token数（排除首个token）
#         h_new = int(hw ** 0.5)  # 恢复空间尺寸（假设正方形）
#         w_new = hw // h_new
#         # 尺寸校准（确保空间尺寸乘积等于token数）
#         if h_new * w_new != hw:
#             h_new = int(hw ** 0.5) + 1
#             w_new = hw // h_new
#         # 维度转换：[b, heads, n-1, head_dim]→[1, b×c, h_new, w_new]（适配分组卷积）
#         v_ = v[:, :, 1:, :].transpose(1, 2).reshape(b, h_new, w_new, c).permute(0, 3, 1, 2).reshape(1, b * c, h_new,
#                                                                                                     w_new)
#         # 分组卷积残差：每个通道独立卷积，强化局部特征
#         residual = F.conv2d(v_, res_weight, None, padding=(1, 1), groups=b * c)
#         # 残差融合：注意力特征 + 卷积残差
#         x[:, 1:, :] = x[:, 1:, :] + residual.reshape(b, c, hw).permute(0, 2, 1)
#
#         # 7. 输出投影与dropout
#         x = self.proj(x)
#         x = self.proj_drop(x)
#
#         return x


class InLineAttention(nn.Module):
    def __init__(self, dim, num_heads=8, qkv_bias=False, attn_drop=0., proj_drop=0.,
                 window=14, **kwargs):
        super().__init__()
        self.dim = dim
        self.num_heads = num_heads
        head_dim = dim // num_heads
        self.scale = head_dim ** -0.5
        self.qkv = nn.Linear(dim, dim * 3, bias=qkv_bias)
        self.attn_drop = nn.Dropout(attn_drop)
        self.proj = nn.Linear(dim, dim)
        self.proj_drop = nn.Dropout(proj_drop)
        self.softmax = nn.Softmax(dim=-1)
        self.window = window

        self.residual = nn.Sequential(
            nn.Conv1d(dim, dim, kernel_size=1, groups=num_heads),
            nn.GELU(),
            nn.Conv1d(dim, dim * 9, kernel_size=1, groups=num_heads)
        )

    def forward(self, x):
        """
        Args:
            x: input features with shape of (num_windows*B, N, C)
            mask: (0/-inf) mask with shape of (num_windows, Wh*Ww, Wh*Ww) or None
        """
        b, n, c = x.shape
        h = int(n ** 0.5)
        w = int(n ** 0.5)
        num_heads = self.num_heads
        head_dim = c // num_heads
        qkv = self.qkv(x).reshape(b, n, 3, c).permute(2, 0, 1, 3)
        q, k, v = qkv[0], qkv[1], qkv[2]  # make torchscript happy (cannot use tensor as tuple)
        # q, k, v: b, n, c

        q = q.reshape(b, n, num_heads, head_dim).permute(0, 2, 1, 3)
        k = k.reshape(b, n, num_heads, head_dim).permute(0, 2, 1, 3)
        v = v.reshape(b, n, num_heads, head_dim).permute(0, 2, 1, 3)

        res_weight = self.residual(x.mean(dim=1).unsqueeze(dim=-1)).reshape(b * c, 1, 3, 3)

        # The self.scale / n = head_dim ** -0.5 / n is a scale factor used in InLine attention.
        # This factor can be equivalently achieved by scaling \phi(Q) = \phi(Q) * self.scale / n
        # Therefore, we omit it in eq. 5 of the paper for simplicity.
        kv = (k.transpose(-2, -1) * (self.scale / n) ** 0.5) @ (v * (self.scale / n) ** 0.5)
        x = q @ kv + (1 - q @ k.mean(dim=2, keepdim=True).transpose(-2, -1) * self.scale) * v.mean(dim=2, keepdim=True)

        x = x.transpose(1, 2).reshape(b, n, c)
        v_ = v[:, :, 1:, :].transpose(1, 2).reshape(b, h, w, c).permute(0, 3, 1, 2).reshape(1, b * c, h, w)
        residual = F.conv2d(v_, res_weight, None, padding=(1, 1), groups=b * c)
        x[:, 1:, :] = x[:, 1:, :] + residual.reshape(b, c, n - 1).permute(0, 2, 1)

        x = self.proj(x)
        x = self.proj_drop(x)
        return x


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 16*16, 64).to(device)
    model = InLineAttention(64, 4).to(device)

    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN、小红书：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)