import torch
import torch.nn as nn
from einops import rearrange  # 张量重排工具，简化多头注意力的维度变换

class refine_att(nn.Module):
    """
    T-MSA专属：多尺度卷积相对位置编码模块
    对应结构图中的位置增强分支，为不同注意力头分配不同窗口尺寸的分组卷积，捕捉多尺度空间依赖
    Args:
        Ch: 单注意力头的通道数
        h: 注意力头总数
        window: 字典格式，{窗口尺寸: 对应头数}，为不同头分配不同感受野
        path: 并行注意力路径数，对应多路径分组设计
    """
    def __init__(self, Ch, h, window, path):
        super().__init__()
        # 解析窗口配置，为不同头分配不同尺寸的卷积
        if isinstance(window, int):
            window = {window: h}
        self.window = window
        self.conv_list = nn.ModuleList()
        self.head_splits = []
        self.num_path = path

        # 为每个窗口尺寸构建分组卷积，对应不同的注意力头
        for cur_window, cur_head_split in window.items():
            dilation = 1
            padding_size = (cur_window + (cur_window - 1) * (dilation - 1)) // 2
            # 分组卷积：组内共享权重，适配多路径+多头设计
            cur_conv = nn.Conv2d(
                cur_head_split * Ch * path,
                cur_head_split * path,
                kernel_size=(cur_window, cur_window),
                padding=(padding_size, padding_size),
                dilation=dilation,
                groups=cur_head_split * path,
            )
            self.conv_list.append(cur_conv)
            self.head_splits.append(cur_head_split)
        self.channel_splits = [x * Ch for x in self.head_splits]

    def forward(self, v, size):
        """前向传播：为value特征生成多尺度位置权重"""
        B, h, N, Ch = v.shape
        H, W = size
        # 张量重排：从序列格式转为图像格式，适配卷积操作
        v_img = rearrange(v, "B h (H W) Ch -> B h Ch H W", H=H, W=W)
        v_img = rearrange(v_img, "b h Ch H W -> b (h Ch) H W", H=H, W=W)
        # 按头数拆分，对应不同窗口的卷积
        v_img_list = torch.split(v_img, self.channel_splits, dim=1)
        # 多路径维度适配
        v_img_list_reshape = [rearrange(x, "(p B) c H W -> B (p c) H W", H=H, W=W, p=self.num_path) for x in v_img_list]
        # 多尺度卷积生成位置编码
        v_att_list = [conv(x) for conv, x in zip(self.conv_list, v_img_list_reshape)]
        # 维度还原
        v_img_list_reshape = [rearrange(x, "B (p c) H W -> (p B) c H W", H=H, W=W, p=self.num_path) for x in v_att_list]
        v_att = torch.cat(v_img_list_reshape, dim=1)
        # 转回序列格式，与注意力输出对齐
        v_att = rearrange(v_att, "B (h Ch) H W -> B h (H W) Ch", h=h)
        return v_att

class Attention(nn.Module):
    """
    泰勒展开多头自注意力(T-MSA)核心模块
    核心创新：泰勒展开分解softmax注意力，结合矩阵结合律将O(n²)复杂度降为O(n)，对应结构图中的T-MSA++
    Args:
        dim: 输入特征通道数
        num_heads: 注意力头数
        bias: 卷积是否带偏置
        qk_norm: q/k归一化开关
        path: 并行注意力路径数
        focusing_factor: 泰勒高阶项聚焦因子，对应结构图中的fm保序映射
        N: 序列最大长度
    """
    def __init__(self, dim, num_heads, bias, shared_refine_att=None, qk_norm=1, path=2, focusing_factor=8, N=256 * 256):
        super().__init__()
        self.norm = qk_norm
        self.num_heads = num_heads
        self.path = path  # 多路径并行设计
        self.focusing_factor = focusing_factor  # 泰勒高阶项聚焦因子

        # 可学习参数：温度系数、缩放系数，自适应调整注意力分布
        self.temperature = nn.Parameter(torch.ones(path, num_heads, 1, 1))
        self.scale = nn.Parameter(torch.ones(path, num_heads, 1, 1))
        self.sigmoid = nn.Sigmoid()

        # QKV生成：1×1分组卷积+3×3深度卷积，适配多路径设计，无跨路径信息泄露
        self.qkv = nn.Conv2d(dim * path, dim * 3 * path, kernel_size=1, groups=path, bias=bias)
        self.qkv_dwconv = nn.Conv2d(dim * 3 * path, dim * 3 * path, kernel_size=3, stride=1, padding=1, groups=dim * 3 * path, bias=bias)
        # 输出投影：分组卷积还原通道
        self.project_out = nn.Conv2d(dim * path, dim * path, kernel_size=1, groups=path, bias=bias)

        # 多尺度卷积相对位置编码模块
        if num_heads == 8:
            crpe_window = {3: 2, 5: 3, 7: 3}
        elif num_heads == 4:
            crpe_window = {3: 2, 5: 2}
        elif num_heads == 2:
            crpe_window = {3: 2}
        elif num_heads == 1:
            crpe_window = {3: 1}
        self.refine_att = refine_att(Ch=dim // num_heads, h=num_heads, window=crpe_window, path=path)

        # 固定参数：序列长度归一化
        self.one_M = nn.Parameter(torch.ones(1), requires_grad=False)

    def forward(self, x):
        """T-MSA前向传播全流程，对应结构图中的泰勒展开注意力计算逻辑"""
        b, c, h, w = x.shape
        relu = nn.ReLU(inplace=False)
        N = h * w  # 序列长度=像素总数

        # 步骤1：多路径维度重排，分组处理不同路径
        x = rearrange(x, '(p B) c h w -> B (p c) h w', B=b // self.path, p=self.path)
        # 步骤2：QKV生成，分组卷积保证路径独立
        qkv = self.qkv_dwconv(self.qkv(x))
        qkv = rearrange(qkv, 'B (p c) h w -> (p B) c h w', B=b // self.path, p=self.path)
        # 拆分Q、K、V三个分支，每个分支shape=(b, c, h, w)
        q, k, v = qkv.chunk(3, dim=1)

        # 步骤3：维度重排，转为多头注意力标准格式
        q = rearrange(q, 'b (head c) h w -> b head (h w) c', head=self.num_heads)
        k = rearrange(k, 'b (head c) h w -> b head c (h w)', head=self.num_heads)
        v = rearrange(v, 'b (head c) h w -> b head (h w) c', head=self.num_heads)

        # 步骤4：双归一化，对应结构图中的LN层与fm保序映射
        # 一阶项归一化：L2归一化，对应结构图中的f1(Q,K)（泰勒一阶项）
        q_norm = torch.norm(q, p=2, dim=-1, keepdim=True) + 1e-8
        q_1 = torch.div(q, q_norm)
        k_norm = torch.norm(k, p=2, dim=-2, keepdim=True) + 1e-8
        k_1 = torch.div(k, k_norm)

        # 高阶项归一化：ReLU幂次+L2归一化，对应结构图中的fr(Q,K)（泰勒高阶余项）
        q_2 = relu(q) ** self.focusing_factor
        k_2 = relu(k) ** self.focusing_factor
        q_2 = q_2 / (q_2.norm(dim=-1, keepdim=True) + 1e-8)
        k_2 = k_2 / (k_2.norm(dim=-2, keepdim=True) + 1e-8)

        # 步骤5：多尺度卷积相对位置编码生成，对应结构图中的位置增强分支
        refine_weight = self.refine_att(v, size=(h, w))
        refine_weight = self.sigmoid(refine_weight)

        # 步骤6：泰勒展开注意力计算（核心复杂度优化）
        # 利用矩阵结合律：softmax(QK^T)V ≈ 一阶项 + 高阶项，先算K@V再算Q@结果，将O(n²)降为O(n)
        attn_1 = k_1 @ v  # 一阶项中间结果
        attn_2 = k_2 @ v  # 高阶项中间结果
        scale = self.sigmoid(self.scale).repeat_interleave(b // self.path, 0)

        # 注意力分子：全局均值 + 一阶项 + 可学习加权高阶项，对应结构图中的f1+fr融合
        out_numerator = torch.sum(v, dim=-2).unsqueeze(2) + (q_1 @ attn_1) + scale * (q_2 @ attn_2)
        # 注意力分母：归一化项，保证注意力权重和为1
        one_M = self.one_M * N
        target_shape = (N, c // self.num_heads)
        expanded_tensor = one_M.expand(target_shape)
        out_denominator = expanded_tensor + q_1 @ torch.sum(k_1, dim=-1).unsqueeze(3).repeat(1, 1, 1, c // self.num_heads) + \
                          q_2 @ torch.sum(scale * k_2, dim=-1).unsqueeze(3).repeat(1, 1, 1, c // self.num_heads) + 1e-8

        # 归一化得到最终注意力输出
        out = torch.div(out_numerator, out_denominator)
        # 温度缩放 + 位置编码残差增强
        out = out * (self.temperature.repeat_interleave(b // self.path, 0)) + refine_weight

        # 步骤7：维度还原与输出投影
        out = rearrange(out, 'b head (h w) c-> b (head c) h w', head=self.num_heads, h=h, w=w)
        out = rearrange(out, '(p b) c h w-> b (p c) h w', h=h, w=w, p=self.path)
        out = self.project_out(out)
        out = rearrange(out, 'b (p c) h w-> (p b) c h w', h=h, w=w, p=self.path)

        # 输出与输入shape完全一致，即插即用
        return out


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    x = torch.randn(2, 64, 32, 32).to(device)
    model = Attention(64,8,True).to(device)
    y = model(x)
    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)