import torch
import torch.nn as nn
import torch.nn.functional as F
from einops import rearrange


class Inter_CacheModulation(nn.Module):
    """
    层间缓存调制（Inter-Modulation）：利用历史QK缓存（跨层信息）调节当前注意力权重
    核心作用：通过跨层信息交互，缓解单一层注意力的局部视野局限（如去雾任务中的全局场景关联）
    输入：
        x1: 当前层注意力权重 [B, C_i, C_i]（C_i为当前头的通道数）
        x2: 历史QK缓存 [B, C, C]（C为总通道数）
    输出：调制后的注意力权重 [B, C_i, C_i]
    """

    def __init__(self, in_c=3):
        super(Inter_CacheModulation, self).__init__()
        self.align = nn.AdaptiveAvgPool2d(in_c)  # 对齐缓存与当前权重的通道数
        self.conv_width = nn.Conv1d(in_c, 2 * in_c, kernel_size=1)  # 生成缩放（scale）和偏移（shift）参数
        self.gatingConv = nn.Conv1d(in_c, in_c, kernel_size=1)  # 门控卷积，筛选有效调制信息

    def forward(self, x1, x2):
        C = x1.shape[-1]
        # 缓存与当前权重融合→生成scale和shift→通道拆分
        x2_pW = self.conv_width(self.align(x2) + x1)
        scale, shift = x2_pW.chunk(2, dim=1)
        #  affine变换：x1 = x1*scale + shift，增强权重判别性
        x1_p = x1 * scale + shift
        # 门控机制：GELU激活+逐元素乘法，抑制无效调制信息
        x1_p = x1_p * F.gelu(self.gatingConv(x1_p))
        return x1_p


class Intra_CacheModulation(nn.Module):
    """
    层内缓存调制（Intra-Modulation）：利用当前层多头QK缓存（头间信息）调节最终特征
    核心作用：促进头间特征协同，减少多头冗余（如低光增强中不同头的亮度/纹理特征融合）
    输入：
        x1: 当前层多头注意力输出 [B, C, L]（L=序列长度）
        x2: 当前层多头QK缓存 [B, C, L]
    输出：调制后的特征 [B, C, L]
    """

    def __init__(self, embed_dim=48):
        super(Intra_CacheModulation, self).__init__()
        self.down = nn.Conv1d(embed_dim, embed_dim // 2, kernel_size=1)  # 通道压缩（降维）
        self.up = nn.Conv1d(embed_dim // 2, embed_dim, kernel_size=1)  # 通道恢复（升维）
        self.gatingConv = nn.Conv1d(embed_dim, embed_dim, kernel_size=1)  # 门控卷积，增强特征非线性

    def forward(self, x1, x2):
        # 头间缓存融合→门控激活→通道压缩→通道恢复
        x_gated = F.gelu(self.gatingConv(x2 + x1)) * (x2 + x1)  # 门控融合头间信息
        x_p = self.up(self.down(x_gated))  # 通道瓶颈结构，减少参数冗余
        return x_p


class ReGroup(nn.Module):
    """
    通道重组模块：基于通道相似性重排序并分组，为HMHA的分层多头提供独立子空间
    核心创新：打破传统MHA的等通道分配，按通道相关性分组，确保各头学习多样化特征
    输入：
        query/key/value: [B, C, L]（C=总通道数，L=序列长度）
    输出：
        分组后的query/key/value列表，每组对应一个注意力头
    """

    def __init__(self, groups=[1, 1, 2, 4]):
        super(ReGroup, self).__init__()
        self.groups = groups  # 分组比例（如[1,2,2,3]，总比例=8，对应通道占比1/8,2/8,2/8,3/8）

    def forward(self, query, key, value):
        C = query.shape[1]  # 总通道数
        # 步骤1：计算通道相关性矩阵（基于通道均值的皮尔逊相关系数）
        channel_features = query.mean(dim=0)  # [C, L]→[C, L]（批次维度平均）
        correlation_matrix = torch.corrcoef(channel_features)  # [C, C]（通道间相关性）
        mean_similarity = correlation_matrix.mean(dim=1)  # [C]（每个通道与其他通道的平均相关性）

        # 步骤2：按相关性降序重排通道（确保相似通道聚集，分组后子空间独立性更强）
        _, sorted_indices = torch.sort(mean_similarity, descending=True)
        query_sorted = query[:, sorted_indices, :]  # [B, C, L]（重排后query）
        key_sorted = key[:, sorted_indices, :]  # [B, C, L]（重排后key）
        value_sorted = value[:, sorted_indices, :]  # [B, C, L]（重排后value）

        # 步骤3：按分组比例分配通道（如总通道64，比例[1,2,2,3]→每组通道数8,16,16,24）
        query_groups = []
        key_groups = []
        value_groups = []
        start_idx = 0
        total_ratio = sum(self.groups)
        # 计算每组通道数（按比例分配，确保总和为C）
        group_sizes = [int(ratio / total_ratio * C) for ratio in self.groups]

        # 拆分通道并分组
        for group_size in group_sizes:
            end_idx = start_idx + group_size
            query_groups.append(query_sorted[:, start_idx:end_idx, :])
            key_groups.append(key_sorted[:, start_idx:end_idx, :])
            value_groups.append(value_sorted[:, start_idx:end_idx, :])
            start_idx = end_idx

        return query_groups, key_groups, value_groups


def CalculateCurrentLayerCache(x, dim=128, groups=[1, 1, 2, 4]):
    """
    计算当前层QK缓存：融合多头注意力权重，生成跨层复用的缓存信息
    输入：
        x: 多头注意力权重列表 [B, C_i, C_i]（共len(groups)个头）
        dim: 目标缓存维度（通常为总通道数）
        groups: 分组比例
    输出：当前层缓存 [B, dim, dim]
    """
    lens = len(groups)
    ceil_dim = dim  # 缓存目标维度
    for i in range(lens):
        # 提取当前头的注意力权重（detach避免梯度传播）
        qv_cache_f = x[i].clone().detach()
        # 批次维度平均，减少冗余
        qv_cache_f = torch.mean(qv_cache_f, dim=0, keepdim=True).detach()
        # 插值对齐到目标维度（确保不同头的缓存维度一致）
        update_elements = F.interpolate(
            qv_cache_f.unsqueeze(1), size=(ceil_dim, ceil_dim),
            mode='bilinear', align_corners=False
        )
        c_i = qv_cache_f.shape[-1]  # 当前头的通道数
        # 累加各头缓存（按通道占比加权，避免小头贡献被掩盖）
        if i == 0:
            qv_cache = update_elements * c_i // dim
        else:
            qv_cache = qv_cache + update_elements * c_i // dim
    return qv_cache.squeeze(1)  # 移除多余维度，输出[B, dim, dim]


class HMHA(nn.Module):
    """
    分层多头注意力（HMHA）：整合通道重组、层间/层内缓存调制、多头协同优化
    核心流程：QKV生成→通道重组分组→多头注意力计算→层间缓存调制→层内缓存调制→输出
    输入：
        x: 特征图 [B, C, H, W]
        qv_cache: 历史QK缓存（可选，初始为None）
    输出：
        out_all: 注意力增强特征 [B, C, H, W]
        qv_cache: 更新后的QK缓存 [B, C, C]
    """

    def __init__(self, dim, num_heads, bias):
        super(HMHA, self).__init__()
        self.num_heads = num_heads  # 注意力头数（与分组数一致）
        self.temperature = nn.Parameter(torch.ones(4, 1, 1))  # 多头温度参数（可学习，调节注意力锐度）

        # QKV生成：1×1卷积（降维）+ 深度可分离卷积（增强局部关联）
        self.qkv = nn.Conv2d(dim, dim * 3, kernel_size=1, bias=bias)  # 一次性生成QKV（3×dim通道）
        self.qkv_dwconv = nn.Conv2d(
            dim * 3, dim * 3, kernel_size=3, stride=1, padding=1,
            groups=dim * 3, bias=bias  # 深度可分离卷积，减少计算量
        )
        self.project_out = nn.Conv2d(dim, dim, kernel_size=1, bias=bias)  # 最终输出投影（维度恢复）

        self.group = [1, 2, 2, 3]  # 分组比例（对应4个头，总比例=8）
        # 缓存调制模块：层内1个，层间4个（每个头对应1个）
        self.intra_modulator = Intra_CacheModulation(embed_dim=dim)
        self.inter_modulator1 = Inter_CacheModulation(in_c=1 * dim // 8)  # 第1头：通道占比1/8
        self.inter_modulator2 = Inter_CacheModulation(in_c=2 * dim // 8)  # 第2头：通道占比2/8
        self.inter_modulator3 = Inter_CacheModulation(in_c=2 * dim // 8)  # 第3头：通道占比2/8
        self.inter_modulator4 = Inter_CacheModulation(in_c=3 * dim // 8)  # 第4头：通道占比3/8
        self.inter_modulators = [self.inter_modulator1, self.inter_modulator2, self.inter_modulator3,
                                 self.inter_modulator4]

        self.regroup = ReGroup(self.group)  # 通道重组模块
        self.dim = dim  # 总特征维度

    def forward(self, x, qv_cache=None):
        b, c, h, w = x.shape  # 解析输入维度

        # 步骤1：生成QKV并增强局部特征
        qkv = self.qkv_dwconv(self.qkv(x))  # [B, 3C, H, W]（QKV+深度可分离卷积）
        q, k, v = qkv.chunk(3, dim=1)  # 按通道拆分Q/K/V，各[B, C, H, W]

        # 步骤2：2D特征→3D序列（适配注意力计算）
        q = rearrange(q, 'b c h w -> b c (h w)')  # [B, C, L]（L=H×W）
        k = rearrange(k, 'b c h w -> b c (h w)')
        v = rearrange(v, 'b c h w -> b c (h w)')

        # 步骤3：通道重组分组（核心创新：按相关性分组，确保头间多样性）
        qu, ke, va = self.regroup(q, k, v)  # qu/ke/va为列表，每个元素对应一个头的Q/K/V

        # 步骤4：多头注意力计算+当前层缓存生成
        attScore = []  # 存储各头注意力权重
        tmp_cache = []  # 存储各头QK缓存（用于层内调制）
        for index in range(len(self.group)):
            query_head = qu[index]  # 当前头的Q [B, C_i, L]
            key_head = ke[index]  # 当前头的K [B, C_i, L]

            # 特征归一化：增强注意力计算的数值稳定性
            query_head = torch.nn.functional.normalize(query_head, dim=-1)
            key_head = torch.nn.functional.normalize(key_head, dim=-1)

            # 计算注意力权重：Q@K^T × 温度参数 → Softmax归一化
            attn = (query_head @ key_head.transpose(-2, -1)) * self.temperature[index, :, :]
            attn = attn.softmax(dim=-1)  # [B, C_i, C_i]（注意力权重矩阵）
            attScore.append(attn)

            # 生成当前头的QK缓存（Q+K，detach避免梯度传播）
            t_cache = query_head.clone().detach() + key_head.clone().detach()
            tmp_cache.append(t_cache)

        # 合并当前层多头缓存（用于后续层内调制）
        tmp_caches = torch.cat(tmp_cache, 1)  # [B, C, L]（C=sum(C_i)）

        # 步骤5：层间缓存调制（利用历史缓存优化当前注意力权重）
        out = []
        if qv_cache is not None:
            # 对齐缓存与当前权重的通道数（若维度不匹配，自适应池化调整）
            if qv_cache.shape[-1] != c:
                qv_cache = F.adaptive_avg_pool2d(qv_cache, c)
        for i in range(4):
            if qv_cache is not None:
                # 调用对应头的层间调制模块，融合历史缓存信息
                inter_modulator = self.inter_modulators[i]
                attScore[i] = inter_modulator(attScore[i], qv_cache) + attScore[i]
                # 注意力加权V：生成当前头的输出特征
                out.append(attScore[i] @ va[i])
            else:
                # 无历史缓存时，直接计算注意力输出
                out.append(attScore[i] @ va[i])

        # 步骤6：更新QK缓存（指数移动平均，平衡历史与当前信息）
        update_factor = 0.9  # 历史缓存权重（0.9表示保留90%历史信息）
        if qv_cache is not None:
            # 计算当前层缓存更新量
            update_elements = CalculateCurrentLayerCache(attScore, c, self.group)
            # 缓存更新：qv_cache = 历史缓存×0.9 + 当前更新量×0.1
            qv_cache = qv_cache * update_factor + update_elements * (1 - update_factor)
        else:
            # 初始缓存生成（无历史时，仅用当前层缓存×0.9）
            qv_cache = CalculateCurrentLayerCache(attScore, c, self.group)
            qv_cache = qv_cache * update_factor

        # 步骤7：层内缓存调制（融合多头缓存，减少头间冗余）
        out_all = torch.concat(out, 1)  # 合并多头输出 [B, C, L]
        out_all = self.intra_modulator(out_all, tmp_caches) + out_all  # 层内调制+残差

        # 步骤8：3D序列→2D特征+输出投影
        out_all = rearrange(out_all, 'b c (h w) -> b c h w', h=h, w=w)  # [B, C, H, W]
        out_all = self.project_out(out_all)  # 1×1卷积增强特征表达

        return [out_all, qv_cache]

if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 64, 32, 32).to(device)
    model = HMHA(64, 4, False)

    model.to(device)
    [y, _] = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("知乎、CSDN：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)