# 波传播算子模块（Wave Propagation Operator, WPO）
# 核心设计：基于二维波动方程的物理启发模型，通过“特征增强→DCT频域转换→波动方程调制→IDCT时域还原”的流程，
# 模拟波的传播与衰减特性，在频域中自适应调制特征的频率成分，强化特征的全局传播与局部细节一致性，
# 实现物理规律引导的特征增强，提升模型对全局依赖与结构信息的捕捉能力

import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from timm.models.layers import DropPath
DropPath.__repr__ = lambda self: f"timm.DropPath({self.drop_prob})"


class Wave2D(nn.Module):
    """
    Wave equation operator:
    d2u/dt2 - c2(d2u/dx2 + d2u/dy2) + αdu/dt = 0;
    du/dx_{x=0, x=a} = 0
    du/dy_{y=0, y=b} = 0
    =>
    A_{n, m} = C(a, b, n==0, m==0) * sum_{0}^{a}{ sum_{0}^{b}{\phi(x, y)cos(n\pi/ax)cos(m\pi/by)dxdy }}
    core = cos(n\pi/ax)cos(m\pi/by) * (1 - [(n\pi/a)^2 + (m\pi/b)^2]c2t2) * e^(-αt)
    u_{x, y, t} = sum_{0}^{\infinite}{ sum_{0}^{\infinite}{ core } }

    assume a = N, b = M; x in [0, N], y in [0, M]; n in [0, N], m in [0, M]; with some slight change
    =>
    (\phi(x, y) = linear(dwconv(input(x, y))))
    A(n, m) = DCT2D(\phi(x, y))
    u(x, y, t) = IDCT2D(A(n, m) * (1 - [(n\pi/a)^2 + (m\pi/b)^2]c2t2) * e^(-αt))

    核心设计：
        - 物理启发调制：基于波动方程的频域衰减/增强核，模拟波传播特性
        - 自适应参数：可学习波速c与衰减系数α，适配不同任务特征分布
        - 特征预处理：深度卷积+线性变换强化输入特征表达
        - 推理优化：支持推理模式预计算调制核，提升推理效率
    Args:
        infer_mode: 是否启用推理优化模式（默认False）
        res: 输入特征分辨率（默认14）
        dim: 输入通道数（默认96）
        hidden_dim: 中间特征通道数（默认96）
    """

    def __init__(self, infer_mode=False, res=14, dim=96, hidden_dim=96, **kwargs):
        super().__init__()
        self.res = res
        self.dwconv = nn.Conv2d(dim, hidden_dim, kernel_size=3, padding=1, groups=hidden_dim)
        self.hidden_dim = hidden_dim
        self.linear = nn.Linear(hidden_dim, 2 * hidden_dim, bias=True)
        self.out_norm = nn.LayerNorm(hidden_dim)
        self.out_linear = nn.Linear(hidden_dim, hidden_dim, bias=True)
        self.infer_mode = infer_mode
        self.to_k = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim, bias=True),
            nn.GELU(),
        )
        self.c = nn.Parameter(torch.ones(1) * 1.0)
        self.alpha = nn.Parameter(torch.ones(1) * 0.1)
        self.save_attention = False

    def infer_init_wave2d(self, freq):
        """
        推理模式初始化：预计算频域调制核，避免重复计算，提升推理效率
        Args:
            freq: 频域特征，用于生成调制核
        """
        weight_exp = self.get_decay_map((self.res, self.res), device=freq.device)
        self.k_exp = nn.Parameter(torch.pow(weight_exp[:, :, None], self.to_k(freq)), requires_grad=False)
        del self.to_k

    @staticmethod
    def get_cos_map(N=224, device=torch.device("cpu"), dtype=torch.float):
        """
        生成DCT/IDCT对应的余弦映射（物理模型离散化核心）
        公式对应：cos((x + 0.5)/N * n * π)，适配DCT-II变换格式
        Returns:
            weight: 余弦映射矩阵，shape=[N, N]（Res_n × Res_x）
        """
        # cos((x + 0.5) / N * n * \pi) which is also the form of DCT and IDCT
        # DCT: F(n) = sum( (sqrt(2/N) if n > 0 else sqrt(1/N)) * cos((x + 0.5) / N * n * \pi) * f(x) )
        # IDCT: f(x) = sum( (sqrt(2/N) if n > 0 else sqrt(1/N)) * cos((x + 0.5) / N * n * \pi) * F(n) )
        # returns: (Res_n, Res_x)
        weight_x = (torch.linspace(0, N - 1, N, device=device, dtype=dtype).view(1, -1) + 0.5) / N
        weight_n = torch.linspace(0, N - 1, N, device=device, dtype=dtype).view(-1, 1)
        weight = torch.cos(weight_n * weight_x * torch.pi) * math.sqrt(2 / N)
        weight[0, :] = weight[0, :] / math.sqrt(2)
        return weight

    @staticmethod
    def get_decay_map(resolution=(224, 224), device=torch.device("cpu"), dtype=torch.float):
        """
        生成波动方程的衰减映射（核心调制项）
        公式对应：(1 - [(nπ/a)² + (mπ/b)²]c²t²) * e^(-αt)，简化为e^(-[(nπ/a)² + (mπ/b)²])
        Args:
            resolution: 特征分辨率（H, W）
        Returns:
            weight: 衰减映射，shape=[H, W]
        """
        # (1 - [(n\pi/a)^2 + (m\pi/b)^2]c2t2) * e^(-αt)
        # returns: (Res_h, Res_w)
        resh, resw = resolution
        weight_n = torch.linspace(0, torch.pi, resh + 1, device=device, dtype=dtype)[:resh].view(-1, 1)
        weight_m = torch.linspace(0, torch.pi, resw + 1, device=device, dtype=dtype)[:resw].view(1, -1)
        # Quadratic term for wave equation
        weight = torch.pow(weight_n, 2) + torch.pow(weight_m, 2)
        weight = torch.exp(-weight)
        return weight

    def forward(self, x: torch.Tensor, freq_embed=None, test_index=None):
        """
        前向传播：特征预处理→频域转换→波动调制→时域还原→输出增强
        Args:
            x: 输入特征，shape=[b, res×res, dim]（序列格式：batch×像素数×通道）
        Returns:
            波传播增强后的特征，shape=[b, res×res, hidden_dim]
        """
        B, C, H, W = x.shape
        x = self.dwconv(x)
        x = self.linear(x.permute(0, 2, 3, 1).contiguous())
        x, z = x.chunk(chunks=2, dim=-1)

        cached_weight_cosn = getattr(self, "__WEIGHT_COSN__", None)
        if ((H, W) == getattr(self, "__RES__", (0, 0))) and cached_weight_cosn is not None and (
                cached_weight_cosn.device == x.device):
            weight_cosn = cached_weight_cosn
            weight_cosm = getattr(self, "__WEIGHT_COSM__", None)
            weight_exp = getattr(self, "__WEIGHT_EXP__", None)
        else:
            weight_cosn = self.get_cos_map(H, device=x.device).detach_()
            weight_cosm = self.get_cos_map(W, device=x.device).detach_()
            weight_exp = self.get_decay_map((H, W), device=x.device).detach_()
            setattr(self, "__RES__", (H, W))
            setattr(self, "__WEIGHT_COSN__", weight_cosn)
            setattr(self, "__WEIGHT_COSM__", weight_cosm)
            setattr(self, "__WEIGHT_EXP__", weight_exp)

        N, M = weight_cosn.shape[0], weight_cosm.shape[0]
        weight_cosn_kernel = weight_cosn.view(H, 1, H)
        weight_cosm_kernel = weight_cosm.view(W, 1, W)
        x_perm = x.permute(0, 3, 2, 1).contiguous()  # [B, C, W, H]
        x_flat_H = x_perm.view(-1, 1, H)  # [B*C*W, 1, H]
        x_u0 = F.conv1d(x_flat_H, weight_cosn_kernel).squeeze(-1)  # [B*C*W, H]
        x_u0 = x_u0.view(B, C, W, H).permute(0, 3, 2, 1).contiguous()  # [B, H, W, C]
        x_perm = x_u0.permute(0, 3, 1, 2).contiguous()  # [B, C, H, W]
        x_flat_W = x_perm.view(-1, 1, W)  # [B*C*H, 1, W]
        x_u0 = F.conv1d(x_flat_W, weight_cosm_kernel).squeeze(-1)  # [B*C*H, W]
        x_u0 = x_u0.view(B, C, H, W).permute(0, 2, 3, 1).contiguous()
        x_perm = x.permute(0, 3, 2, 1).contiguous()  # [B, C, W, H]
        x_flat_H = x_perm.view(-1, 1, H)  # [B*C*W, 1, H]
        x_v0 = F.conv1d(x_flat_H, weight_cosn_kernel).squeeze(-1)  # [B*C*W, H]
        x_v0 = x_v0.view(B, C, W, H).permute(0, 3, 2, 1).contiguous()  # [B, H, W, C]
        x_perm = x_v0.permute(0, 3, 1, 2).contiguous()  # [B, C, H, W]
        x_flat_W = x_perm.view(-1, 1, W)  # [B*C*H, 1, W]
        x_v0 = F.conv1d(x_flat_W, weight_cosm_kernel).squeeze(-1)  # [B*C*H, W]
        x_v0 = x_v0.view(B, C, H, W).permute(0, 2, 3, 1).contiguous()
        if freq_embed is None:
            freq_embed = torch.zeros(B, H, W, self.hidden_dim, device=x.device, dtype=x.dtype)
        t = self.to_k(freq_embed)
        c_t = self.c * t
        cos_term = torch.cos(c_t)
        eps = 1e-8
        sin_term = torch.sin(c_t) / (self.c + eps)
        wave_term = cos_term * x_u0
        velocity_term = sin_term * (x_v0 + (self.alpha / 2) * x_u0)
        final_term = wave_term + velocity_term
        cached_weight_cosn_idct = getattr(self, "__WEIGHT_COSN_IDCT__", None)
        cached_weight_cosm_idct = getattr(self, "__WEIGHT_COSM_IDCT__", None)

        if ((H, W) == getattr(self, "__RES_IDCT__", (0, 0))) and \
                cached_weight_cosn_idct is not None and \
                cached_weight_cosn_idct.device == x.device:
            weight_cosn = cached_weight_cosn_idct
            weight_cosm = cached_weight_cosm_idct
        else:
            weight_cosn = self.get_cos_map(H, device=x.device).detach_()  # (H, H)
            weight_cosm = self.get_cos_map(W, device=x.device).detach_()  # (W, W)
            setattr(self, "__RES_IDCT__", (H, W))
            setattr(self, "__WEIGHT_COSN_IDCT__", weight_cosn)
            setattr(self, "__WEIGHT_COSM_IDCT__", weight_cosm)
        x_w = final_term.permute(0, 1, 3, 2).contiguous().view(B * H * C, 1, W)  # (B*H*C, 1, W)
        weight_cosm_kernel_t = weight_cosm.t().contiguous().view(W, 1, W)  # (W,1,W)
        x_w = F.conv1d(x_w, weight_cosm_kernel_t).squeeze(-1)  # (B*H*C, W)
        x_w = x_w.view(B, H, C, W).permute(0, 1, 3, 2).contiguous()  # (B,H,W,C)
        x_h = x_w.permute(0, 2, 3, 1).contiguous().view(B * W * C, 1, H)  # (B*W*C,1,H)
        weight_cosn_kernel_t = weight_cosn.t().contiguous().view(H, 1, H)  # (H,1,H)
        x_h = F.conv1d(x_h, weight_cosn_kernel_t).squeeze(-1)  # (B*W*C,H)
        x_final = x_h.view(B, W, C, H).permute(0, 3, 1, 2).contiguous()
        x = self.out_norm(x_final)
        gate = nn.functional.silu(z)
        x_gated = x * gate
        x = self.out_linear(x_gated)
        x = x.permute(0, 3, 1, 2).contiguous()
        if test_index is not None and hasattr(self, 'save_attention') and self.save_attention:
            center_h, center_w = H // 2, W // 2
            attention_map = (x_final * x_final[:, center_h:center_h + 1, center_w:center_w + 1, :]).sum(-1)

            import matplotlib.pyplot as plt

            # Ensure the save directory exists
            save_dir = "./save/attention_map"
            os.makedirs(save_dir, exist_ok=True)

            # Move attention_map to cpu and convert to numpy
            att_map_np = attention_map.detach().cpu().numpy()

            # Normalize for visualization
            att_map_norm = (att_map_np - att_map_np.min()) / (att_map_np.max() - att_map_np.min() + 1e-8)

            # Save each sample in the batch
            for i in range(att_map_norm.shape[0]):
                filename = os.path.join(save_dir, f"attention_map_{test_index}_{i}.png")
                plt.imsave(filename, att_map_norm[i], cmap='viridis')

        return x


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 64, 32, 32).to(device)
    model = Wave2D(res=14, dim=64, hidden_dim=64, infer_mode=False).to(device)

    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("小红书：十小大，主页获取往期全部即插即用代码，200+大合集")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)