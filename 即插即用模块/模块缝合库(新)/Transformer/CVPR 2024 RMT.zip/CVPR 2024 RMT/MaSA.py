import torch
import torch.nn as nn
from typing import Tuple


def rotate_every_two(x):
    """
    特征旋转函数：用于相对位置编码的角度偏移
    核心作用：将特征按通道两两分组，对第二组取负后堆叠，实现旋转增强
    输入：特征 [B, N, H, W, D]（D为偶数通道数）
    输出：旋转后特征 [B, N, H, W, D]
    """
    x1 = x[:, :, :, :, ::2]  # 取偶数索引通道
    x2 = x[:, :, :, :, 1::2]  # 取奇数索引通道
    x = torch.stack([-x2, x1], dim=-1)  # 第二组取负后堆叠
    return x.flatten(-2)  # 展平最后两维，恢复通道数


def theta_shift(x, sin, cos):
    """
    角度偏移函数：结合正弦余弦编码，实现相对位置的角度调制
    核心作用：将旋转后的特征与相对位置编码融合，增强位置敏感性
    输入：
        x: 旋转后特征 [B, N, H, W, D]
        sin/cos: 相对位置正弦/余弦编码 [H, W, D]
    输出：角度调制后特征 [B, N, H, W, D]
    """
    return (x * cos) + (rotate_every_two(x) * sin)


class DWConv2d(nn.Module):
    """
    深度可分离卷积模块：适配(B, H, W, C)输入格式，用于局部特征增强
    核心作用：捕捉局部空间关联，作为位置增强补充（LEPE）
    输入：特征 [B, H, W, C]
    输出：增强后特征 [B, H, W, C]
    """

    def __init__(self, dim, kernel_size, stride, padding):
        super().__init__()
        self.conv = nn.Conv2d(dim, dim, kernel_size, stride, padding, groups=dim)  # 深度卷积

    def forward(self, x: torch.Tensor):
        # 维度转换：(B, H, W, C)→(B, C, H, W)，适配卷积
        x = x.permute(0, 3, 1, 2)
        x = self.conv(x)
        # 维度还原：(B, C, H, W)→(B, H, W, C)
        x = x.permute(0, 2, 3, 1)
        return x


class RetNetRelPos2d(nn.Module):
    """
    2D相对位置编码模块：生成基于曼哈顿距离的衰减掩码与角度编码
    核心创新：
        1. 曼哈顿距离衰减：注意力权重随像素间曼哈顿距离递减；
        2. 可学习衰减系数：不同注意力头的衰减速率自适应调整；
        3. 角度编码：结合正弦余弦，增强位置敏感性。
    输入：特征尺寸 (H, W)
    输出：相对位置编码 [(sin, cos), 衰减掩码]
    """

    def __init__(self, embed_dim, num_heads, initial_value, heads_range):
        super().__init__()
        # 生成角度编码的频率因子
        angle = 1.0 / (10000 ** torch.linspace(0, 1, embed_dim // num_heads // 2))
        angle = angle.unsqueeze(-1).repeat(1, 2).flatten()  # 扩展为偶数通道
        self.initial_value = initial_value
        self.heads_range = heads_range
        self.num_heads = num_heads
        # 生成每个注意力头的衰减系数（基于对数映射）
        decay = torch.log(
            1 - 2 ** (-initial_value - heads_range * torch.arange(num_heads, dtype=torch.float) / num_heads))
        self.register_buffer('angle', angle)  # 角度频率（不参与梯度）
        self.register_buffer('decay', decay)  # 衰减系数（不参与梯度）

    def generate_2d_decay(self, H: int, W: int):
        """生成2D曼哈顿距离衰减掩码：(num_heads, H×W, H×W)"""
        index_h = torch.arange(H).to(self.decay)
        index_w = torch.arange(W).to(self.decay)
        grid = torch.meshgrid([index_h, index_w])  # 生成像素坐标网格
        grid = torch.stack(grid, dim=-1).reshape(H * W, 2)  # (H×W, 2)
        # 计算像素对间的曼哈顿距离（x1-x2绝对值之和）
        mask = grid[:, None, :] - grid[None, :, :]
        mask = (mask.abs()).sum(dim=-1)  # (H×W, H×W)
        mask = mask * self.decay[:, None, None]  # 按头应用衰减系数
        return mask

    def generate_1d_decay(self, l: int):
        """生成1D距离衰减掩码：(num_heads, l, l)"""
        index = torch.arange(l).to(self.decay)
        mask = index[:, None] - index[None, :]  # 像素对间距离
        mask = mask.abs()
        mask = mask * self.decay[:, None, None]
        return mask

    def forward(self, slen: Tuple[int], activate_recurrent=False, chunkwise_recurrent=False):
        """
        前向传播：生成相对位置编码与衰减掩码
        slen: 特征尺寸 (H, W)
        返回：retention_rel_pos = [(sin, cos), 衰减掩码]
        """
        H, W = slen
        if activate_recurrent:
            # 循环模式（未实现完整逻辑）
            sin = torch.sin(self.angle * (H * W - 1))
            cos = torch.cos(self.angle * (H * W - 1))
            retention_rel_pos = ((sin, cos), self.decay.exp())
        elif chunkwise_recurrent:
            # 分块循环模式：分别生成H/W维度的衰减掩码
            index = torch.arange(H * W).to(self.decay)
            sin = torch.sin(index[:, None] * self.angle[None, :]).reshape(H, W, -1)
            cos = torch.cos(index[:, None] * self.angle[None, :]).reshape(H, W, -1)
            mask_h = self.generate_1d_decay(H)  # H维度衰减掩码
            mask_w = self.generate_1d_decay(W)  # W维度衰减掩码
            retention_rel_pos = ((sin, cos), (mask_h, mask_w))
        else:
            # 普通模式：生成2D衰减掩码
            index = torch.arange(H * W).to(self.decay)
            sin = torch.sin(index[:, None] * self.angle[None, :]).reshape(H, W, -1)
            cos = torch.cos(index[:, None] * self.angle[None, :]).reshape(H, W, -1)
            mask = self.generate_2d_decay(H, W)  # 2D曼哈顿距离衰减掩码
            retention_rel_pos = ((sin, cos), mask)
        return retention_rel_pos


class VisionRetentionChunk(nn.Module):
    """
    分维度MaSA模块（核心）：按H/W维度分步计算注意力，降低复杂度
    核心创新：
        1. 分维计算：先算W维度注意力，再算H维度注意力，复杂度从O((HW)²)降至O(HW(H+W))；
        2. 曼哈顿衰减：注意力权重随距离递减，强化局部关联；
        3. 位置增强：深度卷积补充局部位置特征（LEPE）。
    输入：
        x: 特征 [B, H, W, C]
        rel_pos: 相对位置编码 [(sin, cos), (mask_h, mask_w)]
    输出：增强后特征 [B, H, W, C]
    """

    def __init__(self, embed_dim, num_heads, value_factor=1):
        super().__init__()
        self.factor = value_factor  # Value通道扩展因子
        self.embed_dim = embed_dim
        self.num_heads = num_heads
        self.head_dim = self.embed_dim * self.factor // num_heads  # 单头Value维度
        self.key_dim = self.embed_dim // num_heads  # 单头QK维度
        self.scaling = self.key_dim ** -0.5  # QK缩放因子

        # QKV投影层
        self.q_proj = nn.Linear(embed_dim, embed_dim, bias=True)
        self.k_proj = nn.Linear(embed_dim, embed_dim, bias=True)
        self.v_proj = nn.Linear(embed_dim, embed_dim * self.factor, bias=True)
        # 局部位置增强（LEPE）：深度卷积
        self.lepe = DWConv2d(embed_dim, 5, 1, 2)
        # 输出投影层
        self.out_proj = nn.Linear(embed_dim * self.factor, embed_dim, bias=True)

        self.reset_parameters()  # 参数初始化

    def reset_parameters(self):
        """初始化投影层参数，保证训练稳定性"""
        nn.init.xavier_normal_(self.q_proj.weight, gain=2 ** -2.5)
        nn.init.xavier_normal_(self.k_proj.weight, gain=2 ** -2.5)
        nn.init.xavier_normal_(self.v_proj.weight, gain=2 ** -2.5)
        nn.init.xavier_normal_(self.out_proj.weight)
        nn.init.constant_(self.out_proj.bias, 0.0)

    def forward(self, x: torch.Tensor, rel_pos, chunkwise_recurrent=False, incremental_state=None):
        bsz, h, w, _ = x.size()
        (sin, cos), (mask_h, mask_w) = rel_pos  # 解析相对位置编码与衰减掩码

        # 步骤1：QKV生成与预处理
        q = self.q_proj(x)
        k = self.k_proj(x)
        v = self.v_proj(x)
        lepe = self.lepe(v)  # 局部位置增强
        k *= self.scaling  # QK缩放

        # 步骤2：维度重排与角度偏移（融入相对位置）
        q = q.view(bsz, h, w, self.num_heads, self.key_dim).permute(0, 3, 1, 2, 4)  # (B, N_heads, H, W, D_k)
        k = k.view(bsz, h, w, self.num_heads, self.key_dim).permute(0, 3, 1, 2, 4)
        qr = theta_shift(q, sin, cos)  # Q融入相对位置
        kr = theta_shift(k, sin, cos)  # K融入相对位置

        # 步骤3：W维度注意力计算（先处理宽度方向）
        qr_w = qr.transpose(1, 2)  # (B, H, N_heads, W, D_k)
        kr_w = kr.transpose(1, 2)
        v = v.reshape(bsz, h, w, self.num_heads, -1).permute(0, 1, 3, 2, 4)  # (B, H, N_heads, W, D_v)
        qk_mat_w = qr_w @ kr_w.transpose(-1, -2)  # QK^T：(B, H, N_heads, W, W)
        qk_mat_w = qk_mat_w + mask_w  # 加入W维度衰减掩码
        qk_mat_w = torch.softmax(qk_mat_w, -1)  # 注意力权重归一化
        v = torch.matmul(qk_mat_w, v)  # 注意力加权V：(B, H, N_heads, W, D_v)

        # 步骤4：H维度注意力计算（再处理高度方向）
        qr_h = qr.permute(0, 3, 1, 2, 4)  # (B, W, N_heads, H, D_k)
        kr_h = kr.permute(0, 3, 1, 2, 4)
        v = v.permute(0, 3, 2, 1, 4)  # (B, W, N_heads, H, D_v)
        qk_mat_h = qr_h @ kr_h.transpose(-1, -2)  # QK^T：(B, W, N_heads, H, H)
        qk_mat_h = qk_mat_h + mask_h  # 加入H维度衰减掩码
        qk_mat_h = torch.softmax(qk_mat_h, -1)  # 注意力权重归一化
        output = torch.matmul(qk_mat_h, v)  # 注意力加权V

        # 步骤5：维度恢复与输出投影
        output = output.permute(0, 3, 1, 2, 4).flatten(-2, -1)  # 展平多头特征
        output = output + lepe  # 融合局部位置增强
        output = self.out_proj(output)  # 输出投影恢复维度

        return output


class VisionRetentionAll(nn.Module):
    """
    全维度MaSA模块：直接计算2D全局注意力，适配小尺寸特征
    核心逻辑：全局QK^T + 2D曼哈顿衰减掩码，保留全局关联捕捉能力
    输入：特征 [B, H, W, C]
    输出：增强后特征 [B, H, W, C]
    """

    def __init__(self, embed_dim, num_heads, value_factor=1):
        super().__init__()
        self.factor = value_factor
        self.embed_dim = embed_dim
        self.num_heads = num_heads
        self.head_dim = self.embed_dim * self.factor // num_heads
        self.key_dim = self.embed_dim // num_heads
        self.scaling = self.key_dim ** -0.5

        # QKV投影与输出投影
        self.q_proj = nn.Linear(embed_dim, embed_dim, bias=True)
        self.k_proj = nn.Linear(embed_dim, embed_dim, bias=True)
        self.v_proj = nn.Linear(embed_dim, embed_dim * self.factor, bias=True)
        self.lepe = DWConv2d(embed_dim, 5, 1, 2)
        self.out_proj = nn.Linear(embed_dim * self.factor, embed_dim, bias=True)

        self.reset_parameters()

    def reset_parameters(self):
        """参数初始化，与分维度模块一致"""
        nn.init.xavier_normal_(self.q_proj.weight, gain=2 ** -2.5)
        nn.init.xavier_normal_(self.k_proj.weight, gain=2 ** -2.5)
        nn.init.xavier_normal_(self.v_proj.weight, gain=2 ** -2.5)
        nn.init.xavier_normal_(self.out_proj.weight)
        nn.init.constant_(self.out_proj.bias, 0.0)

    def forward(self, x: torch.Tensor, rel_pos, chunkwise_recurrent=False, incremental_state=None):
        bsz, h, w, _ = x.size()
        (sin, cos), mask = rel_pos  # 解析2D衰减掩码
        assert h * w == mask.size(1), "掩码尺寸与特征尺寸不匹配"

        # QKV生成与预处理
        q = self.q_proj(x)
        k = self.k_proj(x)
        v = self.v_proj(x)
        lepe = self.lepe(v)
        k *= self.scaling

        # 维度重排与相对位置融合
        q = q.view(bsz, h, w, self.num_heads, -1).permute(0, 3, 1, 2, 4)  # (B, N_heads, H, W, D_k)
        k = k.view(bsz, h, w, self.num_heads, -1).permute(0, 3, 1, 2, 4)
        qr = theta_shift(q, sin, cos)
        kr = theta_shift(k, sin, cos)

        # 全局注意力计算
        qr = qr.flatten(2, 3)  # (B, N_heads, H×W, D_k)
        kr = kr.flatten(2, 3)
        vr = v.reshape(bsz, h, w, self.num_heads, -1).permute(0, 3, 1, 2, 4).flatten(2, 3)  # (B, N_heads, H×W, D_v)
        qk_mat = qr @ kr.transpose(-1, -2)  # (B, N_heads, H×W, H×W)
        qk_mat = qk_mat + mask  # 加入2D曼哈顿衰减掩码
        qk_mat = torch.softmax(qk_mat, -1)
        output = torch.matmul(qk_mat, vr)  # 全局注意力加权

        # 维度恢复与输出
        output = output.transpose(1, 2).reshape(bsz, h, w, -1)
        output = output + lepe
        output = self.out_proj(output)

        return output


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    x = torch.randn(1, 32, 32, 64).to(device)

    # 初始化MaSA模块（分解版本）与相对位置编码模块
    # model = VisionRetentionChunk(64, 4).to(device)
    # relpos = RetNetRelPos2d(64, 4, 1, 3).to(device)
    # rel_pos = relpos((32, 32), chunkwise_recurrent=True)  # 生成相对位置编码

    # 初始化MaSA模块（全维度版本）与相对位置编码模块
    model = VisionRetentionAll(64, 4).to(device)
    relpos = RetNetRelPos2d(64, 4, 1, 3).to(device)
    rel_pos = relpos((32, 32), chunkwise_recurrent=False)  # 生成相对位置编码

    y = model(x, rel_pos)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN：十小大")
    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)