import torch
import torch.nn as nn

# 可选导入Flash注意力（高效GPU加速，默认禁用）
# from flash_attn.flash_attn_interface import flash_attn_func
USE_FLASH_ATTN = False  # 控制是否启用Flash注意力

def autopad(k, p=None, d=1):  # kernel, padding, dilation
    """
    自动计算padding函数：确保卷积后输出特征图尺寸与输入一致（"same" padding）
    参数：
        k: 卷积核大小（int或列表）
        p: 手动指定的padding（默认None，自动计算）
        d: 卷积扩张率（默认1，扩张卷积时调整有效核大小）
    返回：
        p: 计算后的padding（int或列表，与k维度匹配）
    """
    if d > 1:
        # 扩张卷积时，计算有效核大小（dilation*(k-1)+1）
        k = d * (k - 1) + 1 if isinstance(k, int) else [d * (x - 1) + 1 for x in k]
    if p is None:
        # 自动padding：核大小//2（确保same输出）
        p = k // 2 if isinstance(k, int) else [x // 2 for x in k]
    return p


class Conv(nn.Module):
    """
    标准卷积块：卷积+批归一化（BN）+激活函数，为AAttn提供基础特征提取能力
    核心作用：标准化卷积流程，支持分组卷积、扩张卷积，适配目标检测的特征提取需求
    输入：特征图 [B, c1, H, W]（B=批次，c1=输入通道，H/W=高/宽）
    输出：增强后特征 [B, c2, H', W']（H'/W'由卷积步长决定，默认与输入一致）
    """
    default_act = nn.SiLU()  # 默认激活函数（SiLU，适配YOLO系列模型）

    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, d=1, act=True):
        """
        参数初始化：
            c1: 输入通道数
            c2: 输出通道数
            k: 卷积核大小（默认1×1）
            s: 卷积步长（默认1）
            p: padding（默认None，自动计算）
            g: 分组数（默认1，=c1时为深度可分离卷积）
            d: 扩张率（默认1）
            act: 激活函数（True=默认SiLU，False=无激活，或指定自定义激活）
        """
        super().__init__()
        # 卷积层：支持分组、扩张，无偏置（BN已包含偏置功能）
        self.conv = nn.Conv2d(c1, c2, k, s, autopad(k, p, d), groups=g, dilation=d, bias=False)
        # 批归一化：稳定训练，加速收敛
        self.bn = nn.BatchNorm2d(c2)
        # 激活函数：根据参数选择默认SiLU、自定义激活或无激活
        self.act = self.default_act if act is True else act if isinstance(act, nn.Module) else nn.Identity()

    def forward(self, x):
        """标准前向传播：卷积→BN→激活"""
        return self.act(self.bn(self.conv(x)))

    def forward_fuse(self, x):
        """融合前向传播：跳过BN（推理阶段可选，用于加速）"""
        return self.act(self.conv(x))


class AAttn(nn.Module):
    """
    区域注意力模块（AAttn）：通过特征图区域划分，降低注意力计算量，适配实时目标检测
    核心创新：
        1. 均等区域划分：将特征图分为area个区域，独立计算注意力，降低复杂度；
        2. 多注意力头设计：拆分通道为多个头，增强特征判别性；
        3. Flash注意力兼容：支持GPU加速，进一步提升推理速度；
        4. 位置增强（PE）：深度可分离卷积补充局部位置信息，避免区域划分导致的细节丢失；
        5. 即插即用：输入输出维度一致，适配YOLO等检测模型的特征流程。
    输入：特征图 [B, dim, H, W]（dim=通道数）
    输出：注意力增强特征 [B, dim, H, W]（与输入维度完全一致）
    """

    def __init__(self, dim, num_heads, area=1):
        """
        参数初始化：
            dim: 输入/输出通道数（需能被num_heads整除）
            num_heads: 注意力头数（推荐dim//num_heads为32或64的倍数，适配Flash注意力）
            area: 区域划分数量（默认1，即不划分；>1时均等划分特征图）
        """
        super().__init__()
        self.area = area  # 区域划分数量
        self.num_heads = num_heads  # 注意力头数
        self.head_dim = head_dim = dim // num_heads  # 单头通道数
        all_head_dim = head_dim * self.num_heads  # 所有头的总通道数

        # QK投影层：1×1卷积一次性生成Q和K（通道数=2×all_head_dim）
        self.qk = Conv(dim, all_head_dim * 2, 1, act=False)
        # V投影层：1×1卷积生成V（通道数=all_head_dim）
        self.v = Conv(dim, all_head_dim, 1, act=False)
        # 输出投影层：1×1卷积恢复输入通道数
        self.proj = Conv(all_head_dim, dim, 1, act=False)
        # 位置增强（PE）：深度可分离卷积（groups=dim）补充局部位置信息
        self.pe = Conv(all_head_dim, dim, 5, 1, 2, g=dim, act=False)

    def forward(self, x):
        """
        前向传播流程：区域划分→QKV生成→注意力计算→位置增强→输出投影
        """
        B, C, H, W = x.shape  # 解析输入维度：批次、通道数、高、宽
        N = H * W  # 特征图总像素数

        # 步骤1：QK生成与维度转换（BCHW→BNC，N=H×W）
        qk = self.qk(x).flatten(2).transpose(1, 2)  # [B, N, 2×all_head_dim]
        # 步骤2：V生成与位置增强（PE）
        v = self.v(x)  # [B, all_head_dim, H, W]
        pp = self.pe(v)  # 位置增强：深度可分离卷积→[B, dim, H, W]
        v = v.flatten(2).transpose(1, 2)  # [B, N, all_head_dim]

        # 步骤3：区域划分（area>1时，将特征图拆分为area个独立区域）
        if self.area > 1:
            # 维度重排：[B, N, C×2]→[B×area, N//area, C×2]（每个区域独立计算）
            qk = qk.reshape(B * self.area, N // self.area, C * 2)
            v = v.reshape(B * self.area, N // self.area, C)
            B, N, _ = qk.shape  # 更新批次和序列长度（B=原B×area，N=原N//area）

        # 步骤4：拆分Q和K（通道维度拆分）
        q, k = qk.split([C, C], dim=2)  # 各[B, N, all_head_dim]

        # 步骤5：注意力计算（支持Flash注意力加速）
        if x.is_cuda and USE_FLASH_ATTN:
            # Flash注意力模式（GPU加速，适配半精度）
            q = q.view(B, N, self.num_heads, self.head_dim)
            k = k.view(B, N, self.num_heads, self.head_dim)
            v = v.view(B, N, self.num_heads, self.head_dim)
            # 调用Flash注意力函数
            x_attn = flash_attn_func(
                q.contiguous().half(),
                k.contiguous().half(),
                v.contiguous().half()
            ).to(q.dtype)  # [B, N, all_head_dim]
        else:
            # 标准注意力模式（无GPU加速，适配CPU/GPU）
            # 维度重排：[B, N, all_head_dim]→[B, num_heads, head_dim, N]
            q = q.transpose(1, 2).view(B, self.num_heads, self.head_dim, N)
            k = k.transpose(1, 2).view(B, self.num_heads, self.head_dim, N)
            v = v.transpose(1, 2).view(B, self.num_heads, self.head_dim, N)
            # 注意力分数计算（QK^T）+ 缩放（避免数值过大）
            attn = (q.transpose(-2, -1) @ k) * (self.head_dim ** -0.5)  # [B, num_heads, N, N]
            # Softmax归一化（减去最大值，避免数值溢出）
            max_attn = attn.max(dim=-1, keepdim=True).values
            exp_attn = torch.exp(attn - max_attn)
            attn = exp_attn / exp_attn.sum(dim=-1, keepdim=True)
            # 注意力加权V
            x_attn = (v @ attn.transpose(-2, -1))  # [B, num_heads, head_dim, N]
            # 维度重排：[B, num_heads, head_dim, N]→[B, N, all_head_dim]
            x_attn = x_attn.permute(0, 3, 1, 2).reshape(B, N, self.num_heads * self.head_dim)

        # 步骤6：区域合并（area>1时，恢复原始批次和序列长度）
        if self.area > 1:
            # 维度重排：[B×area, N//area, C]→[B, N×area, C]（N×area=原N）
            x_attn = x_attn.reshape(B // self.area, N * self.area, C)
            B, N, _ = x_attn.shape  # 更新批次和序列长度（恢复原始值）

        # 步骤7：维度恢复+位置增强+输出投影
        # 序列→空间：[B, N, C]→[B, H, W, C]→[B, C, H, W]
        x_attn = x_attn.reshape(B, H, W, C).permute(0, 3, 1, 2)
        # 位置增强融合+输出投影：(注意力特征 + 位置特征)→投影恢复通道
        return self.proj(x_attn + pp)


class ABlock(nn.Module):
    """
    区域注意力块（ABlock）：封装AAttn与MLP，构成完整的特征增强单元
    核心作用：结合区域注意力与前馈网络，增强特征判别性，适配深层网络
    输入：特征图 [B, dim, H, W]
    输出：增强后特征 [B, dim, H, W]（残差连接，避免梯度消失）
    """

    def __init__(self, dim, num_heads, mlp_ratio=1.2, area=1):
        """
        参数初始化：
            dim: 输入/输出通道数
            num_heads: 注意力头数
            mlp_ratio: MLP中间通道扩展因子（默认1.2，中间通道=dim×mlp_ratio）
            area: 区域划分数量
        """
        super().__init__()
        self.attn = AAttn(dim, num_heads=num_heads, area=area)  # 区域注意力模块
        mlp_hidden_dim = int(dim * mlp_ratio)  # MLP中间通道数
        # MLP：两层1×1卷积，增强非线性表达
        self.mlp = nn.Sequential(Conv(dim, mlp_hidden_dim, 1), Conv(mlp_hidden_dim, dim, 1, act=False))
        # 参数初始化
        self.apply(self._init_weights)

    def _init_weights(self, m):
        """参数初始化：卷积层权重用截断正态分布，偏置设为0"""
        if isinstance(m, nn.Conv2d):
            nn.init.trunc_normal_(m.weight, std=0.02)
            if m.bias is not None:
                nn.init.constant_(m.bias, 0)

    def forward(self, x):
        """前向传播：残差连接（输入+注意力输出）→残差连接（输入+MLP输出）"""
        x = x + self.attn(x)  # 注意力残差融合
        x = x + self.mlp(x)  # MLP残差融合
        return x


class A2C2f(nn.Module):
    """
    区域注意力增强的C2f模块（A2C2f，又称R-ELAN）：堆叠ABlock，强化特征提取
    核心作用：替代传统C2f模块，用区域注意力提升目标检测的特征判别性，适配YOLO架构
    输入：特征图 [B, c1, H, W]
    输出：融合后特征 [B, c2, H, W]
    """

    def __init__(self, c1, c2, n=1, a2=True, area=1, residual=False, mlp_ratio=2.0, e=0.5, g=1, shortcut=True):
        super().__init__()
        c_ = int(c2 * e)  # 中间通道数（e为扩展因子，默认0.5）
        assert c_ % 32 == 0, "ABlock的中间通道数必须是32的倍数"
        self.num_heads = c_ // 32  # 注意力头数（按中间通道数自动计算）

        self.cv1 = Conv(c1, c_, 1, 1)  # 输入投影：将c1通道转为c_通道
        # 输出投影：合并(n+1)个分支特征（1个初始分支 + n个ABlock分支）
        self.cv2 = Conv((1 + n) * c_, c2, 1)
        # 残差缩放因子（可选）：增强残差连接的灵活性
        self.gamma = nn.Parameter(0.01 * torch.ones((c2)), requires_grad=True) if a2 and residual else None

        # 模块列表：堆叠n个ABlock（或C3k作为备选）
        self.m = nn.ModuleList(
            nn.Sequential(*(ABlock(c_, self.num_heads, mlp_ratio, area) for _ in range(2))) if a2 else C3k(c_, c_, 2,
                                                                                                           shortcut, g)
            for _ in range(n)
        )

    def forward(self, x):
        """前向传播：多分支特征提取→特征拼接→投影融合→残差连接（可选）"""
        y = [self.cv1(x)]  # 初始分支：输入投影
        y.extend(m(y[-1]) for m in self.m)  # 堆叠ABlock分支，逐一分支提取特征
        # 残差融合（可选）：输入 + 缩放后的拼接特征
        if self.gamma is not None:
            return x + self.gamma.view(1, -1, 1, 1) * self.cv2(torch.cat(y, 1))
        # 直接输出：拼接特征→投影
        return self.cv2(torch.cat(y, 1))


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 64, 32, 32).to(device)
    model = ABlock(dim=64, num_heads=4, mlp_ratio=2, area=4).to(device)

    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("知乎、CSDN：十小大")
    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)