import torch
import torch.nn as nn
from einops import rearrange

# LEB
class LocalEnhanceBlock(nn.Module):
    def __init__(self, dims):
        super().__init__()
        self.dims = dims
        self.conv1 = nn.Conv2d(dims, 2*dims, kernel_size=3, padding=1, stride=1, groups=dims, bias=True, dilation = 1)
        self.conv2 = nn.Conv2d(dims, 2*dims, kernel_size=3, padding=4, stride=1, groups=dims, bias=True, dilation = 4)
        self.conv3 = nn.Conv2d(dims, 2*dims, kernel_size=3, padding=9, stride=1, groups=dims, bias=True, dilation = 9)
        self.sca = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(dims, dims, 1)
        )
        self.conv4 = nn.Sequential(
            nn.Conv2d(dims, dims, 3, padding=1, groups=dims),
            nn.Conv2d(dims, dims, 1)
        )

    def forward(self, x):
        x1, t1 = self.conv1(x).chunk(2, dim=1)
        x2, t2 = self.conv2(x).chunk(2, dim=1)
        x3, t3 = self.conv3(x).chunk(2, dim=1)
        x = x1 * t1 + x2 * t2 + x3 * t3
        x = self.sca(x) * x #(b,c,h,w)
        x = self.conv4(x)
        return x


class MetaFuse(nn.Module):
    """
    元融合模块（Meta Fuse）
    功能：将元信息（Meta Data）注入特征，调制Q向量生成
    核心设计：
        - 元信息投影：线性层将元信息映射至特征通道维度
        - 特征调制：元信息权重与特征元素乘法，实现自适应调制
        - 残差连接：保留原始特征信息，缓解过度调制
    """
    def __init__(self, dims, meta_dims):
        super(MetaFuse, self).__init__()
        self.meta_fc = nn.Linear(meta_dims, dims)
        self.conv_in = nn.Conv2d(dims, dims, 1)
        self.conv = nn.Sequential(
            nn.Conv2d(dims, 2 * dims, 3, padding=1, groups=dims),
            nn.GELU(),
            nn.Conv2d(2 * dims, dims, 1)
        )

    def forward(self, x, metadata):
        b, c, h, w = x.shape
        shortcut = x
        x = self.conv_in(x)
        x = x * self.meta_fc(metadata).unsqueeze(-1).unsqueeze(-1)
        x = self.conv(x)
        x = x + shortcut
        return x


class MetaAttentionBlock(nn.Module):
    """
    元自注意力模块（Meta Self-attention, MeSA）
    核心设计：
        - 元信息引导Q：通过MetaFuse模块将元信息注入Q向量，让注意力自适应元信息
        - 轻量化K/V生成：线性层直接生成K/V，避免复杂计算
        - 多头注意力融合：标准化Q/K提升稳定性，可学习温度参数调节注意力分布
        - 端到端可训练：元信息与注意力权重联合优化
    Args:
        dims: 输入/输出特征通道数
        num_heads: 注意力头数（需整除dims）
        meta_dims: 元信息通道数
    """

    def __init__(self, dims, num_heads, meta_dims):
        super().__init__()
        self.num_heads = num_heads
        self.temperature = nn.Parameter(torch.ones(num_heads, 1, 1))  # 可学习注意力温度参数
        self.q = MetaFuse(dims, meta_dims)  # 元信息调制Q生成
        self.k = nn.Linear(dims, dims, bias=False)  # K生成（线性层）
        self.v = nn.Linear(dims, dims, bias=False)  # V生成（线性层）
        self.conv_out = nn.Conv2d(dims, dims, kernel_size=1, bias=False)  # 输出投影

    def forward(self, x, metadata):
        """
        前向传播：元调制Q生成→K/V生成→多头注意力→输出投影
        Args:
            x: 输入特征，shape=[b, dims, h, w]
            metadata: 元信息，shape=[b, meta_dims]（支持批量输入）
        Returns:
            元自注意力增强特征，shape=[b, dims, h, w]（与输入维度一致）
        """
        b, c, h, w = x.shape

        # 1. 元信息调制Q向量生成
        q = self.q(x, metadata)  # [b, dims, h, w]

        # 2. 维度转换：空间格式→序列格式（适配注意力计算）
        x_seq = rearrange(x, 'b c h w -> b (h w) c')  # [b, h×w, dims]
        q_seq = rearrange(q, 'b c h w -> b (h w) c')  # [b, h×w, dims]

        # 3. K/V生成（序列格式）
        k_seq = self.k(x_seq)  # [b, h×w, dims]
        v_seq = self.v(x_seq)  # [b, h×w, dims]

        # 4. 多头维度调整
        q_multi = rearrange(q_seq, 'b l (head c) -> b head c l', head=self.num_heads)  # [b, heads, c//heads, h×w]
        k_multi = rearrange(k_seq, 'b l (head c) -> b head c l', head=self.num_heads)
        v_multi = rearrange(v_seq, 'b l (head c) -> b head c l', head=self.num_heads)

        # 5. 标准化Q/K（提升注意力稳定性）
        q_norm = torch.nn.functional.normalize(q_multi, dim=-1)
        k_norm = torch.nn.functional.normalize(k_multi, dim=-1)

        # 6. 多头注意力计算
        attn = (q_norm @ k_norm.transpose(-2, -1)) * self.temperature  # 注意力得分+温度调节
        attn = attn.softmax(dim=-1)  # 权重归一化
        x_attn = attn @ v_multi  # 注意力加权V

        # 7. 维度恢复：多头→单头，序列→空间
        x_spatial = rearrange(x_attn, 'b head c (h w) -> b (head c) h w', h=h, w=w)  # [b, dims, h, w]

        # 8. 输出投影
        x_out = self.conv_out(x_spatial)
        return x_out


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    dims = 64
    x = torch.randn(1, dims, 32, 32).to(device)

    meta_dims = 2 * dims
    learnable_metadata = nn.Parameter(torch.ones(meta_dims)).to(device)

    model = MetaAttentionBlock(dims, 4, meta_dims).to(device)

    y = model(x, learnable_metadata)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN、小红书：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)