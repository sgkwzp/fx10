# 曲率引导令牌注意力模块（Curvature-guided Token Attention, CGTA）
# 核心设计：基于“曲率特征提取→动态Top-K令牌筛选→跨注意力计算→特征增强”的流程，
# 通过特征曲率捕捉结构变化，结合保留门控筛选关键令牌，在降低计算成本的同时，
# 让注意力聚焦结构关键区域，强化特征的结构依赖性与表达精准性


import torch
import torch.nn as nn
from torch.nn import functional as F
import math


class RetentionGate(nn.Module):
    """
    保留门控模块：动态生成令牌保留分数，筛选有价值的特征令牌
    核心设计：
        - 轻量化MLP架构：两层线性层+ReLU+Sigmoid，快速生成门控分数
        - 令牌级输出：为每个输入令牌生成独立分数，适配Token Attention
    Args:
        dim: 输入令牌通道数
        hidden_dim: 中间层维度（默认64）
    """
    def __init__(self, dim, hidden_dim=64):
        super().__init__()
        self.ret_gate = nn.Sequential(
            nn.Linear(dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 1),
            nn.Sigmoid()
        )

    def forward(self, x):
        return self.ret_gate(x).squeeze(-1)


def get_dynamic_topk_tokens(H, W, training):
    """
    动态计算Top-K令牌数量：根据特征图尺寸与训练/推理模式自适应调整
    核心逻辑：
        - 训练模式：按特征图尺寸的对数动态缩放，保留更多令牌用于学习
        - 推理模式：固定最小保留层级，减少计算成本，提升推理速度
    Args:
        H: 特征图高度
        W: 特征图宽度
        training: 是否为训练模式（bool）
    Returns:
        k_tokens: Top-K筛选的令牌数量
        scale: 特征缩放比例（用于后续特征适配）
    """
    if training:
        time_level = max(int(math.log(H // 4, 4)), int(math.log(W // 4, 4)))
    else:
        time_level = max(2, max(int(math.log(H // 16, 4)), int(math.log(W // 16, 4))))
    scale = 4 ** time_level
    k_tokens = (H // scale) * (W // scale)
    return k_tokens, scale


class CGTA(nn.Module):
    """
    曲率引导令牌注意力模块（Curvature-guided Token Attention, CGTA）
    功能：曲率引导+动态Top-K筛选+跨注意力，高效捕捉结构依赖
    核心设计：
        - 曲率特征提取：深度卷积捕捉特征结构变化，为注意力提供结构先验
        - 双分数筛选：曲率分数+门控分数融合，精准筛选关键令牌
        - 动态Top-K：自适应调整筛选令牌数量，平衡训练效果与推理效率
        - 跨注意力计算：全令牌Query × 关键令牌KV，降低计算成本
        - 卷积位置编码（CPE）：强化价值特征的空间位置信息
    Args:
        dim: 输入/输出令牌通道数
        num_heads: 注意力头数（默认8）
        qkv_bias: QKV生成是否带偏置（默认False）
        qk_scale: 注意力缩放因子（默认None，自动计算）
        attn_drop: 注意力权重dropout概率（默认0.）
        proj_drop: 输出投影dropout概率（默认0.）
        c_ratio: 通道压缩比例（默认0.5，控制KV通道数）
    """
    def __init__(self, dim, num_heads=8, qkv_bias=False, qk_scale=None, attn_drop=0., proj_drop=0., c_ratio=0.5):
        super(CGTA, self).__init__()
        assert dim % num_heads == 0, f"dim {dim} should be divided by num_heads {num_heads}."
        self.num_heads = num_heads
        head_dim = dim // num_heads

        self.cr = int(dim * c_ratio)  # scaled channel dimension

        # self.scale = qk_scale or head_dim ** -0.5
        self.scale = qk_scale or (head_dim * c_ratio) ** -0.5

        # self.curv_conv = nn.Conv2d(dim, 1, kernel_size=3, stride=1, padding=1, bias=False)
        # Curvature guidance components
        self.curvature_conv = nn.Conv2d(dim, dim, 3, 1, 1, groups=dim, bias=False)
        self.gate = RetentionGate(dim, hidden_dim=dim // 2)

        self.q = nn.Linear(dim, self.cr, bias=qkv_bias)
        self.kv_reduce = nn.Conv1d(dim, self.cr, 1)
        self.k = nn.Linear(self.cr, self.cr, bias=qkv_bias)
        self.v = nn.Linear(self.cr, dim, bias=qkv_bias)

        self.norm_act = nn.Sequential(
            nn.LayerNorm(self.cr),
            nn.GELU()
        )

        # CPE
        self.cpe = nn.Conv2d(dim, dim, kernel_size=3, stride=1, padding=1, groups=dim)

        self.proj = nn.Linear(dim, dim)
        self.attn_drop = nn.Dropout(attn_drop)
        self.proj_drop = nn.Dropout(proj_drop)

        self.alpha = nn.Parameter(torch.zeros(1))
        self.beta = nn.Parameter(torch.tensor(0.5))

    def forward(self, x, H, W):
        B, N, C = x.shape

        # reduction
        _x = x.permute(0, 2, 1).reshape(B, C, H, W).contiguous()

        curvature = self.curvature_conv(_x).mean(dim=1, keepdim=True).view(B, -1)  # [B, H*W]
        curvature = F.layer_norm(curvature, curvature.shape[1:])
        gate_score = self.gate(x)
        score = (curvature.abs() + gate_score) / 2

        k_tokens, _scale = get_dynamic_topk_tokens(H, W, self.training)

        topk_scores, topk_indices = score.topk(k_tokens, dim=-1, largest=True, sorted=False)
        x_topk = torch.gather(x, dim=1, index=topk_indices.unsqueeze(-1).expand(-1, -1, C))

        score_topk = torch.gather(score, 1, topk_indices)  # Shape: [B, k_tokens]

        q = self.q(x).reshape(B, N, self.num_heads, self.cr // self.num_heads).permute(0, 2, 1, 3)
        kv_input = x_topk.transpose(1, 2)
        kv_compressed = self.kv_reduce(kv_input).transpose(1, 2)
        kv_compressed = self.norm_act(kv_compressed)

        k = self.k(kv_compressed).reshape(B, k_tokens, self.num_heads, -1).permute(0, 2, 1, 3)
        v = self.v(kv_compressed).reshape(B, k_tokens, self.num_heads, C // self.num_heads).permute(0, 2, 1, 3)

        v = v * score_topk.unsqueeze(1).unsqueeze(-1)

        curvature_topk = torch.gather(curvature, 1, topk_indices).unsqueeze(1)

        # corss-attention
        attn_logits = (q @ k.transpose(-2, -1)) * self.scale
        attn_mod = attn_logits * (1 + self.alpha * curvature_topk.unsqueeze(1))
        attn_std = F.softmax(attn_logits, dim=-1)
        attn_cga = F.softmax(attn_mod, dim=-1)
        attn = self.beta * attn_std + (1 - self.beta) * attn_cga
        attn = self.attn_drop(attn)

        # CPE
        v = v + self.cpe(
            v.transpose(1, 2).reshape(B, -1, C).transpose(1, 2).contiguous().view(B, C, H // _scale, W // _scale)).view(
            B, C, -1).view(B, self.num_heads, int(C / self.num_heads), -1).transpose(-1, -2)

        x = (attn @ v).transpose(1, 2).reshape(B, N, C)
        x = self.proj(x)
        x = self.proj_drop(x)

        return x


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    # B, N, C
    x = torch.randn(1, 32*32, 64).to(device)
    model = CGTA(64, 8).to(device)

    y = model(x, 32, 32)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("小红书：十小大，主页获取往期全部即插即用代码，200+大合集")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)