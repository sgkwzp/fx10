import torch
import torch.nn as nn
# from model.ABC.Module import conv_block, up_conv, _upsample_like, conv_relu_bn, dconv_block
from einops import rearrange


def conv_relu_bn(in_channel, out_channel, dirate):
    """
    基础卷积块：Conv2d + BatchNorm2d + ReLU，支持空洞卷积
    功能：提取局部空间特征，空洞卷积可扩大感受野而不增加参数
    参数：
        in_channel: 输入特征通道数
        out_channel: 输出特征通道数
        dirate: 空洞率（dilation rate），普通卷积为1，空洞卷积>1
    返回：nn.Sequential序列模块
    """
    return nn.Sequential(
        nn.Conv2d(in_channels=in_channel, out_channels=out_channel,
                  kernel_size=3, stride=1, padding=dirate, dilation=dirate),
        nn.BatchNorm2d(out_channel),  # 批量归一化，加速训练并增强稳定性
        nn.ReLU(inplace=True)  # 原地激活，节省内存
    )


class Attention(nn.Module):
    """
    双线性注意力模块：通过卷积+全连接计算注意力权重，显式建模全局相关性
    核心逻辑：将输入特征压缩为单通道后，通过线性层生成Q/K，矩阵乘法得到H×H注意力矩阵
    输入：[B, C, H, W]（B=批次，C=通道，H=高度，W=宽度）
    输出：[B, C, H, W]（与输入同维度的注意力权重图）
    """

    def __init__(self, in_dim, in_feature, out_feature):
        super(Attention, self).__init__()
        # 1×1卷积：将多通道特征压缩为单通道，降低计算量（对应文档2图中“PW Conv”）
        self.query_conv = nn.Conv2d(in_channels=in_dim, out_channels=1, kernel_size=1)
        self.key_conv = nn.Conv2d(in_channels=in_dim, out_channels=1, kernel_size=1)
        # 全连接层：将展平的单通道特征映射为Q/K（对应文档2图中“FC”）
        self.query_line = nn.Linear(in_features=in_feature, out_features=out_feature)  # in_feature=H×W
        self.key_line = nn.Linear(in_features=in_feature, out_features=out_feature)  # out_feature=H
        # 1×1卷积：将注意力矩阵的通道数恢复为输入通道数，用于后续加权
        self.s_conv = nn.Conv2d(in_channels=1, out_channels=in_dim, kernel_size=1)
        # Softmax：归一化注意力权重，确保权重和为1
        self.softmax = nn.Softmax(dim=-1)

    def forward(self, x):
        # 步骤1：生成Query（Q）：单通道卷积→展平为1D序列→线性映射→调整维度为[B, H, 1]
        q = self.query_conv(x)  # [B, 1, H, W]
        q = rearrange(q, 'b 1 h w -> b (h w)')  # 展平：[B, H×W]
        q = self.query_line(q)  # [B, H]（out_feature=H）
        q = rearrange(q, 'b h -> b h 1')  # 调整维度：[B, H, 1]

        # 步骤2：生成Key（K）：与Q流程一致，最终维度为[B, 1, H]
        k = self.key_conv(x)  # [B, 1, H, W]
        k = rearrange(k, 'b 1 h w -> b (h w)')  # [B, H×W]
        k = self.key_line(k)  # [B, H]
        k = rearrange(k, 'b h -> b 1 h')  # [B, 1, H]

        # 步骤3：计算双线性注意力矩阵：Q×K → [B, H, H]（对应文档2图中“H×1 ⊗ 1×H”）
        att = torch.matmul(q, k)  # [B, H, H]
        att = rearrange(att, 'b h w -> b 1 h w')  # 恢复空间维度：[B, 1, H, W]（H=W）
        # 步骤4：权重归一化与通道恢复：1×1卷积→Softmax
        att = self.s_conv(att)  # [B, in_dim, H, W]（通道数恢复为输入维度）
        att = self.softmax(att)  # 沿最后一维归一化：[B, in_dim, H, W]

        return att


class Conv(nn.Module):
    """
    普通卷积模块：3层并行普通卷积（空洞率=1）
    功能：提取细粒度局部特征，为注意力模块提供高质量Value（V）的基础特征
    输入输出维度：[B, in_dim, H, W] → [B, in_dim, H, W]（通道数不变）
    """

    def __init__(self, in_dim):
        super(Conv, self).__init__()
        # 3层conv_relu_bn，空洞率=1（普通卷积）
        self.convs = nn.ModuleList([conv_relu_bn(in_dim, in_dim, 1) for _ in range(3)])

    def forward(self, x):
        for conv in self.convs:
            x = conv(x)  # 逐层卷积，累积局部特征
        return x


class DConv(nn.Module):
    """
    空洞卷积模块：3层不同空洞率的空洞卷积（2→4→2）
    功能：动态调整感受野（先扩大后缩小），捕捉全局上下文的同时保留局部细节
    设计逻辑：对应文档1中“U型空洞卷积结构”，解决深层特征语义稀疏问题
    输入输出维度：[B, in_dim, H, W] → [B, in_dim, H, W]
    """

    def __init__(self, in_dim):
        super(DConv, self).__init__()
        dilation = [2, 4, 2]  # 空洞率序列：先扩大（2→4）增强全局感知，再缩小（4→2）细化细节
        self.dconvs = nn.ModuleList([conv_relu_bn(in_dim, in_dim, dirate) for dirate in dilation])

    def forward(self, x):
        for dconv in self.dconvs:
            x = dconv(x)  # 逐层空洞卷积，动态调整感受野
        return x


class ConvAttention(nn.Module):
    """
    卷积注意力模块（CLFT核心子模块）：融合普通卷积、空洞卷积与双线性注意力
    功能：同时捕捉局部细节（Conv）、全局上下文（DConv）与特征相关性（Attention）
    输入：[B, in_dim, H, W]
    输出：[B, in_dim, H, W]（注意力加权+残差连接后的特征）
    """

    def __init__(self, in_dim, in_feature, out_feature):
        super(ConvAttention, self).__init__()
        self.conv = Conv(in_dim)  # 普通卷积：提取局部细节特征（Q基础）
        self.dconv = DConv(in_dim)  # 空洞卷积：提取全局上下文特征（K基础）
        self.att = Attention(in_dim, in_feature, out_feature)  # 双线性注意力模块
        self.gamma = nn.Parameter(torch.zeros(1))  # 注意力权重系数（可学习，初始为0）

    def forward(self, x):
        # 步骤1：生成Value（V）：普通卷积特征+空洞卷积特征（融合局部与全局信息）
        q = self.conv(x)  # [B, in_dim, H, W]（局部特征）
        k = self.dconv(x)  # [B, in_dim, H, W]（全局特征）
        v = q + k  # [B, in_dim, H, W]（V特征：局部+全局融合）

        # 步骤2：计算注意力权重并加权V
        att = self.att(x)  # [B, in_dim, H, W]（注意力权重）
        out = torch.matmul(att, v)  # 注意力加权：[B, in_dim, H, W]

        # 步骤3：残差连接：注意力输出（γ控制权重）+ V + 原始输入x，避免梯度消失
        return self.gamma * out + v + x


class FeedForward(nn.Module):
    """
    前馈网络：卷积+残差连接，增强特征非线性表达
    功能：对注意力输出的特征进行进一步变换，提升模型表达能力
    输入：[B, in_dim, H, W]
    输出：[B, out_dim, H, W]（通道数从in_dim调整为out_dim）
    """

    def __init__(self, in_dim, out_dim):
        super(FeedForward, self).__init__()
        self.conv = conv_relu_bn(in_dim, out_dim, 1)  # 1×1卷积：调整通道+激活
        # 额外1×1卷积分支：保留原始特征结构，用于残差连接
        self.x_conv = nn.Sequential(
            nn.Conv2d(in_dim, out_dim, kernel_size=1),
            nn.BatchNorm2d(out_dim),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        out = self.conv(x)  # 卷积分支输出：[B, out_dim, H, W]
        x = self.x_conv(x)  # 原始特征分支输出：[B, out_dim, H, W]
        return x + out  # 残差连接：融合两分支特征


class ConvTransformer(nn.Module):
    """
    CLFT核心模块：卷积注意力 + 前馈网络（Transformer编码器结构）
    功能：打破CNN局部感受野限制，同时解决纯Transformer缺乏卷积归纳偏置的问题
    输入：[B, in_dim, H, W]
    输出：[B, out_dim, H, W]
    """

    def __init__(self, in_dim, out_dim, in_feature, out_feature):
        super(ConvTransformer, self).__init__()
        self.attention = ConvAttention(in_dim, in_feature, out_feature)  # 注意力层
        self.feedforward = FeedForward(in_dim, out_dim)  # 前馈层

    def forward(self, x):
        # 步骤1：注意力层：捕捉特征相关性与全局信息
        x = self.attention(x)
        # 步骤2：前馈层：增强特征非线性表达
        out = self.feedforward(x)
        return out

if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 64, 32, 32).to(device)

    # in_dim和out_dim是输入输出特征通道数
    # in_feature是输入特征数，为H*W
    # out_feature是输出特征数，为H
    model = ConvTransformer(64, 64, 32*32, 32)

    model.to(device)
    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("知乎、CSDN：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)