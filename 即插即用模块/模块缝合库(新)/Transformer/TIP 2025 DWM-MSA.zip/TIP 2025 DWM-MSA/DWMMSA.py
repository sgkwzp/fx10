import torch.nn as nn
import torch
import torch.nn.functional as F
from einops import rearrange
from torch import einsum


class DWM_MSA(nn.Module):
    """
    双窗口多尺度多头自注意力模块（Dual-Window Multiscale Multi-head Self-Attention, DWM-MSA）
    功能：通过双窗口尺度（小窗口+大窗口）与局部-非局部双分支，捕捉多尺度特征依赖
    核心设计：
        - 双窗口尺度：window_size1（小窗口，如8×8）捕捉局部细节，window_size2（大窗口，如16×16）捕捉中程依赖
        - 局部-非局部分支：每个窗口尺度下分两支，局部分支聚焦窗口内关联，非局部分支扩展长距离交互
        - 通道拆分并行：Q/K/V通道拆分为4份，分别适配双窗口的局部-非局部分支，提升计算并行性
        - 多头注意力增强：多头部并行计算，捕捉不同维度的特征依赖
    Args:
        dim: 输入特征通道数
        window_size1: 小窗口尺寸（默认(8,8)）
        window_size2: 大窗口尺寸（默认(16,16)）
        dim_head: 单个注意力头的维度（默认28）
        heads: 注意力头数（默认2）
    """

    def __init__(
            self,
            dim,
            window_size1=(8, 8),
            window_size2=(16, 16),
            dim_head=28,
            heads=2,
    ):
        super().__init__()
        self.dim = dim
        self.heads = heads
        self.scale = dim_head ** -0.5  # 注意力缩放因子
        self.window_size1 = window_size1  # 小窗口（局部）
        self.window_size2 = window_size2  # 大窗口（中程）

        inner_dim = dim_head * heads  # 多头总维度
        # Q/K/V线性投影
        self.to_q = nn.Linear(dim, inner_dim, bias=False)
        self.to_k = nn.Linear(dim, inner_dim, bias=False)
        self.to_v = nn.Linear(dim, inner_dim, bias=False)
        # 输出投影
        self.to_out = nn.Linear(inner_dim, dim)

    def forward(self, x):
        """
        前向传播：Q/K/V生成→通道拆分→双窗口双分支注意力→融合输出
        Args:
            x: 输入特征，shape=[b, h, w, c]（batch×高度×宽度×通道）
        Returns:
            注意力增强特征，shape=[b, h, w, c]（与输入维度一致）
        """
        b, h, w, _ = x.shape
        w1_h, w1_w = self.window_size1
        w2_h, w2_w = self.window_size2

        # 验证输入尺寸是否能被窗口尺寸整除
        assert h % w1_h == 0 and w % w1_w == 0, '特征高度/宽度需能被小窗口尺寸整除'
        assert h % w2_h == 0 and w % w2_w == 0, '特征高度/宽度需能被大窗口尺寸整除'

        # 1. Q/K/V线性投影
        q = self.to_q(x)
        k = self.to_k(x)
        v = self.to_v(x)
        _, _, _, c = q.shape

        # 2. 通道拆分（4份，分别对应双窗口的局部-非局部分支）
        q1, q2, q3, q4 = q[:, :, :, :c // 4], q[:, :, :, c // 4:c // 2], q[:, :, :, c // 2:3 * c // 4], q[:, :, :,
                                                                                                        3 * c // 4:]
        k1, k2, k3, k4 = k[:, :, :, :c // 4], k[:, :, :, c // 4:c // 2], k[:, :, :, c // 2:3 * c // 4], k[:, :, :,
                                                                                                        3 * c // 4:]
        v1, v2, v3, v4 = v[:, :, :, :c // 4], v[:, :, :, c // 4:c // 2], v[:, :, :, c // 2:3 * c // 4], v[:, :, :,
                                                                                                        3 * c // 4:]

        # -------------------------- 小窗口（window_size1）分支 --------------------------
        # 3. 小窗口局部分支（q1/k1/v1）
        # 窗口划分：[b, h, w, c1] → [b, 窗口数, 窗口内像素数, c1]
        q1, k1, v1 = map(
            lambda t: rearrange(t, 'b (h b0) (w b1) c -> b (h w) (b0 b1) c', b0=w1_h, b1=w1_w),
            (q1, k1, v1)
        )
        # 多头维度调整：[b, 窗口数, 窗口内像素数, c1] → [b, 窗口数, heads, 窗口内像素数, dim_head]
        q1, k1, v1 = map(
            lambda t: rearrange(t, 'b n mm (h d) -> b n h mm d', h=self.heads),
            (q1, k1, v1)
        )
        q1 *= self.scale  # 缩放
        sim1 = einsum('b n h i d, b n h j d -> b n h i j', q1, k1)  # 注意力相似度
        attn1 = sim1.softmax(dim=-1)  # 注意力权重归一化
        out1 = einsum('b n h i j, b n h j d -> b n h i d', attn1, v1)  # 价值加权
        out1 = rearrange(out1, 'b n h mm d -> b n mm (h d)')  # 多头结果拼接

        # 4. 小窗口非局部分支（q2/k2/v2）（通过维度置换扩展长距离交互）
        q2, k2, v2 = map(
            lambda t: rearrange(t, 'b (h b0) (w b1) c -> b (h w) (b0 b1) c', b0=w1_h, b1=w1_w),
            (q2, k2, v2)
        )
        q2, k2, v2 = map(lambda t: t.permute(0, 2, 1, 3), (q2.clone(), k2.clone(), v2.clone()))  # 置换窗口数与像素数维度
        q2, k2, v2 = map(
            lambda t: rearrange(t, 'b n mm (h d) -> b n h mm d', h=self.heads),
            (q2, k2, v2)
        )
        q2 *= self.scale
        sim2 = einsum('b n h i d, b n h j d -> b n h i j', q2, k2)
        attn2 = sim2.softmax(dim=-1)
        out2 = einsum('b n h i j, b n h j d -> b n h i d', attn2, v2)
        out2 = rearrange(out2, 'b n h mm d -> b n mm (h d)')
        out2 = out2.permute(0, 2, 1, 3)  # 恢复维度顺序

        # 5. 小窗口双分支融合+窗口还原
        out_1 = torch.cat([out1, out2], dim=-1).contiguous()
        out_1 = rearrange(
            out_1, 'b (h w) (b0 b1) c -> b (h b0) (w b1) c',
            h=h // w1_h, w=w // w1_w, b0=w1_h
        )  # 还原为[b, h, w, c1+c2]

        # -------------------------- 大窗口（window_size2）分支 --------------------------
        # 6. 大窗口局部分支（q3/k3/v3）（流程同小窗口局部分支）
        q3, k3, v3 = map(
            lambda t: rearrange(t, 'b (h b0) (w b1) c -> b (h w) (b0 b1) c', b0=w2_h, b1=w2_w),
            (q3, k3, v3)
        )
        q3, k3, v3 = map(
            lambda t: rearrange(t, 'b n mm (h d) -> b n h mm d', h=self.heads),
            (q3, k3, v3)
        )
        q3 *= self.scale
        sim3 = einsum('b n h i d, b n h j d -> b n h i j', q3, k3)
        attn3 = sim3.softmax(dim=-1)
        out3 = einsum('b n h i j, b n h j d -> b n h i d', attn3, v3)
        out3 = rearrange(out3, 'b n h mm d -> b n mm (h d)')

        # 7. 大窗口非局部分支（q4/k4/v4）（流程同小窗口非局部分支）
        q4, k4, v4 = map(
            lambda t: rearrange(t, 'b (h b0) (w b1) c -> b (h w) (b0 b1) c', b0=w2_h, b1=w2_w),
            (q4, k4, v4)
        )
        q4, k4, v4 = map(lambda t: t.permute(0, 2, 1, 3), (q4.clone(), k4.clone(), v4.clone()))
        q4, k4, v4 = map(
            lambda t: rearrange(t, 'b n mm (h d) -> b n h mm d', h=self.heads),
            (q4, k4, v4)
        )
        q4 *= self.scale
        sim4 = einsum('b n h i d, b n h j d -> b n h i j', q4, k4)
        attn4 = sim4.softmax(dim=-1)
        out4 = einsum('b n h i j, b n h j d -> b n h i d', attn4, v4)
        out4 = rearrange(out4, 'b n h mm d -> b n mm (h d)')
        out4 = out4.permute(0, 2, 1, 3)

        # 8. 大窗口双分支融合+窗口还原
        out_2 = torch.cat([out3, out4], dim=-1).contiguous()
        out_2 = rearrange(
            out_2, 'b (h w) (b0 b1) c -> b (h b0) (w b1) c',
            h=h // w2_h, w=w // w2_w, b0=w2_h
        )  # 还原为[b, h, w, c3+c4]

        # -------------------------- 最终融合 --------------------------
        # 9. 双窗口特征聚合+输出投影
        out = torch.cat([out_1, out_2], dim=-1).contiguous()
        out = self.to_out(out)
        return out


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 32, 32, 64).to(device)
    model = DWM_MSA(64).to(device)

    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN、小红书：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)
