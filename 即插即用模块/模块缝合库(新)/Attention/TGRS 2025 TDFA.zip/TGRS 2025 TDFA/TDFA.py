import torch
import torch.nn as nn
from mmcv.cnn import ConvModule
from mmcv.ops import DeformConv2dPack
from mmagic.models.archs import ResidualBlockNoBN
from mmagic.models.utils import make_layer

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


## TDFA module
class TDDA(nn.Module):
    def __init__(self,
                 in_channels=1,
                 mid_channels=32,
                 out_channels=1,
                 position_dim=1089
                 ):
        super(TDDA, self).__init__()

        self.position_dim = position_dim
        self.sigmoid = nn.Sigmoid()
        # self.head_conv = nn.Conv2d(in_channels * 2, out_channels, 3, 1, 1, bias=False)
        self.mlp = nn.Linear(position_dim, position_dim)
        self.feat_extract = nn.Sequential(
            ConvModule(in_channels, mid_channels, 3, padding=1)
        )

        self.feat_aggregate = SK(mid_channels)

        self.align_1 = AugmentedDeformConv2dPack(
            mid_channels, mid_channels, 3, padding=1, deform_groups=1)
        self.align_2 = DeformConv2dPack(
            mid_channels, mid_channels, 3, padding=1, deform_groups=1)
        self.conv = nn.Conv2d(mid_channels, 1, 3, padding=1, bias=True)
        # self.tail_conv = nn.Conv2d(in_channels * 5, out_channels, 3, 1, 1, bias=False)
        self.tail_conv = nn.Sequential(
            ConvModule(in_channels * 5, mid_channels, 3, padding=1),  # 改帧
            make_layer(
                ResidualBlockNoBN,
                5,
                mid_channels=mid_channels),
            nn.Conv2d(mid_channels, out_channels, 3, 1, 1, bias=False))

    def generate_positional_encoding(self, seq_len, feature_dim):
        # Define the time step vector
        time_steps = torch.arange(seq_len).view(-1, 1)  # 形状为 (20, 1)
        pe = time_steps.repeat(1, feature_dim)
        pe = pe / 20

        return pe

    def forward(self, x):
        t, hw = x.shape
        ## add position encoding
        position_encoding = self.generate_positional_encoding(t, self.position_dim).to(x.device)
        position_encoding = self.mlp(position_encoding)
        position_encoding = self.sigmoid(position_encoding)
        x = x * position_encoding
        x = x.view(-1, 1, 33, 33)

        # alignment of frames
        index = []
        final = []
        aligned_imgs = {}
        for j in range(2, t - 2):
            aligned_fea = []
            for i in range(-2, 3):
                m = j + i
                feat_center = x[j, :, :, :].contiguous()
                feat_center = feat_center.view(1, -1, 33, 33)
                if i == 0:
                    aligned_fea.append(feat_center)
                else:
                    feat_center = self.feat_extract(feat_center)
                    feat_neig = x[m, :, :, :].contiguous()
                    feat_neig = feat_neig.view(1, -1, 33, 33)
                    feat_neig = self.feat_extract(feat_neig)
                    feat_agg = self.feat_aggregate(feat_center, feat_neig)
                    aligned_feat = self.align_2(self.align_1(feat_neig, feat_agg))
                    aligned_fea.append(self.conv(aligned_feat))

            aligned_fea = torch.cat(aligned_fea, dim=1)

            # output center frame and the aligned frames
            x_final = self.tail_conv(aligned_fea).view(1, hw)
            aligned_fea = aligned_fea.view(5, hw)
            index.append(j)
            final.append(x_final)
            aligned_imgs[j] = aligned_fea
        return final, index, aligned_imgs