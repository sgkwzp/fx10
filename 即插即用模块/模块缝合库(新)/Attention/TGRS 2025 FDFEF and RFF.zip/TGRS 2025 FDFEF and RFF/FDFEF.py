# 频域特征增强融合模块（Frequency-Domain Feature Enhancement Fusion, FDFEF）
# 核心设计：针对双模态特征（如RGB-深度），通过“频域转换→频域加权增强→幅值-相位分离融合→空域还原”的流程，
# 在频域中分别优化双模态的幅值（强度）与相位（结构）信息，实现频域层面的增强与融合，提升双模态特征的协同表达能力

import torch
import torch.nn as nn
import torch.fft


class FourierBlock(nn.Module):
    """
    频域特征增强融合模块（Frequency-Domain Feature Enhancement Fusion, FDFEF）
    功能：双模态特征频域增强+幅值-相位加权融合，实现频域-空域协同优化
    核心设计：
        - 双模态独立频域增强：为每类模态设计可学习频域权重，针对性优化频域特征
        - 幅值-相位分离融合：分别加权双模态的幅值（强度）与相位（结构），比整体融合更精准
        - 端到端可微分：频域变换与权重学习全程可微分，支持反向传播训练
        - 动态权重初始化：频域权重随输入尺寸自适应初始化，适配不同分辨率特征
    Args:
        channels1: 第一模态（如RGB）输入通道数
        channels2: 第二模态（如深度）输入通道数
    """
    def __init__(self, channels1, channels2):
        super(FourierBlock, self).__init__()

        self.W_L1 = None
        self.W_L2 = None

        self.magnitude_weight1 = nn.Parameter(torch.randn(channels1, 1, 1))
        self.magnitude_weight2 = nn.Parameter(torch.randn(channels2, 1, 1))
        self.phase_weight1 = nn.Parameter(torch.randn(channels1, 1, 1))
        self.phase_weight2 = nn.Parameter(torch.randn(channels2, 1, 1))

    def forward(self, f_G):
        x1, x2 = f_G

        batch_size, channels1, height, width = x1.shape
        batch_size, channels2, height, width = x2.shape

        if self.W_L1 is None or self.W_L1.shape[0] != channels1 or self.W_L1.shape[1] != height or self.W_L1.shape[
            2] != width:
            device = x1.device
            self.W_L1 = nn.Parameter(torch.randn(channels1, height, width, dtype=torch.cfloat, device=device))
            nn.init.xavier_uniform_(self.W_L1.real)
            nn.init.zeros_(self.W_L1.imag)

        if self.W_L2 is None or self.W_L2.shape[0] != channels2 or self.W_L2.shape[1] != height or self.W_L2.shape[
            2] != width:
            device = x2.device
            self.W_L2 = nn.Parameter(torch.randn(channels2, height, width, dtype=torch.cfloat, device=device))
            nn.init.xavier_uniform_(self.W_L2.real)
            nn.init.zeros_(self.W_L2.imag)

        f_SF1 = torch.fft.fft2(x1, dim=(-2, -1))
        f_FW1 = f_SF1 * self.W_L1
        f_FS1 = torch.fft.ifft2(f_FW1, dim=(-2, -1))
        x_FS1 = f_FS1.real + x1
        x_FS11 = torch.fft.fft2(x_FS1, dim=(-2, -1))

        f_SF2 = torch.fft.fft2(x2, dim=(-2, -1))
        f_FW2 = f_SF2 * self.W_L2
        f_FS2 = torch.fft.ifft2(f_FW2, dim=(-2, -1))
        x_FS2 = f_FS2.real + x2
        x_FS22 = torch.fft.fft2(x_FS2, dim=(-2, -1))

        magnitude1 = torch.abs(x_FS11)
        phase1 = torch.angle(x_FS11)
        magnitude2 = torch.abs(x_FS22)
        phase2 = torch.angle(x_FS22)

        fused_magnitude = (self.magnitude_weight1 * magnitude1) + (self.magnitude_weight2 * magnitude2)
        fused_phase = (self.phase_weight1 * phase1) + (self.phase_weight2 * phase2)

        fused_complex = fused_magnitude * torch.exp(1j * fused_phase)

        fused_x = torch.fft.ifft2(fused_complex, dim=(-2, -1)).real

        return fused_x


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    rgb = torch.randn(1, 64, 32, 32).to(device)
    depth = torch.randn(1, 1, 32, 32).to(device)
    model = FourierBlock(64, 64).to(device)

    x = [rgb, depth]

    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN、小红书：十小大")

    print("输入RGB特征维度：", rgb.shape)
    print("输入depth特征维度：", depth.shape)
    print("输出特征维度：", y.shape)