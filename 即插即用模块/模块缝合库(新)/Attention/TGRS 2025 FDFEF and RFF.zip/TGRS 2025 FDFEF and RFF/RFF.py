# 残差特征融合模块（Residual Feature Fusion, RFF）
# 核心设计：针对双输入特征（如主特征-跳跃连接特征），通过“通道适配→通道增强→注意力加权→多尺度强化→残差融合”的流程，
# 动态适配特征维度与尺度，结合可学习非线性变换与注意力机制，实现双特征的深度融合与增强，提升特征表达的完整性与针对性

import torch
import torch.nn as nn
import torch.nn.functional as F

# CVPR 2025 Transformers without Normalization
class DyT(nn.Module):
    def __init__(self, num_features, alpha_init_value=0.5):
        super().__init__()
        self.alpha = nn.Parameter(torch.ones(1) * alpha_init_value)
        self.weight = nn.Parameter(torch.ones(num_features))
        self.bias = nn.Parameter(torch.zeros(num_features))

    def forward(self, x):
        x = torch.tanh(self.alpha * x)
        return x * self.weight.view(1, -1, 1, 1) + self.bias.view(1, -1, 1, 1)


class DFF(nn.Module):
    """
    残差特征融合模块（Residual Feature Fusion, RFF）
    功能：双特征动态适配→增强→融合→残差优化，实现高质量特征融合
    核心设计：
        - 动态维度适配：自动生成1×1卷积，适配双特征通道数差异
        - 动态尺度适配：上采样调整跳跃连接特征尺度，匹配主特征
        - 通道增强：拼接特征经双通道增强与非线性变换，强化特征交互
        - 注意力加权：生成双特征融合注意力掩码，强化关键信息
        - 多尺度强化：分组卷积捕捉局部依赖，提升特征细节
        - 残差融合： shortcut 分支保留原始特征信息，避免过度增强
    Args:
        dim: 目标输出通道数
    """
    def __init__(self, dim):
        super().__init__()
        self.dim = dim

        self.conv_adj_x = None
        self.conv_adj_skip = None

        self.channel_enhance = nn.Sequential(
            nn.Conv2d(dim * 2, dim * 2, kernel_size=1),
            DyT(dim * 2),
            nn.ReLU(inplace=True),
        )

        self.att_conv1 = nn.Conv2d(dim, dim, kernel_size=1, bias=True)
        self.att_conv2 = nn.Conv2d(dim, dim, kernel_size=1, bias=True)
        self.nonlin = nn.Sigmoid()

        self.fuse_conv = nn.Sequential(
            nn.Conv2d(dim * 2, dim, kernel_size=1, bias=False),
            DyT(dim),
            nn.ReLU(inplace=True)
        )

        self.mutiscale_conv = nn.Sequential(
            nn.Conv2d(dim, dim, kernel_size=3, padding=1, groups=dim // 4, bias=False),
            DyT(dim),
            nn.ReLU(inplace=True)
        )

        self.final_dy_t = DyT(dim)

        self.shortcut = nn.Sequential(
            nn.Conv2d(dim * 2, dim, kernel_size=1, bias=False),
            DyT(dim)
        )

    def forward(self, x1):
        skip, x = x1

        if x.shape[1] != self.dim:
            if self.conv_adj_x is None:
                self.conv_adj_x = nn.Conv2d(x.shape[1], self.dim, kernel_size=1, bias=False).to(x.device)
            x = self.conv_adj_x(x)
        if skip.shape[1] != self.dim:
            if self.conv_adj_skip is None:
                self.conv_adj_skip = nn.Conv2d(skip.shape[1], self.dim, kernel_size=1, bias=False).to(skip.device)
            skip = self.conv_adj_skip(skip)

        if skip.shape[2:] != x.shape[2:]:
            skip = F.interpolate(skip, size=x.shape[2:], mode='bilinear', align_corners=True)

        channel_enhanced = self.channel_enhance(torch.cat([x, skip], dim=1))

        fused = self.fuse_conv(channel_enhanced)

        att1 = self.att_conv1(x)
        att2 = self.att_conv2(skip)
        att = self.nonlin(att1 + att2)

        multiscale = self.mutiscale_conv(fused * att)

        residual = self.shortcut(torch.cat([x, skip], dim=1))

        output = self.final_dy_t(multiscale + residual)

        return output


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    f1 = torch.randn(1, 64, 32, 32).to(device)
    f2 = torch.randn(1, 64, 32, 32).to(device)
    model = DFF(64).to(device)

    x = [f1, f2]

    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN、小红书：十小大")

    print("输入f1特征维度：", f1.shape)
    print("输入f2特征维度：", f2.shape)
    print("输出特征维度：", y.shape)

