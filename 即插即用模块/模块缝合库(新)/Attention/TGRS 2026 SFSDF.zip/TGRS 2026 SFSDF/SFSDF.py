import torch
import torch.nn as nn
import math

# -------------------------- 预定义DCT关键频率索引 对应结构图SFGSA的频率选择 --------------------------
def get_freq_indices(method):
    """
    获取DCT变换的关键频率分量索引，支持top(高频)、low(低频)、bot(高频)三种选择
    对应结构图SFGSA中DCT基的频率筛选环节
    """
    assert method in ['top1', 'top2', 'top4', 'top8', 'top16', 'top32',
                      'bot1', 'bot2', 'bot4', 'bot8', 'bot16', 'bot32',
                      'low1', 'low2', 'low4', 'low8', 'low16', 'low32']
    num_freq = int(method[3:])
    if 'top' in method:
        all_top_indices_x = [0, 0, 6, 0, 0, 1, 1, 4, 5, 1, 3, 0, 0, 0, 3, 2, 4, 6, 3, 5, 5, 2, 6, 5, 5, 3, 3, 4, 2, 2,
                             6, 1]
        all_top_indices_y = [0, 1, 0, 5, 2, 0, 2, 0, 0, 6, 0, 4, 6, 3, 5, 2, 6, 3, 3, 3, 5, 1, 1, 2, 4, 2, 1, 1, 3, 0,
                             5, 3]
        mapper_x = all_top_indices_x[:num_freq]
        mapper_y = all_top_indices_y[:num_freq]
    elif 'low' in method:
        all_low_indices_x = [0, 0, 1, 1, 0, 2, 2, 1, 2, 0, 3, 4, 0, 1, 3, 0, 1, 2, 3, 4, 5, 0, 1, 2, 3, 4, 5, 6, 1, 2,
                             3, 4]
        all_low_indices_y = [0, 1, 0, 1, 2, 0, 1, 2, 2, 3, 0, 0, 4, 3, 1, 5, 4, 3, 2, 1, 0, 6, 5, 4, 3, 2, 1, 0, 6, 5,
                             4, 3]
        mapper_x = all_low_indices_x[:num_freq]
        mapper_y = all_low_indices_y[:num_freq]
    elif 'bot' in method:
        all_bot_indices_x = [6, 1, 3, 3, 2, 4, 1, 2, 4, 4, 5, 1, 4, 6, 2, 5, 6, 1, 6, 2, 2, 4, 3, 3, 5, 5, 6, 2, 5, 5,
                             3, 6]
        all_bot_indices_y = [6, 4, 4, 6, 6, 3, 1, 4, 4, 5, 6, 5, 2, 2, 5, 1, 4, 3, 5, 0, 3, 1, 1, 2, 4, 2, 1, 1, 5, 3,
                             3, 3]
        mapper_x = all_bot_indices_x[:num_freq]
        mapper_y = all_bot_indices_y[:num_freq]
    else:
        raise NotImplementedError
    return mapper_x, mapper_y

# -------------------------- 对应结构图【SFGSA】多光谱分组自注意力核心层 --------------------------
class MultiSpectralAttentionLayer(torch.nn.Module):
    """
    多光谱注意力层（SFGSA核心）
    完整对应结构图下方SFGSA虚线框，核心功能：基于DCT提取关键频率分量，生成频域注意力权重
    """
    def __init__(self, channel, dct_h, dct_w, reduction=16, freq_sel_method='top16'):
        super(MultiSpectralAttentionLayer, self).__init__()
        self.reduction = reduction
        self.dct_h = dct_h
        self.dct_w = dct_w
        # 获取关键频率索引
        mapper_x, mapper_y = get_freq_indices(freq_sel_method)
        self.num_split = len(mapper_x)
        # 预生成DCT滤波器
        self.dct_layer = MultiSpectralDCTLayer(dct_h, dct_w, mapper_x, mapper_y, channel)
        # 注意力MLP
        self.fc = nn.Sequential(
            nn.Linear(channel, channel // reduction, bias=False),
            nn.ReLU(inplace=True),
            nn.Linear(channel // reduction, channel, bias=False),
            nn.Sigmoid()
        )

    def forward(self, x):
        n, c, h, w = x.shape
        x_pooled = x
        # 自适应调整尺寸到DCT滤波器大小
        if h != self.dct_h or w != self.dct_w:
            x_pooled = torch.nn.functional.adaptive_avg_pool2d(x, (self.dct_h, self.dct_w))
        # DCT变换提取频域特征
        y = self.dct_layer(x_pooled)
        # 生成频域注意力权重
        y = self.fc(y).view(n, c, 1, 1)
        # 注意力加权原始特征
        return x * y.expand_as(x)

class MultiSpectralDCTLayer(nn.Module):
    """
    多光谱DCT变换层
    对应结构图SFGSA中的DCT基生成与变换环节，预生成固定DCT滤波器，实现高效频域特征提取
    """
    def __init__(self, height, width, mapper_x, mapper_y, channel):
        super(MultiSpectralDCTLayer, self).__init__()
        assert len(mapper_x) == len(mapper_y)
        assert channel % len(mapper_x) == 0
        self.num_freq = len(mapper_x)
        # 预生成DCT滤波器并注册为缓冲区（无参数）
        self.register_buffer('weight', self.get_dct_filter(height, width, mapper_x, mapper_y, channel))

    def forward(self, x):
        assert len(x.shape) == 4, 'x must been 4 dimensions, but got ' + str(len(x.shape))
        # 元素乘DCT滤波器，提取频域特征
        x = x * self.weight
        # 空间维度求和，得到通道级频域特征
        result = torch.sum(x, dim=[2, 3])
        return result

    def build_filter(self, pos, freq, POS):
        """构建一维DCT基函数"""
        result = math.cos(math.pi * freq * (pos + 0.5) / POS) / math.sqrt(POS)
        if freq == 0:
            return result
        else:
            return result * math.sqrt(2)

    def get_dct_filter(self, tile_size_x, tile_size_y, mapper_x, mapper_y, channel):
        """构建二维DCT滤波器"""
        dct_filter = torch.zeros(channel, tile_size_x, tile_size_y)
        c_part = channel // len(mapper_x)
        for i, (u_x, v_y) in enumerate(zip(mapper_x, mapper_y)):
            for t_x in range(tile_size_x):
                for t_y in range(tile_size_y):
                    dct_filter[i * c_part: (i + 1) * c_part, t_x, t_y] = self.build_filter(t_x, u_x,
                                                                                           tile_size_x) * self.build_filter(
                        t_y, v_y, tile_size_y)
        return dct_filter

# -------------------------- SFSDF核心模块 完整对应结构图全流程 --------------------------
class SpecBlock(nn.Module):
    """
    SFSDF: Spectral Frequency and Spatial-Domain Fusion 频谱-空域融合模块
    完整对应结构图全流程，核心功能：多尺度空域分支+多光谱频域分支并行融合，实现局部细节与全局结构的联合增强
    输入：[B, C, H, W]，输出：[B, C, H, W]，即插即用
    """
    expansion = 1
    def __init__(self, inplanes, planes, stride=1, downsample=None, groups=1,
                 base_width=64, dilation=1, norm_layer=None,
                 *, reduction=16, ):
        super(SpecBlock, self).__init__()
        # 通道-分辨率映射表，适配不同网络阶段
        c2wh = dict([(64,56), (128,28), (256,14) ,(512,7)])
        self.planes = planes

        # -------------------------- 频域分支 对应结构图SFGSA分支 --------------------------
        self.conv1 = nn.Conv2d(inplanes, planes, kernel_size=3, stride=stride, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(planes)
        self.conv2 = nn.Conv2d(planes, planes, kernel_size=3, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(planes)
        self.relu = nn.ReLU(inplace=True)
        # 多光谱注意力层（SFGSA核心）
        self.att = MultiSpectralAttentionLayer(planes, c2wh[planes], c2wh[planes],  reduction=reduction, freq_sel_method = 'top16')

        # -------------------------- 空域分支 对应结构图多尺度卷积分支 --------------------------
        self.downsample = downsample
        self.stride = stride
        # 多尺度卷积：1×1、3×3、5×5，对应结构图K=1/3/5的Conv+BN
        self.conv_s1 = nn.Conv2d(inplanes, planes, kernel_size=5, stride=stride, padding=2, bias=False)
        self.conv_s2 = nn.Conv2d(inplanes, planes, kernel_size=3, stride=stride, padding=1, bias=False)
        self.conv_s3 = nn.Conv2d(inplanes, planes, kernel_size=1, stride=stride, padding=0, bias=False)
        self.bn_s1 = nn.BatchNorm2d(planes)
        self.bn_s2 = nn.BatchNorm2d(planes)
        self.bn_s3 = nn.BatchNorm2d(planes)

        # -------------------------- 双分支融合 对应结构图拼接+卷积融合 --------------------------
        self.conv_mix1 = nn.Conv2d(planes * 2, planes, kernel_size=3, padding=1, bias=False)
        self.conv_mixRes = nn.Conv2d(planes * 2, planes, kernel_size=1, padding=0, bias=False)
        self.conv_mix2 = nn.Conv2d(planes, planes, kernel_size=3, padding=1, bias=False)
        self.bn_mix = nn.BatchNorm2d(planes)
        self.bn3 = nn.BatchNorm2d(planes)

    @staticmethod
    def channel_shuffle(x, groups):
        """通道混洗，可选增强跨分支信息交互"""
        b, c, h, w = x.shape
        x = x.reshape(b, groups, -1, h, w)
        x = x.permute(0, 2, 1, 3, 4)
        x = x.reshape(b, -1, h, w)
        return x

    def forward(self, x):
        residual = x
        # 频域分支前向
        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)
        out = self.conv2(out)
        out = self.bn2(out)
        out = self.att(out)  # SFGSA频域注意力增强
        if self.downsample is not None:
            residual = self.downsample(x)

        # 空域多尺度分支前向
        out1 = self.conv_s1(x)
        out1 = self.bn_s1(out1)
        out2 = self.conv_s2(x)
        out2 = self.bn_s2(out2)
        out3 = self.conv_s3(x)
        out3 = self.bn_s3(out3)
        out_sp = out1 + out2 + out3  # 多尺度特征融合

        # 双分支拼接融合 对应结构图C拼接环节
        out_mix = torch.cat([out, out_sp], dim=1)
        out_mixRes = self.conv_mixRes(out_mix)  # 残差投影
        out_mix = self.conv_mix1(out_mix)
        out_mix = self.bn_mix(out_mix)
        out_mix = self.relu(out_mix)
        out_mix = self.conv_mix2(out_mix)
        out_mix = out_mix + out_mixRes  # 残差连接
        out_mix = self.bn3(out_mix)
        out_mix = self.relu(out_mix)

        return out_mix


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    x = torch.randn(1, 64, 32, 32).to(device)
    model = SpecBlock(64, 64).to(device)
    y = model(x)
    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("小红书：十小大，主页获取往期全部即插即用代码，200+大合集")
    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)