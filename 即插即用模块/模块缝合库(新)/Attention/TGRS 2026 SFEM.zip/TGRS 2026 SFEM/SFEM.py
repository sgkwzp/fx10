import torch
import torch.nn as nn
import numpy as np
from einops import rearrange

def autopad(k, p=None, d=1):
    """自动计算padding，保证卷积输出尺寸与输入一致，适配不同卷积核、膨胀率"""
    if d > 1:
        k = d * (k - 1) + 1 if isinstance(k, int) else [d * (x - 1) + 1 for x in k]
    if p is None:
        p = k // 2 if isinstance(k, int) else [x // 2 for x in k]
    return p

class Conv(nn.Module):
    """
    标准卷积封装 对应结构图中所有Conv模块
    集成卷积+BN+激活函数，统一模块接口，简化搭建
    """
    default_act = nn.SiLU()  # 默认激活函数
    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, d=1, act=True):
        super().__init__()
        self.conv = nn.Conv2d(c1, c2, k, s, autopad(k, p, d), groups=g, dilation=d, bias=False)
        self.bn = nn.BatchNorm2d(c2)
        self.act = self.default_act if act is True else act if isinstance(act, nn.Module) else nn.Identity()

    def forward(self, x):
        return self.act(self.bn(self.conv(x)))

    def forward_fuse(self, x):
        """推理时卷积+BN融合，加速推理"""
        return self.act(self.conv(x))

class ScharrConv(nn.Module):
    """
    Scharr边缘提取卷积 对应结构图中Kx、Ky双方向梯度核
    核心功能：固定权重的Scharr算子，提取输入特征的x/y方向梯度，融合得到边缘特征图
    权重固定不训练，零参数量，精准捕捉图像边缘、纹理、细节信息
    """
    def __init__(self, channel):
        super(ScharrConv, self).__init__()
        # Scharr x/y方向梯度核，经典边缘检测算子，对弱边缘响应更敏感
        scharr_kernel_x = np.array([[3, 0, -3],
                                    [10, 0, -10],
                                    [3, 0, -3]], dtype=np.float32)
        scharr_kernel_y = np.array([[3, 10, 3],
                                    [0, 0, 0],
                                    [-3, -10, -3]], dtype=np.float32)
        # 核维度适配：扩展到输入通道数，分组卷积适配多通道
        scharr_kernel_x = torch.tensor(scharr_kernel_x, dtype=torch.float32).unsqueeze(0).unsqueeze(0)
        scharr_kernel_y = torch.tensor(scharr_kernel_y, dtype=torch.float32).unsqueeze(0).unsqueeze(0)
        self.scharr_kernel_x = scharr_kernel_x.expand(channel, 1, 3, 3)
        self.scharr_kernel_y = scharr_kernel_y.expand(channel, 1, 3, 3)

        # 分组卷积实现多通道边缘提取，权重固定不训练
        self.scharr_kernel_x_conv = nn.Conv2d(channel, channel, kernel_size=3, padding=1, groups=channel, bias=False)
        self.scharr_kernel_y_conv = nn.Conv2d(channel, channel, kernel_size=3, padding=1, groups=channel, bias=False)
        self.scharr_kernel_x_conv.weight.data = self.scharr_kernel_x.clone()
        self.scharr_kernel_y_conv.weight.data = self.scharr_kernel_y.clone()
        # 冻结权重，不参与训练，保证边缘先验的稳定性
        self.scharr_kernel_x_conv.requires_grad = False
        self.scharr_kernel_y_conv.requires_grad = False

    def forward(self, x):
        # 分别提取x、y方向梯度
        grad_x = self.scharr_kernel_x_conv(x)
        grad_y = self.scharr_kernel_y_conv(x)
        # 梯度融合，得到边缘幅度特征图
        edge_magnitude = grad_x * 0.5 + grad_y * 0.5
        return edge_magnitude

class FreqSpatial(nn.Module):
    """
    SFEM (Spatial–frequency Feature Enhancement Module) 空域-频域特征增强核心模块
    完整对应结构图全流程：双分支并行设计，上分支为空间边缘增强分支，下分支为频域全局建模分支
    核心功能：同时强化图像的局部边缘细节与全局结构信息，实现空域-频域特征的互补增强
    """
    def __init__(self, in_channels):
        super(FreqSpatial, self).__init__()
        # -------------------------- 空间分支（对应结构图上半部分） --------------------------
        self.sed = ScharrConv(in_channels)  # Scharr边缘提取模块
        self.spatial_conv1 = Conv(in_channels, in_channels)  # 边缘特征第一次卷积变换
        self.spatial_conv2 = Conv(in_channels, in_channels)  # 残差融合后的第二次卷积变换

        # -------------------------- 频域分支（对应结构图下半部分） --------------------------
        self.fft_conv = Conv(in_channels * 2, in_channels * 2, 3)  # 频域实虚部拼接后的卷积
        self.fft_conv2 = Conv(in_channels, in_channels, 3)  # 逆变换回空域后的特征卷积

        # -------------------------- 双分支融合输出 --------------------------
        self.final_conv = Conv(in_channels, in_channels, 1)  # 最终1x1卷积融合输出

    def forward(self, x):
        batch, c, h, w = x.size()

        # -------------------------- 空间分支前向流程 对应结构图上半部分 --------------------------
        # 步骤1：Scharr算子提取输入特征的边缘梯度信息
        spatial_feat = self.sed(x)
        # 步骤2：边缘特征第一次卷积变换
        spatial_feat = self.spatial_conv1(spatial_feat)
        # 步骤3：与原始输入残差融合，保留原始信息+强化边缘
        spatial_feat = self.spatial_conv2(spatial_feat + x)
        # 输出空间增强特征F_spatial

        # -------------------------- 频域分支前向流程 对应结构图下半部分 --------------------------
        # 步骤1：空域→频域RFFT变换，正交归一化保证数值稳定
        fft_feat = torch.fft.rfft2(x, norm='ortho')
        # 步骤2：拆分复数频域特征的实部、虚部，完整保留幅值+相位信息
        x_fft_real = torch.unsqueeze(torch.real(fft_feat), dim=-1)
        x_fft_imag = torch.unsqueeze(torch.imag(fft_feat), dim=-1)
        # 步骤3：实虚部在通道维度拼接，适配卷积操作
        fft_feat = torch.cat((x_fft_real, x_fft_imag), dim=-1)
        fft_feat = rearrange(fft_feat, 'b c h w d -> b (c d) h w').contiguous()
        # 步骤4：频域特征卷积变换，对应结构图中FFT后的Conv模块
        fft_feat = self.fft_conv(fft_feat)
        # 步骤5：维度还原，重构复数频域特征
        fft_feat = rearrange(fft_feat, 'b (c d) h w -> b c h w d', d=2).contiguous()
        fft_feat = torch.view_as_complex(fft_feat)
        # 步骤6：频域→空域IRFFT逆变换，回到空域
        fft_feat = torch.fft.irfft2(fft_feat, s=(h, w), norm='ortho')
        # 步骤7：空域特征卷积优化，输出频域增强特征F_frequency
        fft_feat = self.fft_conv2(fft_feat)

        # -------------------------- 双分支融合与输出 --------------------------
        # 空间增强特征与频域增强特征逐元素相加融合
        out = spatial_feat + fft_feat
        # 1x1卷积做最终特征融合，输出增强结果
        return self.final_conv(out)

# 模块测试代码
if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    x = torch.randn(1, 64, 32, 32).to(device)
    model = FreqSpatial(64).to(device)
    y = model(x)
    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("小红书：十小大，主页获取往期全部即插即用代码，200+大合集")
    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)