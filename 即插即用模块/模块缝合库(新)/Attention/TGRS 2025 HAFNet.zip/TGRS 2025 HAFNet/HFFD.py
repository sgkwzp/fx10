import torch
import torch.nn as nn


def autopad(k, p=None, d=1):  # kernel, padding, dilation
    # Pad to 'same' shape outputs
    if d > 1:
        k = d * (k - 1) + 1 if isinstance(k, int) else [d * (x - 1) + 1 for x in k]  # actual kernel-size
    if p is None:
        p = k // 2 if isinstance(k, int) else [x // 2 for x in k]  # auto-pad
    return p



class CBR(nn.Module):
    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, d=1, act=True):
        super().__init__()
        self.conv = nn.Conv2d(c1, c2, k, s, autopad(k, p, d), groups=g, dilation=d, bias=False)
        self.bn = nn.BatchNorm2d(c2)
        self.act = nn.ReLU()
        # self.act = self.default_act if ahaoct is True else act if isinstance(act, nn.Module) else nn.Identity()

    def forward(self, x):
        x = self.conv(x)
        x = self.bn(x)
        x = self.act(x)
        return x

    def forward_fuse(self, x):
        return self.act(self.conv(x))


class HFFD(nn.Module):
    def __init__(self, inchannel_encode, inchannel_hfe, inchannel_decode, out_channel):
        super(HFFD, self).__init__()

        self.conv1 = nn.Conv2d(inchannel_encode, out_channel, kernel_size=1, stride=1, bias=True)
        self.conv2 = nn.Conv2d(inchannel_hfe, out_channel, kernel_size=1, stride=1, bias=True)
        self.conv3 = nn.Conv2d(inchannel_decode, out_channel, kernel_size=1, stride=1, bias=True)

        self.conv4 = nn.Conv2d(out_channel * 2, out_channel, kernel_size=1, stride=1, bias=True)

        self.layer_conv1 = CBR(out_channel * 2, out_channel, 1)
        self.layer_conv2 = CBR(out_channel * 2, out_channel, 1)
        self.layer_conv3 = CBR(out_channel * 2, out_channel, 1)
        self.layer_conv4 = CBR(out_channel * 2, out_channel * 3, 1)

        # Dilation convolutions
        self.layer_dil1 = nn.Sequential(
            nn.Conv2d(out_channel, out_channel, kernel_size=3, stride=1, padding=1, dilation=1, bias=True),
            nn.BatchNorm2d(out_channel),
            nn.ReLU()
        )
        self.layer_dil2 = nn.Sequential(
            nn.Conv2d(out_channel, out_channel, kernel_size=3, stride=1, padding=2, dilation=2, bias=True),
            nn.BatchNorm2d(out_channel),
            nn.ReLU()
        )
        self.layer_dil3 = nn.Sequential(
            nn.Conv2d(out_channel, out_channel, kernel_size=3, stride=1, padding=5, dilation=5, bias=True),
            nn.BatchNorm2d(out_channel),
            nn.ReLU()
        )
        # Concatenation and output layers
        self.layer_cat = nn.Sequential(
            nn.Conv2d(out_channel * 3, out_channel, kernel_size=3, stride=1, padding=1, bias=True),
            nn.BatchNorm2d(out_channel),
            nn.ReLU()
        )
        self.layer_out = nn.Sequential(
            nn.Conv2d(out_channel * 3, out_channel, kernel_size=3, stride=1, padding=1, bias=True),
            nn.BatchNorm2d(out_channel),
            nn.ReLU()
        )

    def forward(self, x_e, x_hfe ,x_d):

        x_e = self.conv1(x_e)
        x_hfe = self.conv2(x_hfe)
        x_d = self.conv3(x_d)

        x = torch.cat((x_e, x_d),dim=1)

        x1 = self.layer_conv1(x)
        x2 = self.layer_conv2(x)
        x3 = self.layer_conv3(x)
        x4 = self.layer_conv4(x)

        # Apply dilated convolutions
        x_dil3 = self.layer_dil3(x3)
        x_dil2 = self.layer_dil2(x2 + x_dil3)
        x_dil1 = self.layer_dil1(x1 + x_dil2)

        # Concatenate the dilated features
        x_cat = torch.cat((x_dil3, x_dil2, x_dil1), dim=1)

        # Pass through the final layers and output
        out = self.layer_out(x_cat + x4)
        out = self.conv4(torch.cat((out, x_hfe), dim=1))

        return out

if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x_encoder = torch.randn(1, 64, 32, 32).to(device)
    x_hffd_output = torch.randn(1, 128, 32, 32).to(device)
    x_decoder = torch.randn(1, 128, 32, 32).to(device)
    model = HFFD(64, 128, 128, 64).to(device)

    y = model(x_encoder, x_hffd_output, x_decoder)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN、小红书：十小大")

    print("输入特征维度：", x_encoder.shape)
    print("输入特征维度：", x_hffd_output.shape)
    print("输入特征维度：", x_decoder.shape)
    print("输出特征维度：", y.shape)