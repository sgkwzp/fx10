import torch
import torch.nn as nn
import torch.nn.functional as F


##########################################################################
# ---------- Prompt Gen Module -----------------------
class PromptGenBlock(nn.Module):
    def __init__(self, prompt_dim=128, prompt_len=5, prompt_size=96, lin_dim=192, num_expert=1):
        super(PromptGenBlock, self).__init__()
        self.prompt_param = nn.Parameter(torch.rand(
            1, prompt_len, prompt_dim, prompt_size, prompt_size), requires_grad=True)
        self.linear_layer = nn.Linear(lin_dim, prompt_len)
        self.conv3x3 = nn.Conv2d(
            prompt_dim, prompt_dim, kernel_size=3, stride=1, padding=1, bias=False)
        self.num_expert = num_expert
        self.prompt_len = prompt_len

    def forward(self, x, is_neg=False):
        """
        Args:
            x: Input features
            is_neg (bool): 如果为 True，则返回与当前输入不匹配的随机负样本 Prompt
        """
        B, C, H, W = x.shape
        emb = x.mean(dim=(-2, -1))

        # 计算每个 Prompt 的权重
        prompt_weights = F.softmax(self.linear_layer(emb), dim=1).to(x.dtype)

        # 获取当前认为最好的 Top-K (Positive Candidates)
        topk_weights, topk_experts = torch.topk(
            prompt_weights, self.num_expert)

        if not is_neg:
            # === 正样本模式 (Normal Path) ===
            selected_weights = prompt_weights
            selected_experts = topk_experts

            # 构建稀疏权重矩阵
            exp_weights = torch.zeros_like(prompt_weights)
            exp_weights.scatter_(1, selected_experts,
                                 selected_weights.gather(1, selected_experts))

            # 生成 Prompt
            prompt = self._generate_prompt(exp_weights, B)

        else:
            # === 负样本模式 (Counterfactual / Negative Path) ===
            with torch.no_grad():
                # 1. 创建掩码：标记 Top-K 位置为 False，其他位置为 True
                mask = torch.ones_like(prompt_weights, dtype=torch.bool)
                mask.scatter_(1, topk_experts, False)

                # 2. 生成随机噪声作为选择依据
                noise = torch.rand_like(prompt_weights)

                # 3. 将 Top-K 位置的噪声设为负无穷，确保不会被选中
                noise.masked_fill_(~mask, -float('inf'))

                # 4. 在剩余的 (非 Top-K) 候选中选取 Top-K 个作为负样本
                _, neg_experts = torch.topk(noise, self.num_expert)

                # 5. 获取负样本对应的原始权重
                neg_weights_values = prompt_weights.gather(1, neg_experts)

                # 6. 构建稀疏权重
                exp_weights = torch.zeros_like(prompt_weights)
                exp_weights.scatter_(1, neg_experts, neg_weights_values)

                # 7. 生成 Prompt 并 Detach (确保没有梯度传回 Prompt 参数)
                prompt = self._generate_prompt(exp_weights, B).detach()

        # 后处理沿用：上采样 + 卷积
        prompt = F.interpolate(
            prompt, (H, W), mode="bilinear", align_corners=False)
        prompt = self.conv3x3(prompt)

        return prompt

    def _generate_prompt(self, exp_weights, batch_size):
        """辅助函数：根据权重组合 Prompt"""
        # (B, prompt_len, 1, 1, 1)
        weights = exp_weights.unsqueeze(-1).unsqueeze(-1).unsqueeze(-1)

        # (B, prompt_len, dim, size, size)
        params = self.prompt_param.unsqueeze(0).repeat(
            batch_size, 1, 1, 1, 1, 1).squeeze(1)

        # Weighted sum: (B, dim, size, size)
        prompt = torch.sum(weights * params, dim=1)
        return prompt


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 64, 32, 32).to(device)
    model = PromptGenBlock(64, 5, 64, 64, 1).to(device)

    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("小红书：十小大，主页获取往期全部即插即用代码，200+大合集")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)