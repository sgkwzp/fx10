import torch
import torch.nn as nn

class StripBlock(nn.Module):
    """
    条纹注意力核心块（StripBlock）：通过交叉条纹状分组卷积生成空间注意力权重
    核心作用：
        1. 条纹卷积捕捉定向空间关联（如水平/垂直纹理）；
        2. 分组卷积实现轻量化，降低计算量；
        3. 生成注意力权重与输入特征逐元素乘法，实现空间特征筛选。
    输入：特征图 [B, dim, H, W]（B=批次，dim=通道数，H/W=高/宽）
    输出：注意力权重图 [B, dim, H, W]（与输入维度一致，用于加权）
    """
    def __init__(self, dim, k1, k2):
        """
        参数初始化：
            dim: 输入/输出通道数（需保持一致，适配分组卷积）
            k1/k2: 条纹卷积核尺寸（(k1,k2)与(k2,k1)交叉，形成条纹状感受野）
        """
        super().__init__()
        # 1. 初始卷积：5×5分组卷积，初步提取空间特征
        self.conv0 = nn.Conv2d(dim, dim, 5, padding=2, groups=dim)  # 分组数=通道数，深度可分离卷积
        # 2. 条纹卷积1：(k1,k2)核，捕捉第一方向条纹关联（如水平长条纹）
        self.conv_spatial1 = nn.Conv2d(
            dim, dim, kernel_size=(k1, k2), stride=1,
            padding=(k1//2, k2//2), groups=dim
        )
        # 3. 条纹卷积2：(k2,k1)核，捕捉交叉方向条纹关联（如垂直长条纹）
        self.conv_spatial2 = nn.Conv2d(
            dim, dim, kernel_size=(k2, k1), stride=1,
            padding=(k2//2, k1//2), groups=dim
        )
        # 4. 1×1卷积：融合条纹特征，生成最终注意力权重
        self.conv1 = nn.Conv2d(dim, dim, 1)

    def forward(self, x):
        """前向传播：初始卷积→条纹卷积1→条纹卷积2→权重生成"""
        # 步骤1：初始空间特征提取
        attn = self.conv0(x)
        # 步骤2：交叉条纹卷积，捕捉双向定向关联
        attn = self.conv_spatial1(attn)
        attn = self.conv_spatial2(attn)
        # 步骤3：生成注意力权重
        attn = self.conv1(attn)
        return x * attn

class Attention(nn.Module):
    """
    条纹注意力模块（StripAttn）：封装StripBlock与门控机制，实现轻量化空间特征增强
    核心创新：
        1. 条纹状空间注意力：定向捕捉长距离空间关联，比传统注意力效率高；
        2. 空间门控机制：GELU激活+StripBlock生成权重，动态筛选特征；
        3. 轻量化设计：全分组卷积+1×1投影，计算量仅为传统注意力的1/10；
        4. 即插即用：输入输出维度一致，支持无缝替换传统卷积/注意力块。
    输入：特征图 [B, d_model, H, W]
    输出：增强后特征 [B, d_model, H, W]（与输入维度完全一致）
    """
    def __init__(self, d_model, k1, k2):
        """
        参数初始化：
            d_model: 输入/输出通道数
            k1/k2: 条纹卷积核尺寸（如(1,19)形成水平长条纹，(19,1)形成垂直长条纹）
        """
        super().__init__()
        # 1. 1×1投影层1：调整特征通道，为门控做准备
        self.proj_1 = nn.Conv2d(d_model, d_model, 1)
        # 2. 激活函数：GELU，增强非线性表达
        self.activation = nn.GELU()
        # 3. 空间门控单元：StripBlock生成注意力权重
        self.spatial_gating_unit = StripBlock(d_model, k1, k2)
        # 4. 1×1投影层2：融合门控特征，恢复通道
        self.proj_2 = nn.Conv2d(d_model, d_model, 1)

    def forward(self, x):
        """
        前向传播流程：残差保存→投影增强→激活→空间门控→投影融合→残差输出
        """
        shortcut = x.clone()  # 保存残差连接的原始特征
        # 步骤1：特征投影与激活
        x = self.proj_1(x)  # 1×1卷积调整特征
        x = self.activation(x)  # 非线性激活增强
        # 步骤2：空间门控（条纹注意力权重生成+加权）
        x = self.spatial_gating_unit(x)  # 生成注意力权重
        # 步骤3：投影融合与残差连接
        x = self.proj_2(x)  # 融合特征
        x = x + shortcut  # 残差融合，避免梯度消失
        return x

if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 64, 32, 32).to(device)
    model = Attention(64, 1, 19)

    model.to(device)
    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)