import torch
import torch.nn as nn
import torch.nn.functional as F

class DynamicSpatialAttention(nn.Module):
    """
    动态空间注意力模块（DSA）：基于输入特征动态生成卷积核，实现样本特异性空间注意力
    核心创新：
        1. 样本级动态核：每个样本生成独立卷积核，适配不同样本的空间特征分布；
        2. 轻量级设计：通过全局池化+1×1卷积生成核，计算量远低于传统自注意力；
        3. 分组卷积实现：确保每个动态核对应用于对应样本，避免跨样本干扰。
    输入：特征图 [B, C, H, W]（B=批次，C=通道，H/W=高/宽）
    输出：注意力加权特征 [B, C, H, W]（与输入维度一致，支持即插即用）
    """

    def __init__(self, in_channels=32, kernel_size=3):
        """
        参数说明：
            in_channels: 输入特征通道数（需与生成动态核的卷积层适配）
            kernel_size: 动态卷积核大小（默认3×3，需为奇数，确保padding后尺寸不变）
        """
        super().__init__()
        self.kernel_size = kernel_size  # 动态卷积核大小（如3×3）

        # 动态核生成器：从输入特征中学习样本特异性卷积核
        self.kernel_generator = nn.Sequential(
            # 步骤1：全局平均池化（GAP）：压缩空间维度，保留通道统计信息→[B, C, 1, 1]
            nn.AdaptiveAvgPool2d(1),
            # 步骤2：1×1卷积：通道映射，提取关键统计特征→[B, C, 1, 1]
            nn.Conv2d(in_channels, in_channels, kernel_size=1),
            # 步骤3：ReLU激活：增强非线性表达，提升核生成能力
            nn.ReLU(),
            # 步骤4：1×1卷积：生成k²个核参数（k=kernel_size）→[B, k², 1, 1]
            nn.Conv2d(in_channels, kernel_size ** 2, kernel_size=1)
        )

        self.sigmoid = nn.Sigmoid()  # 注意力权重归一化（输出∈[0,1]）

    def forward(self, x):
        """
        前向传播流程：动态核生成→通道均值计算→分组卷积注意力→权重归一化→特征加权
        """
        B, C, H, W = x.shape  # 解析输入维度

        # 步骤1：生成样本特异性动态卷积核
        # 核生成器输出：[B, k², 1, 1]→reshape为[B, 1, k, k]（1个输入通道，k×k核大小）
        kernels = self.kernel_generator(x).view(B, 1, self.kernel_size, self.kernel_size)

        # 步骤2：计算通道均值特征（压缩通道维度，突出空间分布）
        # 通道维度平均：[B, C, H, W]→[B, 1, H, W]（1个通道的空间特征图）
        x_mean = x.mean(dim=1, keepdim=True)

        # 步骤3：维度调整，适配分组卷积格式
        # x_mean：[B, 1, H, W]→[1, B, H, W]（分组数=B，每个组对应1个样本）
        x_mean = x_mean.view(1, B, H, W)
        # kernels：[B, 1, k, k]→保持格式（分组卷积的权重需与分组数匹配）
        kernels = kernels.view(B, 1, self.kernel_size, self.kernel_size)

        # 步骤4：执行步骤4：执行分组卷积，生成空间注意力图
        # 分组卷积逻辑：每组（样本）用独立核卷积，避免跨样本干扰
        att = F.conv2d(
            x_mean,  # 输入：[1, B, H, W]
            weight=kernels,  # 权重：[B, 1, k, k]（B个核，每个核对应1个样本）
            padding=self.kernel_size // 2,  # padding=k//2，确保卷积后尺寸不变
            groups=B  # 分组数=B，每个核仅作用于对应样本
        )

        # 步骤5：维度恢复与注意力权重归一化
        # 恢复维度：[1, B, H, W]→[B, 1, H, W]（每个样本1个空间注意力图）
        att = att.view(B, 1, H, W)
        # Sigmoid归一化：注意力权重∈[0,1]，突出关键空间区域
        att = self.sigmoid(att)

        # 步骤6：注意力加权特征（逐元素乘法，突出高权重区域）
        return x * att


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    x = torch.randn(1, 64, 32, 32).to(device)

    model = DynamicSpatialAttention(64, 3)
    model.to(device)

    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("知乎、CSDN：十小大")
    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)