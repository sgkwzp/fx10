import torch
import torch.nn as nn
import torch.nn.functional as F


def autopad(k, p=None, d=1):
    """自动计算padding，保证卷积输出尺寸与输入一致"""
    if d > 1:
        k = d * (k - 1) + 1 if isinstance(k, int) else [d * (x - 1) + 1 for x in k]
    if p is None:
        p = k // 2 if isinstance(k, int) else [x // 2 for x in k]
    return p


class activation(nn.ReLU):
    """增强型激活函数：ReLU后接7×7深度卷积+BN，支持部署时Conv-BN融合"""

    def __init__(self, dim, act_num=3, deploy=False):
        super().__init__()
        self.deploy = deploy
        self.weight = nn.Parameter(torch.randn(dim, 1, act_num * 2 + 1, act_num * 2 + 1))
        self.bias = None
        self.bn = nn.BatchNorm2d(dim, eps=1e-6)
        self.dim = dim
        self.act_num = act_num

    def forward(self, x):
        if self.deploy:
            return F.conv2d(
                super().forward(x), self.weight, self.bias,
                padding=(self.act_num * 2 + 1) // 2, groups=self.dim
            )
        else:
            return self.bn(F.conv2d(
                super().forward(x), self.weight,
                padding=(self.act_num * 2 + 1) // 2, groups=self.dim
            ))

    def switch_to_deploy(self):
        """部署时融合Conv和BN，提升推理速度"""
        kernel, bias = self._fuse_bn_tensor(self.weight, self.bn)
        self.weight.data = kernel
        self.bias = nn.Parameter(torch.zeros(self.dim))
        self.bias.data = bias
        del self.bn
        self.deploy = True

    def _fuse_bn_tensor(self, weight, bn):
        running_mean = bn.running_mean
        running_var = bn.running_var
        gamma = bn.weight
        beta = bn.bias
        eps = bn.eps
        std = (running_var + eps).sqrt()
        t = (gamma / std).reshape(-1, 1, 1, 1)
        return weight * t, beta + (0 - running_mean) * gamma / std


class CBR(nn.Module):
    """标准Conv-BN-Activation模块，使用增强型激活函数"""

    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, d=1, act=True):
        super().__init__()
        self.conv = nn.Conv2d(c1, c2, k, s, autopad(k, p, d), groups=g, dilation=d, bias=False)
        self.bn = nn.BatchNorm2d(c2)
        self.act = activation(c2, act_num=3) if act else nn.Identity()

    def forward(self, x):
        return self.act(self.bn(self.conv(x)))


class h_sigmoid(nn.Module):
    """硬sigmoid激活，计算更快，适合端侧部署"""

    def __init__(self, inplace=True):
        super().__init__()
        self.relu = nn.ReLU6(inplace=inplace)

    def forward(self, x):
        return self.relu(x + 3) / 6


class h_swish(nn.Module):
    """硬swish激活，性能接近swish但计算更快"""

    def __init__(self, inplace=True):
        super().__init__()
        self.sigmoid = h_sigmoid(inplace=inplace)

    def forward(self, x):
        return x * self.sigmoid(x)


class CoordAttiton(nn.Module):
    """
    坐标注意力模块（对应结构图中的CAM）
    生成全局方向感知的融合权重，引导跨尺度特征融合
    """

    def __init__(self, inp, oup, reduction=32):
        super().__init__()
        self.pool_h = nn.AdaptiveAvgPool2d((None, 1))
        self.pool_w = nn.AdaptiveAvgPool2d((1, None))
        mip = max(8, inp // reduction)
        self.conv1 = nn.Conv2d(inp, mip, kernel_size=1, stride=1, padding=0)
        self.bn1 = nn.BatchNorm2d(mip)
        self.act = h_swish()
        self.conv_h = nn.Conv2d(mip, oup, kernel_size=1, stride=1, padding=0)
        self.conv_w = nn.Conv2d(mip, oup, kernel_size=1, stride=1, padding=0)

    def forward(self, x):
        identity = x
        n, c, h, w = x.size()
        x_h = self.pool_h(x)
        x_w = self.pool_w(x).permute(0, 1, 3, 2)
        y = torch.cat([x_h, x_w], dim=2)
        y = self.conv1(y)
        y = self.bn1(y)
        y = self.act(y)
        x_h, x_w = torch.split(y, [h, w], dim=2)
        x_w = x_w.permute(0, 1, 3, 2)
        a_h = self.conv_h(x_h).sigmoid()
        a_w = self.conv_w(x_w).sigmoid()
        out = identity * a_w * a_h
        return out


class SpatialAttention(nn.Module):
    """
    局部空间注意力模块（对应结构图中的LSAM）
    基于平均池化+最大池化生成局部空间注意力权重，增强显著区域特征
    """

    def __init__(self, kernel_size=3):
        super().__init__()
        assert kernel_size in (3, 7), 'kernel size must be 3 or 7'
        padding = 3 if kernel_size == 7 else 1
        self.conv1 = nn.Conv2d(2, 1, kernel_size, padding=padding, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        x_source = x
        # 分别计算通道维度的平均和最大值，捕捉局部空间显著性
        avg_out = torch.mean(x, dim=1, keepdim=True)
        max_out, _ = torch.max(x, dim=1, keepdim=True)
        x = torch.cat([avg_out, max_out], dim=1)
        x = self.conv1(x)
        # 生成空间注意力权重并加权原始特征
        return self.sigmoid(x) * x_source


class SCFM(nn.Module):
    """
    Semantic-guided Cross-attention Fusion Module (语义引导跨注意力融合模块)
    对应上方结构图的完整流程：局部空间增强→双向交叉显著性→全局坐标融合→双路径输出
    输入：low_feat=高层语义特征，high_feat=低层细节特征
    输出：融合后的特征，与高分辨率输入尺寸一致
    Args:
        low_channels: 高层特征通道数
        high_channels: 低层特征通道数
        out_channels: 输出特征通道数
        kernel_size: 显著性提取卷积核尺寸
    """

    def __init__(self, low_channels, high_channels, out_channels, kernel_size):
        super().__init__()
        # 1. 局部空间注意力模块（LSAM）
        self.low_spatial_att = SpatialAttention()
        self.high_spatial_att = SpatialAttention()

        # 2. 双向显著性权重生成（对应结构图中的ω_low和ω_high）
        self.low_saliency_block = nn.Sequential(
            CBR(low_channels, low_channels // 16, kernel_size),
            nn.Conv2d(low_channels // 16, 1, 1, padding=0),
            nn.Sigmoid()
        )
        self.high_saliency_block = nn.Sequential(
            CBR(high_channels, high_channels // 16, kernel_size),
            nn.Conv2d(high_channels // 16, 1, 1, padding=0),
            nn.Sigmoid()
        )

        # 3. 特征投影层
        self.low_proj = CBR(low_channels, out_channels, 1)
        self.high_proj = CBR(high_channels, out_channels, 1)
        self.mix_proj = CBR(low_channels + high_channels, out_channels, 1)

        # 4. 上采样层（尺寸对齐）
        self.upsample = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True)

        # 5. 全局坐标注意力融合（对应结构图中的CAM）
        self.coord_att = CoordAttiton(out_channels, out_channels)

        # 6. 最终融合卷积
        self.fusion_conv = CBR(out_channels * 2, out_channels, 1)

    def forward(self, low_feat, high_feat):
        """前向传播，严格对应结构图流程"""
        b1, c1, h1, w1 = low_feat.size()
        b2, c2, h2, w2 = high_feat.size()

        # 步骤1：尺寸对齐，若高低层尺寸不一致则上采样低层特征
        if (h1, w1) != (h2, w2):
            high_feat = self.upsample(high_feat)

        # 保留原始特征用于残差连接
        low_identity = low_feat
        high_identity = high_feat

        # 步骤2：局部空间注意力预增强（对应结构图中的LSAM）
        low_att_feat = self.low_spatial_att(low_feat)
        high_att_feat = self.high_spatial_att(high_feat)

        # 步骤3：生成双向显著性权重（对应结构图中的ω_low和ω_high）
        low_saliency = self.low_saliency_block(low_att_feat)  # 高层语义显著性
        high_saliency = self.high_saliency_block(high_att_feat)  # 低层细节显著性

        # 步骤4：交叉注意力特征生成（核心创新：双向语义引导）
        # 高层语义显著性引导低层细节，低层细节显著性引导高层语义
        mixed_feat = torch.cat(
            [
                low_identity * high_saliency,  # 低层细节 × 高层语义显著性
                high_identity * low_saliency  # 高层语义 × 低层细节显著性
            ],
            dim=1
        )

        # 步骤5：全局坐标注意力生成融合权重（对应结构图中的CAM和ω_fusion）
        cross_att = torch.sigmoid(self.coord_att(self.mix_proj(mixed_feat)))

        # 步骤6：双路径特征投影与全局加权
        low_out = cross_att * self.low_proj(low_identity + low_att_feat)
        high_out = cross_att * self.high_proj(high_identity + high_att_feat)

        # 步骤7：最终融合输出
        out = self.fusion_conv(torch.cat([low_out, high_out], dim=1))
        return out


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    x_low = torch.randn(1, 64, 64, 64).to(device)
    x_high = torch.randn(1, 64, 64, 64).to(device)
    model = SCFM(64, 64, 64, 3).to(device)
    y = model(x_low, x_high)
    print("输入低层特征维度：", x_low.shape)
    print("输入高层特征维度：", x_high.shape)
    print("输出特征维度：", y.shape)