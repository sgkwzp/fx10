import torch
import torch.nn as nn
import torch.nn.functional as F

def autopad(k, p=None, d=1):
    """自动计算padding，保证卷积输出尺寸与输入一致"""
    if d > 1:
        k = d * (k - 1) + 1 if isinstance(k, int) else [d * (x - 1) + 1 for x in k]
    if p is None:
        p = k // 2 if isinstance(k, int) else [x // 2 for x in k]
    return p

class activation(nn.ReLU):
    """增强型激活函数：ReLU后接7×7深度卷积+BN，支持部署时Conv-BN融合"""
    def __init__(self, dim, act_num=3, deploy=False):
        super().__init__()
        self.deploy = deploy
        self.weight = nn.Parameter(torch.randn(dim, 1, act_num*2+1, act_num*2+1))
        self.bias = None
        self.bn = nn.BatchNorm2d(dim, eps=1e-6)
        self.dim = dim
        self.act_num = act_num

    def forward(self, x):
        if self.deploy:
            return F.conv2d(
                super().forward(x), self.weight, self.bias,
                padding=(self.act_num*2+1)//2, groups=self.dim
            )
        else:
            return self.bn(F.conv2d(
                super().forward(x), self.weight,
                padding=(self.act_num*2+1)//2, groups=self.dim
            ))

    def switch_to_deploy(self):
        """部署时融合Conv和BN，提升推理速度"""
        kernel, bias = self._fuse_bn_tensor(self.weight, self.bn)
        self.weight.data = kernel
        self.bias = nn.Parameter(torch.zeros(self.dim))
        self.bias.data = bias
        del self.bn
        self.deploy = True

    def _fuse_bn_tensor(self, weight, bn):
        running_mean = bn.running_mean
        running_var = bn.running_var
        gamma = bn.weight
        beta = bn.bias
        eps = bn.eps
        std = (running_var + eps).sqrt()
        t = (gamma / std).reshape(-1, 1, 1, 1)
        return weight * t, beta + (0 - running_mean) * gamma / std

class CBR(nn.Module):
    """标准Conv-BN-Activation模块，使用增强型激活函数"""
    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, d=1, act=True):
        super().__init__()
        self.conv = nn.Conv2d(c1, c2, k, s, autopad(k, p, d), groups=g, dilation=d, bias=False)
        self.bn = nn.BatchNorm2d(c2)
        self.act = activation(c2, act_num=3) if act else nn.Identity()

    def forward(self, x):
        return self.act(self.bn(self.conv(x)))

class h_sigmoid(nn.Module):
    """硬sigmoid激活，计算更快，适合端侧部署"""
    def __init__(self, inplace=True):
        super().__init__()
        self.relu = nn.ReLU6(inplace=inplace)
    def forward(self, x):
        return self.relu(x + 3) / 6

class h_swish(nn.Module):
    """硬swish激活，性能接近swish但计算更快"""
    def __init__(self, inplace=True):
        super().__init__()
        self.sigmoid = h_sigmoid(inplace=inplace)
    def forward(self, x):
        return x * self.sigmoid(x)

class CoordAttiton(nn.Module):
    """坐标注意力模块，可选用于特征增强"""
    def __init__(self, inp, oup, reduction=32):
        super().__init__()
        self.pool_h = nn.AdaptiveAvgPool2d((None, 1))
        self.pool_w = nn.AdaptiveAvgPool2d((1, None))
        mip = max(8, inp // reduction)
        self.conv1 = nn.Conv2d(inp, mip, kernel_size=1, stride=1, padding=0)
        self.bn1 = nn.BatchNorm2d(mip)
        self.act = h_swish()
        self.conv_h = nn.Conv2d(mip, oup, kernel_size=1, stride=1, padding=0)
        self.conv_w = nn.Conv2d(mip, oup, kernel_size=1, stride=1, padding=0)

    def forward(self, x):
        identity = x
        n, c, h, w = x.size()
        x_h = self.pool_h(x)
        x_w = self.pool_w(x).permute(0, 1, 3, 2)
        y = torch.cat([x_h, x_w], dim=2)
        y = self.conv1(y)
        y = self.bn1(y)
        y = self.act(y)
        x_h, x_w = torch.split(y, [h, w], dim=2)
        x_w = x_w.permute(0, 1, 3, 2)
        a_h = self.conv_h(x_h).sigmoid()
        a_w = self.conv_w(x_w).sigmoid()
        out = identity * a_w * a_h
        return out

class GSFM(nn.Module):
    """
    Global Semantic-aware Fusion Module (全局语义感知融合模块)
    核心：将高低层特征统一降采样到小尺寸计算全局注意力，实现四向全交互跨尺度融合
    输入：low_feat=高层语义特征（低分辨率），high_feat=低层细节特征（高分辨率）
    输出：融合后的高分辨率特征，与high_feat尺寸一致
    Args:
        low_C: 高层特征通道数
        high_C: 低层特征通道数
        out_C: 输出特征通道数
        size: 低层特征的空间尺寸（用于计算统一注意力的小尺寸）
    """
    def __init__(self, low_C, high_C, out_C, size):
        super().__init__()
        self.attn_size = size // 8  # 统一注意力计算尺寸：原尺寸的1/8，大幅降低计算量
        # 高层特征QKV生成（对应结构图F_low分支的Conv）
        self.LOW_K = CBR(high_C, out_C, 3, 1, 1)
        self.LOW_V = CBR(high_C, out_C, 3, 1, 1)
        self.LOW_Q = CBR(high_C, out_C, 3, 1, 1)
        # 低层特征QKV生成（对应结构图F_high分支的Conv）
        self.HIGH_K = CBR(high_C, out_C, 3, 1, 1)
        self.HIGH_V = CBR(high_C, out_C, 3, 1, 1)
        self.HIGH_Q = CBR(high_C, out_C, 3, 1, 1)
        # 四分支融合卷积（对应结构图的Concat+Conv）
        self.REDUCE = CBR(out_C * 4, out_C, 3, 1, 1)
        # 可学习残差权重，自适应平衡四个分支的贡献（初始化为0，训练更稳定）
        self.gamma1 = nn.Parameter(torch.zeros(1))  # 高层自注意力分支权重
        self.gamma2 = nn.Parameter(torch.zeros(1))  # 低层自注意力分支权重
        self.gamma3 = nn.Parameter(torch.zeros(1))  # 高层→低层交叉注意力权重
        self.gamma4 = nn.Parameter(torch.zeros(1))  # 低层→高层交叉注意力权重
        self.softmax = nn.Softmax(dim=-1)
        # 高层特征通道对齐：将low_C映射为high_C
        self.conv1 = nn.Conv2d(low_C, high_C, 1, 1)

    def forward(self, low_feat, high_feat):
        """
        前向传播，严格对应结构图流程
        Args:
            low_feat: 高层语义特征 [B, low_C, Hl, Wl]
            high_feat: 低层细节特征 [B, high_C, Hh, Wh]（Hh=2*Hl, Wh=2*Wl）
        Returns:
            GLOBAL_ATT: 融合后的特征 [B, out_C, Hh, Wh]
        """
        m_batchsize, c, h, w = high_feat.shape
        # 步骤1：高层特征上采样+通道对齐，与低层特征尺寸/通道一致
        low_feat = F.interpolate(low_feat, size=(h, w), mode='bilinear', align_corners=True)
        low_feat = self.conv1(low_feat)  # [B, high_C, Hh, Wh]
        # 步骤2：统一降采样到小尺寸（原尺寸1/8），计算全局注意力（核心复杂度优化）
        low_re = F.interpolate(low_feat, size=(self.attn_size, self.attn_size), mode='bilinear', align_corners=True)
        high_re = F.interpolate(high_feat, size=(self.attn_size, self.attn_size), mode='bilinear', align_corners=True)
        # 步骤3：生成高低层特征的QKV
        LOW_K = self.LOW_K(low_re)
        LOW_V = self.LOW_V(low_re)
        LOW_Q = self.LOW_Q(low_re)
        HIGH_K = self.HIGH_K(high_re)
        HIGH_V = self.HIGH_V(high_re)
        HIGH_Q = self.HIGH_Q(high_re)
        # 步骤4：共享融合V特征（创新点：V_fuse=V_low+V_high，增强语义融合）
        DUAL_V = LOW_V + HIGH_V
        # 维度重塑：适配批量矩阵乘法
        LOW_V = LOW_V.view(m_batchsize, -1, self.attn_size * self.attn_size)
        LOW_K = LOW_K.view(m_batchsize, -1, self.attn_size * self.attn_size).permute(0, 2, 1)
        LOW_Q = LOW_Q.view(m_batchsize, -1, self.attn_size * self.attn_size)
        HIGH_V = HIGH_V.view(m_batchsize, -1, self.attn_size * self.attn_size)
        HIGH_K = HIGH_K.view(m_batchsize, -1, self.attn_size * self.attn_size).permute(0, 2, 1)
        HIGH_Q = HIGH_Q.view(m_batchsize, -1, self.attn_size * self.attn_size)
        DUAL_V = DUAL_V.view(m_batchsize, -1, self.attn_size * self.attn_size)

        # 步骤5：四向全交互注意力计算（对应结构图的四个GAM）
        # 分支1：高层特征自注意力 GAM_low
        LOW_mask = torch.bmm(LOW_K, LOW_Q)
        LOW_mask = self.softmax(LOW_mask)
        LOW_refine = torch.bmm(DUAL_V, LOW_mask.permute(0, 2, 1))
        LOW_refine = LOW_refine.view(m_batchsize, -1, self.attn_size, self.attn_size)
        # 上采样+残差连接
        LOW_refine = self.gamma1 * LOW_refine
        LOW_refine = F.interpolate(LOW_refine, size=(h, w), mode='bilinear', align_corners=True) + low_feat

        # 分支2：低层特征自注意力 GAM_high
        HIGH_mask = torch.bmm(HIGH_K, HIGH_Q)
        HIGH_mask = self.softmax(HIGH_mask)
        HIGH_refine = torch.bmm(DUAL_V, HIGH_mask.permute(0, 2, 1))
        HIGH_refine = HIGH_refine.view(m_batchsize, -1, self.attn_size, self.attn_size)
        # 上采样+残差连接
        HIGH_refine = self.gamma2 * HIGH_refine
        HIGH_refine = F.interpolate(HIGH_refine, size=(h, w), mode='bilinear', align_corners=True) + high_feat

        # 分支3：高层→低层交叉注意力 GAM_low→high
        LOW_HIGH_mask = torch.bmm(LOW_K, HIGH_Q)
        LOW_HIGH_mask = self.softmax(LOW_HIGH_mask)
        LOW_HIGH_refine = torch.bmm(LOW_V, LOW_HIGH_mask.permute(0, 2, 1))
        LOW_HIGH_refine = LOW_HIGH_refine.view(m_batchsize, -1, self.attn_size, self.attn_size)
        # 上采样+残差连接
        LOW_HIGH_refine = self.gamma3 * LOW_HIGH_refine
        LOW_HIGH_refine = F.interpolate(LOW_HIGH_refine, size=(h, w), mode='bilinear', align_corners=True) + high_feat

        # 分支4：低层→高层交叉注意力 GAM_high→low
        HIGH_LOW_mask = torch.bmm(HIGH_K, LOW_Q)
        HIGH_LOW_mask = self.softmax(HIGH_LOW_mask)
        HIGH_LOW_refine = torch.bmm(HIGH_V, HIGH_LOW_mask.permute(0, 2, 1))
        HIGH_LOW_refine = HIGH_LOW_refine.view(m_batchsize, -1, self.attn_size, self.attn_size)
        # 上采样+残差连接
        HIGH_LOW_refine = self.gamma4 * HIGH_LOW_refine
        HIGH_LOW_refine = F.interpolate(HIGH_LOW_refine, size=(h, w), mode='bilinear', align_corners=True) + low_feat

        # 步骤6：四分支拼接+卷积融合（对应结构图的Concat+Conv）
        GLOBAL_ATT = self.REDUCE(
            torch.cat((LOW_refine, HIGH_refine, LOW_HIGH_refine, HIGH_LOW_refine), dim=1)
        )
        return GLOBAL_ATT


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    x_low = torch.randn(1, 64, 32, 32).to(device)
    x_high = torch.randn(1, 64, 64, 64).to(device)
    model = GSFM(64, 64, 64, 64).to(device)
    y = model(x_low, x_high)
    print("输入低层特征维度：", x_low.shape)
    print("输入高层特征维度：", x_high.shape)
    print("输出特征维度：", y.shape)