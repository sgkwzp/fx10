import torch
import torch.nn as nn
import torch.nn.functional as F

def autopad(k, p=None, d=1):
    """自动计算padding，保证卷积输出尺寸与输入一致"""
    if d > 1:
        k = d * (k - 1) + 1 if isinstance(k, int) else [d * (x - 1) + 1 for x in k]
    if p is None:
        p = k // 2 if isinstance(k, int) else [x // 2 for x in k]
    return p


class activation(nn.ReLU):
    """
    增强型激活函数：ReLU后接深度卷积+BN，支持部署时的Conv-BN融合
    替代普通ReLU，在激活后引入局部特征增强
    """
    def __init__(self, dim, act_num=3, deploy=False):
        super().__init__()
        self.deploy = deploy
        # 深度卷积核，尺寸为7×7（act_num=3时，2*3+1=7）
        self.weight = nn.Parameter(torch.randn(dim, 1, act_num*2+1, act_num*2+1))
        self.bias = None
        self.bn = nn.BatchNorm2d(dim, eps=1e-6)
        self.dim = dim
        self.act_num = act_num

    def forward(self, x):
        if self.deploy:
            return F.conv2d(
                super().forward(x), self.weight, self.bias,
                padding=(self.act_num*2+1)//2, groups=self.dim
            )
        else:
            return self.bn(F.conv2d(
                super().forward(x), self.weight,
                padding=(self.act_num*2+1)//2, groups=self.dim
            ))

    def switch_to_deploy(self):
        """部署时融合Conv和BN，提升推理速度"""
        kernel, bias = self._fuse_bn_tensor(self.weight, self.bn)
        self.weight.data = kernel
        self.bias = nn.Parameter(torch.zeros(self.dim))
        self.bias.data = bias
        del self.bn
        self.deploy = True

    def _fuse_bn_tensor(self, weight, bn):
        """融合Conv和BN的权重与偏置"""
        running_mean = bn.running_mean
        running_var = bn.running_var
        gamma = bn.weight
        beta = bn.bias
        eps = bn.eps
        std = (running_var + eps).sqrt()
        t = (gamma / std).reshape(-1, 1, 1, 1)
        return weight * t, beta + (0 - running_mean) * gamma / std

class CBR(nn.Module):
    """标准Conv-BN-Activation模块，使用增强型激活函数"""
    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, d=1, act=True):
        super().__init__()
        self.conv = nn.Conv2d(c1, c2, k, s, autopad(k, p, d), groups=g, dilation=d, bias=False)
        self.bn = nn.BatchNorm2d(c2)
        self.act = activation(c2, act_num=3) if act else nn.Identity()

    def forward(self, x):
        return self.act(self.bn(self.conv(x)))

class h_sigmoid(nn.Module):
    """硬sigmoid激活，计算更快，适合端侧部署"""
    def __init__(self, inplace=True):
        super().__init__()
        self.relu = nn.ReLU6(inplace=inplace)
    def forward(self, x):
        return self.relu(x + 3) / 6

class h_swish(nn.Module):
    """硬swish激活，性能接近swish但计算更快"""
    def __init__(self, inplace=True):
        super().__init__()
        self.sigmoid = h_sigmoid(inplace=inplace)
    def forward(self, x):
        return x * self.sigmoid(x)

class CoordAttiton(nn.Module):
    """
    坐标注意力模块（对应结构图中的CAM）
    核心：分别捕捉水平和垂直方向的长距离依赖，生成方向感知的注意力权重
    """
    def __init__(self, inp, oup, reduction=32):
        super().__init__()
        # 分别对高度和宽度维度做全局平均池化
        self.pool_h = nn.AdaptiveAvgPool2d((None, 1))
        self.pool_w = nn.AdaptiveAvgPool2d((1, None))
        mip = max(8, inp // reduction)  # 中间通道数，最小为8
        # 共享卷积层
        self.conv1 = nn.Conv2d(inp, mip, kernel_size=1, stride=1, padding=0)
        self.bn1 = nn.BatchNorm2d(mip)
        self.act = h_swish()
        # 分别生成水平和垂直方向的注意力权重
        self.conv_h = nn.Conv2d(mip, oup, kernel_size=1, stride=1, padding=0)
        self.conv_w = nn.Conv2d(mip, oup, kernel_size=1, stride=1, padding=0)

    def forward(self, x):
        identity = x
        n, c, h, w = x.size()
        # 步骤1：分别提取水平和垂直方向的全局特征
        x_h = self.pool_h(x)  # [B,C,H,1]
        x_w = self.pool_w(x).permute(0, 1, 3, 2)  # [B,C,1,W] → [B,C,W,1]
        # 步骤2：拼接后做特征变换
        y = torch.cat([x_h, x_w], dim=2)  # [B,C,H+W,1]
        y = self.conv1(y)
        y = self.bn1(y)
        y = self.act(y)
        # 步骤3：拆分并生成方向注意力权重
        x_h, x_w = torch.split(y, [h, w], dim=2)
        x_w = x_w.permute(0, 1, 3, 2)  # 还原维度
        a_h = self.conv_h(x_h).sigmoid()  # 水平方向注意力
        a_w = self.conv_w(x_w).sigmoid()  # 垂直方向注意力
        # 步骤4：逐元素相乘，增强方向相关特征
        out = identity * a_w * a_h
        return out

class MPM(nn.Module):
    """
    Multi-scale Perception Module (多尺度感知模块) 核心实现
    对应上方结构图的完整流程：通道拆分→多尺度分支→原始特征拼接→1×1融合→坐标注意力增强
    Args:
        in_channel: 输入/输出通道数
    """
    def __init__(self, in_channel):
        super().__init__()
        # 多尺度卷积分支，对应结构图中的四个Conv分支
        self.Conv_3 = nn.Sequential(
            nn.Conv2d(in_channel//4, in_channel//4, 3, 1, padding=1),
            nn.BatchNorm2d(in_channel//4),
            nn.ReLU()
        )
        self.Conv_5 = nn.Sequential(
            nn.Conv2d(in_channel//4, in_channel//4, 5, 1, padding=2),
            nn.BatchNorm2d(in_channel//4),
            nn.ReLU()
        )
        self.Conv_7 = nn.Sequential(
            nn.Conv2d(in_channel//4, in_channel//4, 7, 1, padding=3),
            nn.BatchNorm2d(in_channel//4),
            nn.ReLU()
        )
        # 多尺度特征与原始特征融合
        self.Conv = CBR(in_channel * 2, in_channel, 1)
        # 坐标注意力增强，对应结构图中的CAM
        self.ca = CoordAttiton(in_channel, in_channel)

    def forward(self, x):
        b, c, h, w = x.size()
        # 步骤1：通道维度均等拆分，对应结构图中的Channel Split
        x1 = x[:, :c//4, :, :]    # F1分支
        x2 = x[:, c//4:c//2, :, :] # F2分支
        x3 = x[:, c//2:3*c//4, :, :] # F3分支
        x4 = x[:, 3*c//4:, :, :]  # F4分支
        # 步骤2：多尺度分支并行处理
        x1_out = self.Conv_7(x1)  # F1 → 7×7卷积
        x2_out = self.Conv_7(x2)  # F2 → 7×7卷积
        x3_out = self.Conv_5(x3)  # F3 → 5×5卷积
        x4_out = self.Conv_3(x4)  # F4 → 3×3卷积
        # 步骤3：多尺度分支与原始特征拼接（核心创新：全局残差拼接）
        concat_feat = torch.cat([x1_out, x2_out, x3_out, x4_out, x], dim=1)
        # 步骤4：1×1卷积融合特征，将2C通道降回C
        fused_feat = self.Conv(concat_feat)
        # 步骤5：坐标注意力增强，输出最终特征
        out = self.ca(fused_feat)
        return out


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    x = torch.randn(1, 64, 32, 32).to(device)
    model = MPM(64).to(device)
    y = model(x)
    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)