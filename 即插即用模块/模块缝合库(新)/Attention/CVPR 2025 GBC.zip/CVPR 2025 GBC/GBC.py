import torch
import torch.nn as nn


class BottConv(nn.Module):
    """
    瓶颈卷积模块（Bottleneck Convolution）：基于“点卷积→深度可分离卷积→点卷积”的轻量化结构
    核心作用：在保持精度的前提下大幅降低计算量，适配边缘设备与高分辨率任务
    输入：特征图 [B, in_channels, H, W]（B=批次，in_channels=输入通道，H/W=高/宽）
    输出：卷积增强特征 [B, out_channels, H', W']（H'/W'由深度可分离卷积步长决定，默认与输入一致）
    """

    def __init__(self, in_channels, out_channels, mid_channels, kernel_size, stride=1, padding=0, bias=True):
        """
        参数初始化：
            in_channels: 输入通道数
            out_channels: 输出通道数
            mid_channels: 中间通道数（瓶颈层，通常为in_channels的1/8~1/4，降低计算量）
            kernel_size: 深度可分离卷积的核大小（如3×3、1×1）
            stride: 深度可分离卷积的步长（默认1，步长>1时输出尺寸缩小）
            padding: 深度可分离卷积的padding（默认0，确保输出尺寸与输入一致）
            bias: 第一个点卷积是否使用偏置（默认True，后续层无偏置，避免冗余）
        """
        super(BottConv, self).__init__()
        # 1. 点卷积1（Pointwise Conv）：通道压缩→降低后续深度卷积计算量
        self.pointwise_1 = nn.Conv2d(
            in_channels, mid_channels, kernel_size=1, bias=bias
        )  # [B, in_channels, H, W]→[B, mid_channels, H, W]

        # 2. 深度可分离卷积（Depthwise Conv）：分组数=mid_channels，每个通道独立卷积
        self.depthwise = nn.Conv2d(
            mid_channels, mid_channels, kernel_size=kernel_size,
            stride=stride, padding=padding, groups=mid_channels, bias=False
        )  # [B, mid_channels, H, W]→[B, mid_channels, H', W']

        # 3. 点卷积2（Pointwise Conv）：通道恢复→匹配输出通道数
        self.pointwise_2 = nn.Conv2d(
            mid_channels, out_channels, kernel_size=1, bias=False
        )  # [B, mid_channels, H', W']→[B, out_channels, H', W']

    def forward(self, x):
        """前向传播：点卷积1→深度可分离卷积→点卷积2（激活函数在GBC主模块中统一添加）"""
        x = self.pointwise_1(x)
        x = self.depthwise(x)
        x = self.pointwise_2(x)
        return x


def get_norm_layer(norm_type, channels, num_groups):
    """
    归一化层生成函数：支持分组归一化（GN）与实例归一化（IN，3D版本，适配扩展场景）
    参数：
        norm_type: 归一化类型（'GN'为分组归一化，其他为实例归一化）
        channels: 输入通道数（适配归一化层的通道维度）
        num_groups: 分组归一化的组数（通常为通道数的1/16，确保每组通道数合理）
    返回：
        归一化层实例（GN或IN3d）
    """
    if norm_type == 'GN':
        # 分组归一化：将通道分为num_groups组，每组独立归一化，增强局部特征一致性
        return nn.GroupNorm(num_groups=num_groups, num_channels=channels)
    else:
        # 实例归一化（3D）：适配3D特征（如视频、医学图像），默认备用
        return nn.InstanceNorm3d(channels)


class GBC(nn.Module):
    """
    分组瓶颈卷积（GBC）：融合4个瓶颈卷积块、分组归一化、残差连接，实现轻量化特征增强
    核心创新：
        1. 多路径瓶颈卷积：4个块分路径提取特征（3×3+3×3+1×1+1×1），兼顾局部与全局；
        2. 分组归一化增强：GN比BN更适配分组卷积，提升小批量数据训练稳定性；
        3. 特征交互机制：块1+块2的串行特征与块3的并行特征逐元素乘法，增强特征判别性；
        4. 残差连接：避免梯度消失，确保深层网络训练收敛。
    输入：特征图 [B, in_channels, H, W]
    输出：增强后特征 [B, in_channels, H, W]（与输入维度完全一致，支持即插即用）
    """

    def __init__(self, in_channels, norm_type='GN'):
        """
        参数初始化：
            in_channels: 输入/输出通道数（需保持一致，适配残差连接）
            norm_type: 归一化类型（默认'GN'，分组归一化）
        """
        super(GBC, self).__init__()
        # 路径1：2个3×3瓶颈卷积串行（捕捉局部关联，如边缘、纹理）
        self.block1 = nn.Sequential(
            # 瓶颈卷积：in→in（mid=in//8），3×3核，padding=1→输出尺寸不变
            BottConv(in_channels, in_channels, in_channels // 8, 3, 1, 1),
            get_norm_layer(norm_type, in_channels, in_channels // 16),  # GN分组数=in//16
            nn.ReLU()  # 激活函数：增强非线性表达
        )
        self.block2 = nn.Sequential(
            BottConv(in_channels, in_channels, in_channels // 8, 3, 1, 1),
            get_norm_layer(norm_type, in_channels, in_channels // 16),
            nn.ReLU()
        )

        # 路径2：1×1瓶颈卷积并行（捕捉全局关联，压缩通道冗余）
        self.block3 = nn.Sequential(
            BottConv(in_channels, in_channels, in_channels // 8, 1, 1, 0),  # 1×1核，无padding
            get_norm_layer(norm_type, in_channels, in_channels // 16),
            nn.ReLU()
        )

        # 路径3：1×1瓶颈卷积（融合交互特征，恢复表达能力）
        self.block4 = nn.Sequential(
            BottConv(in_channels, in_channels, in_channels // 8, 1, 1, 0),
            get_norm_layer(norm_type, in_channels, 16),  # 固定分组数=16，适配小通道场景
            nn.ReLU()
        )

    def forward(self, x):
        """
        前向传播流程：多路径特征提取→特征交互→融合→残差输出
        """
        residual = x  # 残差连接：保留原始输入特征，避免梯度消失

        # 路径1：串行特征提取（block1→block2）→捕捉局部细节
        x1 = self.block1(x)
        x1 = self.block2(x1)  # [B, C, H, W]

        # 路径2：并行特征提取（block3）→捕捉全局关联
        x2 = self.block3(x)  # [B, C, H, W]

        # 特征交互：串行特征 × 并行特征→增强关键区域（如目标边缘）
        x = x1 * x2  # [B, C, H, W]

        # 路径3：融合特征增强→恢复特征表达
        x = self.block4(x)  # [B, C, H, W]

        # 残差融合：增强特征 + 原始特征→输出
        return x + residual


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 64, 32, 32).to(device)
    model = GBC(64).to(device)

    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("知乎、CSDN：十小大")
    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)