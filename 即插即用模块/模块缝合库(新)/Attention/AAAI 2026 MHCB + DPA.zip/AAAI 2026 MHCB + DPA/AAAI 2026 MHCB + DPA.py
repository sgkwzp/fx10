import torch
import torch.nn as nn

def default_conv(ch_in, ch_out, kernel_size, bias=True):
    return nn.Conv2d(
        ch_in, ch_out, kernel_size,
        padding=(kernel_size//2), bias=bias)

# MHCB
class MDCB(nn.Module):
    def __init__(self, ch_in, ch_out, bias=True, activation=nn.ReLU(inplace=True)):
        super(MDCB, self).__init__()

        kernel_size_1 = 3
        kernel_size_2 = 5

        self.conv_3_1 = default_conv(ch_in=ch_in, ch_out=ch_in, kernel_size=kernel_size_1,  bias=bias)
        self.conv_3_2 = default_conv(ch_in=ch_out, ch_out=ch_out, kernel_size=kernel_size_1,  bias=bias)
        self.conv_5_1 = default_conv(ch_in=ch_in, ch_out=ch_in, kernel_size=kernel_size_2,  bias=bias)
        self.conv_5_2 = default_conv(ch_in=ch_out, ch_out=ch_out, kernel_size=kernel_size_2,  bias=bias)
        self.confusion_3 = nn.Conv2d(ch_in * 3, ch_out, 1, padding=0, bias=True)
        self.confusion_5 = nn.Conv2d(ch_in * 3, ch_out, 1, padding=0, bias=True)
        self.confusion_bottle = nn.Conv2d(ch_in * 3 + ch_out * 2, ch_out, 1, padding=0, bias=True)
        # self.relu = nn.ReLU(inplace=True)
        self.activation = activation

    def forward(self, x):
        input_1 = x  # [1, 3, 256, 256]
        output_3_1 = self.activation(self.conv_3_1(input_1))  # [1, 3, 256, 256]
        output_3_1 += x
        output_5_1 = self.activation(self.conv_5_1(input_1))  # [1, 3, 256, 256]
        output_5_1 += x
        input_2 = torch.cat([input_1, output_3_1, output_5_1], 1)  # [1, 9, 256, 256]

        input_2_3 = self.confusion_3(input_2)
        input_2_5 = self.confusion_5(input_2)

        output_3_2 = self.activation(self.conv_3_2(input_2_3))
        output_5_2 = self.activation(self.conv_5_2(input_2_5))
        input_3 = torch.cat([input_1, output_3_1, output_5_1, output_3_2, output_5_2], 1)
        output = self.confusion_bottle(input_3)
        # output += x
        return output  # [1, 3, 256, 256]


# DPA
class Multi_SEAttention(nn.Module):
    def __init__(self, in_planes, reduction=16):
        super(Multi_SEAttention, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)
        self.fc1 = nn.Sequential(
            nn.Linear(in_planes, in_planes // reduction, bias=False),
            nn.ReLU(inplace=True),
            nn.Linear(in_planes // reduction, in_planes, bias=False),
            nn.Sigmoid()
        )

        self.fc2 = nn.Sequential(
            nn.Linear(in_planes, in_planes // reduction, bias=False),
            nn.ReLU(inplace=True),
            nn.Linear(in_planes // reduction, in_planes, bias=False),
            nn.Sigmoid()
        )

        # self.sum = nn.Conv2d(in_planes * 3, in_planes, kernel_size=1, padding=0, bias=False)

    def forward(self, x):
        b, c, _, _ = x.size()
        y = self.avg_pool(x).view(b, c)
        y = self.fc1(y).view(b, c, 1, 1)

        z = self.max_pool(x).view(b, c)
        z = self.fc2(z).view(b, c, 1, 1)
        x1 = x * y.expand_as(x)
        x2 = x * z.expand_as(x)
        x_sum = x1 + x2 + x
        return x_sum


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x1 = torch.randn(1, 64, 32, 32).to(device)
    model1 = MDCB(64, 64).to(device)

    y1 = model1(x1)

    x2 = torch.randn(1, 64, 32, 32).to(device)
    model2 = Multi_SEAttention(64).to(device)

    y2 = model2(x2)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN、小红书：十小大")

    print("### MHCB ###")
    print("输入特征维度：", x1.shape)
    print("输出特征维度：", y1.shape)

    print("### DPA ###")
    print("输入特征维度：", x2.shape)
    print("输出特征维度：", y2.shape)