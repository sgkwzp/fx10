import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import numbers
from einops import rearrange

# HIN Block
class UNetConvBlock(nn.Module):
    """HIN增强型UNet卷积块
    功能：基于UNet的双层卷积结构，融入半实例归一化（HIN），增强特征表达并稳定训练
    核心逻辑：
        - 双层3×3卷积+LeakyReLU激活，提取局部特征
        - 半实例归一化（仅对一半通道做实例归一化），平衡特征多样性与稳定性
        - 1×1卷积残差连接，避免梯度消失并保留原始特征
    参数：
        in_size: 输入特征通道数
        out_size: 输出特征通道数
        relu_slope: LeakyReLU的负斜率（默认0.1，控制负区间梯度）
        use_HIN: 是否使用半实例归一化（默认True）
    输入：x (Tensor) - 形状 [B, in_size, H, W]（B=批量，H=高度，W=宽度）
    输出：out (Tensor) - 形状 [B, out_size, H, W]（残差增强后的特征）
    """
    def __init__(self, in_size, out_size, relu_slope=0.1, use_HIN=True):
        super(UNetConvBlock, self).__init__()
        # 残差连接：1×1卷积匹配输入输出通道数
        self.identity = nn.Conv2d(in_size, out_size, 1, 1, 0)
        # 第一层3×3卷积（提取基础特征）
        self.conv_1 = nn.Conv2d(in_size, out_size, kernel_size=3, padding=1, bias=True)
        self.relu_1 = nn.LeakyReLU(relu_slope, inplace=False)
        # 第二层3×3卷积（深化特征提取）
        self.conv_2 = nn.Conv2d(out_size, out_size, kernel_size=3, padding=1, bias=True)
        self.relu_2 = nn.LeakyReLU(relu_slope, inplace=False)
        # 半实例归一化：仅对输出通道的一半进行实例归一化（保留另一半通道多样性）
        if use_HIN:
            self.norm = nn.InstanceNorm2d(out_size // 2, affine=True)  # affine=True：可学习缩放和平移参数
        self.use_HIN = use_HIN

    def forward(self, x):
        out = self.conv_1(x)  # 第一层卷积：[B, in_size, H, W]→[B, out_size, H, W]
        # 半实例归一化（仅在use_HIN=True时生效）
        if self.use_HIN:
            # 按通道维度拆分为两部分（各out_size//2通道）
            out_1, out_2 = torch.chunk(out, 2, dim=1)
            # 对第一部分做实例归一化，第二部分保持不变，再拼接
            out = torch.cat([self.norm(out_1), out_2], dim=1)
        out = self.relu_1(out)  # 激活函数引入非线性
        out = self.relu_2(self.conv_2(out))  # 第二层卷积+激活
        out += self.identity(x)  # 残差连接：原始特征与提取特征相加
        return out

class InvBlock(nn.Module):
    """可逆变换块
    功能：通过通道拆分与非线性映射实现可逆特征变换，增强特征表达的同时保留原始信息
    核心逻辑：
        - 将输入通道拆分为两部分（x1和x2），分别通过UNetConvBlock进行非线性变换
        - 引入自适应缩放因子（s），动态调整x2的贡献度
        - 输出为两部分变换后的特征拼接，保证变换可逆性
    参数：
        channel_num: 输入特征总通道数（如3）
        channel_split_num: 第一部分拆分通道数（如1，剩余通道为channel_num - split_num）
        clamp: 缩放因子s的钳位值（默认0.8，限制s的范围，避免数值爆炸）
    输入：x (Tensor) - [B, channel_num, H, W]
    输出：out (Tensor) - [B, channel_num, H, W]（可逆变换后的特征）
    """
    def __init__(self, channel_num, channel_split_num, clamp=0.8):
        super(InvBlock, self).__init__()
        self.split_len1 = channel_split_num  # 第一部分通道数（如1）
        self.split_len2 = channel_num - channel_split_num  # 第二部分通道数（如2）
        self.clamp = clamp  # 缩放因子钳位值
        # 三个UNetConvBlock：分别用于x2→x1、x1→x2、x1→缩放因子的变换
        self.F = UNetConvBlock(self.split_len2, self.split_len1)  # 输入x2，输出x1维度特征
        self.G = UNetConvBlock(self.split_len1, self.split_len2)  # 输入x1，输出x2维度特征
        self.H = UNetConvBlock(self.split_len1, self.split_len2)  # 输入x1，输出x2维度缩放因子
        # 可逆卷积（当前为占位符，预留扩展接口）
        self.flow_permutation = lambda z, logdet, rev: self.invconv(z, logdet, rev)

    def forward(self, x):
        # 按通道拆分输入：x1（前split_len1通道）、x2（剩余split_len2通道）
        x1 = x.narrow(1, 0, self.split_len1)  # narrow(dim, start, length)：按维度截取
        x2 = x.narrow(1, self.split_len1, self.split_len2)
        # 变换1：x1 += F(x2)（用x2的特征增强x1）
        y1 = x1 + self.F(x2)
        # 变换2：生成自适应缩放因子s（钳位在[-clamp, clamp]）
        self.s = self.clamp * (torch.sigmoid(self.H(y1)) * 2 - 1)  # sigmoid输出[0,1]→调整为[-1,1]→钳位
        # 变换3：x2 = x2 * exp(s) + G(x1)（用x1的特征增强x2，并通过s动态缩放）
        y2 = x2.mul(torch.exp(self.s)) + self.G(y1)
        # 拼接两部分变换后的特征
        out = torch.cat((y1, y2), 1)
        return out

# Spatial Branch
class SpaBlock(nn.Module):
    """空间分支模块
    功能：在空间域对特征进行增强，捕捉局部空间依赖（边缘、纹理等细节）
    核心逻辑：
        - 复用InvBlock实现空间特征的可逆变换
        - 输入通道数拆分为两半（channel_split_num=nc//2），平衡两部分特征的变换
    参数：
        nc: 输入特征通道数
    输入：x (Tensor) - [B, nc, H, W]
    输出：yy (Tensor) - [B, nc, H, W]（空间增强后的特征）
    """
    def __init__(self, nc):
        super(SpaBlock, self).__init__()
        # 初始化可逆块：通道拆分为nc//2和nc//2（如nc=64→32+32）
        self.block = InvBlock(nc, nc // 2)

    def forward(self, x):
        yy = self.block(x)  # 可逆变换增强空间特征
        return x + yy  # 残差连接：原始空间特征与增强特征相加

# Frequency Branch
class FreBlock(nn.Module):
    """频域分支模块
    功能：在频域对特征进行增强，分别优化幅度（全局结构）和相位（空间位置）信息
    核心逻辑：
        - 将空间域特征通过FFT转换为频域，拆分为幅度和相位
        - 用1×1卷积分别优化幅度和相位（1×1卷积在频域等价于全局滤波）
        - 重构复数特征并返回频域结果
    参数：
        nc: 输入特征通道数（频域特征通道数与空间域一致）
    输入：x (Tensor) - [B, nc, H, W//2+1]（复数频域特征，rfft2输出格式）
    输出：x_out (Tensor) - [B, nc, H, W//2+1]（频域增强后的复数特征）
    """
    def __init__(self, nc):
        super(FreBlock, self).__init__()
        # 幅度处理分支：1×1卷积+LeakyReLU，优化全局结构信息
        self.processmag = nn.Sequential(
            nn.Conv2d(nc, nc, 1, 1, 0),  # 1×1卷积：频域全局滤波
            nn.LeakyReLU(0.1, inplace=True),  # 非线性激活
            nn.Conv2d(nc, nc, 1, 1, 0)   # 二次卷积深化优化
        )
        # 相位处理分支：1×1卷积+LeakyReLU，优化空间位置信息
        self.processpha = nn.Sequential(
            nn.Conv2d(nc, nc, 1, 1, 0),
            nn.LeakyReLU(0.1, inplace=True),
            nn.Conv2d(nc, nc, 1, 1, 0)
        )

    def forward(self, x):
        # 频域特征拆分：幅度（mag，全局结构）和相位（pha，空间位置）
        mag = torch.abs(x)  # 幅度：复数的模，反映频率成分的强度
        pha = torch.angle(x)  # 相位：复数的角度，反映频率成分的位置
        # 分别优化幅度和相位
        mag = self.processmag(mag)  # 增强重要频率成分的强度
        pha = self.processpha(pha)  # 校正频率成分的空间位置
        # 重构复数频域特征：real=mag*cos(pha), imag=mag*sin(pha)
        real = mag * torch.cos(pha)
        imag = mag * torch.sin(pha)
        x_out = torch.complex(real, imag)  # 合并实部和虚部为复数特征
        return x_out

# SFD Block
class ProcessBlock(nn.Module):
    """空间-频域双分支模块（SFD Block）
    功能：通过空间域与频域解耦建模，分别增强细节与全局特征，再融合输出
    核心流程：
        1. 输入特征拆分至空间分支和频域分支
        2. 空间分支：SpaBlock增强局部细节
        3. 频域分支：FFT转换→FreBlock增强→IFFT还原至空间域
        4. 双分支特征拼接→1×1卷积融合→残差连接输出
    参数：
        in_nc: 输入特征通道数（空间与频域分支通道数一致）
    输入：x (Tensor) - [B, in_nc, H, W]（空间域输入特征）
    输出：x_out (Tensor) - [B, in_nc, H, W]（双分支融合增强后的特征）
    """

    def __init__(self, in_nc):
        super(ProcessBlock, self).__init__()
        self.spatial_process = SpaBlock(in_nc)  # 空间分支处理
        self.frequency_process = FreBlock(in_nc)  # 频域分支处理
        # 空间-频域特征融合：1×1卷积将双分支拼接特征（2*in_nc）压缩回in_nc通道
        self.cat = nn.Conv2d(2 * in_nc, in_nc, 1, 1, 0)

    def forward(self, x):
        xori = x  # 备份原始输入，用于最终残差连接
        _, _, H, W = x.shape  # 获取输入特征尺寸（B, C, H, W）

        # 步骤1：频域分支处理
        x_freq = torch.fft.rfft2(x, norm='backward')  # 空间域→频域（rfft2：仅保留正频率，减少计算）
        x_freq = self.frequency_process(x_freq)  # 频域特征增强
        x_freq_spatial = torch.fft.irfft2(x_freq, s=(H, W), norm='backward')  # 频域→空间域（还原至原始尺寸）

        # 步骤2：空间分支处理
        x = self.spatial_process(x)  # 空间域特征增强

        # 步骤3：双分支特征融合
        xcat = torch.cat([x, x_freq_spatial], 1)  # 拼接空间分支和频域还原特征（通道数：in_nc→2*in_nc）
        x_out = self.cat(xcat)  # 1×1卷积融合，通道数还原为in_nc

        # 步骤4：残差连接输出（原始特征+融合特征，避免信息丢失）
        return x_out + xori


if __name__ == '__main__':
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    x = torch.randn(1, 64, 32, 32).to(device)
    sfd = ProcessBlock(64).to(device)
    y = sfd(x)
    print("微信公众号：十小大的底层视觉工坊")
    print("知乎、CSDN：十小大")
    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)