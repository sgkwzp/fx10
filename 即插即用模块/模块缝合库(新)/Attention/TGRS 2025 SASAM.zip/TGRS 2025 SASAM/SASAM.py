import torch
from torch import nn
import torch.nn.functional as F


class new_Spatial_Att_Bridge(nn.Module):
    """
    共享空间注意力：为多尺度输入特征生成共享参数的空间注意力权重
    核心设计：
        - 共享卷积核：所有尺度特征共用一个7×7膨胀卷积，减少参数量，保证注意力模式一致性
        - 自适应加权池化：可学习参数a/b平衡平均池化（全局统计）与最大池化（局部峰值）特征
        - 膨胀卷积增强：dilation=3扩大感受野，精准捕捉大范围空间依赖
        - Sigmoid激活：生成0~1空间权重，自适应强化关键区域
    """
    def __init__(self):
        super().__init__()
        self.shared_conv2d = nn.Sequential(nn.Conv2d(1, 1, 7, stride=1, padding=9, dilation=3),
                                           nn.Sigmoid())
        self.a = nn.Parameter(torch.tensor(0.5))  # 可训练的标量 a
        self.b = nn.Parameter(torch.tensor(0.5))  # 可训练的标量 b

    def forward(self, t1, t2, t3, t4, t5):
        t_list = [t1, t2, t3, t4, t5]
        att_list = []
        for t in t_list:
            avg_out = torch.mean(t, dim=1, keepdim=True)
            max_out, _ = torch.max(t, dim=1, keepdim=True)
            att = self.a * avg_out + self.b * max_out
            att = self.shared_conv2d(att)
            att_list.append(att)
        return att_list[0], att_list[1], att_list[2], att_list[3], att_list[4]


class SASAM_Bridge(nn.Module):
    """
    共享自适应空间注意力模块（SASAM）核心载体
    功能：集成共享空间注意力，对多尺度特征进行注意力加权+残差融合
    核心设计：
        - 多尺度同步增强：同时处理5个不同尺度的特征，适配多尺度架构
        - 注意力加权：空间权重与原特征逐元素相乘，强化关键区域
        - 残差连接：保留原始特征信息，缓解过度注意力导致的特征失真
    """
    def __init__(self):
        super().__init__()

        self.satt = new_Spatial_Att_Bridge()

    def forward(self, t1, t2, t3, t4, t5):
        r1, r2, r3, r4, r5 = t1, t2, t3, t4, t5

        satt1, satt2, satt3, satt4, satt5 = self.satt(t1, t2, t3, t4, t5)
        t1, t2, t3, t4, t5 = satt1 * t1, satt2 * t2, satt3 * t3, satt4 * t4, satt5 * t5

        t1, t2, t3, t4, t5 = t1 + r1, t2 + r2, t3 + r3, t4 + r4, t5 + r5

        return t1, t2, t3, t4, t5


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    t1 = torch.randn(1, 64, 32, 32).to(device)
    t2 = torch.randn(1, 64, 16, 16).to(device)
    t3 = torch.randn(1, 64, 8, 8).to(device)
    t4 = torch.randn(1, 64, 4, 4).to(device)
    t5 = torch.randn(1, 64, 2, 2).to(device)

    model = SASAM_Bridge().to(device)

    y1, y2, y3, y4, y5 = model(t1, t2, t3, t4, t5)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN、小红书：十小大")

    print("输入特征维度：", t1.shape)
    print("输入特征维度：", t2.shape)
    print("输入特征维度：", t3.shape)
    print("输入特征维度：", t4.shape)
    print("输入特征维度：", t5.shape)

    print("输出特征维度：", y1.shape)
    print("输出特征维度：", y2.shape)
    print("输出特征维度：", y3.shape)
    print("输出特征维度：", y4.shape)
    print("输出特征维度：", y5.shape)
