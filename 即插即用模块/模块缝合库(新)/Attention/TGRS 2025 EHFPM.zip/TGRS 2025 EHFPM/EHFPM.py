import torch.nn as nn
import torch
import torch.nn.functional as F
from mmengine.model import BaseModule
from mmcv.cnn import ConvModule

# pip install torch_dct
import torch_dct as DCT


def dwt_init(x):
    x01 = x[:, :, 0::2, :]
    x02 = x[:, :, 1::2, :]
    x1 = x01[:, :, :, 0::2]
    x2 = x02[:, :, :, 0::2]
    x3 = x01[:, :, :, 1::2]
    x4 = x02[:, :, :, 1::2]

    min_height = min(x1.size(2), x2.size(2), x3.size(2), x4.size(2))
    min_width = min(x1.size(3), x2.size(3), x3.size(3), x4.size(3))

    x1 = x1[:, :, :min_height, :min_width]
    x2 = x2[:, :, :min_height, :min_width]
    x3 = x3[:, :, :min_height, :min_width]
    x4 = x4[:, :, :min_height, :min_width]

    x_LL = (x1 + x2 + x3 + x4) / 4
    x_HL = (-x1 - x2 + x3 + x4) / 4
    x_LH = (-x1 + x2 - x3 + x4) / 4
    x_HH = (x1 - x2 - x3 + x4) / 4

    return x_LL, x_HL, x_LH, x_HH


class DWT(nn.Module):
    def __init__(self):
        super(DWT, self).__init__()
        self.requires_grad = False

    def forward(self, x):
        return dwt_init(x)


def idwt_init(x_LL, x_HL, x_LH, x_HH):
    min_height = min(x_LL.size(2), x_HL.size(2), x_LH.size(2), x_HH.size(2))
    min_width = min(x_LL.size(3), x_HL.size(3), x_LH.size(3), x_HH.size(3))

    x_LL = x_LL[:, :, :min_height, :min_width]
    x_HL = x_HL[:, :, :min_height, :min_width]
    x_LH = x_LH[:, :, :min_height, :min_width]
    x_HH = x_HH[:, :, :min_height, :min_width]

    x1 = x_LL - x_HL - x_LH + x_HH
    x2 = x_LL - x_HL + x_LH - x_HH
    x3 = x_LL + x_HL - x_LH - x_HH
    x4 = x_LL + x_HL + x_LH + x_HH

    # 拼接回原始尺寸
    upper = torch.zeros(x1.size(0), x1.size(1), x1.size(2)*2, x1.size(3), device=x1.device, dtype=x1.dtype)
    lower = torch.zeros_like(upper)

    upper[:, :, 0::2, :] = x1
    upper[:, :, 1::2, :] = x2
    lower[:, :, 0::2, :] = x3
    lower[:, :, 1::2, :] = x4

    x = torch.zeros(x1.size(0), x1.size(1), upper.size(2), upper.size(3)*2, device=x1.device, dtype=x1.dtype)
    x[:, :, :, 0::2] = upper
    x[:, :, :, 1::2] = lower

    return x


class IDWT(nn.Module):
    def __init__(self):
        super(IDWT, self).__init__()
        self.requires_grad = False

    def forward(self, x_LL, x_HL, x_LH, x_HH):
        return idwt_init(x_LL, x_HL, x_LH, x_HH)


class DctSpatialInteraction(BaseModule):
    """
    DCT空间交互模块：通过DCT强化空间高频细节，生成空间掩码
    核心设计：
        - DWT分解频域分量，DCT过滤低频，强化高频空间信息
        - 可学习噪声阈值，自适应抑制高频噪声
        - 支持非DCT模式（纯空间注意力），灵活适配不同场景
    """
    def __init__(self,
                 in_channels,
                 ratio,
                 isdct=True,
                 init_cfg=dict(
                     type='Xavier', layer='Conv2d', distribution='uniform')):
        super(DctSpatialInteraction, self).__init__(init_cfg)
        self.ratio = ratio
        self.isdct = isdct  # true when in p1&p2 # false when in p3&p4
        if not self.isdct:
            self.spatial1x1 = nn.Sequential(
                *[ConvModule(in_channels, 1, kernel_size=1, bias=False)]
            )

        self.noise_threshold = nn.Parameter(torch.tensor(0.1))  # 控制高频抑制强度

    def forward(self, x):
        x, x_HL, x_LH, x_HH = dwt_init(x)
        _, _, h0, w0 = x.size()
        if not self.isdct:
            return x * torch.sigmoid(self.spatial1x1(x))
        idct = DCT.dct_2d(x, norm='ortho')
        weight = self._compute_weight(h0, w0, self.ratio).to(x.device)

        idct = torch.where(torch.abs(idct) > self.noise_threshold, torch.tanh(idct), idct)

        weight = weight.view(1, h0, w0).expand_as(idct)
        dct = idct * weight  # filter out low-frequency features
        dct_ = DCT.idct_2d(dct, norm='ortho')  # generate spatial mask
        out = idwt_init(x * dct_, x_HL * dct_, x_LH * dct_, x_HH * dct_)
        return out

    def _compute_weight(self, h, w, ratio):
        h0 = int(h * ratio[0])
        w0 = int(w * ratio[1])
        weight = torch.ones((h, w), requires_grad=False)
        weight[:h0, :w0] = 0
        return weight


class DctChannelInteraction(BaseModule):
    """
    DCT通道交互模块：通过DCT强化通道高频特征，生成通道权重
    核心设计：
        - DCT频域过滤低频，强化通道维度高频信息
        - 结合全局最大/平均池化，生成通道注意力权重
        - 支持非DCT模式（纯通道注意力），适配不同场景
    """
    def __init__(self,
                 in_channels,
                 patch,
                 ratio,
                 isdct=True,
                 init_cfg=dict(
                     type='Xavier', layer='Conv2d', distribution='uniform')
                 ):
        super(DctChannelInteraction, self).__init__(init_cfg)
        self.in_channels = in_channels
        self.h = patch[0]
        self.w = patch[1]
        self.ratio = ratio
        self.isdct = isdct
        self.channel1x1 = nn.Sequential(
            *[ConvModule(in_channels, in_channels, kernel_size=1, groups=in_channels, bias=False)],
        )
        self.channel2x1 = nn.Sequential(
            *[ConvModule(in_channels, in_channels, kernel_size=1, groups=in_channels, bias=False)],
        )
        self.gelu = nn.GELU()

    def forward(self, x):
        n, c, h, w = x.size()
        if not self.isdct:  # true when in p1&p2 # false when in p3&p4
            amaxp = F.adaptive_max_pool2d(x, output_size=(1, 1))
            aavgp = F.adaptive_avg_pool2d(x, output_size=(1, 1))
            channel = self.channel1x1(self.gelu(amaxp)) + self.channel1x1(self.gelu(aavgp))  # 2025 03 15 szc
            return x * torch.sigmoid(self.channel2x1(channel))

        idct = DCT.dct_2d(x, norm='ortho')
        weight = self._compute_weight(h, w, self.ratio).to(x.device)
        weight = weight.view(1, h, w).expand_as(idct)
        dct = idct * weight  # filter out low-frequency features
        dct_ = DCT.idct_2d(dct, norm='ortho')

        amaxp = F.adaptive_max_pool2d(dct_, output_size=(self.h, self.w))
        aavgp = F.adaptive_avg_pool2d(dct_, output_size=(self.h, self.w))
        amaxp = torch.sum(self.gelu(amaxp), dim=[2, 3]).view(n, c, 1, 1)
        aavgp = torch.sum(self.gelu(aavgp), dim=[2, 3]).view(n, c, 1, 1)

        channel = self.channel1x1(amaxp) + self.channel1x1(aavgp)
        return x * torch.sigmoid(self.channel2x1(channel))

    def _compute_weight(self, h, w, ratio):
        h0 = int(h * ratio[0])
        w0 = int(w * ratio[1])
        weight = torch.ones((h, w), requires_grad=False)
        weight[:h0, :w0] = 0
        return weight


class HFP(BaseModule):
    """
    增强高频感知模块（Enhanced High Frequency Perception Module, EHFPM）
    功能：整合空间交互与通道交互双路径，增强高频细节，抑制低频冗余
    核心设计：
        - 双路径并行：空间路径强化高频空间细节，通道路径强化高频通道特征
        - 频域协同：DWT+DCT联合频域处理，精准捕捉高频信息
        - 灵活适配：支持开启/关闭DCT，适配不同任务需求
        - 特征融合：双路径特征相加后经卷积优化，提升表达能力
    """
    def __init__(self,
                in_channels,
                ratio=(0.25, 0.25),
                patch = (8,8),
                isdct = True,
                init_cfg=dict(
                type='Xavier', layer='Conv2d', distribution='uniform')):
        super(HFP, self).__init__(init_cfg)
        self.spatial = DctSpatialInteraction(in_channels, ratio=ratio, isdct = isdct)
        self.channel = DctChannelInteraction(in_channels, patch=patch, ratio=ratio, isdct = isdct)
        self.out =  nn.Sequential(
            *[ConvModule(in_channels, in_channels, kernel_size=3, padding=1),
            nn.GroupNorm(in_channels, in_channels)]
            )
    def forward(self, x):
        spatial = self.spatial(x)
        channel = self.channel(x)
        return self.out(spatial + channel)


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 64, 32, 32).to(device)
    model = HFP(64).to(device)

    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN、小红书：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)