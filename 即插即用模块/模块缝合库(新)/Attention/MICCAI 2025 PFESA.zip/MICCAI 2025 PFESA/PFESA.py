import torch
import torch.nn as nn
import torch.fft as fft

class PFESA(nn.Module):
    """
    PFESA: Parameter-Free Edge-Structure Attention 无参数边缘-结构注意力模块
    完整对应结构图全流程：频域分解(FD)→高低频解耦→边缘注意力(EA)+结构注意力(SA)→权重融合→特征增强
    核心特性：全程无任何可训练参数，纯统计特性驱动，零参数量、零训练负担
    """
    def __init__(self, base_ratio=0.1):
        super(PFESA, self).__init__()
        self.activation = nn.Sigmoid()  # 注意力权重归一化，对应结构图S算子
        self.base_ratio = base_ratio    # 高斯低通滤波器的基础截止频率，自适应适配输入尺寸
        self.eps = 1e-5                 # 数值稳定项，避免除零错误

    def _edge_attention(self, x):
        """
        边缘注意力EA模块 对应结构图(b)完整流程
        输入：高频特征Xh，输出：高频边缘注意力权重
        流程：特征减全局均值→平方→除以全局方差→标准化边缘响应
        """
        # 计算特征与全局均值的偏差平方
        x_minus_mu_square = (x - x.mean(dim=[2, 3], keepdim=True)).pow(2)
        # 计算特征全局方差
        x_var = x.var(dim=[2, 3], keepdim=True)
        # 标准化得到边缘响应，方差越大的边缘区域响应越强
        y = x_minus_mu_square / (x_var + self.eps)
        return y

    def _structure_attention(self, x):
        """
        结构注意力SA模块 对应结构图(c)完整流程
        输入：低频特征Xl，输出：低频结构注意力权重
        流程：特征取平方→减全局均值→除以全局方差→Sigmoid归一化
        """
        # 计算低频特征的能量分布
        energy_low = torch.pow(x, 2)
        # 能量分布的全局均值与方差
        energy_mu = torch.mean(energy_low, dim=[2, 3], keepdim=True)
        energy_var = torch.var(energy_low, dim=[2, 3], keepdim=True)
        # 标准化得到结构响应
        y = (energy_low - energy_mu) / (energy_var + self.eps)
        # Sigmoid归一化到0-1，得到结构注意力权重
        y = self.activation(y)
        return y

    def forward(self, x):
        b, c, h, w = x.size()
        # -------------------------- 步骤1：频域分解(FD) 对应结构图左侧FD模块 --------------------------
        # 1.1 空域特征→频域变换，仅对H、W维度做FFT
        x_freq = fft.fftn(x, dim=(-2, -1))
        # 1.2 频域零频分量移到中心，方便高低频拆分
        x_freq = fft.fftshift(x_freq, dim=(-2, -1))
        # 1.3 生成自适应高斯低通/高通掩码，对应结构图Gaussian Filter
        low_freq_mask = self._create_low_freq_mask(h, w, device=x_freq.device)
        high_freq_mask = 1 - low_freq_mask
        # 1.4 频域高低频解耦拆分
        low_freq = x_freq * low_freq_mask
        high_freq = x_freq * high_freq_mask
        # 1.5 逆FFT变换回空域，得到低频结构特征Xl、高频边缘特征Xh
        low_freq = torch.abs(fft.ifftn(low_freq, dim=(-2, -1)))
        high_freq = torch.abs(fft.ifftn(high_freq, dim=(-2, -1)))

        # -------------------------- 步骤2：双注意力计算 对应结构图EA、SA模块 --------------------------
        # 低频特征→结构注意力权重
        low_edge_att = self._structure_attention(low_freq)
        # 高频特征→边缘注意力权重
        high_edge_att = self._edge_attention(high_freq)

        # -------------------------- 步骤3：注意力融合与特征增强 --------------------------
        # 双注意力权重融合
        out_att = low_edge_att + high_edge_att
        # Sigmoid归一化到0-1，得到最终注意力图
        out_att = self.activation(out_att)
        # 注意力权重与原始输入逐元素相乘，输出增强特征
        return out_att * x

    def _create_low_freq_mask(self, h, w, device='cpu'):
        """
        生成自适应高斯低通掩码 对应结构图FD模块的Gaussian Filter
        根据输入宽高比自动调整截止频率，实现自适应高低频拆分
        """
        # 根据输入宽高比自适应调整掩码截止频率
        mask_ratio = self.base_ratio * min(h, w) / max(h, w)
        # 生成归一化坐标网格
        y = torch.linspace(-1, 1, h, device=device)
        x = torch.linspace(-1, 1, w, device=device)
        Y, X = torch.meshgrid(y, x, indexing='ij')
        # 生成2D高斯掩码，中心低频区域权重高，边缘高频区域权重低
        mask = torch.exp(-(Y ** 2 + X ** 2) / (2 * mask_ratio ** 2))
        return mask

# 模块测试代码
if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    x = torch.randn(1, 64, 32, 32).to(device)
    model = PFESA().to(device)
    y = model(x)
    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("小红书：十小大，主页获取往期全部即插即用代码，200+大合集")
    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)