import torch
import torch.nn as nn
import torch.nn.functional as F


class DomainRelated_Feature_Selection(nn.Module):
    """
    领域相关特征选择模块（DFS）：基于教师-学生网络架构，利用学生网络的先验特征（prior）
    对教师网络的特征（x）进行权重分配，筛选出与目标领域相关的关键特征，抑制冗余信息
    核心作用：在跨领域或蒸馏任务中，强化领域相关特征，提升模型泛化能力与特征利用率
    """

    def __init__(self, num_channels=256):
        """
        Args:
            num_channels (int): 第一个特征层的通道数（基础通道数），后续层通道数按2倍、4倍递增
        """
        super(DomainRelated_Feature_Selection, self).__init__()
        self.num_channels = num_channels  # 基础通道数（对应第一个特征层）

        # 初始化可学习权重参数theta（用于调节特征选择强度），默认初始化为0，加载到GPU
        # theta1：对应通道数=num_channels的特征层（第1层）
        self.theta1 = nn.Parameter(torch.zeros(1, num_channels, 1, 1)).to("cuda")
        # theta2：对应通道数=num_channels×2的特征层（第2层）
        self.theta2 = nn.Parameter(torch.zeros(1, num_channels * 2, 1, 1)).to("cuda")
        # theta3：对应通道数=num_channels×4的特征层（第3层及以后复用）
        self.theta3 = nn.Parameter(torch.zeros(1, num_channels * 4, 1, 1)).to("cuda")

    def forward(self, xs, priors, learnable=True, conv=False, max=True):
        """
        前向传播流程：先验特征处理→权重计算→领域相关权重融合→特征加权筛选→输出筛选后特征
        Args:
            xs (list[torch.Tensor]): 教师网络的特征列表，每个元素形状为[B, C, H, W]（B=批量，C=通道，H/W=空间尺寸）
            priors (list[torch.Tensor]): 学生网络的先验特征列表，与xs一一对应，形状完全一致
            learnable (bool): 是否启用可学习权重theta（True=启用，False=固定theta=1）
            conv (bool): 是否使用卷积方式生成权重（当前代码未实现，预留扩展）
            max (bool): 是否对先验特征进行最大值归一化（True=减去最大值避免数值偏移）
        Returns:
            list[torch.Tensor]: 筛选后的特征列表，与输入xs形状完全一致
        """
        features = []  # 存储筛选后的特征
        # 遍历教师特征与学生先验特征（按层匹配）
        for idx, (x, prior) in enumerate(zip(xs, priors)):
            theta = 1  # 初始化theta为1（默认无调节作用）

            # 步骤1：计算可学习权重theta（仅当learnable=True时启用）
            if learnable:
                # 按特征层索引选择对应的theta参数，确保不同通道数适配
                if idx < 3:
                    # 第1~3层：分别使用theta1、theta2、theta3
                    theta_param = eval(f"self.theta{idx + 1}")
                else:
                    # 第4层及以后：复用theta3（通道数按4倍基础通道数扩展）
                    theta_param = eval(f"self.theta{idx - 2}")
                # theta值调节：Sigmoid归一化（0~1）×1.0 + 0.5 → 范围0.5~1.5，再限制最大值为1
                # 目的：避免theta过小导致特征权重丢失，确保基础选择强度
                theta = torch.clamp(torch.sigmoid(theta_param) * 1.0 + 0.5, max=1)

            # 步骤2：先验特征处理（生成特征选择权重）
            b, c, h, w = x.shape  # 解析特征维度
            if not conv:  # 非卷积方式（当前默认启用）
                # 先验特征展平：[B, C, H, W] → [B, C, H×W]（空间维度展平，便于计算权重）
                prior_flat = prior.view(b, c, -1)
                # 最大值归一化（可选）：减去每个通道的最大值，避免数值偏差影响Softmax
                if max:
                    prior_flat_max = prior_flat.max(dim=-1, keepdim=True)[0]  # 每个通道的最大值
                    prior_flat = prior_flat - prior_flat_max
                # Softmax归一化：将先验特征转换为权重（空间维度求和为1，突出重要区域）
                weights = F.softmax(prior_flat, dim=-1)
                # 权重恢复空间维度：[B, C, H×W] → [B, C, H, W]（与输入特征匹配）
                weights = weights.view(b, c, h, w)
                # 计算全局先验信息：先验特征在空间维度的均值（反映通道级全局重要性）
                global_inf = prior.mean(dim=(-2, -1), keepdim=True)  # [B, C, 1, 1]
                # 领域相关权重融合：空间权重 × (可学习theta + 全局先验)，结合局部与全局信息
                inter_weights = weights * (theta + global_inf)
                # 特征加权筛选：教师特征 × 领域相关权重，强化关键特征，抑制冗余
                x_selected = x * inter_weights
                features.append(x_selected)  # 加入筛选后特征列表
            else:
                # 卷积方式生成权重（预留扩展，当前未实现）
                pass

        return features


def domain_related_feature_selection(xs, priors, max=True):
    """
    DFS模块的函数式实现（无参数版本）：功能与类模块一致，但不包含可学习theta参数
    核心作用：轻量级特征筛选，适用于无需动态调节选择强度的场景
    Args:
        xs (list[torch.Tensor]): 教师网络特征列表，形状[B, C, H, W]
        priors (list[torch.Tensor]): 学生网络先验特征列表，与xs一一对应
        max (bool): 是否对先验特征进行最大值归一化
    Returns:
        list[torch.Tensor]: 筛选后的特征列表
    """
    features_list = []
    theta = 1  # 固定theta=1（无调节作用）
    for (x, prior) in zip(xs, priors):
        b, c, h, w = x.shape
        # 先验特征展平与归一化（步骤与类模块一致）
        prior_flat = prior.view(b, c, -1)
        if max:
            prior_flat_max = prior_flat.max(dim=-1, keepdim=True)[0]
            prior_flat = prior_flat - prior_flat_max
        # 权重计算与特征筛选
        weights = F.softmax(prior_flat, dim=-1).view(b, c, h, w)
        global_inf = prior.mean(dim=(-2, -1), keepdim=True)
        inter_weights = weights * (theta + global_inf)
        x_selected = x * inter_weights
        features_list.append(x_selected)

    return features_list

if __name__ == "__main__":

    print("微信公众号：十小大的底层视觉工坊")
    print("知乎、CSDN：十小大")

    batch_size = 1
    channels_list = [256, 512, 1024]  # 对应 theta1, theta2, theta3 的通道数， 假设学生-教师网络有三个特征层
    height, width = 16, 16

    xs = []
    priors = []
    for c in channels_list:
        x = torch.randn(batch_size, c, height, width).to("cuda")  # 教师网络，要被筛选的特征
        prior = torch.randn(batch_size, c, height, width).to("cuda")  # 学生网络，获得的先验特征
        xs.append(x)
        priors.append(prior)

    model = DomainRelated_Feature_Selection(num_channels=256).to("cuda")
    outputs_class = model(xs, priors, learnable=True)

    # 打印类输出形状
    print("=== DomainRelated_Feature_Selection 输出 ===")
    for i, out in enumerate(outputs_class):
        print(f"第{i + 1}个特征形状: {out.shape}")



