import torch
from torch import nn

class SpatialCrossAttention(nn.Module):
    r"""
    核心空间交叉注意力单元 对应结构图(b) Centering Spectral Spatial Cross Attention (CS²CA) 核心计算流程
    功能：以中心像素先验为引导，建模水平-垂直全局空间上下文，实现光谱-空间双维度的交叉注意力增强
    适配：高光谱图像的单光谱分组特征处理
    """
    def __init__(self, channels):
        super(SpatialCrossAttention, self).__init__()
        self.softmax = nn.Softmax(-1)
        # 全局平均池化：提取中心像素向量(CPV)，对应结构图中的V_center中心特征
        self.agp = nn.AdaptiveAvgPool2d((1, 1))
        # 水平/垂直自适应池化：提取全局空间上下文，对应结构图中的V_spatial空间特征
        self.pool_h = nn.AdaptiveAvgPool2d((None, 1))  # 垂直方向压缩，保留水平全局信息
        self.pool_w = nn.AdaptiveAvgPool2d((1, None))  # 水平方向压缩，保留垂直全局信息
        # 分组归一化：适配高光谱单组通道的归一化，保证数值稳定性
        self.gn = nn.GroupNorm(channels, channels)
        # 1×1卷积：融合水平-垂直空间特征，生成坐标注意力权重
        self.conv1x1 = nn.Conv2d(channels, channels, kernel_size=1, stride=1, padding=0)
        # 3×3卷积：增强局部空间特征，对应结构图中的空间特征卷积增强
        self.conv3x3 = nn.Conv2d(channels, channels, kernel_size=3, stride=1, padding=1)

    def forward(self, x):
        b, c, h, w = x.size()
        group_x = x.reshape(b, -1, h, w)  # 单组光谱特征输入

        # -------------------------- 分支1：坐标注意力分支 对应结构图V_spatial空间特征分支 --------------------------
        # 提取水平、垂直全局空间上下文
        x_h = self.pool_h(group_x)  # [B, C, H, 1]
        x_w = self.pool_w(group_x).permute(0, 1, 3, 2)  # [B, C, W, 1] → 转置为[B, C, 1, W]
        # 拼接水平-垂直特征，1×1卷积融合
        hw = self.conv1x1(torch.cat([x_h, x_w], dim=2))
        x_h, x_w = torch.split(hw, [h, w], dim=2)
        # 生成空间坐标注意力，加权原始特征
        x1 = self.gn(group_x * x_h.sigmoid() * x_w.permute(0, 1, 3, 2).sigmoid())
        # 生成空间注意力矩阵与特征矩阵，对应结构图矩阵乘法分支
        x11 = self.softmax(self.agp(x1).reshape(b, -1, 1).permute(0, 2, 1))  # 中心引导的空间权重
        x12 = x1.reshape(b, c, -1)  # 空间特征展平

        # -------------------------- 分支2：中心先验增强分支 对应结构图V_center中心特征分支 --------------------------
        # 3×3卷积增强局部空间特征
        x2 = self.conv3x3(group_x)
        # 全局中心先验加权，对应结构图CPV中心像素引导
        x21 = self.gn(group_x).sigmoid()
        x12_feat = x2 + self.agp(self.gn(group_x)).sigmoid() * x21
        # 生成中心引导的注意力矩阵与特征矩阵
        x21_weight = self.softmax(self.agp(x12_feat).reshape(b, -1, 1).permute(0, 2, 1))
        x22 = x1.reshape(b, c, -1)  # 中心增强特征展平

        # -------------------------- 光谱-空间交叉注意力融合 对应结构图矩阵乘法+SUM+Sigmoid --------------------------
        # 双分支交叉矩阵乘法，融合空间-中心特征，生成全局空间权重
        weights = (torch.matmul(x11, x12) + torch.matmul(x21_weight, x22)).reshape(b, 1, h, w)
        # 权重加权原始输入，输出增强后的单组光谱特征
        return (group_x * weights.sigmoid()).reshape(b, c, h, w)


class CascadedSpatialCrossAttention(torch.nn.Module):
    r"""
    CSSCA (Centering Spectral–Spatial Cross-Attention) 中心引导光谱-空间交叉注意力模块
    完整对应结构图(b) CS²CA全流程，级联分组设计实现光谱维度的信息传递与融合
    核心：将高光谱通道按光谱维度分组，级联处理每个光谱组，实现光谱间信息传递+空间特征增强
    """
    def __init__(self, channels, group_num):
        super(CascadedSpatialCrossAttention, self).__init__()
        self.group_num = group_num  # 光谱分组数，对应结构图中的光谱维度分组
        # 为每个光谱组创建独立的空间交叉注意力单元
        self.attn = nn.ModuleList(SpatialCrossAttention(channels//group_num) for i in range(self.group_num))

    def forward(self, x):  # 输入高光谱特征 [B, C, H, W]，C为光谱通道数
        # 步骤1：沿光谱通道维度分组，对应结构图(a)光谱选择卷积的分组操作
        feats_in = x.chunk(self.group_num, dim=1)
        feats_out = []
        feat = feats_in[0]  # 初始化为第一个光谱组

        # 步骤2：级联处理每个光谱组，实现光谱间的信息传递
        for i in range(self.group_num):
            if i > 0:
                # 将前一个光谱组的输出，叠加到当前组的输入，实现光谱维度的级联融合
                feat = feat + feats_in[i]
            # 对当前光谱组做空间交叉注意力增强
            feat = self.attn[i](feat)
            feats_out.append(feat)

        # 步骤3：所有光谱组输出拼接，还原原始通道数
        x = torch.cat(feats_out, 1)
        return x


# 模块测试代码
if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    x = torch.randn(1, 64, 32, 32).to(device)
    model = CascadedSpatialCrossAttention(64, 4).to(device)
    y = model(x)
    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("小红书：十小大，主页获取往期全部即插即用代码，200+大合集")
    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)