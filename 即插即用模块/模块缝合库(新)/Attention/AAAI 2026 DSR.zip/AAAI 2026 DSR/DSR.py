# 双风格随机化模块（Dual Style Randomization, DSR）
# 核心设计：通过“前景风格随机化”与“全局风格随机化”双路径，在频域中融合不同风格的幅度与相位信息，
# 实现特征风格的多样化增强，同时保留核心结构信息，提升模型的泛化能力与鲁棒性

import random
import numpy as np

import torch
from torch import nn
import torch.nn.functional as F


class RandomConv(nn.Module):
    """
    随机卷积模块：生成随机卷积核，对特征进行全局风格扰动
    核心设计：
        - 随机核生成：基于正态分布生成卷积核，无监督引入风格多样性
        - 固定padding：确保输入输出空间尺寸一致，支持即插即用
    """
    def __init__(self, in_channels=3, kernel_size=3, std=0.1):
        super().__init__()
        self.in_channels = in_channels
        self.kernel_size = kernel_size
        self.std = std
        self.padding = kernel_size // 2

    def forward(self, x):
        # N(0, std^2)
        weight = (torch.randn(
            self.in_channels,
            self.in_channels,
            self.kernel_size,
            self.kernel_size,
            device=x.device
        ) * self.std)

        x = F.conv2d(x, weight, padding=self.padding, bias=None)
        return x


class MaskDilator(nn.Module):
    """
    掩码膨胀模块：扩大前景掩码范围，确保前景区域的完整性
    核心设计：
        - 双池化膨胀：先最大池化扩大掩码，再平均池化平滑边界
        - 奇数核约束：确保padding对称，掩码尺寸不变
    """
    def __init__(self, kernel_size=3):
        super().__init__()
        assert kernel_size % 2 == 1, "Kernel size must be odd"
        self.kernel_size = kernel_size
        self.padding = kernel_size // 2

    def forward(self, mask):
        # [B, 1, H, W]
        new_mask = mask.float().unsqueeze(1)

        # maxpooling
        new_mask = F.max_pool2d(
            new_mask,
            kernel_size=self.kernel_size,
            padding=self.padding,
            stride=1
        )
        # avgpooling
        new_mask = F.avg_pool2d(
            new_mask,
            kernel_size=self.kernel_size,
            padding=self.padding,
            stride=1
        )

        # [B, H, W]
        new_mask = new_mask.squeeze(1)
        return new_mask


# Dual Style Randomization
class DoublePerturb(nn.Module):
    """
    双风格随机化模块（Dual Style Randomization, DSR）
    功能：通过前景局部风格扰动与全局风格扰动，在频域融合幅度与相位，实现特征多样化增强
    核心设计：
        - 双路径扰动：前景路径聚焦局部区域，全局路径覆盖整体特征
        - 频域融合：固定相位（保结构）、混合幅度（改风格），兼顾稳定性与多样性
        - 动态区域选择：基于超像素掩码随机选择扰动区域，提升泛化性
        - 概率控制：可调节扰动概率，平衡原始特征与增强特征
    """
    def __init__(self, feat_dim=3, random_size=3, random_std=0.1, prob=1.0, mask_size=9):
        super(DoublePerturb, self).__init__()
        self.random_conv = RandomConv(feat_dim, random_size, random_std)
        self.mask_dilator = MaskDilator(kernel_size=mask_size)

        self.feat_dim = feat_dim
        self.prob = prob

    def forward(self, feature, mask, spixel_mask):
        # foreground style randomization
        if random.random() < self.prob:
            feature = self.foreground_perturb(feature, mask, spixel_mask)

        # global style randomization
        if random.random() < self.prob:
            feature = self.global_perturb(feature)

        return feature

    def foreground_perturb(self, feature, mask, spixel_mask):
        bs, nc, fh, fw = feature.shape
        # [B,H,W]
        mask = F.interpolate(mask.unsqueeze(1).float(), size=feature.shape[-2:], mode='nearest').squeeze(1)
        # preprocess
        dilate_mask = self.mask_dilator(mask)
        # [B,L,H,W]
        spixel_mask = F.interpolate(spixel_mask.float(), size=feature.shape[-2:], mode='nearest')

        perturb_feature_list = []
        for epi in range(bs):
            # [C,H,W]
            cur_feat = feature[epi]
            # [H,W]
            cur_dilate_mask = dilate_mask[epi]
            cur_spixel_mask = spixel_mask[epi][0]

            # region id
            unique_labels = torch.unique(cur_spixel_mask)
            # random select
            selected_label = np.random.choice(unique_labels.cpu().numpy())
            # region mask
            selected_mask = torch.zeros_like(cur_spixel_mask)
            selected_mask[cur_spixel_mask == selected_label] = 1.0

            # if selected region too small, skip perturbation
            M = selected_mask.sum()
            if M < (fh * fw) / unique_labels.shape[0] or cur_dilate_mask.sum() < (fh * fw) / unique_labels.shape[0]:
                perturb_feature_list.append(cur_feat.view(1, nc, fh, fw))
                continue

            # bounding box
            coords1 = torch.nonzero(cur_dilate_mask)
            coords2 = torch.nonzero(selected_mask)
            y1_min, x1_min = torch.min(coords1, dim=0).values
            y1_max, x1_max = torch.max(coords1, dim=0).values
            y2_min, x2_min = torch.min(coords2, dim=0).values
            y2_max, x2_max = torch.max(coords2, dim=0).values

            # crop patches
            patch1 = cur_feat[:, y1_min:y1_max + 1, x1_min:x1_max + 1]  # [C, H1, W1]
            patch2 = cur_feat[:, y2_min:y2_max + 1, x2_min:x2_max + 1]  # [C, H2, W2]
            patch2 = F.interpolate(patch2.unsqueeze(0), size=patch1.shape[-2:], mode='bilinear',
                                   align_corners=True).squeeze(0)

            # sample perturbation weight
            perturb_weight = (0.25 * torch.randn_like(patch1.mean(dim=(1, 2), keepdim=True))).unsqueeze(0).clamp(-1.0,
                                                                                                                 1.0)

            # foreground phase
            feature_fg_freq = torch.fft.fftshift(torch.fft.fft2(patch1.unsqueeze(0)))
            phase = torch.angle(feature_fg_freq)
            # local amplitude
            feature_bg_freq = torch.fft.fftshift(torch.fft.fft2(patch2.unsqueeze(0)))
            bg_amplitude = torch.abs(feature_bg_freq)
            # fusion amplitude
            amplitude = perturb_weight * bg_amplitude + (1 - perturb_weight) * torch.abs(feature_fg_freq)

            fusion_freq = torch.polar(amplitude, phase)
            patch1 = torch.fft.ifft2(torch.fft.ifftshift(fusion_freq)).real

            perturb_feat = cur_feat.clone()
            perturb_feat[:, y1_min:y1_max + 1, x1_min:x1_max + 1] = patch1
            perturb_feat = perturb_feat * cur_dilate_mask.unsqueeze(0) + cur_feat * (1 - cur_dilate_mask.unsqueeze(0))

            perturb_feature_list.append(perturb_feat.view(1, nc, fh, fw))

        # [B,C,H,W]
        perturb_feature = torch.cat(perturb_feature_list, dim=0)

        return perturb_feature

    def global_perturb(self, feature):
        random_feature = self.random_conv(feature)

        # phase
        feature_freq = torch.fft.fftshift(torch.fft.fft2(feature))
        phase = torch.angle(feature_freq)
        # random amplitude
        random_feature_freq = torch.fft.fftshift(torch.fft.fft2(random_feature))
        amplitude = torch.abs(random_feature_freq)

        fusion_freq = torch.polar(amplitude, phase)
        perturb_feature = torch.fft.ifft2(torch.fft.ifftshift(fusion_freq)).real

        return perturb_feature


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    model = DoublePerturb(64).to(device)

    img_q = torch.randn(1, 64, 32, 32).to(device)
    mask_q = torch.randn(1, 32, 32).to(device)
    spixel_mask_q = torch.randn(1, 64, 32, 32).to(device)

    y = model(img_q, mask_q, spixel_mask_q)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN、小红书：十小大")

    print("输入特征维度：", img_q.shape)
    print("输出特征维度：", y.shape)