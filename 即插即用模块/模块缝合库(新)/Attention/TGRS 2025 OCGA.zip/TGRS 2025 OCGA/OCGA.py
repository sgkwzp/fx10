import torch
import torch.nn as nn
import torch.nn.functional as F


def build_upsample_layer(cfg):
    if cfg['type'] == 'deconv':
        in_channels = cfg['in_channels']
        out_channels = cfg['out_channels']
        kernel_size = cfg['kernel_size']
        stride = cfg['stride']
        padding = (kernel_size - 1) // 2

        return nn.ConvTranspose2d(in_channels, out_channels, kernel_size, stride=stride, padding=padding)


def adj_index(h, k, node_num):
    dist = torch.cdist(h, h, p=2)
    each_adj_index = torch.topk(dist, k, dim=2).indices
    adj = torch.zeros(
        h.size(0), node_num, node_num,
        dtype=torch.int, device=h.device, requires_grad=False
    ).scatter_(dim=2, index=each_adj_index, value=1)
    return adj


def build_upsample_layer(cfg):
    """
    构建上采样层（反卷积）
    功能：根据配置生成反卷积层，用于恢复特征图尺寸
    Args:
        cfg: 配置字典，包含type、in_channels、out_channels、kernel_size、stride
    Returns:
        反卷积层（nn.ConvTranspose2d）
    """
    if cfg['type'] == 'deconv':
        in_channels = cfg['in_channels']
        out_channels = cfg['out_channels']
        kernel_size = cfg['kernel_size']
        stride = cfg['stride']
        padding = (kernel_size - 1) // 2  # 保证上采样后尺寸匹配
        return nn.ConvTranspose2d(in_channels, out_channels, kernel_size, stride=stride, padding=padding)

def adj_index(h, k, node_num):
    """
    生成图邻接矩阵（最优邻域选择）
    功能：基于欧氏距离筛选每个节点的top-k近邻，构建二进制邻接矩阵
    Args:
        h: 图节点特征，shape=[b, node_num, in_feature]
        k: 每个节点的邻域数量（top-k）
        node_num: 图节点总数
    Returns:
        邻接矩阵，shape=[b, node_num, node_num]（1表示相连，0表示不相连）
    """
    # 计算节点间欧氏距离
    dist = torch.cdist(h, h, p=2)
    # 筛选每个节点的top-k近邻索引
    each_adj_index = torch.topk(dist, k, dim=2).indices
    # 构建邻接矩阵（二进制）
    adj = torch.zeros(
        h.size(0), node_num, node_num,
        dtype=torch.int, device=h.device, requires_grad=False
    ).scatter_(dim=2, index=each_adj_index, value=1)
    return adj

class GraphAttentionLayer(nn.Module):
    """
    图注意力层
    功能：基于节点特征与邻接矩阵，计算注意力权重并聚合邻域特征
    核心设计：
        - 线性投影：通过权重矩阵W将节点特征映射到高维空间
        - 注意力机制：基于节点特征交互生成注意力分数，仅聚合邻域节点特征
        - 激活函数：ELU/LeakyReLU增强非线性表达
    Args:
        in_features: 输入节点特征维度
        out_features: 输出节点特征维度
        alpha: LeakyReLU负斜率（默认0.2）
        concat: 多头注意力时是否拼接输出（默认True）
    """
    def __init__(self, in_features, out_features, alpha=0.2, concat=True):
        super(GraphAttentionLayer, self).__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.alpha = alpha
        self.concat = concat
        # 节点特征投影权重W
        self.W = nn.Parameter(torch.empty(size=(in_features, out_features)))
        # 注意力分数计算参数a
        self.a = nn.Parameter(torch.empty(size=(2 * out_features, 1)))
        self.activation = nn.ELU()
        self.leakyrelu = nn.LeakyReLU(self.alpha)
        self._init_weights()

    def _init_weights(self):
        """参数初始化：Xavier均匀分布，保证训练稳定性"""
        nn.init.xavier_uniform_(self.W.data, gain=1.414)
        nn.init.xavier_uniform_(self.a.data, gain=1.414)

    def forward(self, h, adj):
        """
        前向传播：特征投影→注意力分数计算→邻域聚合
        Args:
            h: 节点特征，shape=[b, node_num, in_features]
            adj: 邻接矩阵，shape=[b, node_num, node_num]
        Returns:
            聚合后节点特征，shape=[b, node_num, out_features]
        """
        # 1. 节点特征线性投影（b, node_num, out_features）
        Wh = torch.matmul(h, self.W)
        # 2. 计算注意力分数（b, node_num, node_num）
        e = self._prepare_attentional_mechanism_input(Wh)
        # 3. 仅保留邻域节点的注意力分数（非邻域设为-9e15，Softmax后趋近于0）
        attention = torch.where(adj > 0, e, -9e15 * torch.ones_like(e))
        # 4. 注意力权重归一化
        attention = F.softmax(attention, dim=2)
        # 5. 邻域特征聚合
        h_prime = torch.matmul(attention, Wh)
        # 6. 激活输出（多头时拼接，单头时直接输出）
        if self.concat:
            return self.activation(h_prime)
        else:
            return h_prime

    def _prepare_attentional_mechanism_input(self, Wh):
        """计算注意力原始分数：e_ij = LeakyReLU(a^T [Wh_i || Wh_j])"""
        Wh1 = torch.matmul(Wh, self.a[:self.out_features, :])  # (b, node_num, 1)
        Wh2 = torch.matmul(Wh, self.a[self.out_features:, :])  # (b, node_num, 1)
        e = Wh1 + Wh2.transpose(1, 2)  # (b, node_num, node_num)，e_ij = Wh1_i + Wh2_j
        return self.leakyrelu(e)

    def __repr__(self):
        return self.__class__.__name__ + ' (' + str(self.in_features) + ' -> ' + str(self.out_features) + ')'


class OCGA(nn.Module):
    """
    最优选择图注意力模块（Optimal Choice Graph Attention, OCGA）
    功能：将网格特征转化为图结构，通过最优邻域选择与图注意力聚合，强化长距离特征依赖
    核心设计：
        - 特征token化：卷积降维+步长采样，将网格特征转化为图节点，降低计算成本
        - 最优邻域构建：基于欧氏距离选择top-k近邻，构建稀疏图，提升聚合效率
        - 多头图注意力：多组图注意力并行聚合，增强特征表达多样性
        - 残差融合：上采样恢复尺寸后与原始特征残差融合，保留局部细节
    Args:
        in_feature: 输入特征通道数
        out_feature: 输出特征通道数
        top_k: 每个节点的邻域数量（默认11）
        token: 卷积步长与反卷积核大小（默认3）
        alpha: 图注意力层LeakyReLU负斜率（默认0.2）
        num_heads: 多头注意力头数（默认1）
    """

    def __init__(self, in_feature, out_feature, top_k=11, token=3, alpha=0.2, num_heads=1):
        super(OCGA, self).__init__()
        self.top_k = top_k
        hidden_feature = in_feature  # 隐藏层特征通道数（与输入一致）
        # 特征token化：卷积降维+步长采样（网格→节点）
        self.conv = nn.Sequential(
            nn.Conv2d(in_feature, hidden_feature, token, stride=token),
            nn.BatchNorm2d(hidden_feature),
            nn.ReLU(inplace=True)
        )
        # 多头图注意力层
        self.attentions = [
            GraphAttentionLayer(
                hidden_feature, hidden_feature, alpha=alpha, concat=True
            ) for _ in range(num_heads)
        ]
        for i, attention in enumerate(self.attentions):
            self.add_module('attention_{}'.format(i), attention)
        # 输出图注意力层（聚合多头特征）
        self.out_att = GraphAttentionLayer(
            hidden_feature * num_heads, out_feature, alpha=alpha, concat=False)
        # 上采样层（恢复原始特征尺寸）
        self.deconv = build_upsample_layer(
            cfg=dict(type='deconv',
                     in_channels=out_feature, out_channels=out_feature,
                     kernel_size=token, stride=token)
        )
        self.activation = nn.ELU()
        self._init_weights()

    def _init_weights(self):
        """参数初始化：反卷积层Kaiming正态，偏置归零"""
        for m in [self.deconv]:
            nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
            nn.init.constant_(m.bias, 0)

    def forward(self, x):
        """
        前向传播：特征token化→图构建→多头注意力聚合→输出注意力聚合→上采样恢复→残差融合
        Args:
            x: 输入特征，shape=[b, in_feature, h, w]
        Returns:
            增强后特征，shape=[b, out_feature, h, w]（与输入尺寸一致）
        """
        # 1. 特征token化：卷积降维+步长采样（b, hidden_feature, h//token, w//token）
        h = self.conv(x)
        batch_size, in_feature, column, row = h.shape
        node_num = column * row  # 图节点总数（h//token * w//token）

        # 2. 网格→图转化：reshape为节点特征（b, node_num, hidden_feature）
        h_node = h.view(batch_size, in_feature, node_num).permute(0, 2, 1)

        # 3. 构建图邻接矩阵：基于欧氏距离选择top-k近邻（b, node_num, node_num）
        adj = adj_index(h_node, self.top_k, node_num)

        # 4. 多头图注意力聚合：拼接多头输出（b, node_num, hidden_feature * num_heads）
        h_multi_head = torch.cat([att(h_node, adj) for att in self.attentions], dim=2)

        # 5. 输出注意力聚合：融合多头特征（b, node_num, out_feature）
        h_agg = self.activation(self.out_att(h_multi_head, adj))

        # 6. 图→网格转化：reshape为特征图（b, out_feature, column, row）
        h_grid = h_agg.view(batch_size, column, row, -1).permute(0, 3, 1, 2)

        # 7. 上采样恢复：反卷积+双线性插值，恢复原始尺寸（b, out_feature, h, w）
        h_up = F.interpolate(
            self.deconv(h_grid), x.shape[-2:], mode='bilinear', align_corners=True)

        # 8. 残差融合输出
        return F.relu(h_up + x)


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 64, 32, 32).to(device)
    model = OCGA(64, 64).to(device)

    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN、小红书：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)