import random
import torch
import torch.nn as nn
import torch.nn.functional as F


def generate_disc_prompt(feat_s, mask_s, feat_q, eps=1e-6):
    """
    生成判别性前景先验掩码，为DFM模块提供前景-背景的判别性调制依据
    核心逻辑：从支持集特征中提取前景/背景原型，通过余弦相似度计算查询集的前景置信度，
    构建前景相对背景的判别性先验掩码，实现对查询集特征的前景调制
    Args:
        feat_s: 支持集特征 (Support Set)，[B, C, H, W]，提供前景/背景参考
        mask_s: 支持集前景掩码，[B, 1, H, W]，标注支持集中的前景区域（1为前景，0为背景）
        feat_q: 查询集特征 (Query Set)，[B, C, H, W]，需要被调制的目标特征
        eps: 数值稳定性小值，防止除零错误，默认1e-6
    Returns:
        P_Q_disc: 判别性先验掩码，[B, H, W]，查询集的前景相对判别置信度
        P_q_fg: 查询集特征与前景原型的余弦相似度，[B, H, W]
        P_q_bg: 查询集特征与背景原型的余弦相似度，[B, H, W]
    """
    B, C, H, W = feat_s.shape
    # 步骤1：从支持集掩码中分离前景/背景二值掩码
    fg_mask = (mask_s == 1).float()  # [B, 1, H, W] 前景掩码（1为前景）
    bg_mask = (mask_s == 0).float()  # [B, 1, H, W] 背景掩码（0为背景）

    # 定义带掩码的全局平均池化函数：仅对掩码覆盖区域做池化，提取纯前景/背景原型
    def masked_gap(feat, mask):
        masked_feat = feat * mask  # 特征与掩码逐元素相乘，屏蔽非目标区域 [B, C, H, W]
        # 掩码区域特征求和后除以掩码像素数，得到目标区域的特征原型 [B, C]
        gap = masked_feat.sum(dim=(2, 3)) / (mask.sum(dim=(2, 3)) + eps)
        return gap

    # 步骤2：提取支持集的前景/背景特征原型（全局特征代表）
    proto_fg = masked_gap(feat_s, fg_mask)  # [B, C] 前景原型
    proto_bg = masked_gap(feat_s, bg_mask)  # [B, C] 背景原型

    # 步骤3：对查询集特征和前景/背景原型做L2归一化，为余弦相似度计算做准备
    feat_q_flat = feat_q.view(B, C, -1)  # 查询集特征展平 [B, C, H*W]
    feat_q_norm = F.normalize(feat_q_flat, dim=1)  # 通道维度归一化 [B, C, H*W]
    # 原型增加维度并归一化，适配余弦相似度的矩阵计算 [B, C, 1]
    proto_fg_norm = F.normalize(proto_fg.unsqueeze(2), dim=1)
    proto_bg_norm = F.normalize(proto_bg.unsqueeze(2), dim=1)

    # 步骤4：计算查询集每个像素与前景/背景原型的余弦相似度（衡量像素的前景/背景归属）
    P_q_fg = torch.sum(feat_q_norm * proto_fg_norm, dim=1)  # [B, H*W] 前景相似度
    P_q_bg = torch.sum(feat_q_norm * proto_bg_norm, dim=1)  # [B, H*W] 背景相似度

    # 定义最小-最大归一化函数：将特征值映射到[0,1]区间，保证数值稳定性和可比性
    def minmax_norm(x):
        x_min = x.min(dim=1, keepdim=True)[0]  # 按批次取最小值
        x_max = x.max(dim=1, keepdim=True)[0]  # 按批次取最大值
        return (x - x_min) / (x_max - x_min + eps)

    # 步骤5：将相似度恢复为2D特征图尺寸 [B, H, W]
    P_q_fg = P_q_fg.view(B, H, W)
    P_q_bg = P_q_bg.view(B, H, W)

    # 步骤6：构建判别性先验掩码——突出前景相对背景的判别性，过滤负向值并归一化
    P_q_disc = F.relu(P_q_fg - P_q_bg)  # 前景-背景相似度，ReLU过滤负向（背景占优）区域 [B, H, W]
    P_q_disc = minmax_norm(P_q_disc.view(B, -1)).view(B, H, W)  # 归一化到[0,1]，作为最终判别掩码

    return P_q_disc, P_q_fg, P_q_bg  # 返回判别掩码和原始相似度掩码


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    fs = torch.randn(1, 64, 32, 32).to(device)
    fq = torch.randn(1, 64, 32, 32).to(device)
    mask = torch.randn(1, 1, 32, 32).to(device)
    P_q_disc, P_q_fg, P_q_bg = generate_disc_prompt(fs, mask, fq)

    # 三个输出堆叠变成(b,c,h,w)
    output = torch.stack([P_q_disc, P_q_fg, P_q_bg], dim=1).to(device)
    # 1×1卷积变回64通道
    Conv11 = nn.Conv2d(3, 64, kernel_size=1, stride=1, padding=0, bias=False).to(device)
    output1 = Conv11(output)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("小红书：十小大，主页获取往期全部即插即用代码，200+大合集")

    print("输入特征维度：", fs.shape)
    print("输出特征维度：", output1.shape)