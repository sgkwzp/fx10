# 双提示块（Dual Prompt Block, DPB）
# 核心设计：通过频率分离、频域专属提示生成、高低频提示调制的全流程，实现“频率分离-专属提示-精准融合”的特征增强，
# 分别优化低频结构特征与高频细节特征，同时利用提示学习强化关键信息，提升特征表达的针对性与丰富度

import torch
import torch.nn as nn
import torch.nn.functional as F
from einops import rearrange


## channel dynamic filters
class dynamic_filter_channel(nn.Module):
    """
    通道动态滤波器：生成动态低通滤波器，实现特征的高低频分离
    核心设计：
        - 动态滤波器生成：基于输入特征全局统计信息，生成自适应低通滤波核
        - 门控机制：通过Sigmoid门控调节滤波器强度，避免过度滤波
        - 高低频分离：原始特征减去低通滤波结果，得到高频特征，实现无监督频率分离
    """
    def __init__(self, inchannels, kernel_size=3, stride=1, group=8):
        super(dynamic_filter_channel, self).__init__()
        self.stride = stride
        self.kernel_size = kernel_size
        self.group = group

        self.conv = nn.Conv2d(inchannels, group * kernel_size ** 2, kernel_size=1, stride=1, bias=False)
        self.conv_gate = nn.Conv2d(group * kernel_size ** 2, group * kernel_size ** 2, kernel_size=1, stride=1,
                                   bias=False)
        self.act_gate = nn.Sigmoid()
        self.bn = nn.BatchNorm2d(group * kernel_size ** 2)
        self.act = nn.Softmax(dim=-2)
        nn.init.kaiming_normal_(self.conv.weight, mode='fan_out', nonlinearity='relu')

        self.pad = nn.ReflectionPad2d(kernel_size // 2)

        self.ap_1 = nn.AdaptiveAvgPool2d((1, 1))
        # self.ap_2 = nn.AdaptiveMaxPool2d((1, 1))

    def forward(self, x):
        identity_input = x
        low_filter1 = self.ap_1(x)
        # low_filter2 = self.ap_2(x)
        low_filter = self.conv(low_filter1)
        low_filter = low_filter * self.act_gate(self.conv_gate(low_filter))
        low_filter = self.bn(low_filter)

        n, c, h, w = x.shape
        x = F.unfold(self.pad(x), kernel_size=self.kernel_size).reshape(n, self.group, c // self.group,
                                                                        self.kernel_size ** 2, h * w)

        n, c1, p, q = low_filter.shape
        low_filter = low_filter.reshape(n, c1 // self.kernel_size ** 2, self.kernel_size ** 2, p * q).unsqueeze(2)

        low_filter = self.act(low_filter)
        # print('low_filter size',low_filter.shape)
        # print('low_filter n,c1,p,q',n,c1,p,q)

        low_part = torch.sum(x * low_filter, dim=3).reshape(n, c, h, w)

        out_high = identity_input - low_part
        return low_part, out_high


class splitFrequencyModule(nn.Module):
    """
    频率分离模块：封装动态滤波器，实现输入特征的高低频分离
    功能：将输入特征拆分为低频结构特征和高频细节特征，为后续频域专属提示提供基础
    """
    def __init__(self, basic_dim=32, dim=32, input_resolution=128):
        super().__init__()

        self.dyna_channel = dynamic_filter_channel(inchannels=basic_dim)

    def forward(self, F_low):
        _,c_basic,h_ori, w_ori = F_low.shape

        low_part, out_high = self.dyna_channel(F_low)

        return low_part, out_high


def window_partition(x, win_size, dilation_rate=1):
    B, H, W, C = x.shape
    if dilation_rate != 1:
        x = x.permute(0, 3, 1, 2)  # B, C, H, W
        assert type(dilation_rate) is int, 'dilation_rate should be a int'
        x = F.unfold(x, kernel_size=win_size, dilation=dilation_rate, padding=4 * (dilation_rate - 1),
                     stride=win_size)  # B, C*Wh*Ww, H/Wh*W/Ww
        windows = x.permute(0, 2, 1).contiguous().view(-1, C, win_size, win_size)  # B' ,C ,Wh ,Ww
        windows = windows.permute(0, 2, 3, 1).contiguous()  # B' ,Wh ,Ww ,C
    else:
        x = x.view(B, H // win_size, win_size, W // win_size, win_size, C)
        windows = x.permute(0, 1, 3, 2, 4, 5).contiguous().view(-1, win_size, win_size, C)  # B' ,Wh ,Ww ,C
    return windows


def window_reverse(windows, win_size, H, W, dilation_rate=1):
    # B' ,Wh ,Ww ,C
    B = int(windows.shape[0] / (H * W / win_size / win_size))
    x = windows.view(B, H // win_size, W // win_size, win_size, win_size, -1)
    if dilation_rate != 1:
        x = windows.permute(0, 5, 3, 4, 1, 2).contiguous()  # B, C*Wh*Ww, H/Wh*W/Ww
        x = F.fold(x, (H, W), kernel_size=win_size, dilation=dilation_rate, padding=4 * (dilation_rate - 1),
                   stride=win_size)
    else:
        x = x.permute(0, 1, 3, 2, 4, 5).contiguous().view(B, H, W, -1)
    return x


class lowFrequencyPromptFusion(nn.Module):
    """
    低频提示融合器（Low-frequency Prompt Modulator, LPM）
    功能：将低频专属提示与目标特征融合，强化结构信息
    核心设计：
        - 全局提示提取：自适应平均池化压缩提示特征，聚焦全局结构
        - 多头注意力融合：通过QKV注意力机制，让目标特征自适应吸收提示信息
        - 可学习温度参数：调节注意力权重分布，提升融合精准度
    """
    def __init__(self, dim, dim_bak, num_heads, win_size=8, bias=False):
        super(lowFrequencyPromptFusion, self).__init__()
        self.num_heads = num_heads
        self.temperature = nn.Parameter(torch.ones(num_heads, 1, 1))
        self.q = nn.Conv2d(dim, dim, kernel_size=1, bias=bias)
        self.ap_kv = nn.AdaptiveAvgPool2d(1)
        self.kv = nn.Conv2d(dim_bak, dim * 2, kernel_size=1, bias=bias)

        self.project_out = nn.Conv2d(dim, dim, kernel_size=1, bias=bias)

    def forward(self, feature, prompt_feature):
        b, c1, h, w = feature.shape
        _, c2, _, _ = prompt_feature.shape

        query = self.q(feature).reshape(b, h * w, self.num_heads, c1 // self.num_heads).permute(0, 2, 1, 3).contiguous()

        prompt_feature = self.ap_kv(prompt_feature)  # .reshape(b, c2, -1).permute(0, 2, 1)
        key_value = self.kv(prompt_feature).reshape(b, 2 * c1, -1).permute(0, 2, 1).contiguous().reshape(b, -1, 2,
                                                                                                         self.num_heads,
                                                                                                         c1 // self.num_heads).permute(
            2, 0, 3, 1, 4).contiguous()
        key, value = key_value[0], key_value[1]

        attn = (query @ key.transpose(-2, -1).contiguous()) * self.temperature
        attn = attn.softmax(dim=-1)

        out = (attn @ value)

        out = rearrange(out, 'b head (h w) c -> b (head c) h w', head=self.num_heads, h=h, w=w)
        out = self.project_out(out)

        return out


class LinearProjection(nn.Module):
    def __init__(self, dim, heads=8, dim_head=64, dropout=0., bias=True, isQuery=True):
        super().__init__()
        self.isQuery = isQuery
        inner_dim = dim_head * heads
        self.heads = heads
        if self.isQuery:
            self.to_q = nn.Linear(dim, inner_dim, bias=bias)
        else:
            self.to_kv = nn.Linear(dim, 2 * inner_dim, bias=bias)
        self.dim = dim
        self.inner_dim = inner_dim

    def forward(self, x, attn_kv=None):
        B_, N, C = x.shape
        if attn_kv is not None:
            attn_kv = attn_kv.unsqueeze(0).repeat(B_, 1, 1)
        else:
            attn_kv = x
        N_kv = attn_kv.size(1)
        if self.isQuery:
            q = self.to_q(x).reshape(B_, N, 1, self.heads, C // self.heads).permute(2, 0, 3, 1, 4).contiguous()
            q = q[0]
            return q
        else:
            C = self.inner_dim
            kv = self.to_kv(attn_kv).reshape(B_, N_kv, 2, self.heads, C // self.heads).permute(2, 0, 3, 1,
                                                                                               4).contiguous()
            k, v = kv[0], kv[1]
            return k, v


class highFrequencyPromptFusion(nn.Module):
    """
    高频提示融合器（High-frequency Prompt Modulator, HPM）
    功能：将高频专属提示与目标特征融合，强化细节信息
    核心设计：
        - 窗口注意力：局部窗口内计算注意力，聚焦细节关联
        - 深度卷积增强：提示特征经深度卷积强化局部细节
        - 线性投影融合：轻量化实现提示与目标特征的自适应融合
    """
    def __init__(self, dim, dim_bak, win_size, num_heads, qkv_bias=True, qk_scale=None, bias=False):
        super(highFrequencyPromptFusion, self).__init__()
        self.num_heads = num_heads
        self.win_size = win_size  # Wh, Ww
        head_dim = dim // num_heads
        self.scale = qk_scale or head_dim ** -0.5

        self.to_q = LinearProjection(dim, num_heads, dim // num_heads, bias=qkv_bias, isQuery=True)
        self.to_kv = LinearProjection(dim_bak, num_heads, dim // num_heads, bias=qkv_bias, isQuery=False)

        self.kv_dwconv = nn.Conv2d(dim_bak, dim_bak, kernel_size=3, stride=1, padding=1, groups=dim_bak, bias=bias)

        self.softmax = nn.Softmax(dim=-1)

        self.project_out = nn.Linear(dim, dim)

    def forward(self, query_feature, key_value_feature):
        b, c, h, w = query_feature.shape
        _, c_2, _, _ = key_value_feature.shape

        key_value_feature = self.kv_dwconv(key_value_feature)

        # partition windows
        query_feature = rearrange(query_feature, ' b c1 h w -> b h w c1 ', h=h, w=w)
        query_feature_windows = window_partition(query_feature, self.win_size)  # nW*B, win_size, win_size, C  N*C->C
        query_feature_windows = query_feature_windows.view(-1, self.win_size * self.win_size,
                                                           c)  # nW*B, win_size*win_size, C

        key_value_feature = rearrange(key_value_feature, ' b c2 h w -> b h w c2 ', h=h, w=w)
        key_value_feature_windows = window_partition(key_value_feature,
                                                     self.win_size)  # nW*B, win_size, win_size, C  N*C->C
        key_value_feature_windows = key_value_feature_windows.view(-1, self.win_size * self.win_size,
                                                                   c_2)  # nW*B, win_size*win_size, C

        B_, N, C = query_feature_windows.shape

        query = self.to_q(query_feature_windows)
        query = query * self.scale

        key, value = self.to_kv(key_value_feature_windows)
        attn = (query @ key.transpose(-2, -1).contiguous())
        attn = attn.softmax(dim=-1)

        out = (attn @ value).transpose(1, 2).contiguous().reshape(B_, N, C)

        out = self.project_out(out)

        # merge windows
        attn_windows = out.view(-1, self.win_size, self.win_size, C)
        attn_windows = window_reverse(attn_windows, self.win_size, h, w)  # B H' W' C
        return rearrange(attn_windows, 'b h w c -> b c h w', h=h, w=w)


class frequenctSpecificPromptGenetator(nn.Module):
    """
    频域专属提示生成器（Frequency-Specific Prompt Generator, FSPG）
    功能：为高低频特征分别生成专属提示特征，强化频域关键信息
    核心设计：
        - 高频提示：空间域卷积增强，适配细节特征
        - 低频提示：频域滤波增强，适配结构特征
        - 自适应插值：匹配目标特征尺寸
    """
    def __init__(self, dim=3, h=128, w=65, flag_highF=True):
        super().__init__()
        self.flag_highF = flag_highF
        k_size = 3
        if flag_highF:
            w = (w - 1) * 2
            self.w = w
            self.h = h
            self.weight = nn.Parameter(torch.randn(1, dim, h, w, dtype=torch.float32) * 0.02)
            self.body = nn.Sequential(nn.Conv2d(dim, dim, (1, k_size), padding=(0, k_size // 2), groups=dim),
                                      nn.Conv2d(dim, dim, (k_size, 1), padding=(k_size // 2, 0), groups=dim),
                                      nn.GELU())
        else:
            self.complex_weight = nn.Parameter(torch.randn(1, dim, h, w, 2, dtype=torch.float32) * 0.02)
            self.body = nn.Sequential(nn.Conv2d(2 * dim, 2 * dim, kernel_size=1, stride=1),
                                      nn.GELU(),
                                      )

    def forward(self, ffm, H, W):
        if self.flag_highF:
            ffm = F.interpolate(ffm, size=(H, W), mode='bilinear')
            y_att = self.body(ffm)

            y_f = y_att * ffm
            y = y_f * self.weight

        else:
            ffm = F.interpolate(ffm, size=(H, W), mode='bicubic')
            y = torch.fft.rfft2(ffm.to(torch.float32).cuda())
            y_imag = y.imag
            y_real = y.real
            y_f = torch.cat([y_real, y_imag], dim=1)
            weight = torch.complex(self.complex_weight[..., 0], self.complex_weight[..., 1])
            y_att = self.body(y_f)
            y_f = y_f * y_att
            y_real, y_imag = torch.chunk(y_f, 2, dim=1)
            y = torch.complex(y_real, y_imag)
            y = y * weight
            y = torch.fft.irfft2(y, s=(H, W))

        return y


##########################################################################
## PromptModule
class PromptModule(nn.Module):
    """
    双提示块（Dual Prompt Block, DPB）核心模块
    功能：整合频率分离、频域专属提示生成、高低频提示融合，实现全流程特征增强
    核心设计：
        - 双提示并行：高低频特征分别生成专属提示，针对性优化
        - 模块化融合：不同频域采用适配的融合机制（全局注意力→低频，窗口注意力→高频）
        - 特征聚合：1×1卷积融合双提示特征，恢复原始维度
    """
    def __init__(self, basic_dim=32, dim=32, input_resolution=128):
        super().__init__()
        h = input_resolution
        w = input_resolution // 2 + 1
        self.simple_Fusion = nn.Conv2d(2 * dim, dim, kernel_size=1, stride=1)

        self.FSPG_high = frequenctSpecificPromptGenetator(basic_dim, h, w, flag_highF=True)
        self.FSPG_low = frequenctSpecificPromptGenetator(basic_dim, h, w, flag_highF=False)

        self.modulator_hi = highFrequencyPromptFusion(dim, basic_dim, win_size=8, num_heads=2, bias=False)
        self.modulator_lo = lowFrequencyPromptFusion(dim, basic_dim, win_size=8, num_heads=2, bias=False)

    def forward(self, low_part, out_high, x):
        b, c, h, w = x.shape

        y_h = self.FSPG_high(out_high, h, w)
        y_l = self.FSPG_low(low_part, h, w)

        y_h = self.modulator_hi(x, y_h)
        y_l = self.modulator_lo(x, y_l)

        x = self.simple_Fusion(torch.cat([y_h, y_l], dim=1))

        return x


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    dim = 64
    shallow_f = torch.randn(2, dim, 32, 32).to(device)
    deep_f = torch.randn(2, dim, 32, 32).to(device)

    model1 = splitFrequencyModule(basic_dim=dim, dim=dim, input_resolution=32).to(device)
    model2 = PromptModule(basic_dim=dim, dim=dim, input_resolution=32).to(device)

    low_part, out_high = model1(shallow_f)
    y = model2(low_part, out_high, deep_f)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN、小红书：十小大")

    print("输入特征维度：", shallow_f.shape)
    print("输出特征维度：", y.shape)