import math
import torch.nn as nn
import torch


class ADSF(nn.Module):
    def __init__(self, channel, m=-0.80, b=1, gamma=2):
        super(ADSF, self).__init__()


        self.w = torch.nn.Parameter(torch.FloatTensor([m]), requires_grad=True)
        self.mix_block = nn.Sigmoid()


        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        t = int(abs((math.log(channel, 2) + b) / gamma))
        k = t if t % 2 else t + 1
        self.conv1 = nn.Conv1d(1, 1, kernel_size=k, padding=int(k / 2), bias=False)
        self.fc = nn.Conv2d(channel, channel, 1, padding=0, bias=True)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x1, x2):

        ax1 = self.avg_pool(x1)
        ax2 = self.avg_pool(x2)
        ax1 = self.conv1(ax1.squeeze(-1).transpose(-1, -2)).transpose(-1, -2)  # (1, C, 1)
        ax2 = self.fc(ax2).squeeze(-1).transpose(-1, -2)  # (1, C, 1)
        out1 = torch.sum(torch.matmul(ax1, ax2), dim=1).unsqueeze(-1).unsqueeze(-1)  # (1, C, 1, 1)
        out1 = self.sigmoid(out1)
        out2 = torch.sum(torch.matmul(ax2.transpose(-1, -2), ax1.transpose(-1, -2)), dim=1).unsqueeze(-1).unsqueeze(-1)
        out2 = self.sigmoid(out2)
        mix_factor = self.mix_block(self.w)
        out = out1 * mix_factor + out2 * (1 - mix_factor)
        out = self.conv1(out.squeeze(-1).transpose(-1, -2)).transpose(-1, -2).unsqueeze(-1)
        out = self.sigmoid(out)

        # 融合，维度不变
        # out = x2 * out + x1

        # 源码，维度扩大
        out = torch.cat([(x2 * out), x1], dim=1)

        return out


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x_d = torch.randn(1, 64, 32, 32).to(device)
    x_f = torch.randn(1, 64, 32, 32).to(device)
    model = ADSF(64).to(device)

    y = model(x_d, x_f)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN、小红书：十小大")

    print("输入深层特征维度：", x_d.shape)
    print("输入浅层特征维度：", x_f.shape)
    print("输出特征维度：", y.shape)