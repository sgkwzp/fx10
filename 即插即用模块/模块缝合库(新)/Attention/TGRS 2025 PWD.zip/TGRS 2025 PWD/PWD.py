# 参数化小波下采样模块（Parametric Wavelet Downsampling, PWD）
# 核心设计：融合小波变换（WT）的频域特征提取与参数化卷积的可学习能力，
# 通过“小波频域分解+卷积下采样+通道注意力”的协同流程，在实现2倍下采样的同时，
# 保留多尺度频域信息，提升下采样特征的丰富度与辨识度

import torch
import torch.nn as nn
import torch.nn.functional as F
import pywt
import pywt.data


def create_wavelet_filter(wave, in_size, out_size, type=torch.float):
    """
    生成小波分解（dec）与逆分解（rec）滤波器
    Args:
        wave: 小波类型（如'db1'、'haar'）
        in_size: 输入通道数（用于分解滤波器）
        out_size: 输出通道数（用于逆分解滤波器）
        type: 数据类型（默认torch.float）
    Returns:
        dec_filters: 分解滤波器，shape=[4, in_size, k, k]（4对应LL/LH/HL/HH四个频域分量）
        rec_filters: 逆分解滤波器，shape=[4, out_size, k, k]
    """
    w = pywt.Wavelet(wave)
    dec_hi = torch.tensor(w.dec_hi[::-1], dtype=type)
    dec_lo = torch.tensor(w.dec_lo[::-1], dtype=type)
    dec_filters = torch.stack([dec_lo.unsqueeze(0) * dec_lo.unsqueeze(1),
                               dec_lo.unsqueeze(0) * dec_hi.unsqueeze(1),
                               dec_hi.unsqueeze(0) * dec_lo.unsqueeze(1),
                               dec_hi.unsqueeze(0) * dec_hi.unsqueeze(1)], dim=0)

    dec_filters = dec_filters[:, None].repeat(in_size, 1, 1, 1)

    rec_hi = torch.tensor(w.rec_hi[::-1], dtype=type).flip(dims=[0])
    rec_lo = torch.tensor(w.rec_lo[::-1], dtype=type).flip(dims=[0])
    rec_filters = torch.stack([rec_lo.unsqueeze(0) * rec_lo.unsqueeze(1),
                               rec_lo.unsqueeze(0) * rec_hi.unsqueeze(1),
                               rec_hi.unsqueeze(0) * rec_lo.unsqueeze(1),
                               rec_hi.unsqueeze(0) * rec_hi.unsqueeze(1)], dim=0)

    rec_filters = rec_filters[:, None].repeat(out_size, 1, 1, 1)

    return dec_filters, rec_filters


def wavelet_transform(x, filters):
    """
    小波分解：将输入特征分解为4个频域分量（LL/LH/HL/HH）
    Args:
        x: 输入特征，shape=[b, c, h, w]
        filters: 分解滤波器，shape=[4, c, k, k]
    Returns:
        分解后的特征，shape=[b, c, 4, h//2, w//2]（4对应4个频域分量）
    """
    b, c, h, w = x.shape
    pad = (filters.shape[2] // 2 - 1, filters.shape[3] // 2 - 1)
    x = F.conv2d(x, filters, stride=2, groups=c, padding=pad)
    x = x.reshape(b, c, 4, h // 2, w // 2)
    return x


def inverse_wavelet_transform(x, filters):
    """
    小波逆分解：将4个频域分量重构为原始尺寸特征
    Args:
        x: 分解特征，shape=[b, c×4, h//2, w//2]
        filters: 逆分解滤波器，shape=[4, c, k, k]
    Returns:
        重构特征，shape=[b, c, h, w]
    """
    b, c, _, _ = x.shape
    pad = (filters.shape[2] // 2 - 1, filters.shape[3] // 2 - 1)
    # x = x.reshape(b, c * 4, h_half, w_half)
    x = F.conv_transpose2d(x, filters, stride=2, groups=c // 4, padding=pad)
    return x


class _ScaleModule(nn.Module):
    """
    尺度调节模块：可学习的特征缩放，用于平衡小波分解与卷积下采样的特征强度
    核心设计：单参数权重，轻量化调节，避免特征失衡
    """
    def __init__(self, dims, init_scale=1.0, init_bias=0):
        super(_ScaleModule, self).__init__()
        self.dims = dims
        self.weight = nn.Parameter(torch.ones(*dims) * init_scale, requires_grad=True)
        self.bias = None

    def forward(self, x):
        return torch.mul(self.weight, x)


class ChannelAttention(nn.Module):
    """
    通道注意力模块（CA）：筛选关键通道特征，强化有用信息
    核心设计：平均池化+最大池化双路径，捕捉更全面的通道依赖
    """
    def __init__(self, in_planes, ratio=16):
        super(ChannelAttention, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)
        self.fc1 = nn.Conv2d(in_planes, in_planes // 16, 1, bias=False)
        self.relu1 = nn.ReLU()
        self.fc2 = nn.Conv2d(in_planes // 16, in_planes, 1, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = self.fc2(self.relu1(self.fc1(self.avg_pool(x))))
        max_out = self.fc2(self.relu1(self.fc1(self.max_pool(x))))
        out = avg_out + max_out
        return self.sigmoid(out)


class PWD2d(nn.Module):  # 小波+卷积下采样核
    """
    2D参数化小波下采样模块（PWD）
    功能：融合小波频域分解与参数化卷积，实现下采样并保留多频域信息
    核心设计：
        - 双路径下采样：小波分解（频域保留）+ 分组卷积（参数学习）
        - 通道注意力引导：筛选关键频域/通道特征，提升针对性
        - 尺度平衡：可学习缩放因子平衡双路径特征强度
        - 特征压缩：1×1卷积降低通道维度，避免冗余
    """
    def __init__(self, in_channels, out_channels, wt_type='db1'):
        super(PWD2d, self).__init__()

        assert in_channels * 4 == out_channels      # 输出通道数必须是输入通道数的4倍（对应4个频域分量）

        self.in_channels = in_channels
        self.wt_filter, self.iwt_filter = create_wavelet_filter(wt_type, in_channels, in_channels, torch.float)
        self.wt_filter = nn.Parameter(self.wt_filter, requires_grad=False)

        self.para_conv = nn.Sequential(
            nn.Conv2d(in_channels, in_channels * 4, kernel_size=2, stride=2, groups=in_channels),
            nn.BatchNorm2d(in_channels * 4),
            nn.ReLU())  # 分组2*2卷积
        self.ca = ChannelAttention(out_channels)

        self.wavelet_scale = _ScaleModule([1, in_channels * 4, 1, 1], init_scale=0.1)
        self.conv1x1 = nn.Conv2d(out_channels, in_channels * 2, kernel_size=1, stride=1)
        self.bnorm = nn.BatchNorm2d(in_channels * 2)
        self.act = nn.ReLU()

    def forward(self, x):
        curr_x_ll = x

        x = self.para_conv(x)
        ca = self.ca(x)
        x = x * ca

        curr_shape = curr_x_ll.shape
        if (curr_shape[2] % 2 > 0) or (curr_shape[3] % 2 > 0):
            curr_pads = (0, curr_shape[3] % 2, 0, curr_shape[2] % 2)
            curr_x_ll = F.pad(curr_x_ll, curr_pads)

        curr_x = wavelet_transform(curr_x_ll, self.wt_filter)
        shape_x = curr_x.shape
        curr_x_wt = curr_x.reshape(shape_x[0], shape_x[1] * 4, shape_x[3], shape_x[4])

        curr_x_wt = curr_x_wt * ca
        curr_x_wt = self.wavelet_scale(curr_x_wt)

        out = x + curr_x_wt
        out = self.act(self.bnorm(self.conv1x1(out)))

        return out


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 16, 32, 32).to(device)
    model = PWD2d(16, 16*4).to(device)

    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN、小红书：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)