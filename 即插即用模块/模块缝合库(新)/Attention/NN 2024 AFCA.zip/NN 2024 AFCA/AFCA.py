# 自适应特征通道注意力模块（Adaptive Feature Channel Attention, AFCA）
# 核心设计：通过双路径通道关联建模+可学习混合机制，自适应增强关键通道特征，
# 同时抑制冗余信息，兼顾通道交互的灵活性与计算效率

import math
import torch
from torch import nn


class Mix(nn.Module):
    """
    可学习双特征混合模块
    功能：通过可学习参数生成混合因子，对两个输入特征进行自适应加权融合
    核心设计：
        - 单参数轻量化设计，仅需学习一个混合系数
        - Sigmoid激活函数将参数映射到[0,1]区间，确保混合因子的合理性
        - 支持广播机制，适配不同维度特征的融合
    """
    def __init__(self, m=-0.80):
        super(Mix, self).__init__()
        # 初始化可学习混合参数（默认值-0.8，经Sigmoid后约0.31，初始偏向fea2）
        self.w = torch.nn.Parameter(torch.FloatTensor([m]), requires_grad=True)
        self.mix_block = nn.Sigmoid()  # 将参数映射到[0,1]区间

    def forward(self, fea1, fea2):
        """
        前向传播：自适应加权融合两个特征
        Args:
            fea1: 第一个输入特征（任意维度，需与fea2形状一致）
            fea2: 第二个输入特征（与fea1形状一致）
        Returns:
            out: 融合后的特征（与输入形状一致）
        """
        mix_factor = self.mix_block(self.w)  # 生成混合因子（ scalar ）
        # 广播混合因子并加权融合：fea1*mix_factor + fea2*(1-mix_factor)
        out = fea1 * mix_factor.expand_as(fea1) + fea2 * (1 - mix_factor.expand_as(fea2))
        return out


class AFCA(nn.Module):
    """
    自适应特征通道注意力模块（AFCA）
    功能：通过全局特征统计、双路径通道关联建模、自适应混合，生成通道注意力权重
    核心设计：
        - 全局平均池化（GAP）：聚合空间维度信息，得到通道级全局特征
        - 双路径通道关联：1D卷积路径（捕捉局部通道依赖）+ 1×1卷积路径（捕捉全局通道映射）
        - 矩阵乘法建模交互：通过通道特征的矩阵运算，强化通道间非线性关联
        - 可学习混合与二次优化：Mix模块融合双路径输出，再经1D卷积优化权重平滑性
    """

    def __init__(self, channel, b=1, gamma=2):
        super(AFCA, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)  # 全局平均池化：[b,c,h,w]→[b,c,1,1]

        # 1D卷积核大小自适应计算（基于通道数动态调整）
        t = int(abs((math.log(channel, 2) + b) / gamma))  # 基础核大小
        k = t if t % 2 else t + 1  # 确保核大小为奇数（方便padding保持维度）

        # 双路径通道特征提取
        self.conv1 = nn.Conv1d(1, 1, kernel_size=k, padding=int(k / 2), bias=False)  # 局部通道依赖路径
        self.fc = nn.Conv2d(channel, channel, 1, padding=0, bias=True)  # 全局通道映射路径

        self.sigmoid = nn.Sigmoid()  # 注意力权重归一化（映射到[0,1]）
        self.mix = Mix()  # 双路径输出融合模块

    def forward(self, input):
        """
        前向传播：AFCA完整注意力流程
        Args:
            input: 输入特征，shape=[b, c, h, w]（b=批量，c=通道，h=高度，w=宽度）
        Returns:
            注意力加权后的特征，shape=[b, c, h, w]（与输入维度一致）
        """
        # 1. 全局特征聚合：全局平均池化（GAP）压缩空间维度
        x = self.avg_pool(input)  # [b, c, h, w] → [b, c, 1, 1]

        # 2. 路径1：1D卷积建模局部通道依赖
        # 维度调整：[b, c, 1, 1] → [b, 1, c]（适配1D卷积输入格式）
        x1 = x.squeeze(-1).transpose(-1, -2)  # squeeze(-1)移除最后一维→[b,c,1]，transpose交换后两维→[b,1,c]
        x1 = self.conv1(x1)  # 1D卷积捕捉局部通道关联→[b,1,c]
        x1 = x1.transpose(-1, -2)  # 恢复维度→[b,c,1]

        # 3. 路径2：1×1卷积建模全局通道映射
        x2 = self.fc(x)  # 1×1卷积实现通道间全连接映射→[b,c,1,1]
        x2 = x2.squeeze(-1).transpose(-1, -2)  # 维度调整→[b,1,c]

        # 4. 双路径通道交互：矩阵乘法+求和，强化通道关联
        # 路径1输出 [b,c,1] × 路径2输出 [b,1,c] → [b,c,c]（通道交互矩阵），求和后→[b,c,1]
        out1 = torch.matmul(x1, x2)  # 矩阵乘法：建模通道间两两交互→[b,c,c]
        out1 = torch.sum(out1, dim=1).unsqueeze(-1).unsqueeze(-1)  # 求和压缩→[b,c,1,1]（适配输入维度）
        out1 = self.sigmoid(out1)  # 归一化得到注意力权重1→[b,c,1,1]

        # 5. 反向通道交互：交换路径2维度后重复上述过程，捕捉双向关联
        x2_t = x2.transpose(-1, -2)  # [b,1,c] → [b,c,1]
        x1_t = x1.transpose(-1, -2)  # [b,c,1] → [b,1,c]
        out2 = torch.matmul(x2_t, x1_t)  # 反向矩阵乘法→[b,c,c]
        out2 = torch.sum(out2, dim=1).unsqueeze(-1).unsqueeze(-1)  # 求和压缩→[b,c,1,1]
        out2 = self.sigmoid(out2)  # 归一化得到注意力权重2→[b,c,1,1]

        # 6. 自适应混合双路径权重：通过Mix模块学习最优融合比例
        out = self.mix(out1, out2)  # [b,c,1,1] → [b,c,1,1]

        # 7. 权重平滑优化：1D卷积进一步调整权重，提升泛化性
        out = out.squeeze(-1).transpose(-1, -2)  # 维度调整→[b,1,c]
        out = self.conv1(out)  # 1D卷积平滑权重→[b,1,c]
        out = out.transpose(-1, -2).unsqueeze(-1)  # 恢复维度→[b,c,1,1]
        out = self.sigmoid(out)  # 最终归一化→[b,c,1,1]

        # 8. 注意力加权：输入特征 × 通道注意力权重（广播机制）
        return input * out


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 64, 32, 32).to(device)
    model = AFCA(64).to(device)

    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN、小红书：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)


