import pywt
import torch
import torch.nn as nn
import torch.nn.functional as F

class MultiScaleWaveletNet(nn.Module):
    """
    多尺度小波变换网络 对应结构图(b)中的【Multi-Channel Wavelet】模块
    核心功能：对输入特征做多尺度Haar小波分解，得到LL(低频结构)、LH(水平细节)、HL(垂直细节)、HH(对角细节)四个频带分量，实现结构-纹理的频域解耦
    """
    def __init__(self, in_channels: int, out_channels: int, levels: int = 3) -> None:
        super().__init__()
        self.levels = levels  # 小波分解的尺度数，实现多尺度频域建模
        self.in_channels = in_channels  # 输入图像/特征的通道数
        self.wavelet_channels = in_channels * 4  # 单通道小波分解后输出4个频带，通道数×4
        self.out_channels_per_level = out_channels // levels  # 每个分解尺度的输出通道数
        # 每个尺度的小波特征卷积融合层，对应结构图中的频带特征处理
        self.wavelet_convs = nn.ModuleList(
            [
                nn.Sequential(
                    nn.Conv2d(self.wavelet_channels, self.out_channels_per_level, 3, 1, 1),
                    nn.InstanceNorm2d(self.out_channels_per_level),
                    nn.PReLU(),
                )
                for _ in range(levels)
            ]
        )
        # 多尺度小波特征融合层，对应结构图中的【FreqFusion】模块
        self.fusion = nn.Sequential(
            nn.Conv2d(self.out_channels_per_level * levels, out_channels, 1, 1, 0),
            nn.InstanceNorm2d(out_channels),
            nn.PReLU(),
        )

    def wavelet_transform(self, x: torch.Tensor) -> torch.Tensor:
        """单通道2D Haar小波变换，输出LL/LH/HL/HH四个频带分量"""
        device = x.device
        coeffs = []
        # 逐样本做小波分解，适配批量输入
        for batch_index in range(x.shape[0]):
            image = x[batch_index, 0].detach().cpu().numpy()
            # Haar小波一级分解，得到低频近似LL + 三个高频细节分量
            ll, (lh, hl, hh) = pywt.dwt2(image, "haar")
            bands = []
            # 四个频带分量分别处理，上采样到与输入相同尺寸
            for band in (ll, lh, hl, hh):
                band_tensor = torch.from_numpy(band).float().unsqueeze(0).unsqueeze(0)
                if band_tensor.shape[2:] != x.shape[2:]:
                    band_tensor = F.interpolate(
                        band_tensor,
                        size=x.shape[2:],
                        mode="bilinear",
                        align_corners=False,
                    )
                bands.append(band_tensor)
            # 四个频带在通道维度拼接
            coeffs.append(torch.cat(bands, dim=1))
        return torch.cat(coeffs, dim=0).to(device)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        multi_scale_features = []
        current_x = x
        # 层级化多尺度小波分解
        for level, wavelet_conv in enumerate(self.wavelet_convs):
            wavelet_features = []
            # 逐通道做小波分解，适配多通道输入
            for channel_index in range(self.in_channels):
                coeffs = self.wavelet_transform(current_x[:, channel_index : channel_index + 1])
                wavelet_features.append(coeffs)
            # 所有通道的小波分量拼接
            wavelet_tensor = torch.cat(wavelet_features, dim=1)
            # 单尺度小波特征卷积处理
            features = wavelet_conv(wavelet_tensor)
            # 多尺度特征对齐到输入尺寸
            if level > 0:
                features = F.interpolate(
                    features,
                    size=x.shape[2:],
                    mode="bilinear",
                    align_corners=False,
                )
            multi_scale_features.append(features)
            # 下采样，进入下一个更粗的分解尺度
            if level < self.levels - 1:
                current_x = F.avg_pool2d(current_x, 2)
        # 多尺度小波特征融合，输出最终频域特征
        return self.fusion(torch.cat(multi_scale_features, dim=1))


class FrequencyAttention(nn.Module):
    """
    频率感知注意力模块 对应结构图(b)中的【FreqAttention】模块
    核心功能：通过全局平均/最大池化，自适应学习不同频带的重要性权重，强化结构/纹理相关的关键频带，抑制无效噪声
    """
    def __init__(self, channels: int) -> None:
        super().__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)  # 全局平均池化，捕捉频带的全局统计特性
        self.max_pool = nn.AdaptiveMaxPool2d(1)  # 全局最大池化，捕捉频带的显著特征
        # 通道压缩-还原分支，生成频带注意力权重
        self.fc = nn.Sequential(
            nn.Conv2d(channels * 4, channels, 1, bias=False),
            nn.ReLU(inplace=True),
            nn.Conv2d(channels, channels * 4, 1, bias=False),
            nn.Sigmoid(),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # 双池化分支分别生成权重，相加融合
        attention = self.fc(self.avg_pool(x)) + self.fc(self.max_pool(x))
        # 频带特征加权增强
        return x * attention


class FrequencyStructuralDecoupling(nn.Module):
    """
    FSD: Frequency-aware Structural Decoupling 频率感知结构解耦模块
    完整对应结构图(b)全流程，是DTP框架【Decoupling Stage】的核心模块
    核心功能：通过多尺度小波变换+频率注意力，将输入低质图像解耦为「亮度结构分量(低频I_llr)」和「纹理细节分量(高频T_llr)」
    """
    def __init__(self, features: int = 64) -> None:
        super().__init__()
        # 多尺度小波变换网络，实现频域分解
        self.wavelet_net = MultiScaleWaveletNet(3, features)
        # 频率感知注意力，自适应增强关键频带
        self.frequency_attention = FrequencyAttention(features // 4)
        # 频域特征提取层，强化解耦后的特征表达
        self.feature_extraction = nn.Sequential(
            nn.Conv2d(features, features, 3, 1, 1),
            nn.BatchNorm2d(features),
            nn.PReLU(),
            nn.Conv2d(features, features, 3, 1, 1),
            nn.BatchNorm2d(features),
            nn.PReLU(),
        )
        # 结构-纹理分离器 对应结构图(b)中的【Separator】模块，输出解耦后的亮度和纹理分量
        self.separator = nn.Sequential(
            nn.Conv2d(features, 6, 3, 1, 1),
            nn.BatchNorm2d(6),
            nn.Sigmoid(),
        )

    def forward(self, x: torch.Tensor):
        # 步骤1：多尺度小波变换，得到频域分解特征
        wavelet_features = self.wavelet_net(x)
        # 步骤2：频率注意力加权，增强关键频带
        attended_features = self.frequency_attention(wavelet_features)
        # 步骤3：特征提取强化，提升解耦特征的表达能力
        enhanced_features = self.feature_extraction(attended_features)

        # 非LLIE任务只要增强特征即可
        # 步骤4：分离器解耦，输出亮度结构分量I_llr和纹理细节分量T_llr
        separated = self.separator(enhanced_features)
        texture_llr = torch.stack([separated[:, index, :, :] for index in range(3)], dim=1)  # 前3通道为纹理分量
        luminance_llr = torch.stack([separated[:, index, :, :] for index in range(3, 6)], dim=1)  # 后3通道为亮度分量
        return luminance_llr, texture_llr, enhanced_features


# 模块测试代码
if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    x = torch.randn(1, 3, 256, 256).to(device)  # FSD模块输入为3通道RGB图像
    model = FrequencyStructuralDecoupling(64).to(device)
    luminance, texture, feat = model(x)
    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("小红书：十小大，主页获取往期全部即插即用代码，200+大合集")
    print("输入图像维度：", x.shape)
    print("解耦亮度结构分量维度：", luminance.shape)
    print("解耦纹理细节分量维度：", texture.shape)
    print("增强特征维度：", feat.shape)