import torch
import torch.nn as nn
from typing import Optional, Callable, Union, Tuple, Any
import torch
from torch import nn, Tensor
import numpy as np
from typing import Optional
import math
from torch import nn

# -------------------------- 工具函数 --------------------------
def makeDivisible(v: float, divisor: int, min_value: Optional[int] = None) -> int:
    """通道数对齐工具，保证输出通道数为divisor的整数倍，适配硬件部署"""
    if min_value is None:
        min_value = divisor
    new_v = max(min_value, int(v + divisor / 2) // divisor * divisor)
    if new_v < 0.9 * v:
        new_v += divisor
    return new_v

def callMethod(self, ElementName):
    """动态获取模块属性，适配多尺度池化层的动态调用"""
    return getattr(self, ElementName)

def setMethod(self, ElementName, ElementValue):
    """动态设置模块属性，批量生成不同尺度的池化层"""
    return setattr(self, ElementName, ElementValue)

def shuffleTensor(Feature: Tensor, Mode: int=1) -> Tensor:
    """特征随机打乱函数，训练时做数据增强，提升注意力模块的泛化性"""
    if isinstance(Feature, Tensor):
        Feature = [Feature]
    Indexs = None
    Output = []
    for f in Feature:
        B, C, H, W = f.shape
        if Mode == 1:
            f = f.flatten(2)
            if Indexs is None:
                Indexs = torch.randperm(f.shape[-1], device=f.device)
            f = f[:, :, Indexs.to(f.device)]
            f = f.reshape(B, C, H, W)
        else:
            if Indexs is None:
                Indexs = [torch.randperm(H, device=f.device),
                          torch.randperm(W, device=f.device)]
            f = f[:, :, Indexs[0].to(f.device)]
            f = f[:, :, :, Indexs[1].to(f.device)]
        Output.append(f)
    return Output

# -------------------------- 基础算子封装 --------------------------
class AdaptiveAvgPool2d(nn.AdaptiveAvgPool2d):
    """自适应平均池化封装，添加参数量统计接口，适配部署"""
    def __init__(self, output_size: int or tuple=1):
        super(AdaptiveAvgPool2d, self).__init__(output_size=output_size)
    def profileModule(self, Input: Tensor):
        Output = self.forward(Input)
        return Output, 0.0, 0.0

class AdaptiveMaxPool2d(nn.AdaptiveMaxPool2d):
    """自适应最大池化封装，添加参数量统计接口，适配部署"""
    def __init__(self, output_size: int or tuple=1):
        super(AdaptiveMaxPool2d, self).__init__(output_size=output_size)
    def profileModule(self, Input: Tensor):
        Output = self.forward(Input)
        return Output, 0.0, 0.0

class BaseConv2d(nn.Module):
    """基础卷积封装，集成BN、激活函数、权重初始化，简化模块搭建"""
    def __init__(
            self,
            in_channels: int,
            out_channels: int,
            kernel_size: int,
            stride: Optional[int] = 1,
            padding: Optional[int] = None,
            groups: Optional[int] = 1,
            bias: Optional[bool] = None,
            BNorm: bool = False,
            ActLayer: Optional[Callable[..., nn.Module]] = None,
            dilation: int = 1,
            Momentum: Optional[float] = 0.1,
            **kwargs: Any
    ) -> None:
        super(BaseConv2d, self).__init__()
        if padding is None:
            padding = int((kernel_size - 1) // 2 * dilation)
        if bias is None:
            bias = not BNorm
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.kernel_size = kernel_size
        self.stride = stride
        self.padding = padding
        self.groups = groups
        self.bias = bias
        self.Conv = nn.Conv2d(in_channels, out_channels,
                              kernel_size, stride, padding, dilation, groups, bias, **kwargs)
        self.Bn = nn.BatchNorm2d(out_channels, eps=0.001, momentum=Momentum) if BNorm else nn.Identity()
        if ActLayer is not None:
            if isinstance(list(ActLayer().named_modules())[0][1], nn.Sigmoid):
                self.Act = ActLayer()
            else:
                self.Act = ActLayer(inplace=True)
        else:
            self.Act = ActLayer
        self.apply(initWeight)
    def forward(self, x: Tensor) -> Tensor:
        x = self.Conv(x)
        x = self.Bn(x)
        if self.Act is not None:
            x = self.Act(x)
        return x

NormLayerTuple = (
    nn.BatchNorm1d,
    nn.BatchNorm2d,
    nn.SyncBatchNorm,
    nn.LayerNorm,
    nn.InstanceNorm1d,
    nn.InstanceNorm2d,
    nn.GroupNorm,
    nn.BatchNorm3d,
)

def initWeight(Module):
    """通用权重初始化函数，适配卷积、归一化、全连接层，保证训练初始稳定性"""
    if Module is None:
        return
    elif isinstance(Module, (nn.Conv2d, nn.Conv3d, nn.ConvTranspose2d)):
        nn.init.kaiming_uniform_(Module.weight, a=math.sqrt(5))
        if Module.bias is not None:
            fan_in, _ = nn.init._calculate_fan_in_and_fan_out(Module.weight)
            if fan_in != 0:
                bound = 1 / math.sqrt(fan_in)
                nn.init.uniform_(Module.bias, -bound, bound)
    elif isinstance(Module, NormLayerTuple):
        if Module.weight is not None:
            nn.init.ones_(Module.weight)
        if Module.bias is not None:
            nn.init.zeros_(Module.bias)
    elif isinstance(Module, nn.Linear):
        nn.init.kaiming_uniform_(Module.weight, a=math.sqrt(5))
        if Module.bias is not None:
            fan_in, _ = nn.init._calculate_fan_in_and_fan_out(Module.weight)
            bound = 1 / math.sqrt(fan_in) if fan_in > 0 else 0
            nn.init.uniform_(Module.bias, -bound, bound)
    elif isinstance(Module, (nn.Sequential, nn.ModuleList)):
        for m in Module:
            initWeight(m)
    elif list(Module.children()):
        for m in Module.children():
            initWeight(m)

# -------------------------- 核心注意力模块（对应结构图MCA分支） --------------------------
class Attention(nn.Module):
    """
    多尺度隐语义感知通道注意力（MCA） 对应结构图右侧完整流程
    核心功能：训练时随机选择不同池化尺度+特征打乱增强，推理时用全局池化，自适应生成多尺度语义注意力权重
    对应结构图：Random Choice(RC)、Pooling1/2/3、Conv1x1、Selective Emphasis Map生成
    """
    def __init__(
            self,
            InChannels: int,
            HidChannels: int = None,
            SqueezeFactor: int = 4,
            PoolRes: list = [1, 2, 3],
            Act: Callable[..., nn.Module] = nn.ReLU,
            ScaleAct: Callable[..., nn.Module] = nn.Sigmoid,
            MoCOrder: bool = True,
            **kwargs: Any,
    ) -> None:
        super().__init__()
        # 隐藏层通道数自动对齐
        if HidChannels is None:
            HidChannels = max(makeDivisible(InChannels // SqueezeFactor, 8), 32)
        # 生成多尺度池化层，对应Pooling1/2/3
        AllPoolRes = PoolRes + [1] if 1 not in PoolRes else PoolRes
        for k in AllPoolRes:
            Pooling = AdaptiveAvgPool2d(k)
            setMethod(self, 'Pool%d' % k, Pooling)
        # SE通道变换分支，对应Conv1x1生成Emphasis Map
        self.SELayer = nn.Sequential(
            BaseConv2d(InChannels, HidChannels, 1, ActLayer=Act),
            BaseConv2d(HidChannels, InChannels, 1, ActLayer=ScaleAct),
        )
        self.PoolRes = PoolRes
        self.MoCOrder = MoCOrder

    def RandomSample(self, x: Tensor) -> Tensor:
        """随机尺度池化采样，对应结构图Random Choice(RC)，训练时增强泛化性"""
        if self.training:
            # 训练时随机选择池化尺度
            PoolKeep = np.random.choice(self.PoolRes)
            # 特征随机打乱，提升鲁棒性
            x1 = shuffleTensor(x)[0] if self.MoCOrder else x
            # 对应Pooling1/2/3
            AttnMap: Tensor = callMethod(self, 'Pool%d' % PoolKeep)(x1)
            # 多尺度池化结果压缩为1x1通道特征
            if AttnMap.shape[-1] > 1:
                AttnMap = AttnMap.flatten(2)
                AttnMap = AttnMap[:, :, torch.randperm(AttnMap.shape[-1])[0]]
                AttnMap = AttnMap[:, :, None, None]
        else:
            # 推理时固定用全局1x1池化，保证结果稳定
            AttnMap: Tensor = callMethod(self, 'Pool%d' % 1)(x)
        return AttnMap

    def forward(self, x: Tensor) -> Tensor:
        # 生成多尺度注意力权重
        AttnMap = self.RandomSample(x)
        # 特征加权，对应结构图元素相乘
        return x * self.SELayer(AttnMap)

def channel_shuffle(x, groups):
    """通道混洗操作 对应结构图Shuffle模块，实现跨分支信息交互，消除特征冗余"""
    batchsize, num_channels, height, width = x.data.size()
    channels_per_group = num_channels // groups
    x = x.view(batchsize, groups, channels_per_group, height, width)
    x = torch.transpose(x, 1, 2).contiguous()
    x = x.view(batchsize, -1, height, width)
    return x

# -------------------------- LaSEA主模块 --------------------------
class LaSEA(nn.Module):
    """
    LaSEA (Latent-aware Semantic Extraction and Aggregation) 隐语义感知特征提取与聚合模块
    完整对应结构图全流程：多尺度膨胀卷积提取→特征拼接→通道混洗→1x1融合→MCA注意力加权→残差输出
    核心功能：多尺度感受野提取隐语义特征，自适应强化关键语义信息，解决传统卷积感受野受限、多尺度特征融合冗余问题
    """
    def __init__(self, in_channels):
        super(LaSEA, self).__init__()
        self.in_channels = in_channels
        self.out_channels = in_channels

        # 多尺度并行膨胀卷积分支 对应结构图左侧4个dilation卷积分支，提取不同感受野的语义特征
        self.conv_1 = nn.Sequential(
            nn.Conv2d(in_channels, in_channels, padding=1, kernel_size=3, dilation=1),
            nn.BatchNorm2d(in_channels),
            nn.ReLU(inplace=True)
        )
        self.conv_2 = nn.Sequential(
            nn.Conv2d(in_channels, in_channels, padding=2, kernel_size=3, dilation=2),
            nn.BatchNorm2d(in_channels),
            nn.ReLU(inplace=True)
        )
        self.conv_3 = nn.Sequential(
            nn.Conv2d(in_channels, in_channels, padding=3, kernel_size=3, dilation=3),
            nn.BatchNorm2d(in_channels),
            nn.ReLU(inplace=True)
        )
        self.conv_4 = nn.Sequential(
            nn.Conv2d(in_channels, in_channels, padding=4, kernel_size=3, dilation=4),
            nn.BatchNorm2d(in_channels),
            nn.ReLU(inplace=True)
        )

        # 多尺度特征融合 对应结构图Conv1x1融合模块
        self.fuse = nn.Sequential(
            nn.Conv2d(in_channels * 4, in_channels, kernel_size=1, padding=0),
            nn.BatchNorm2d(in_channels),
            nn.ReLU(inplace=True)
        )

        # 多尺度隐语义注意力MCA 对应结构图右侧注意力分支
        self.mca = Attention(InChannels=in_channels, HidChannels=16)

    def forward(self, x):
        # 残差分支，对应结构图Input输入
        d = x
        # 步骤1：多尺度膨胀卷积并行提取不同感受野的语义特征
        c1 = self.conv_1(x)
        c2 = self.conv_2(x)
        c3 = self.conv_3(x)
        c4 = self.conv_4(x)
        # 步骤2：多分支特征拼接 对应结构图Concatenate(C)
        cat = torch.cat([c1, c2, c3, c4], dim=1)
        # 步骤3：通道混洗，跨分支信息交互 对应结构图Shuffle
        cat = channel_shuffle(cat, groups=4)
        # 步骤4：1x1卷积融合多尺度特征，压缩通道数
        M = self.fuse(cat)
        # 步骤5：MCA隐语义注意力加权，强化关键语义特征
        O = self.mca(M)
        # 步骤6：残差连接输出 对应结构图Input+加权特征输出
        return O + d

# 模块测试代码
if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    x = torch.randn(1, 64, 32, 32).to(device)
    model = LaSEA(64).to(device)
    y = model(x)
    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("小红书：十小大，主页获取往期全部即插即用代码，200+大合集")
    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)