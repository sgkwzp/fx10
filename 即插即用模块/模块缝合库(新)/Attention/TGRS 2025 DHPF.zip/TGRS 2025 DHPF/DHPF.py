# 动态高通滤波器模块（Dynamic High-Pass Filter, DHPF）
# 核心设计：基于频域能量统计自适应生成滤波掩码，通过“FFT频域转换→动态低频抑制→iFFT时域恢复”的流程，
# 自适应保留图像高频细节（如边缘、纹理），抑制低频冗余，提升特征的细节辨识度与表达能力

import torch
import torch.nn as nn


class DHPF(nn.Module):
    """
    动态高通滤波器模块（Dynamic High-Pass Filter, DHPF）
    功能：根据输入特征的频域能量分布，自适应确定低频截止频率，抑制低频成分，强化高频细节
    核心设计：
        - 能量驱动动态滤波：基于目标能量占比自动计算截止频率，而非固定阈值，适配不同输入特征
        - 频域精准抑制：在频域中心区域（低频集中区）设置掩码，直接归零低频成分，滤波效果更精准
        - 批次独立处理：对每个批次样本单独计算截止频率，适配批量数据中不同特征的频域分布
        - 无参数可学习：纯频域变换与能量统计操作，轻量化且泛化性强
    Args:
        energy: 目标低频能量占比（0~1），用于确定截止频率，值越大，截止频率越高，抑制的低频范围越广
    """

    def __init__(self, energy):
        super(DHPF, self).__init__()
        self.energy = energy  # 目标低频能量占比（例：0.8表示保留80%能量对应的低频区域并抑制）

    def _determine_cutoff_frequency(self, f_transform, target_ratio):
        """
        动态确定低频截止频率：找到满足“低频能量≥总能量×目标占比”的最小截止频率
        Args:
            f_transform: 单通道频域特征（fftshift后），shape=[H, W]
            target_ratio: 目标低频能量占比（self.energy）
        Returns:
            cutoff_frequency: 低频截止频率（像素单位）
        """
        total_energy = self._calculate_total_energy(f_transform)  # 计算频域总能量
        target_low_freq_energy = total_energy * target_ratio  # 目标低频能量

        # 遍历可能的截止频率（从1到图像半宽/半高的最小值）
        max_possible_cutoff = min(f_transform.shape[0], f_transform.shape[1]) // 2
        for cutoff_frequency in range(1, max_possible_cutoff):
            low_freq_energy = self._calculate_low_freq_energy(f_transform, cutoff_frequency)
            if low_freq_energy >= target_low_freq_energy:
                return cutoff_frequency  # 找到满足条件的最小截止频率
        return 5  # 默认截止频率（防止极端情况）

    def _calculate_total_energy(self, f_transform):
        """计算频域特征的总能量（幅度谱的平方和）"""
        magnitude_spectrum = torch.abs(f_transform)  # 频域幅度谱
        total_energy = torch.sum(magnitude_spectrum ** 2)  # 能量=幅度平方和
        return total_energy

    def _calculate_low_freq_energy(self, f_transform, cutoff_frequency):
        """计算截止频率内的低频能量（频域中心区域）"""
        magnitude_spectrum = torch.abs(f_transform)
        height, width = magnitude_spectrum.shape
        # 频域中心区域（低频集中区）：[H//2-cutoff : H//2+cutoff, W//2-cutoff : W//2+cutoff]
        low_freq_region = magnitude_spectrum[
                          height // 2 - cutoff_frequency:height // 2 + cutoff_frequency,
                          width // 2 - cutoff_frequency:width // 2 + cutoff_frequency
                          ]
        low_freq_energy = torch.sum(low_freq_region ** 2)  # 低频区域能量
        return low_freq_energy

    def forward(self, x):
        """
        前向传播：时域→频域→动态低频抑制→频域→时域
        Args:
            x: 输入特征，shape=[B, C, H, W]（批次、通道、高度、宽度）
        Returns:
            高频增强特征，shape=[B, C, H, W]（与输入维度完全一致）
        """
        B, C, H, W = x.shape

        # 1. 时域→频域转换（2D FFT）
        f = torch.fft.fft2(x)  # 快速傅里叶变换：[B, C, H, W]（复数张量）
        fshift = torch.fft.fftshift(f)  # 频域移位：将低频成分移至图像中心

        # 2. 确定频域中心坐标
        crow, ccol = H // 2, W // 2

        # 3. 逐批次动态生成掩码并抑制低频
        for i in range(B):
            # 基于第一通道的频域能量确定截止频率（所有通道共享同一截止频率，保证一致性）
            cutoff_frequency = self._determine_cutoff_frequency(fshift[i, 0], self.energy)
            # 低频区域归零（高通滤波核心：抑制中心低频成分）
            fshift[i, :,  # 所有通道
            crow - cutoff_frequency:crow + cutoff_frequency,  # 高度方向低频范围
            ccol - cutoff_frequency:ccol + cutoff_frequency  # 宽度方向低频范围
            ] = 0  # 低频成分归零

        # 4. 频域→时域恢复（逆FFT）
        ishift = torch.fft.ifftshift(fshift)  # 逆频域移位
        ideal_high_pass = torch.abs(torch.fft.ifft2(ishift))  # 逆FFT+取绝对值（恢复实数特征）

        return ideal_high_pass


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 64, 32, 32).to(device)
    model = DHPF(0.8).to(device)

    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN、小红书：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)