import torch
import torch.nn as nn
import torch.nn.functional as F


class ConvBN(nn.Sequential):
    def __init__(self, in_channels, out_channels, kernel_size=3, dilation=1, stride=1, norm_layer=nn.BatchNorm2d, bias=False):
        super(ConvBN, self).__init__(
            nn.Conv2d(in_channels, out_channels, kernel_size=kernel_size, bias=bias,
                      dilation=dilation, stride=stride, padding=((stride - 1) + dilation * (kernel_size - 1)) // 2),
            norm_layer(out_channels)
        )


class Conv(nn.Sequential):
    def __init__(self, in_channels, out_channels, kernel_size=3, dilation=1, stride=1, bias=False):
        super(Conv, self).__init__(
            nn.Conv2d(in_channels, out_channels, kernel_size=kernel_size, bias=bias,
                      dilation=dilation, stride=stride, padding=((stride - 1) + dilation * (kernel_size - 1)) // 2)
        )


class SpatialAttention(nn.Module):
    def __init__(self, kernel_size=7):
        super(SpatialAttention, self).__init__()

        assert kernel_size in (3, 7), 'kernel size must be 3 or 7'
        padding = 3 if kernel_size == 7 else 1

        self.conv1 = nn.Conv2d(2, 1, kernel_size, padding=padding, bias=False)

        self.relu1 = nn.ReLU(inplace=True)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        residual = x.clone()
        avg_out = torch.mean(x, dim=1, keepdim=True)

        max_out, _ = torch.max(x, dim=1, keepdim=True)

        out = torch.cat([avg_out, max_out], dim=1)
        out1 = self.conv1(out)

        out2 = self.relu1(out1)

        out = self.sigmoid(out2)

        y = x * out.view(out.size(0), 1, out.size(-2), out.size(-1))
        return y


class depthwise_separable_conv(nn.Module):
    def __init__(self, nin, nout,dilation):

        super(depthwise_separable_conv, self).__init__()

        self.depthwise = nn.Conv2d(nin, nin, kernel_size=3, dilation=dilation,padding=(( dilation * 2) // 2), groups=nin)
        self.pointwise = nn.Conv2d(nin, nout, kernel_size=1)


    def forward(self, x):
        out = self.depthwise(x)
        out = self.pointwise(out)
        return out

class _DenseASPPConv(nn.Sequential):
    def __init__(self, in_channels, inter_channels, out_channels, atrous_rate,
                 drop_rate=0.1, norm_layer=nn.BatchNorm2d, norm_kwargs=None):
        super(_DenseASPPConv, self).__init__()
        self.add_module('conv1', nn.Conv2d(in_channels, inter_channels, 1)),
        self.add_module('bn1', norm_layer(inter_channels, **({} if norm_kwargs is None else norm_kwargs))),
        self.add_module('relu1', nn.ReLU(True)),
        self.add_module('conv2', depthwise_separable_conv(nin=inter_channels,nout=out_channels,dilation=atrous_rate)),
        self.add_module('bn2', norm_layer(out_channels, **({} if norm_kwargs is None else norm_kwargs))),
        self.add_module('relu2', nn.ReLU(True)),
        self.drop_rate = drop_rate

    def forward(self, x):
        features = super(_DenseASPPConv, self).forward(x)
        if self.drop_rate > 0:
            features = F.dropout(features, p=self.drop_rate, training=self.training)
        return features


class ASPPModule(nn.Module):
    """
    密集多尺度连接模块（Dense Multi-Scale Connection, DMSC）：基于ASPP的密集多尺度特征提取
    核心设计：三分支不同膨胀率卷积，密集拼接融合，捕捉多尺度上下文
    Args:
        in_channels: 输入通道数
        atrous_rates: 三个分支的膨胀率列表
    """
    def __init__(self, in_channels, atrous_rates):
        super(ASPPModule, self).__init__()
        out_channels = in_channels
        rate1, rate2, rate3 = atrous_rates

        self.b0 = _DenseASPPConv(in_channels,out_channels//2,out_channels,rate1,0.1)
        self.b1 = _DenseASPPConv(in_channels+out_channels*1,(in_channels+out_channels*1)//2,out_channels,rate2,0.1)
        self.b2 = _DenseASPPConv(in_channels+out_channels*2,(in_channels+out_channels*2)//2,out_channels,rate3,0.1)
        self.project = nn.Sequential(nn.Conv2d(in_channels+3 * out_channels, out_channels, 1, bias=False),
                                     nn.BatchNorm2d(out_channels),
                                     nn.ReLU(True))

    def forward(self, x):
        u=x.clone()
        aspp1=self.b0(x)
        x=torch.cat([aspp1,x],dim=1)

        aspp2=self.b1(x)
        x=torch.cat([aspp2,x],dim=1)

        aspp3=self.b2(x)
        x=torch.cat([aspp3,x],dim=1)
        return self.project(x)*u


class CSDF(nn.Module):
    """
    通道-空间注意力与密集多尺度特征融合模块（Channel–Spatial Attention and Dense Multiscale Fusion, CSDF）
    功能：整合多尺度提取、通道注意力、空间注意力，实现特征多维度优化
    核心设计：
        - 密集多尺度提取：ASPPModule捕捉不同尺度上下文，密集拼接提升融合质量
        - 双通道注意力：通道注意力筛选关键通道，空间注意力定位关键区域，双重优化
        - 残差与激活：多特征相加融合，ReLU6激活限制数值范围，提升稳定性
    Args:
        dim: 输入/输出通道数
        num_heads: 注意力头数（当前未使用，预留扩展）
        atten_drop: 注意力dropout概率（默认0.）
        proj_drop: 投影dropout概率（默认0.）
        dilation: 多尺度膨胀率列表（默认[3,5,7]）
        fc_ratio: 通道注意力压缩比例（默认4）
    """
    def __init__(self, dim, num_heads, atten_drop = 0., proj_drop = 0., dilation = [3, 5, 7], fc_ratio=4):
        super(CSDF, self).__init__()
        assert dim % num_heads == 0, f"dim {dim} should be divided by num_heads {num_heads}."
        self.dim = dim
        self.num_heads = num_heads
        head_dim = dim // num_heads
        self.scale = head_dim ** -0.5
        self.atten_drop = nn.Dropout(atten_drop)
        self.proj_drop = nn.Dropout(proj_drop)
        self.DMSC= ASPPModule(dim, dilation)

        self.avgpool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(
            nn.Conv2d(in_channels=dim, out_channels=dim//fc_ratio, kernel_size=1),
            nn.ReLU6(),
            nn.Conv2d(in_channels=dim//fc_ratio, out_channels=dim, kernel_size=1),
            nn.Sigmoid()
        )
        self.spat_atten=SpatialAttention()
        self.kv = Conv(dim, 2 * dim, 1)
        self.fc2 = ConvBN(in_channels=dim, out_channels=dim, kernel_size=1)
        self.act = nn.ReLU6()

    def forward(self, x):
        u = x.clone()
        # Dense multi-scale connections
        attn = self.DMSC(x)

        # Channel Attention
        c_attn = self.avgpool(x)
        c_attn = self.fc(c_attn)
        c_attn = c_attn * u

        # Spatial Attention
        s_attn=self.spat_atten(x)

        x=self.fc2(attn+c_attn+s_attn)
        x = self.act(x)

        return x


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 64, 32, 32).to(device)
    model = CSDF(64, 4).to(device)

    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN、小红书：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)