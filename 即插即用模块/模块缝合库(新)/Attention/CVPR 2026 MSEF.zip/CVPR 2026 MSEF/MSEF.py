import torch
import torch.nn as nn
import torch.nn.functional as F

# ---------- MSEF 辅助组件 -------------
class LayerNormalization(nn.Module):
    """适配CNN的层归一化：解决PyTorch原生LayerNorm默认通道最后格式的问题
    输入输出均为 (B, C, H, W) 格式，对应结构图中的 Layer Norm. 模块
    """
    def __init__(self, dim):
        super(LayerNormalization, self).__init__()
        self.norm = nn.LayerNorm(dim)

    def forward(self, x):
        # 通道优先 -> 通道最后，适配LayerNorm计算
        x = x.permute(0, 2, 3, 1)
        x = self.norm(x)
        # 通道最后 -> 通道优先，还原CNN标准格式
        return x.permute(0, 3, 1, 2)


class SEBlock(nn.Module):
    """改进版Squeeze-and-Excitation通道注意力模块
    核心改进：将原始SE的Sigmoid激活替换为Tanh，输出范围[-1,1]，支持特征增强+抑制
    对应结构图中的 GAP+ReLU+tanh 分支，输出注意力权重Z
    """
    def __init__(self, input_channels, reduction_ratio=16):
        super(SEBlock, self).__init__()
        # 全局平均池化：压缩空间维度，提取全局通道统计特征
        self.pool = nn.AdaptiveAvgPool2d(1)
        # 两个全连接层：通道维度压缩-扩张，学习通道间的依赖关系
        self.fc1 = nn.Linear(input_channels, input_channels // reduction_ratio)
        self.fc2 = nn.Linear(input_channels // reduction_ratio, input_channels)

    def forward(self, x):
        batch_size, num_channels, _, _ = x.size()
        # Squeeze阶段：(B,C,H,W) -> (B,C,1,1) -> (B,C)
        y = self.pool(x).reshape(batch_size, num_channels)
        # Excitation阶段：学习通道权重
        y = F.relu(self.fc1(y))
        # 核心改进：Tanh激活替代Sigmoid，输出[-1,1]
        y = torch.tanh(self.fc2(y))
        # 重塑为广播格式，用于后续逐元素相乘
        y = y.reshape(batch_size, num_channels, 1, 1)
        return x * y


class MSEFBlock(nn.Module):
    """Multi-stage Squeeze and Excite Fusion (MSEF) 核心模块
    双分支并行融合架构：空间局部特征(DWConv) + 全局通道特征(改进SE)
    输入输出维度完全一致，即插即用，对应上方完整结构图
    """
    def __init__(self, ch, reduction_ratio=16):
        super(MSEFBlock, self).__init__()
        # 前置层归一化：Pre-LN结构，训练更稳定
        self.layer_norm = LayerNormalization(ch)
        # 空间分支：3x3深度可分离卷积，提取单通道内的空间局部上下文
        self.depthwise_conv = nn.Conv2d(ch, ch, kernel_size=3, padding=1, groups=ch)
        # 通道分支：改进版SE注意力，提取全局通道依赖
        self.se_attn = SEBlock(ch, reduction_ratio)

    def forward(self, x):
        # 前置归一化：统一特征分布
        x_norm = self.layer_norm(x)
        # 分支1：空间局部特征提取
        x1 = self.depthwise_conv(x_norm)
        # 分支2：全局通道注意力加权
        x2 = self.se_attn(x_norm)
        # 核心融合：逐元素相乘（哈达玛积），实现空间-通道自适应融合
        x_fused = x1 * x2
        # 残差连接：保证梯度流通，避免梯度消失
        x_out = x_fused + x
        return x_out


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    x = torch.randn(1, 64, 32, 32).to(device)
    model = MSEFBlock(64).to(device)
    y = model(x)
    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)