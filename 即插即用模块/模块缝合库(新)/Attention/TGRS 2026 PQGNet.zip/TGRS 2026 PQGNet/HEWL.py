import torch
from torch import nn
import pywt
from torch.autograd import Function

# -------------------------- 对应结构图【ResBlock】残差特征增强模块 --------------------------
class ResidualLeakBlock(nn.Module):
    """
    带LeakyReLU的残差卷积块
    对应结构图(b)最右侧的ResBlock模块，核心功能：对重建后的融合特征做增强，缓解梯度消失，强化结构信息
    """
    def __init__(self, in_channels, out_channels, stride=1):
        super().__init__()
        # 输入投影卷积，统一通道维度
        self.proj = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=3, stride=stride, padding=1, bias=True),
            nn.BatchNorm2d(out_channels),
            nn.LeakyReLU()
        )
        # 残差主体卷积，5×3多尺度卷积捕捉细节特征
        self.body = nn.Sequential(
            nn.Conv2d(out_channels, out_channels, kernel_size=5, stride=stride, padding=2, bias=True),
            nn.BatchNorm2d(out_channels),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Conv2d(out_channels, out_channels, kernel_size=3, stride=1, padding=1, bias=True),
            nn.BatchNorm2d(out_channels),
        )
        self.relu = nn.LeakyReLU(0.2, inplace=True)

    def forward(self, x):
        x = self.proj(x)
        residual = x
        x = self.body(x)
        # 残差连接，避免重建过程中的信息丢失
        out = self.relu(x + residual)
        return out

# -------------------------- 可微二维离散小波变换（DWT）核心实现 对应结构图【DWT】模块 --------------------------
class DWT_Function(Function):
    """
    基于PyTorch Autograd的可微DWT前向/反向传播实现
    对应结构图(b)中的DWT模块，核心功能：将输入特征解耦为LL(低频结构)、LH(水平高频)、HL(垂直高频)、HH(对角高频)四个子带，支持端到端训练
    """
    @staticmethod
    def forward(ctx, x, w_ll, w_lh, w_hl, w_hh):
        x = x.contiguous()
        # 保存反向传播所需的滤波器与输入形状
        ctx.save_for_backward(w_ll, w_lh, w_hl, w_hh)
        ctx.shape = x.shape
        dim = x.shape[1]
        # 分组卷积实现小波分解，步长2实现2倍下采样
        x_ll = torch.nn.functional.conv2d(x, w_ll.expand(dim, -1, -1, -1), stride=2, groups=dim)
        x_lh = torch.nn.functional.conv2d(x, w_lh.expand(dim, -1, -1, -1), stride=2, groups=dim)
        x_hl = torch.nn.functional.conv2d(x, w_hl.expand(dim, -1, -1, -1), stride=2, groups=dim)
        x_hh = torch.nn.functional.conv2d(x, w_hh.expand(dim, -1, -1, -1), stride=2, groups=dim)
        # 四个子带沿通道拼接
        x = torch.cat([x_ll, x_lh, x_hl, x_hh], dim=1)
        return x

    @staticmethod
    def backward(ctx, dx):
        if ctx.needs_input_grad[0]:
            w_ll, w_lh, w_hl, w_hh = ctx.saved_tensors
            B, C, H, W = ctx.shape
            dx = dx.view(B, 4, -1, H // 2, W // 2)
            dx = dx.transpose(1, 2).reshape(B, -1, H // 2, W // 2)
            filters = torch.cat([w_ll, w_lh, w_hl, w_hh], dim=0).repeat(C, 1, 1, 1)
            # 转置卷积实现反向传播的上采样
            dx = torch.nn.functional.conv_transpose2d(dx, filters, stride=2, groups=C)
        return dx, None, None, None, None

# -------------------------- 可微二维逆离散小波变换（IDWT）核心实现 对应结构图【IDWT】模块 --------------------------
class IDWT_Function(Function):
    """
    可微IDWT实现，与DWT配对实现小波域的特征重建
    对应结构图(b)中的IDWT模块，核心功能：将增强后的高低频子带重建回原始分辨率的空域特征
    """
    @staticmethod
    def forward(ctx, x, filters):
        ctx.save_for_backward(filters)
        ctx.shape = x.shape
        B, _, H, W = x.shape
        x = x.view(B, 4, -1, H, W).transpose(1, 2)
        C = x.shape[1]
        x = x.reshape(B, -1, H, W)
        filters = filters.repeat(C, 1, 1, 1)
        # 转置卷积实现逆小波变换，2倍上采样
        x = torch.nn.functional.conv_transpose2d(x, filters, stride=2, groups=C)
        return x

    @staticmethod
    def backward(ctx, dx):
        if ctx.needs_input_grad[0]:
            filters = ctx.saved_tensors[0]
            B, C, H, W = ctx.shape
            C = C // 4
            dx = dx.contiguous()
            w_ll, w_lh, w_hl, w_hh = torch.unbind(filters, dim=0)
            x_ll = torch.nn.functional.conv2d(dx, w_ll.unsqueeze(1).expand(C, -1, -1, -1), stride=2, groups=C)
            x_lh = torch.nn.functional.conv2d(dx, w_lh.unsqueeze(1).expand(C, -1, -1, -1), stride=2, groups=C)
            x_hl = torch.nn.functional.conv2d(dx, w_hl.unsqueeze(1).expand(C, -1, -1, -1), stride=2, groups=C)
            x_hh = torch.nn.functional.conv2d(dx, w_hh.unsqueeze(1).expand(C, -1, -1, -1), stride=2, groups=C)
            dx = torch.cat([x_ll, x_lh, x_hl, x_hh], dim=1)
        return dx, None

# -------------------------- IDWT封装模块 --------------------------
class IDWT_2D(nn.Module):
    """2D逆小波变换封装，支持自定义小波基"""
    def __init__(self, wave):
        super(IDWT_2D, self).__init__()
        w = pywt.Wavelet(wave)
        rec_hi = torch.Tensor(w.rec_hi)
        rec_lo = torch.Tensor(w.rec_lo)
        # 构建二维重构滤波器
        w_ll = rec_lo.unsqueeze(0) * rec_lo.unsqueeze(1)
        w_lh = rec_lo.unsqueeze(0) * rec_hi.unsqueeze(1)
        w_hl = rec_hi.unsqueeze(0) * rec_lo.unsqueeze(1)
        w_hh = rec_hi.unsqueeze(0) * rec_hi.unsqueeze(1)
        w_ll = w_ll.unsqueeze(0).unsqueeze(1)
        w_lh = w_lh.unsqueeze(0).unsqueeze(1)
        w_hl = w_hl.unsqueeze(0).unsqueeze(1)
        w_hh = w_hh.unsqueeze(0).unsqueeze(1)
        filters = torch.cat([w_ll, w_lh, w_hl, w_hh], dim=0)
        self.register_buffer('filters', filters)
        self.filters = self.filters.to(dtype=torch.float32)

    def forward(self, x):
        return IDWT_Function.apply(x, self.filters)

# -------------------------- DWT封装模块 --------------------------
class DWT_2D(nn.Module):
    """2D离散小波变换封装，对应结构图(b)中的DWT模块，支持自定义小波基"""
    def __init__(self, wave):
        super(DWT_2D, self).__init__()
        w = pywt.Wavelet(wave)
        dec_hi = torch.Tensor(w.dec_hi[::-1])
        dec_lo = torch.Tensor(w.dec_lo[::-1])
        # 构建二维分解滤波器
        w_ll = dec_lo.unsqueeze(0) * dec_lo.unsqueeze(1)
        w_lh = dec_lo.unsqueeze(0) * dec_hi.unsqueeze(1)
        w_hl = dec_hi.unsqueeze(0) * dec_lo.unsqueeze(1)
        w_hh = dec_hi.unsqueeze(0) * dec_hi.unsqueeze(1)
        self.register_buffer('w_ll', w_ll.unsqueeze(0).unsqueeze(0))
        self.register_buffer('w_lh', w_lh.unsqueeze(0).unsqueeze(0))
        self.register_buffer('w_hl', w_hl.unsqueeze(0).unsqueeze(0))
        self.register_buffer('w_hh', w_hh.unsqueeze(0).unsqueeze(0))
        self.w_ll = self.w_ll.to(dtype=torch.float32)
        self.w_lh = self.w_lh.to(dtype=torch.float32)
        self.w_hl = self.w_hl.to(dtype=torch.float32)
        self.w_hh = self.w_hh.to(dtype=torch.float32)

    def forward(self, x):
        return DWT_Function.apply(x, self.w_ll, self.w_lh, self.w_hl, self.w_hh)

# -------------------------- 对应结构图【AC】交替通道拼接模块 --------------------------
class AlternateCat(nn.Module):
    """
    交替通道拼接模块 对应结构图(c)中的AC模块
    核心功能：对多个特征张量沿通道维度做交替拼接，实现不同统计特征的深度融合
    """
    def __init__(self, dim=1, num=3):
        super().__init__()
        self.dim = dim
        self.num = num

    def forward(self, x_list):
        # 校验输入张量数量与尺寸一致性
        assert len(x_list) == self.num, f'输入张量数量错误！'
        for i in range(self.num):
            assert x_list[0].shape == x_list[i].shape, f'第{i}个输入张量尺寸不匹配！'
        size = x_list[0].size(self.dim)
        # 拆分每个张量的通道切片
        x_list_slices = []
        for i in range(self.num):
            x_list_slices.append(torch.split(x_list[i], 1, dim=self.dim))
        # 交替拼接所有张量的通道切片
        interleaved_slices = []
        for i in range(size):
            for j in range(self.num):
                interleaved_slices.append(x_list_slices[j][i])
        concatenated = torch.cat(interleaved_slices, dim=self.dim)
        return concatenated

# -------------------------- 对应结构图【ALCA】交替通道-空间注意力模块 --------------------------
class AlCattention(nn.Module):
    """
    ALCA: Alternate Channel-Spatial Attention 交替通道-空间联合注意力
    完整对应结构图(b)中的ALCA模块+结构图(c)的注意力全流程，核心功能：自适应学习通道与空间权重，精准增强高频细节特征
    """
    def __init__(self, dim):
        super(AlCattention, self).__init__()
        self.dim = dim
        # 全局池化模块 对应结构图GAP/GMP/GSP
        self.avg_pool = nn.AdaptiveAvgPool2d(1)  # 全局平均池化，捕捉通道平均统计特性
        self.max_pool = nn.AdaptiveMaxPool2d(1)  # 全局最大池化，捕捉通道显著特性
        # 交替通道拼接模块
        self.alcat = AlternateCat(dim=1, num=3)
        # 共享MLP，生成通道注意力权重
        self.share_mlp = nn.Sequential(
            nn.Conv2d(dim * 3, dim, kernel_size=1, stride=1, padding=0, bias=True, groups=self.dim),
            nn.ReLU(inplace=True),
            nn.Conv2d(dim, dim, kernel_size=1, stride=1, padding=0, bias=True),
            nn.Sigmoid()
        )
        # 空间注意力卷积，生成空间注意力权重
        self.spconv = nn.Sequential(
            nn.Conv2d(2, 1, kernel_size=3, stride=1, padding=1, bias=True),
            nn.Sigmoid()
        )

    def forward(self, x, highf):
        """
        :param x: 解码器低频特征（对应结构图O_i+1）
        :param highf: 编码器DWT分解的三个高频子带[LH, HL, HH]（对应结构图DWT输出的高频分量）
        :return: 增强后的高低频拼接特征，用于IDWT重建
        """
        # -------------------------- 步骤1：通道注意力计算 对应结构图(c)全流程 --------------------------
        x_avg = self.avg_pool(x)  # 全局平均池化
        x_max = self.max_pool(x)  # 全局最大池化
        std = torch.std(x, dim=(2, 3), keepdim=True)  # 全局标准差池化GSP
        # 三种统计特征交替拼接 对应结构图AC模块
        x_ams = self.alcat([x_avg, x_max, std])
        # 生成通道注意力权重，加权增强低频特征
        channel_weights = self.share_mlp(x_ams)
        x_1 = x * channel_weights + x  # 残差连接

        # -------------------------- 步骤2：空间注意力计算 对应结构图(b)空间权重生成 --------------------------
        avg_out = torch.mean(x_1, dim=1, keepdim=True)
        max_out, _ = torch.max(x_1, dim=1, keepdim=True)
        spatial_features = torch.cat([avg_out, max_out], dim=1)
        spatial_weights = self.spconv(spatial_features)  # 生成空间注意力权重

        # -------------------------- 步骤3：高频子带增强 --------------------------
        dwt = [x_1]  # 第一个元素为增强后的低频LL分量
        for i in range(len(highf)):
            # 空间权重加权增强每个高频子带，残差连接避免信息丢失
            temp = highf[i] * spatial_weights.expand_as(highf[i]) + highf[i]
            dwt.append(temp)
        # 高低频分量沿通道拼接，适配IDWT输入格式
        dwt = torch.cat(dwt, dim=1)
        return dwt

# -------------------------- HEWL核心模块 完整对应结构图(b)全流程 --------------------------
class HEWL(nn.Module):
    """
    HEWL: High-frequency Enhanced Wavelet Layer 高频增强小波层
    完整对应结构图(b)全流程，核心功能：小波域高频增强+通道-空间联合注意力+逆小波重建，实现上采样过程中的细节增强与特征重建
    输入：x(解码器低频特征O_i+1)、e(编码器跳连特征D_i+1)
    输出：增强后的特征、上采样预测图
    """
    def __init__(self, dim=32, out_ch=1, scale_factor=8, wave='haar'):
        super().__init__()
        self.dim = dim
        # 小波变换模块
        self.dwt = DWT_2D(wave)
        self.idwt = IDWT_2D(wave)
        # ALCA交替通道-空间注意力模块
        self.alca = AlCattention(dim=dim)
        # 重建特征卷积增强
        self.Conv = nn.Sequential(
            nn.Conv2d(dim, dim, kernel_size=3, stride=1, padding=1, bias=True),
            nn.BatchNorm2d(dim),
            nn.LeakyReLU(inplace=True)
        )
        # 上采样预测输出头
        self.PredOut = nn.Sequential(
            nn.Conv2d(dim, out_ch, kernel_size=1, stride=1, padding=0),
            nn.Upsample(scale_factor=scale_factor)
        )
        # 最终残差增强块 对应结构图ResBlock
        self.Out = ResidualLeakBlock(dim * 2, dim)

    def forward(self, x, e):
        # 步骤1：编码器跳连特征DWT分解，解耦高低频 对应结构图(b)DWT模块
        e_dwt = self.dwt(e)
        e_ll, e_lh, e_hl, e_hh = e_dwt.split(self.dim, 1)
        e_high = [e_lh, e_hl, e_hh]  # 三个高频子带

        # 步骤2：ALCA注意力增强高低频特征 对应结构图(b)ALCA模块
        x_idwt = self.alca(x, e_high)

        # 步骤3：IDWT逆小波重建，恢复原始分辨率 对应结构图(b)IDWT模块
        x = self.idwt(x_idwt)

        # 步骤4：重建特征增强与预测输出
        d = self.Conv(x)
        pred = self.PredOut(d)  # 上采样预测图输出

        # 步骤5：与原始跳连特征融合，残差增强 对应结构图(b)ResBlock模块
        d = torch.cat((e, d), dim=1)
        out = self.Out(d)

        return out, pred

# 模块测试代码
if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    x = torch.randn(1, 64, 16, 16).to(device)  # 解码器低频特征
    e = torch.randn(1, 64, 32, 32).to(device)  # 编码器跳连特征
    model = HEWL(64).to(device)
    y, _ = model(x, e)
    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("小红书：十小大，主页获取往期全部即插即用代码，200+大合集")
    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)