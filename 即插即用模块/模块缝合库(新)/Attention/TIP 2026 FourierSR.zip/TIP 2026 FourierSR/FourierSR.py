import torch
import torch.nn as nn
import torch.nn.functional as F

class Frequency_Convolution(nn.Module):
    """
    FourierSR 核心频域卷积模块 完整对应结构图(a) FourierSR全流程
    功能：专为图像超分辨率设计的频域全局建模模块，通过「FFT频域变换→CTM通道令牌混合→实虚部解耦双分支FP滤波→IFFT逆变换」实现全局特征增强
    对应结构图模块：FFT、CTM(Channel Tokens Mix)、FP(Filter Product)、实虚部分支、IFFT
    """
    def __init__(self, channels, num_blocks=8, sparsity_threshold=0.01):
        super().__init__()
        # 校验：通道数必须可被分组数整除，对应结构图中CTM的分组数ρ
        assert channels % num_blocks == 0, f"channels {channels} 必须能被 num_blocks {num_blocks} 整除"
        self.channels = channels
        self.sparsity_threshold = sparsity_threshold  # 软阈值稀疏化参数，抑制频域噪声
        self.num_blocks = num_blocks  # CTM通道分组数ρ，对应结构图(b)的Token分组
        self.block_size = channels // self.num_blocks  # 每个分组的通道数
        self.scale = 0.02  # 权重初始化缩放系数，保证训练稳定性

        # 【对应结构图(b) CTM模块的Filter ω_m】频域通道混合权重，实现分组内的通道令牌交互
        self.w = nn.Parameter(self.scale * torch.randn(self.num_blocks, self.block_size, self.block_size, 2))
        # 【对应结构图(c) FP模块的Local Filter ω】实部分支滤波权重
        self.w1 = nn.Parameter(self.scale * torch.randn(2, self.num_blocks, self.block_size, 1, 1))
        # 【对应结构图(c) FP模块的Local Filter ω】虚部分支滤波权重
        self.w2 = nn.Parameter(self.scale * torch.randn(2, self.num_blocks, self.block_size, 1, 1))
        # 频域滤波偏置项
        self.b = nn.Parameter(self.scale * torch.randn(2, self.num_blocks, self.block_size))

    def forward(self, x):
        bias = x  # 残差连接，对应结构图的全局恒等映射，避免频域信息丢失
        dtype = x.dtype  # 保存输入数据类型，保证精度一致性
        x = x.float()
        B, C, H, W = x.shape

        # -------------------------- 步骤1：空域→频域FFT变换 对应结构图FFT模块 --------------------------
        # 对H、W维度做正交归一化的2D实值FFT，映射到频域
        x = torch.fft.rfft2(x, dim=(2, 3), norm="ortho")
        # 通道维度分组，对应结构图(b) CTM的Token分组操作
        x = x.reshape(B, self.num_blocks, self.block_size, x.shape[2], x.shape[3])

        # -------------------------- 步骤2：CTM通道令牌混合 对应结构图(b) CTM模块 --------------------------
        # 将权重转为复数，实现频域通道间的令牌混合
        weight = torch.view_as_complex(self.w.contiguous())
        # 爱因斯坦求和实现分组内的通道矩阵乘法，完成频域令牌交互
        x = torch.einsum('bkihw,kio->bkohw', x, weight)

        # -------------------------- 步骤3：实虚部解耦双分支FP滤波 对应结构图(a)上下分支+图(c)FP模块 --------------------------
        # 上分支：实部滤波（对应结构图Real分支，建模图像结构信息）
        o1_real = F.relu(
            torch.mul(x.real, self.w1[0].unsqueeze(dim=0)) - \
            torch.mul(x.imag, self.w1[1].unsqueeze(dim=0)) + \
            self.b[0, :, :, None, None]
        )
        # 下分支：虚部滤波（对应结构图Imag分支，建模图像相位/细节信息）
        o1_imag = F.relu(
            torch.mul(x.imag, self.w2[0].unsqueeze(dim=0)) + \
            torch.mul(x.real, self.w2[1].unsqueeze(dim=0)) + \
            self.b[1, :, :, None, None]
        )

        # -------------------------- 步骤4：双分支交叉融合+稀疏化 对应结构图(a)交叉加减融合 --------------------------
        # 实虚部堆叠，还原复数格式
        x = torch.stack([o1_real, o1_imag], dim=-1)
        # 软阈值稀疏化，抑制频域噪声和无效分量，提升鲁棒性
        x = F.softshrink(x, lambd=self.sparsity_threshold)
        x = torch.view_as_complex(x)

        # -------------------------- 步骤5：通道还原+IFFT逆变换 对应结构图IFFT模块 --------------------------
        x = x.reshape(B, C, x.shape[3], x.shape[4])
        # 频域→空域逆FFT变换，还原为空域特征
        x = torch.fft.irfft2(x, s=(H, W), dim=(2, 3), norm="ortho")
        x = x.type(dtype)

        # -------------------------- 步骤6：残差连接输出 --------------------------
        return x + bias


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 64, 32, 32).to(device)
    model = Frequency_Convolution(64).to(device)

    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("小红书：十小大，主页获取往期全部即插即用代码，200+大合集")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)