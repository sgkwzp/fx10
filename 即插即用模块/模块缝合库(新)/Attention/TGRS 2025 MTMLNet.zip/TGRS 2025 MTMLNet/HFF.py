import torch
import torch.nn as nn

class SpatialAttention(nn.Module):
    def __init__(self):
        super(SpatialAttention, self).__init__()
        self.sa = nn.Conv2d(2, 1, 7, padding=3, padding_mode='reflect', bias=True)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        x_avg = torch.mean(x, dim=1, keepdim=True)
        x_max, _ = torch.max(x, dim=1, keepdim=True)
        x2 = torch.concat([x_avg, x_max], dim=1)
        output = self.sa(x2)
        output = self.sigmoid(output)
        return output


class ChannelAttention(nn.Module):
    def __init__(self, dim, reduction=8):
        super(ChannelAttention, self).__init__()
        self.maxpool = nn.AdaptiveMaxPool2d(1)
        self.avgpool = nn.AdaptiveAvgPool2d(1)
        self.gap = nn.AdaptiveAvgPool2d(1)
        self.ca = nn.Sequential(
            nn.Conv2d(dim, dim // reduction, 1, padding=0, bias=False),
            nn.ReLU(inplace=True),
            nn.Conv2d(dim // reduction, dim, 1, padding=0, bias=False),
        )
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        max = self.maxpool(x)
        avg = self.avgpool(x)
        max_ca = self.ca(max)
        avg_ca = self.ca(avg)
        output = self.sigmoid(max_ca + avg_ca)
        return output


class PA(nn.Module):
    '''PA is pixel attention'''
    def __init__(self, nf):

        super(PA, self).__init__()
        self.conv = nn.Conv2d(nf, nf, 1)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x, att):
        x = self.conv(x)
        # x = self.sigmoid(x)
        y = att
        out = torch.mul(x, y)

        return out


class HFF(nn.Module):
    def __init__(self, dim, reduction=8):
        super(HFF, self).__init__()
        self.sa = SpatialAttention()
        self.ca = ChannelAttention(dim, reduction)
        self.pa = PA(dim)
        self.conv = nn.Conv2d(dim, dim, 1, bias=True)
        self.sigmoid = nn.Sigmoid()

    def forward(self, data):
        x, y = data
        raw = x + y
        cattn = self.ca(raw)
        sattn = self.sa(raw)
        mix_att = sattn + cattn
        new = self.sigmoid(self.pa(raw, mix_att))
        out = raw + new * x + (1 - new) * y
        out = self.conv(out)
        return out


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x_low = torch.randn(1, 64, 32, 32).to(device)
    x_high = torch.randn(1, 64, 32, 32).to(device)
    model = HFF(64).to(device)

    y = model((x_low, x_high))

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN、小红书：十小大")

    print("输入浅层特征维度：", x_low.shape)
    print("输入深层特征维度：", x_high.shape)
    print("输出特征维度：", y.shape)