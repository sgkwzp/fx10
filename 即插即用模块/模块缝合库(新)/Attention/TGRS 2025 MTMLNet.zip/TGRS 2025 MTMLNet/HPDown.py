import torch
import torch.nn as nn


def autopad(k, p=None, d=1):  # kernel, padding, dilation
    # Pad to 'same' shape outputs
    if d > 1:
        k = d * (k - 1) + 1 if isinstance(k, int) else [d * (x - 1) + 1 for x in k]  # actual kernel-size
    if p is None:
        p = k // 2 if isinstance(k, int) else [x // 2 for x in k]  # auto-pad
    return p


class Conv(nn.Module):
    # Standard convolution with args(ch_in, ch_out, kernel, stride, padding, groups, dilation, activation)
    default_act = nn.SiLU()  # default activation

    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, d=1, act=True):
        super().__init__()
        self.conv = nn.Conv2d(c1, c2, k, s, autopad(k, p, d), groups=g, dilation=d, bias=False)
        self.bn = nn.BatchNorm2d(c2)
        self.act = self.default_act if act is True else act if isinstance(act, nn.Module) else nn.Identity()

    def forward(self, x):
        return self.act(self.bn(self.conv(x)))

    def forward_fuse(self, x):
        return self.act(self.conv(x))


class HPDown(nn.Module):
    def __init__(self, c1, c2):  # ch_in, ch_out, shortcut, kernels, groups, expand
        super().__init__()
        self.c = c2 // 2
        self.cv1 = Conv(c1 // 2, self.c, 3, 2, 1)
        self.cv2 = Conv(c1 // 2, self.c, 1, 1, 0)
        # self.cv3 = Conv(c1 // 4, self.c // 2, 3, 2, 1)
        # self.cv4 = Conv(c1 // 4, self.c // 2, 5, 2, 2)

        self.cv3 = Conv(c1 // 4, self.c // 2, 5, 2, 2)
        self.cv4 = Conv(c1 // 4, self.c // 2, 7, 2, 3)

    # #源码
    # def forward(self, x):
    #     x = torch.nn.functional.avg_pool2d(x, 2, 1, 0, False, True)
    #     x1,x2 = x.chunk(2, 1)
    #     x1 = self.cv1(x1)
    #     x2 = torch.nn.functional.max_pool2d(x2, 3, 2, 1)
    #     x2 = self.cv2(x2)
    #     return torch.cat((x1, x2), 1)
    # version 1
    # def forward(self, x):
    #     x1, x2 = x.chunk(2, 1)
    #     x1 = torch.nn.functional.avg_pool2d(x1, 2, 1, 0, False, True)
    #     x1 = self.cv1(x1)
    #     x2 = torch.nn.functional.max_pool2d(x2, 3, 2, 1)
    #     x2 = self.cv2(x2)
    #     return torch.cat((x1, x2), 1)

    # version 2
    def forward(self, x):
        x1, x2 = x.chunk(2, 1)

        x1 = torch.nn.functional.avg_pool2d(x1, 2, 1, 0, False, True)
        x3, x4 = x1.chunk(2, 1)
        x3 = self.cv4(x3)
        x4 = self.cv3(x4)
        x3_4 = torch.cat((x3, x4), 1)

        x2 = torch.nn.functional.max_pool2d(x2, 3, 2, 1)  # 源码 尺寸减半的最大池化操作
        # x2 = torch.nn.functional.max_pool2d(x2, 2, 1, 0, False, True)
        # x5, x6 = x2.chunk(2, 1)
        # x5 = self.cv1(x5)
        # x6 = self.cv2(x6)
        # x5_6 = torch.cat((x5, x6), 1)
        x2 = self.cv2(x2)
        return torch.cat((x3_4, x2), 1)


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 64, 32, 32).to(device)
    model = HPDown(64, 64).to(device)

    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN、小红书：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)