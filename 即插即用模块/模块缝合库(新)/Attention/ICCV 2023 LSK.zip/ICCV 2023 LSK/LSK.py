import torch
import torch.nn as nn


class LSKblock(nn.Module):
    """
    大核选择注意力模块（Large Selective Kernel block, LSKblock）
    核心设计：通过多尺度大卷积核提取不同范围的空间特征，结合通道压缩与自适应选择机制，
    动态融合多尺度注意力权重，实现“局部细节+全局依赖”的精准建模
    """

    def __init__(self, dim):
        """
        初始化LSK模块参数

        Args:
            dim (int): 输入特征图的通道数（需与上游模块输出通道一致，如代码示例中为64）
        """
        super().__init__()
        # 分支1：5×5深度可分离卷积（小范围大核）
        # 作用：捕捉较近范围的空间依赖，groups=dim确保逐通道独立卷积，减少参数量
        self.conv0 = nn.Conv2d(dim, dim, 5, padding=2, groups=dim)

        # 分支2：7×7带 dilation 的深度可分离卷积（大范围大核）
        # 关键参数：dilation=3（膨胀率）→ 实际感受野=7 + (3-1)×(7-1) = 19×19，padding=9确保输出尺寸与输入一致
        # 作用：捕捉更远范围的全局空间依赖，无需增大卷积核尺寸即可扩展感受野
        self.conv_spatial = nn.Conv2d(dim, dim, 7, stride=1, padding=9, groups=dim, dilation=3)

        # 通道压缩卷积：将两个分支的通道数从dim压缩至dim//2，降低后续计算量
        self.conv1 = nn.Conv2d(dim, dim // 2, 1)  # 对应分支1的通道压缩
        self.conv2 = nn.Conv2d(dim, dim // 2, 1)  # 对应分支2的通道压缩

        # 特征聚合卷积：对AvgPool和MaxPool的结果进行卷积，生成注意力选择权重
        self.conv_squeeze = nn.Conv2d(2, 2, 7, padding=3)  # 输入通道=2（Avg+Max），输出通道=2（对应两个分支的权重）

        # 通道恢复卷积：将融合后的dim//2通道恢复为原始dim，确保模块输入输出维度一致
        self.conv = nn.Conv2d(dim // 2, dim, 1)

    def forward(self, x):
        """
        LSK前向传播流程：多尺度特征提取→通道压缩→特征聚合→权重选择→特征融合→通道恢复

        Args:
            x (torch.Tensor): 输入特征图，形状为 [batch_size, dim, height, width]
                             （代码示例中为[1, 64, 32, 32]，即1个样本、64通道、32×32分辨率）
        Returns:
            torch.Tensor: 输出特征图，形状与输入完全一致 [batch_size, dim, height, width]，
                          确保模块可无缝级联到网络中
        """
        # 步骤1：多尺度空间特征提取（双分支并行）
        attn1 = self.conv0(x)  # 分支1（小范围）：[b, dim, h, w] → [b, dim, h, w]
        attn2 = self.conv_spatial(attn1)  # 分支2（大范围）：基于分支1结果进一步提取全局依赖 → [b, dim, h, w]

        # 步骤2：通道压缩（降低维度，减少计算量）
        attn1 = self.conv1(attn1)  # 分支1通道压缩：[b, dim, h, w] → [b, dim//2, h, w]
        attn2 = self.conv2(attn2)  # 分支2通道压缩：[b, dim, h, w] → [b, dim//2, h, w]

        # 步骤3：多分支特征拼接（通道维度合并，为后续聚合做准备）
        attn = torch.cat([attn1, attn2], dim=1)  # 形状：[b, dim//2 + dim//2, h, w] → [b, dim, h, w]

        # 步骤4：特征聚合（通过池化压缩空间维度，提取全局统计信息）
        avg_attn = torch.mean(attn, dim=1, keepdim=True)  # 通道维度平均池化：[b, 1, h, w]
        max_attn, _ = torch.max(attn, dim=1, keepdim=True)  # 通道维度最大池化：[b, 1, h, w]
        agg = torch.cat([avg_attn, max_attn], dim=1)  # 池化结果拼接：[b, 2, h, w]

        # 步骤5：生成自适应选择权重（Sigmoid确保权重在0~1之间，实现“选择”效果）
        sig = self.conv_squeeze(agg).sigmoid()  # 形状：[b, 2, h, w]，两个通道分别对应分支1和分支2的权重

        # 步骤6：多分支特征融合（基于权重动态选择不同尺度的特征）
        # sig[:, 0, :, :].unsqueeze(1)：分支1的权重（扩展通道维度匹配attn1）
        # sig[:, 1, :, :].unsqueeze(1)：分支2的权重（扩展通道维度匹配attn2）
        attn = attn1 * sig[:, 0, :, :].unsqueeze(1) + attn2 * sig[:, 1, :, :].unsqueeze(1)  # 形状：[b, dim//2, h, w]

        # 步骤7：通道恢复（将dim//2通道恢复为原始dim，确保输入输出维度一致）
        attn = self.conv(attn)  # 形状：[b, dim//2, h, w] → [b, dim, h, w]

        # 步骤8：残差融合（注意力结果与原始输入相乘，增强特征表达并稳定训练）
        return x * attn

if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 64, 32, 32).to(device)
    model = LSKblock(64)

    model.to(device)
    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)