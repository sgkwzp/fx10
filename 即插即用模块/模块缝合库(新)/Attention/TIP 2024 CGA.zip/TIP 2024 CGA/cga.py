import torch
from torch import nn
from einops.layers.torch import Rearrange


class SpatialAttention(nn.Module):
    """空间注意力模块
    功能：聚焦图像的“空间位置信息”，通过对不同空间位置（如目标区域、背景区域）的特征加权，突出重要空间区域
    核心逻辑：
        - 对输入特征图沿通道维度计算“平均池化”和“最大池化”，得到两个单通道的空间描述图
        - 拼接两个描述图后，通过7×7卷积（大感受野）融合空间信息，生成空间注意力权重图
        - 权重图中每个位置的数值代表该空间位置的重要程度（0~1，经后续Sigmoid激活）
    优势：7×7卷积的大感受野可捕捉长距离空间依赖，避免仅关注局部空间的局限
    输入：x (Tensor) - 形状 [B, C, H, W]（B=批量，C=通道数，H=高度，W=宽度）
    输出：sattn (Tensor) - 形状 [B, 1, H, W]（单通道空间注意力权重图）
    """

    def __init__(self):
        super(SpatialAttention, self).__init__()
        # 7×7卷积：融合平均池化和最大池化的特征，padding=3保证输入输出尺寸一致
        # padding_mode='reflect'：边缘反射填充，减少边缘信息丢失
        self.sa = nn.Conv2d(2, 1, 7, padding=3, padding_mode='reflect', bias=True)

    def forward(self, x):
        # 步骤1：沿通道维度计算平均池化和最大池化（压缩通道信息，保留空间信息）
        x_avg = torch.mean(x, dim=1, keepdim=True)  # [B, 1, H, W]，通道平均的空间描述
        x_max, _ = torch.max(x, dim=1, keepdim=True)  # [B, 1, H, W]，通道最大的空间描述

        # 步骤2：拼接两个空间描述图（通道数从1+1=2）
        x2 = torch.concat([x_avg, x_max], dim=1)  # [B, 2, H, W]

        # 步骤3：通过7×7卷积生成空间注意力权重（未激活，后续与通道注意力融合后统一激活）
        sattn = self.sa(x2)  # [B, 1, H, W]
        return sattn


class ChannelAttention(nn.Module):
    """通道注意力模块
    功能：聚焦图像的“通道语义信息”，通过对不同通道（如RGB颜色通道、边缘特征通道）的特征加权，突出关键语义通道
    核心逻辑：
        - 对输入特征图沿空间维度计算“全局平均池化（GAP）”，将每个通道压缩为单个数值（全局通道描述）
        - 通过“1×1卷积+ReLU+1×1卷积”构成的瓶颈结构（Bottleneck），动态学习各通道的重要性权重
        - 权重值代表对应通道的语义重要程度（0~1，经后续Sigmoid激活）
    优势：瓶颈结构（通道数先降后升）减少参数量，同时通过GAP捕捉全局通道依赖
    参数：
        dim: 输入特征图的通道数（C）
        reduction: 通道压缩系数（默认8，即中间瓶颈层通道数=dim//reduction）
    输入：x (Tensor) - [B, C, H, W]
    输出：cattn (Tensor) - [B, C, 1, 1]（单空间维度的通道注意力权重，需广播至[B, C, H, W]使用）
    """

    def __init__(self, dim, reduction=8):
        super(ChannelAttention, self).__init__()
        # 全局平均池化：将每个通道的[H, W]特征压缩为[1, 1]，保留通道全局信息
        self.gap = nn.AdaptiveAvgPool2d(1)

        # 瓶颈结构：动态学习通道权重
        self.ca = nn.Sequential(
            # 1×1卷积：通道数从dim降至dim//reduction（压缩特征，减少计算）
            nn.Conv2d(dim, dim // reduction, 1, padding=0, bias=True),
            nn.ReLU(inplace=True),  # 非线性激活，增强表达能力
            # 1×1卷积：通道数从dim//reduction恢复至dim（生成最终通道权重）
            nn.Conv2d(dim // reduction, dim, 1, padding=0, bias=True),
        )

    def forward(self, x):
        # 步骤1：全局平均池化，得到通道全局描述
        x_gap = self.gap(x)  # [B, C, 1, 1]

        # 步骤2：通过瓶颈结构生成通道注意力权重（未激活，后续融合后统一激活）
        cattn = self.ca(x_gap)  # [B, C, 1, 1]
        return cattn


class PixelAttention(nn.Module):
    """像素注意力模块
    功能：聚焦图像的“像素级细粒度信息”，通过结合原始特征与前序注意力（通道+空间），动态学习每个像素的重要性
    核心逻辑：
        - 将原始特征图与“通道-空间融合注意力图”按通道维度拼接，形成双分支特征
        - 通过7×7分组卷积（Group Conv），在每个通道组内学习像素间的依赖关系，生成像素注意力权重
        - 权重图中每个像素的数值代表该像素的细粒度重要程度（0~1，经Sigmoid激活）
    优势：分组卷积减少参数量，同时像素级建模可捕捉局部细节（如边缘、纹理的像素级差异）
    参数：
        dim: 输入特征图的通道数（C）
    输入：
        x: 原始特征图 (Tensor) - [B, C, H, W]
        pattn1: 通道-空间融合注意力图 (Tensor) - [B, C, H, W]（需先将通道注意力广播至空间维度）
    输出：pattn2 (Tensor) - [B, C, H, W]（像素注意力权重图，与输入特征图尺寸完全一致）
    """

    def __init__(self, dim):
        super(PixelAttention, self).__init__()
        # 7×7分组卷积：输入通道数=2*dim（原始特征+融合注意力），输出通道数=dim，分组数=dim（每个组对应1个原始通道）
        self.pa2 = nn.Conv2d(2 * dim, dim, 7, padding=3, padding_mode='reflect', groups=dim, bias=True)
        self.sigmoid = nn.Sigmoid()  # 激活函数，将权重值映射到0~1区间

    def forward(self, x, pattn1):
        B, C, H, W = x.shape  # 获取输入特征图尺寸

        # 步骤1：扩展维度，为通道维度拼接做准备（新增维度用于区分原始特征和融合注意力）
        x = x.unsqueeze(dim=2)  # [B, C, 1, H, W]（原始特征分支）
        pattn1 = pattn1.unsqueeze(dim=2)  # [B, C, 1, H, W]（融合注意力分支）

        # 步骤2：沿新增维度拼接，形成双分支特征
        x2 = torch.cat([x, pattn1], dim=2)  # [B, C, 2, H, W]

        # 步骤3：维度重排，将“通道×分支”合并为新的通道维度（适配分组卷积输入）
        x2 = Rearrange('b c t h w -> b (c t) h w')(x2)  # [B, C*2, H, W]

        # 步骤4：分组卷积学习像素依赖，生成像素注意力权重并激活
        pattn2 = self.pa2(x2)  # [B, C, H, W]
        pattn2 = self.sigmoid(pattn2)  # 权重值映射到0~1
        return pattn2


class CGA(nn.Module):
    """通道-空间-像素注意力模块（CGA）
    功能：融合通道、空间、像素三个维度的注意力，动态筛选从宏观到微观的关键特征
    流程逻辑：
        1. 通道注意力（CA）：学习各通道的语义重要性
        2. 空间注意力（SA）：学习各空间位置的重要性
        3. 融合CA与SA：生成“通道-空间”联合注意力图
        4. 像素注意力（PA）：结合原始特征与联合注意力，学习像素级细粒度权重
    优势：层级递进的注意力设计，兼顾全局语义（CA）、空间定位（SA）和局部细节（PA）
    参数：
        dim: 输入特征图的通道数（C），需与各子模块通道数匹配
        reduction: 通道注意力的通道压缩系数（默认8）
    输入：x (Tensor) - [B, C, H, W]（原始特征图）
    输出：pattn2 (Tensor) - [B, C, H, W]（最终像素级注意力权重图，用于加权原始特征）
    """

    def __init__(self, dim, reduction=8):
        super(CGA, self).__init__()
        # 初始化三个注意力子模块
        self.sa = SpatialAttention()  # 空间注意力
        self.ca = ChannelAttention(dim, reduction)  # 通道注意力（带通道压缩）
        self.pa = PixelAttention(dim)  # 像素注意力

    def forward(self, x):
        res = x  # 备份原始特征（用于后续注意力计算的基准）

        # 步骤1：计算通道注意力和空间注意力
        cattn = self.ca(res)  # [B, C, 1, 1]（通道权重）
        sattn = self.sa(res)  # [B, 1, H, W]（空间权重）

        # 步骤2：融合通道与空间注意力（需先将通道权重广播至空间维度）
        # 广播逻辑：[B, C, 1, 1] → [B, C, H, W]（与空间权重尺寸匹配）
        pattn1 = sattn + cattn  # [B, C, H, W]（通道-空间联合注意力，未激活）
        pattn1 = nn.Sigmoid()(pattn1)  # 激活，权重值映射到0~1

        # 步骤3：计算像素注意力（结合原始特征与联合注意力）
        pattn2 = self.pa(res, pattn1)  # [B, C, H, W]（最终像素级注意力权重）

        return pattn2


# 测试代码：验证CGA模块的输入输出尺寸一致性
if __name__ == '__main__':
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    x = torch.randn(1, 64, 32, 32).to(device)  # 模拟输入：1个样本，64通道，32×32尺寸
    cga = CGA(64).to(device)  # 初始化CGA（通道数=64）
    y = cga(x)  # 前向传播
    print("微信公众号：十小大的底层视觉工坊")
    print("知乎、CSDN：十小大")
    print("输入特征维度：", x.shape)  # 输出：torch.Size([1, 64, 32, 32])
    print("输出特征维度：", y.shape)  # 输出：torch.Size([1, 64, 32, 32])（与输入尺寸一致）