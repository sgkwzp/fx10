import math
import torch
import torch.nn as nn
import torch.nn.functional as F


def get_freq_indices(method):
    """
    获取频率域采样索引：根据指定方法（高频/低频/底部频率+采样数量），返回DCT频率域的(x,y)索引
    核心作用：为多频率分支选择特定频率分量，适配不同频率特征的提取需求
    Args:
        method (str): 频率选择方法，格式为“类型+数量”（如top16=前16个高频，low8=前8个低频）
    Returns:
        tuple: (mapper_x, mapper_y)，频率域x/y方向的索引列表，长度=采样数量
    """
    # 校验方法有效性（仅支持预定义的高频/低频/底部频率类型）
    assert method in ['top1', 'top2', 'top4', 'top8', 'top16', 'top32',
                      'bot1', 'bot2', 'bot4', 'bot8', 'bot16', 'bot32',
                      'low1', 'low2', 'low4', 'low8', 'low16', 'low32']
    num_freq = int(method[3:])  # 提取采样数量（如top16中的16）

    # 预定义不同频率类型的索引（基于7×7频率域网格，后续缩放适配任意尺寸）
    if 'top' in method:
        # 高频索引：对应频率域右上角（包含细节信息）
        all_top_indices_x = [0, 0, 6, 0, 0, 1, 1, 4, 5, 1, 3, 0, 0, 0, 3, 2, 4, 6, 3, 5, 5, 2, 6, 5, 5, 3, 3, 4, 2, 2,
                             6, 1]
        all_top_indices_y = [0, 1, 0, 5, 2, 0, 2, 0, 0, 6, 0, 4, 6, 3, 5, 2, 6, 3, 3, 3, 5, 1, 1, 2, 4, 2, 1, 1, 3, 0,
                             5, 3]
        mapper_x = all_top_indices_x[:num_freq]  # 截取前num_freq个索引
        mapper_y = all_top_indices_y[:num_freq]
    elif 'low' in method:
        # 低频索引：对应频率域左上角（包含全局信息）
        all_low_indices_x = [0, 0, 1, 1, 0, 2, 2, 1, 2, 0, 3, 4, 0, 1, 3, 0, 1, 2, 3, 4, 5, 0, 1, 2, 3, 4, 5, 6, 1, 2,
                             3, 4]
        all_low_indices_y = [0, 1, 0, 1, 2, 0, 1, 2, 2, 3, 0, 0, 4, 3, 1, 5, 4, 3, 2, 1, 0, 6, 5, 4, 3, 2, 1, 0, 6, 5,
                             4, 3]
        mapper_x = all_low_indices_x[:num_freq]
        mapper_y = all_low_indices_y[:num_freq]
    elif 'bot' in method:
        # 底部频率索引：对应频率域右下角（包含特定高频细节）
        all_bot_indices_x = [6, 1, 3, 3, 2, 4, 1, 2, 4, 4, 5, 1, 4, 6, 2, 5, 6, 1, 6, 2, 2, 4, 3, 3, 5, 5, 6, 2, 5, 5,
                             3, 6]
        all_bot_indices_y = [6, 4, 4, 6, 6, 3, 1, 4, 4, 5, 6, 5, 2, 2, 5, 1, 4, 3, 5, 0, 3, 1, 1, 2, 4, 2, 1, 1, 5, 3,
                             3, 3]
        mapper_x = all_bot_indices_x[:num_freq]
        mapper_y = all_bot_indices_y[:num_freq]
    else:
        raise NotImplementedError("仅支持top/low/bot三种频率类型")
    return mapper_x, mapper_y

class MultiFrequencyChannelAttention(nn.Module):
    """
    多频率通道注意力模块（MFCA）：通过多分支DCT频率提取+通道注意力，强化关键频率的通道权重
    核心流程：多频率DCT滤波→多池化融合→通道权重预测→注意力加权
    """
    def __init__(self,
                 in_channels,
                 dct_h, dct_w,
                 frequency_branches=16,
                 frequency_selection='top',
                 reduction=16):
        """
        Args:
            in_channels (int): 输入特征通道数
            dct_h/dct_w (int): DCT频率域的高度/宽度（通常与输入特征尺寸适配）
            frequency_branches (int): 频率分支数量（1/2/4/8/16/32，即采样频率数量）
            frequency_selection (str): 频率选择类型（top=高频，low=低频，bot=底部频率）
            reduction (int): 通道压缩比（默认16，用于降低注意力计算复杂度）
        """
        super(MultiFrequencyChannelAttention, self).__init__()
        # 校验频率分支数量有效性（仅支持预定义的数量）
        assert frequency_branches in [1, 2, 4, 8, 16, 32]
        # 构建频率选择方法（如top+16→top16）
        self.frequency_selection = frequency_selection + str(frequency_branches)
        self.num_freq = frequency_branches  # 频率分支总数
        self.dct_h = dct_h  # DCT频率域高度
        self.dct_w = dct_w  # DCT频率域宽度
        self.in_channels = in_channels  # 输入通道数

        # 步骤1：获取频率索引并缩放适配DCT尺寸（基于7×7网格缩放至dct_h×dct_w）
        mapper_x, mapper_y = get_freq_indices(self.frequency_selection)
        self.num_split = len(mapper_x)  # 频率分支数量（与frequency_branches一致）
        # 索引缩放：将7×7网格的索引映射到dct_h×dct_w网格（如dct_h=28→7×4，索引×4）
        mapper_x = [temp_x * (dct_h // 7) for temp_x in mapper_x]
        mapper_y = [temp_y * (dct_w // 7) for temp_y in mapper_y]
        assert len(mapper_x) == len(mapper_y), "x/y方向索引数量必须一致"

        # 步骤2：预初始化多分支DCT滤波器（注册为缓冲区，不参与梯度更新）
        for freq_idx in range(frequency_branches):
            # 为每个频率分支生成DCT滤波器，并注册为缓冲区（命名格式：dct_weight_0~frequency_branches-1）
            dct_filter = self.get_dct_filter(dct_h, dct_w, mapper_x[freq_idx], mapper_y[freq_idx], in_channels)
            self.register_buffer('dct_weight_{}'.format(freq_idx), dct_filter)

        # 步骤3：通道注意力预测网络（通过1×1卷积压缩通道，降低计算量）
        self.fc = nn.Sequential(
            # 通道压缩：in_channels → in_channels/reduction
            nn.Conv2d(in_channels, in_channels // reduction, kernel_size=1, stride=1, padding=0, bias=False),
            nn.ReLU(inplace=True),  # 非线性激活增强表达
            # 通道恢复：in_channels/reduction → in_channels（预测通道权重）
            nn.Conv2d(in_channels // reduction, in_channels, kernel_size=1, stride=1, padding=0, bias=False)
        )

        # 步骤4：多池化操作（平均/最大/最小池化，融合不同统计信息）
        self.average_channel_pooling = nn.AdaptiveAvgPool2d(1)  # 平均池化（全局均值）
        self.max_channel_pooling = nn.AdaptiveMaxPool2d(1)    # 最大池化（全局最大值）

    def forward(self, x):
        """
        前向传播流程：特征尺寸适配→多频率DCT滤波→多池化融合→通道权重预测→注意力加权
        Args:
            x (torch.Tensor): 输入特征，形状 [B, C, H, W]（B=批量，C=通道，H=高度，W=宽度）
        Returns:
            torch.Tensor: 注意力加权后的特征，形状与输入一致 [B, C, H, W]
        """
        batch_size, C, H, W = x.shape
        x_pooled = x  # 初始化特征池化结果

        # 步骤1：特征尺寸适配（若输入尺寸≠DCT尺寸，通过自适应平均池化调整）
        if H != self.dct_h or W != self.dct_w:
            x_pooled = F.adaptive_avg_pool2d(x, (self.dct_h, self.dct_w))

        # 步骤2：多频率DCT滤波与多池化融合（遍历所有DCT滤波器分支）
        multi_spectral_feature_avg = 0  # 平均池化特征累积
        multi_spectral_feature_max = 0  # 最大池化特征累积
        multi_spectral_feature_min = 0  # 最小池化特征累积（通过-最大池化实现）
        # 遍历所有注册的DCT滤波器（state_dict中含"dct_weight"的参数）
        for name, dct_weight in self.state_dict().items():
            if 'dct_weight' in name:
                # 频率滤波：输入特征 × DCT滤波器（提取当前频率分支的特征）
                x_pooled_spectral = x_pooled * dct_weight.unsqueeze(0)  # 适配批量维度 [B, C, dct_h, dct_w]
                # 多池化计算并累积（每个分支的特征贡献平均分配）
                multi_spectral_feature_avg += self.average_channel_pooling(x_pooled_spectral)
                multi_spectral_feature_max += self.max_channel_pooling(x_pooled_spectral)
                multi_spectral_feature_min += -self.max_channel_pooling(-x_pooled_spectral)  # 最小池化= -max(-x)

        # 步骤3：多池化特征归一化（除以分支数量，平衡各分支贡献）
        multi_spectral_feature_avg = multi_spectral_feature_avg / self.num_freq
        multi_spectral_feature_max = multi_spectral_feature_max / self.num_freq
        multi_spectral_feature_min = multi_spectral_feature_min / self.num_freq

        # 步骤4：通道注意力权重预测（多池化特征→通道权重→Sigmoid归一化）
        # 平均池化特征→权重
        multi_spectral_avg_map = self.fc(multi_spectral_feature_avg).view(batch_size, C, 1, 1)
        # 最大池化特征→权重
        multi_spectral_max_map = self.fc(multi_spectral_feature_max).view(batch_size, C, 1, 1)
        # 最小池化特征→权重
        multi_spectral_min_map = self.fc(multi_spectral_feature_min).view(batch_size, C, 1, 1)
        # 权重融合并归一化（Sigmoid确保权重在0~1）
        multi_spectral_attention_map = F.sigmoid(
            multi_spectral_avg_map + multi_spectral_max_map + multi_spectral_min_map
        )

        # 步骤5：注意力加权（输入特征 × 通道权重，强化关键通道）
        return x * multi_spectral_attention_map.expand_as(x)  # 权重广播适配输入尺寸

    def get_dct_filter(self, tile_size_x, tile_size_y, mapper_x, mapper_y, in_channels):
        """
        生成单分支DCT滤波器：基于DCT-II公式，生成适配通道数的2D DCT滤波核
        Args:
            tile_size_x/tile_size_y (int): 滤波器的高度/宽度
            mapper_x/mapper_y (int): 当前频率分支的(x,y)索引
            in_channels (int): 输入通道数（滤波器需与通道数匹配）
        Returns:
            torch.Tensor: DCT滤波器，形状 [in_channels, tile_size_x, tile_size_y]
        """
        # 初始化滤波器（通道数×高度×宽度）
        dct_filter = torch.zeros(in_channels, tile_size_x, tile_size_y)
        # 遍历滤波器的每个像素，计算DCT值（分离x/y方向的DCT，乘积得到2D DCT）
        for t_x in range(tile_size_x):
            for t_y in range(tile_size_y):
                # x方向DCT值 × y方向DCT值，赋值给所有通道（通道共享同一滤波器）
                dct_filter[:, t_x, t_y] = self.build_filter(t_x, mapper_x, tile_size_x) * \
                                          self.build_filter(t_y, mapper_y, tile_size_y)
        return dct_filter

    def build_filter(self, pos, freq, POS):
        """
        计算1D DCT值（DCT-II公式），用于构建2D DCT滤波器
        Args:
            pos (int): 像素位置（0~POS-1）
            freq (int): 频率索引（对应DCT的频率分量）
            POS (int): 维度大小（高度或宽度）
        Returns:
            float: 1D DCT值
        """
        # DCT-II公式：cos(π×freq×(pos+0.5)/POS) / sqrt(POS)，freq=0时额外归一化
        result = math.cos(math.pi * freq * (pos + 0.5) / POS) / math.sqrt(POS)
        if freq == 0:
            return result  # 直流分量（freq=0）无需额外缩放
        else:
            return result * math.sqrt(2)  # 交流分量（freq>0）需乘以√2归一化

if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    in_channels = 64
    x = torch.randn(1, in_channels, 32, 32).to(device)
    c2wh = dict([(32, 112), (64, 56), (128, 28), (256, 14), (512, 7)])

    model = MultiFrequencyChannelAttention(in_channels, c2wh[in_channels], c2wh[in_channels],)

    model.to(device)
    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("知乎、CSDN：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)