import torch
import torch.nn as nn
import torchvision  # 提供官方可变形卷积接口


class DeformConv(nn.Module):
    """标准可变形卷积模块：通过学习偏移量动态调整卷积核采样位置
    核心逻辑：先预测偏移量，再用可变形卷积层按偏移量采样特征
    """

    def __init__(self, in_channels, groups, kernel_size=(3, 3), padding=1, stride=1, dilation=1, bias=True):
        super(DeformConv, self).__init__()
        # 偏移量预测网络：输出通道数=2×卷积核尺寸（每个卷积核位置需x/y两个偏移量）
        self.offset_net = nn.Conv2d(
            in_channels=in_channels,
            out_channels=2 * kernel_size[0] * kernel_size[1],  # 偏移量维度：2×k_h×k_w
            kernel_size=kernel_size,
            padding=padding,
            stride=stride,
            dilation=dilation,
            bias=True
        )
        # 可变形卷积层（基于torchvision官方实现）
        self.deform_conv = torchvision.ops.DeformConv2d(
            in_channels=in_channels,
            out_channels=in_channels,  # 输出通道数与输入一致（用于特征增强）
            kernel_size=kernel_size,
            padding=padding,
            groups=groups,  # 分组卷积：增强通道独立性，降低计算量
            stride=stride,
            dilation=dilation,
            bias=False
        )

    def forward(self, x):
        offsets = self.offset_net(x)  # 步骤1：预测每个卷积核位置的偏移量
        out = self.deform_conv(x, offsets)  # 步骤2：按偏移量执行可变形卷积
        return out


class DeformConv_3x3(nn.Module):
    """简化版3×3可变形卷积：固定偏移量预测网络为3×3卷积（适配特定场景）
    注：代码存在继承类名错误（应为DeformConv_3x3），实际功能与DeformConv一致但偏移量网络核固定为3×3
    """

    def __init__(self, in_channels, groups, kernel_size=(3, 3), padding=1, stride=1, dilation=1, bias=True):
        super(DeformConv, self).__init__()  # 此处应为super(DeformConv_3x3, self).__init__()
        # 偏移量预测网络：固定使用3×3卷积（无论输入kernel_size如何）
        self.offset_net = nn.Conv2d(
            in_channels=in_channels,
            out_channels=2 * kernel_size[0] * kernel_size[1],
            kernel_size=3,  # 固定核大小为3×3
            padding=1,
            stride=1,
            bias=True
        )
        # 可变形卷积层（与标准版一致）
        self.deform_conv = torchvision.ops.DeformConv2d(
            in_channels=in_channels,
            out_channels=in_channels,
            kernel_size=kernel_size,
            padding=padding,
            groups=groups,
            stride=stride,
            dilation=dilation,
            bias=False
        )

    def forward(self, x):
        offsets = self.offset_net(x)
        out = self.deform_conv(x, offsets)
        return out


class DeformConv_experimental(nn.Module):
    """实验版可变形卷积：增加通道调整层，优化偏移量预测精度
    改进点：先通过1×1卷积调整通道数，再用深度可分离卷积预测偏移量，增强偏移量与特征的关联性
    """

    def __init__(self, in_channels, groups, kernel_size=(3, 3), padding=1, stride=1, dilation=1, bias=True):
        super(DeformConv_experimental, self).__init__()
        # 通道调整层：将输入通道数转为偏移量所需通道数（2×k_h×k_w）
        self.conv_channel_adjust = nn.Conv2d(
            in_channels=in_channels,
            out_channels=2 * kernel_size[0] * kernel_size[1],
            kernel_size=(1, 1)  # 1×1卷积仅调整通道，不改变空间维度
        )
        # 偏移量预测网络：使用深度可分离卷积（groups=输出通道数），降低计算量
        self.offset_net = nn.Conv2d(
            in_channels=2 * kernel_size[0] * kernel_size[1],
            out_channels=2 * kernel_size[0] * kernel_size[1],
            kernel_size=3,
            padding=1,
            stride=1,
            groups=2 * kernel_size[0] * kernel_size[1],  # 深度可分离：每个通道独立卷积
            bias=True
        )
        # 可变形卷积层（与标准版一致）
        self.deform_conv = torchvision.ops.DeformConv2d(
            in_channels=in_channels,
            out_channels=in_channels,
            kernel_size=kernel_size,
            padding=padding,
            groups=groups,
            stride=stride,
            dilation=dilation,
            bias=False
        )

    def forward(self, x):
        x_chan = self.conv_channel_adjust(x)  # 步骤1：调整通道数适配偏移量预测
        offsets = self.offset_net(x_chan)  # 步骤2：深度可分离卷积预测偏移量
        out = self.deform_conv(x, offsets)  # 步骤3：可变形卷积特征增强
        return out


class deformable_LKA(nn.Module):
    """可变形LKA（Large Kernel Attention）模块：结合可变形卷积与大核注意力，增强长距离空间建模
    核心逻辑：通过多尺度可变形卷积捕捉不同范围空间特征，生成注意力权重并作用于原始输入
    """

    def __init__(self, dim):
        super().__init__()
        # 第一层可变形卷积：5×5核，分组卷积（groups=dim），捕捉中距离空间特征
        self.conv0 = DeformConv(dim, kernel_size=(5, 5), padding=2, groups=dim)
        # 第二层可变形卷积：7×7大核+ dilation=3（膨胀卷积），扩大感受野至21×21（7+3×(7-1)）
        self.conv_spatial = DeformConv(
            dim,
            kernel_size=(7, 7),
            stride=1,
            padding=9,  # 适配膨胀卷积的padding：(7-1)*3//2 = 9
            groups=dim,
            dilation=3  # 膨胀率3，提升长距离空间建模能力
        )
        # 1×1卷积：融合多尺度特征，输出注意力权重
        self.conv1 = nn.Conv2d(dim, dim, 1)

    def forward(self, x):
        u = x.clone()  # 保存原始输入（用于后续注意力加权）
        attn = self.conv0(x)  # 步骤1：中距离空间特征提取
        attn = self.conv_spatial(attn)  # 步骤2：长距离空间特征提取（大核+膨胀）
        attn = self.conv1(attn)  # 步骤3：特征融合生成注意力权重
        return u * attn  # 步骤4：注意力加权原始输入，增强关键空间特征


class deformable_LKA_experimental(nn.Module):
    """实验版可变形LKA：使用实验版可变形卷积（DeformConv_experimental）优化偏移量预测
    功能与deformable_LKA一致，仅替换可变形卷积实现版本
    """

    def __init__(self, dim):
        super().__init__()
        self.conv0 = DeformConv_experimental(dim, kernel_size=(5, 5), padding=2, groups=dim)
        self.conv_spatial = DeformConv_experimental(
            dim,
            kernel_size=(7, 7),
            stride=1,
            padding=9,
            groups=dim,
            dilation=3
        )
        self.conv1 = nn.Conv2d(dim, dim, 1)

    def forward(self, x):
        u = x.clone()
        attn = self.conv0(x)
        attn = self.conv_spatial(attn)
        attn = self.conv1(attn)
        return u * attn


class deformable_LKA_Attention(nn.Module):
    """可变形LKA注意力封装：添加残差连接与特征投影，适配网络集成
    结构：1×1投影→激活→可变形LKA→1×1投影→残差连接，增强特征表达与训练稳定性
    """

    def __init__(self, d_model):
        super().__init__()
        self.proj_1 = nn.Conv2d(d_model, d_model, 1)  # 特征投影1：调整通道分布
        self.activation = nn.GELU()  # 激活函数：引入非线性，缓解梯度消失
        self.spatial_gating_unit = deformable_LKA(d_model)  # 空间门控单元：可变形LKA
        self.proj_2 = nn.Conv2d(d_model, d_model, 1)  # 特征投影2：融合门控结果

    def forward(self, x):
        shorcut = x.clone()  # 残差连接：保存输入用于后续相加
        x = self.proj_1(x)  # 步骤1：特征投影调整
        x = self.activation(x)  # 步骤2：非线性激活
        x = self.spatial_gating_unit(x)  # 步骤3：可变形LKA空间注意力
        x = self.proj_2(x)  # 步骤4：特征投影融合
        x = x + shorcut  # 步骤5：残差连接，稳定训练
        return x


class deformable_LKA_Attention_experimental(nn.Module):
    """实验版可变形LKA注意力：使用实验版可变形LKA（deformable_LKA_experimental）
    功能与deformable_LKA_Attention一致，仅替换空间门控单元实现版本
    """

    def __init__(self, d_model):
        super().__init__()
        self.proj_1 = nn.Conv2d(d_model, d_model, 1)
        self.activation = nn.GELU()
        self.spatial_gating_unit = deformable_LKA_experimental(d_model)  # 实验版LKA
        self.proj_2 = nn.Conv2d(d_model, d_model, 1)

    def forward(self, x):
        shorcut = x.clone()
        x = self.proj_1(x)
        x = self.activation(x)
        x = self.spatial_gating_unit(x)
        x = self.proj_2(x)
        x = x + shorcut
        return x


from fvcore.nn import FlopCountAnalysis

if __name__ == '__main__':
    input = torch.rand(1, 96, 56, 56).cuda(0)
    lka_layer_exp = deformable_LKA_Attention_experimental(d_model=96).cuda(0)
    lka_layer = deformable_LKA_Attention(d_model=96).cuda(0)

    output = lka_layer(input)

    flops = FlopCountAnalysis(lka_layer, input)
    flops_exp = FlopCountAnalysis(lka_layer_exp, input)

    n_parameters = sum(p.numel() for p in lka_layer.parameters() if p.requires_grad)
    n_parameters_exp = sum(p.numel() for p in lka_layer_exp.parameters() if p.requires_grad)

    model_flops = flops.total()
    model_flops_exp = flops_exp.total()

    print("微信公众号：十小大的底层视觉工坊")
    print("知乎、CSDN：十小大")

    print(f"Total trainable parameters: {round(n_parameters * 1e-3, 4)} K")
    print(f"MAdds: {round(model_flops * 1e-6, 4)} M")
    print(f"Total trainable parameters exp: {round(n_parameters_exp * 1e-3, 4)} K")
    print(f"MAdds exp: {round(model_flops_exp * 1e-6, 4)} M")

    print(f"输入特征维度： {input.shape}")
    print(f"输出特征维度: {output.shape}")