# 解耦注意力模块（Decoupled Attention Modules, DAM）
# 核心设计：针对RGB-深度双模态融合场景，通过“双模态解耦注意力+跨模态引导+多策略融合”的流程，
# 分别对RGB与深度模态进行独立注意力增强，再通过跨模态注意力引导与“逐元素乘+通道最大”双策略融合，
# 强化双模态的互补信息，抑制冗余干扰，提升融合特征的辨识度与鲁棒性


import torch
import torch.nn as nn


class h_sigmoid(nn.Module):
    def __init__(self, inplace=True):
        super(h_sigmoid, self).__init__()
        self.relu = nn.ReLU6(inplace=inplace)

    def forward(self, x):
        return self.relu(x + 3) / 6


class h_swish(nn.Module):
    def __init__(self, inplace=True):
        super(h_swish, self).__init__()
        self.sigmoid = h_sigmoid(inplace=inplace)

    def forward(self, x):
        return x * self.sigmoid(x)


class SA_Enhance(nn.Module):
    def __init__(self, kernel_size=7):
        super(SA_Enhance, self).__init__()

        assert kernel_size in (3, 7), 'kernel size must be 3 or 7'
        padding = 3 if kernel_size == 7 else 1

        self.conv1 = nn.Conv2d(1, 1, kernel_size, padding=padding, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        max_out, _ = torch.max(x, dim=1, keepdim=True)
        x = max_out
        x = self.conv1(x)
        return self.sigmoid(x)


class CoordAtt(nn.Module):
    """
    坐标注意力模块：同时捕捉通道依赖与空间坐标信息
    功能：通过行列池化提取长程依赖，生成通道-坐标关联的注意力权重
    核心设计：
        - 双池化策略：自适应行列池化，分别捕捉水平/垂直方向依赖
        - 轻量通道投影：1×1卷积降维，降低计算成本
        - 双注意力输出：生成水平/垂直方向注意力，动态调制特征
    Args:
        inp: 输入通道数
        oup: 输出通道数
        reduction: 通道压缩比例（默认2，平衡效率与表达）
    """
    def __init__(self, inp, oup, reduction=2):
        super(CoordAtt, self).__init__()
        self.pool_h = nn.AdaptiveAvgPool2d((None, 1))
        self.pool_w = nn.AdaptiveAvgPool2d((1, None))

        mip = max(8, inp // reduction)

        self.conv1 = nn.Conv2d(inp, mip, kernel_size=1, stride=1, padding=0)
        self.bn1 = nn.BatchNorm2d(mip)
        self.act = h_swish()

        self.conv_h = nn.Conv2d(mip, oup, kernel_size=1, stride=1, padding=0)
        self.conv_w = nn.Conv2d(mip, oup, kernel_size=1, stride=1, padding=0)

    def forward(self, x):
        identity = x

        n, c, h, w = x.size()
        x_h = self.pool_h(x)
        x_w = self.pool_w(x).permute(0, 1, 3, 2)

        y = torch.cat([x_h, x_w], dim=2)
        y = self.conv1(y)
        y = self.bn1(y)
        y = self.act(y)

        x_h, x_w = torch.split(y, [h, w], dim=2)
        x_w = x_w.permute(0, 1, 3, 2)

        a_h = self.conv_h(x_h).sigmoid()
        a_w = self.conv_w(x_w).sigmoid()

        out = identity * a_w * a_h

        return out


class DAM(nn.Module):
    """
    解耦注意力模块（Decoupled Attention Modules, DAM）
    功能：RGB-深度双模态解耦注意力增强与融合，强化模态互补性
    核心设计：
        - 双模态解耦注意力：RGB与深度模态分别经CoordAtt独立增强，保留模态特性
        - 跨模态引导：用深度模态注意力引导RGB特征，RGB注意力引导深度特征，强化模态关联
        - 双策略融合：逐元素乘（强化共性）+ 通道最大（保留强响应），融合效果更全面
        - 轻量输出投影：1×1卷积整合融合特征，适配后续任务
    Args:
        inch: 输入模态通道数（RGB与深度模态通道数需一致）
        outch: 输出融合特征通道数
    """
    def __init__(self, inch, outch):
        super(DAM, self).__init__()
        self.rgb_att = CoordAtt(inch, inch)
        self.depth_att = CoordAtt(inch, inch)
        self.self_SA_Enhance = SA_Enhance()
        self.conv_trnas = nn.Conv2d(inch * 2, outch, 1, 1, 0)

    def forward(self, rgb, depth):
        identify_rgb = rgb
        identify_depth = depth

        rgb_att = self.self_SA_Enhance(self.rgb_att(rgb))
        depth_att = self.self_SA_Enhance(self.depth_att(depth))

        identify_rgb = identify_rgb * depth_att
        identify_depth = identify_depth * rgb_att

        ful_mul = torch.mul(identify_rgb, identify_depth)
        x_in1 = torch.reshape(identify_rgb, [identify_rgb.shape[0], 1, identify_rgb.shape[1], identify_rgb.shape[2],
                                             identify_rgb.shape[3]])
        x_in2 = torch.reshape(identify_depth,
                              [identify_depth.shape[0], 1, identify_depth.shape[1], identify_depth.shape[2],
                               identify_depth.shape[3]])
        x_cat = torch.cat((x_in1, x_in2), dim=1)
        ful_max = x_cat.max(dim=1)[0]

        out = self.conv_trnas(torch.cat([ful_mul, ful_max], dim=1))
        return out


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    rgb = torch.randn(1, 64, 32, 32).to(device)
    depth = torch.randn(1, 64, 32, 32).to(device)
    model = DAM(64, 64).to(device)

    y = model(rgb, depth)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("小红书：十小大，主页获取往期全部即插即用代码，200+大合集")

    print("输入rgb特征维度：", rgb.shape)
    print("输入depth特征维度：", depth.shape)
    print("输出特征维度：", y.shape)