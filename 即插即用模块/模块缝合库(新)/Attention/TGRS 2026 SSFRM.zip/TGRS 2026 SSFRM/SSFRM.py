import torch
from torch import nn
import torch.nn.functional as F


# ---------- SSFRM 辅助组件 -------------
class SpatialAttention(nn.Module):
    """空间相似度注意力模块：计算两个空间特征向量的相似度，生成空间注意力权重
    对应结构图4中Linear+矩阵乘法+Sigmoid+加权的流程
    输入维度由stage参数动态决定，适配不同分辨率的特征图
    """

    def __init__(self, in_dim1, in_dim2):
        super(SpatialAttention, self).__init__()
        # 将深层特征的空间维度映射到浅层特征的空间维度，实现维度对齐
        self.linear = nn.Linear(in_dim1, in_dim2)

    def forward(self, x1, x2):
        # x1: 深层解码器的空间特征向量 [B, 1, in_dim1]
        # x2: 浅层编码器的空间特征向量 [B, 1, in_dim2]
        x1_transformed = self.linear(x1)  # 维度对齐: [B, 1, in_dim2]

        # 计算空间相似度矩阵: 转置相乘得到两两像素的相似度
        attention_scores = torch.bmm(x2.transpose(1, 2), x1_transformed)  # [B, in_dim2, in_dim2]
        attention_weights = F.softmax(attention_scores, dim=-1)  # 归一化得到注意力权重

        # 用相似度权重加权浅层空间特征
        weighted_x2 = torch.bmm(x2, attention_weights)  # [B, 1, in_dim2]
        return weighted_x2


class Relation_Refine(nn.Module):
    """Semantic-Spatial Feature Refinement Module (SSFRM) 核心模块
    双分支并行架构：分组语义提纯分支 + 分组空间提纯分支
    输入：x1(深层解码器特征)、x2(浅层编码器特征)
    输出：提纯后的融合特征，维度与x2完全一致
    对应论文图3(语义提纯)和图4(空间提纯)的完整流程
    """

    def __init__(self, in_channels1, in_channels2, stage, groups1=8, groups2=16):
        super(Relation_Refine, self).__init__()
        self.groups1 = groups1  # 语义分支的通道分组数M
        self.groups2 = groups2  # 空间分支的空间分组数N²（N=4时为16）

        # 全局平均池化：提取每个通道组的全局语义统计特征
        self.gap1 = nn.AdaptiveAvgPool2d(1)
        self.gap2 = nn.AdaptiveAvgPool2d(1)

        # 1x1 Conv1d替代Linear，实现通道维度映射，适配分组计算
        self.Conv1 = nn.Sequential(
            nn.Conv1d(in_channels1 // groups1, in_channels2 // groups1, kernel_size=1),
            nn.ReLU()
        )
        self.Conv2 = nn.Sequential(
            nn.Conv1d(in_channels2 // groups1, in_channels2 // groups1, kernel_size=1),
            nn.ReLU()
        )

        # 空间分支：1x1卷积压缩通道维度，提取单通道空间位置特征
        self.conv1 = nn.Conv2d(in_channels1, 1, kernel_size=1)
        self.conv2 = nn.Conv2d(in_channels2, 1, kernel_size=1)

        # 最终融合层：统一特征分布，提升非线性表达能力
        self.convbnrelu = nn.Sequential(
            nn.Conv2d(in_channels2, in_channels2, kernel_size=1),
            nn.BatchNorm2d(in_channels2),
            nn.ReLU()
        )

        # stage参数：适配不同分辨率的特征图，自动设置空间注意力的维度
        # stage=4: 最高分辨率特征图(H/16, W/16)；stage=1: 最低分辨率特征图(H/2, W/2)
        self.stage = stage
        if self.stage == 4:
            self.sa = SpatialAttention(4, 16)
        elif self.stage == 3:
            self.sa = SpatialAttention(16, 64)
        elif self.stage == 2:
            self.sa = SpatialAttention(64, 256)
        elif self.stage == 1:
            self.sa = SpatialAttention(256, 1024)

    def forward(self, x1, x2):
        # x1: 深层解码器特征 (B, in_channels1, H1, W1)
        # x2: 浅层编码器特征 (B, in_channels2, H2, W2)
        B, C1, H1, W1 = x1.size()
        B, C2, H2, W2 = x2.size()

        # -------------------------- 分支1：分组语义提纯（对应论文图3） --------------------------
        sem_refine_x2_list = []
        c1_group = C1 // self.groups1  # 每个通道组的通道数
        c2_group = C2 // self.groups1

        # 按通道维度切分为M个独立的组，组内计算语义相似度
        for i in range(self.groups1):
            # 切分得到第i个通道组的特征
            x1_group = x1[:, i * c1_group: (i + 1) * c1_group, :, :]
            x2_group = x2[:, i * c2_group: (i + 1) * c2_group, :, :]

            # Squeeze阶段：全局平均池化提取组内全局语义特征
            gap1 = self.gap1(x1_group).view(B, c1_group, -1)  # (B, c1_group, 1)
            gap2 = self.gap2(x2_group).view(B, c2_group, -1)  # (B, c2_group, 1)

            # 通道维度映射，实现深浅特征的语义维度对齐
            mlp1 = self.Conv1(gap1)  # (B, c2_group, 1)
            mlp2 = self.Conv2(gap2)  # (B, c2_group, 1)

            # 计算跨模态语义相似度矩阵：深层语义引导浅层语义
            sem_matrix = torch.bmm(mlp1, mlp2.transpose(1, 2))  # (B, c2_group, c2_group)

            # 生成通道注意力权重：Softmax归一化后得到每个通道的重要性
            channel_weight = torch.softmax(torch.bmm(sem_matrix, mlp2), dim=1)
            channel_weight = channel_weight.view(B, c2_group, 1, 1)  # 重塑为广播格式

            # 用语义权重加权浅层通道组特征，实现语义提纯
            sem_refine_x2 = x2_group * channel_weight
            sem_refine_x2_list.append(sem_refine_x2)

        # 拼接所有通道组的提纯特征，恢复完整通道维度
        sem_refine_x2 = torch.cat(sem_refine_x2_list, dim=1)

        # -------------------------- 分支2：分组空间提纯（对应论文图4） --------------------------
        spa_refine_x2_list = []
        # 计算每个空间子区域的尺寸
        split_size_h1 = H1 // self.groups2
        split_size_w1 = W1 // self.groups2
        split_size_h2 = H2 // self.groups2
        split_size_w2 = W2 // self.groups2

        # 按空间位置切分为N²个独立的子区域，子区域内计算空间相似度
        for i in range(self.groups2):
            for j in range(self.groups2):
                # 切分得到第(i,j)个空间子区域的特征
                x1_group = x1[:, :, i * split_size_h1:(i + 1) * split_size_h1,
                           j * split_size_w1:(j + 1) * split_size_w1]
                x2_group = x2[:, :, i * split_size_h2:(i + 1) * split_size_h2,
                           j * split_size_w2:(j + 1) * split_size_w2]

                # 压缩通道维度为1，提取单通道空间位置特征
                pos1 = self.conv1(x1_group).view(B, 1, -1)  # (B, 1, h1*w1)
                pos2 = self.conv2(x2_group).view(B, 1, -1)  # (B, 1, h2*w2)

                # 计算空间相似度，用深层空间特征引导浅层空间特征提纯
                spa_refine_x2 = self.sa(pos1, pos2)
                spa_refine_x2_list.append(spa_refine_x2)

        # 拼接所有空间子区域的提纯特征，重塑为2D特征图
        spa_refine_x2 = torch.cat(spa_refine_x2_list, dim=2).view(B, 1, H2, W2)

        # -------------------------- 语义-空间特征融合 --------------------------
        # 逐元素相加融合两个分支的提纯特征
        fuse_feature = self.convbnrelu(sem_refine_x2 + spa_refine_x2)
        return fuse_feature


# Relation_Refine2与Relation_Refine完全一致，为作者预留的备份版本，实际使用时二选一即可
class Relation_Refine2(nn.Module):
    def __init__(self, in_channels1, in_channels2, stage, groups1=8, groups2=16):
        super(Relation_Refine2, self).__init__()
        self.groups1 = groups1
        self.groups2 = groups2
        self.gap1 = nn.AdaptiveAvgPool2d(1)
        self.gap2 = nn.AdaptiveAvgPool2d(1)
        self.Conv1 = nn.Sequential(
            nn.Conv1d(in_channels1 // groups1, in_channels2 // groups1, kernel_size=1),
            nn.ReLU()
        )
        self.Conv2 = nn.Sequential(
            nn.Conv1d(in_channels2 // groups1, in_channels2 // groups1, kernel_size=1),
            nn.ReLU()
        )
        self.conv1 = nn.Conv2d(in_channels1, 1, kernel_size=1)
        self.conv2 = nn.Conv2d(in_channels2, 1, kernel_size=1)
        self.convbnrelu = nn.Sequential(
            nn.Conv2d(in_channels2, in_channels2, kernel_size=1),
            nn.BatchNorm2d(in_channels2),
            nn.ReLU()
        )
        self.stage = stage
        if self.stage == 4:
            self.sa = SpatialAttention(4, 16)
        elif self.stage == 3:
            self.sa = SpatialAttention(16, 64)
        elif self.stage == 2:
            self.sa = SpatialAttention(64, 256)
        elif self.stage == 1:
            self.sa = SpatialAttention(256, 1024)

    def forward(self, x1, x2):
        B, C1, H1, W1 = x1.size()
        B, C2, H2, W2 = x2.size()

        sem_refine_x2_list = []
        c1_group = C1 // self.groups1
        c2_group = C2 // self.groups1
        for i in range(self.groups1):
            x1_group = x1[:, i * c1_group: (i + 1) * c1_group, :, :]
            x2_group = x2[:, i * c2_group: (i + 1) * c2_group, :, :]
            gap1 = self.gap1(x1_group).view(B, c1_group, -1)
            gap2 = self.gap2(x2_group).view(B, c2_group, -1)
            mlp1 = self.Conv1(gap1)
            mlp2 = self.Conv2(gap2)
            sem_matrix = torch.bmm(mlp1, mlp2.transpose(1, 2))
            channel_weight = torch.softmax(torch.bmm(sem_matrix, mlp2), dim=1)
            channel_weight = channel_weight.view(B, c2_group, 1, 1)
            sem_refine_x2 = x2_group * channel_weight
            sem_refine_x2_list.append(sem_refine_x2)
        sem_refine_x2 = torch.cat(sem_refine_x2_list, dim=1)

        spa_refine_x2_list = []
        split_size_h1 = H1 // self.groups2
        split_size_w1 = W1 // self.groups2
        split_size_h2 = H2 // self.groups2
        split_size_w2 = W2 // self.groups2
        for i in range(self.groups2):
            for j in range(self.groups2):
                x1_group = x1[:, :, i * split_size_h1:(i + 1) * split_size_h1,
                           j * split_size_w1:(j + 1) * split_size_w1]
                x2_group = x2[:, :, i * split_size_h2:(i + 1) * split_size_h2,
                           j * split_size_w2:(j + 1) * split_size_w2]
                pos1 = self.conv1(x1_group).view(B, 1, -1)
                pos2 = self.conv2(x2_group).view(B, 1, -1)
                spa_refine_x2 = self.sa(pos1, pos2)
                spa_refine_x2_list.append(spa_refine_x2)
        spa_refine_x2 = torch.cat(spa_refine_x2_list, dim=2).view(B, 1, H2, W2)

        fuse_feature = self.convbnrelu(sem_refine_x2 + spa_refine_x2)
        return fuse_feature


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    x1 = torch.randn(1, 32, 32, 32).to(device)  # 深层解码器特征
    x2 = torch.randn(1, 64, 64, 64).to(device)  # 浅层编码器特征
    model = Relation_Refine(32, 64, 4).to(device)
    y = model(x1, x2)
    print("输入x1维度：", x1.shape)
    print("输入x2维度：", x2.shape)
    print("输出特征维度：", y.shape)