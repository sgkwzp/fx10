import torch
import torch.nn as nn


class _RepDWLite(nn.Module):
    """
    Lightweight re-parameterized depthwise composition:
    DW(1xK) -> DW(Kx1) + DW(3x3) + DW(1x1 ~ identity)
    """
    def __init__(self, dim: int, K: int, stride: int = 1):
        super().__init__()

        # separable large-kernel approximation
        self.dw_h = nn.Conv2d(
            dim, dim, kernel_size=(1, K),
            stride=(1, stride), padding=(0, K // 2),
            groups=dim, bias=False
        )
        self.dw_v = nn.Conv2d(
            dim, dim, kernel_size=(K, 1),
            stride=(stride, 1), padding=(K // 2, 0),
            groups=dim, bias=False
        )

        # complementary 3x3 + identity-like DW(1x1)
        self.dw_s = nn.Conv2d(
            dim, dim, kernel_size=3,
            stride=stride, padding=1, dilation=1,
            groups=dim, bias=False
        )
        self.dw_i = nn.Conv2d(
            dim, dim, kernel_size=1,
            stride=stride, groups=dim, bias=False
        )
        nn.init.dirac_(self.dw_i.weight)  # start as identity

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.dw_v(self.dw_h(x)) + self.dw_s(x) + self.dw_i(x)


class MSInit(nn.Module):

    def __init__(self, in_ch: int, out_ch: int, k_list=(3,5,7), stride: int = 1, use_gn: bool = True):
        super().__init__()
        # equal split for branches
        self.branches = nn.ModuleList([
            nn.Sequential(
                _RepDWLite(in_ch, K=k, stride=stride),
                nn.Conv2d(in_ch, out_ch // len(k_list), 1, bias=False)
            ) for k in k_list
        ])

        # handle remainder channels
        gap = out_ch - (out_ch // len(k_list)) * len(k_list)
        self.tail = nn.Identity() if gap == 0 else nn.Sequential(
            _RepDWLite(in_ch, K=k_list[0], stride=stride),
            nn.Conv2d(in_ch, gap, 1, bias=False)
        )

        self.fuse = nn.Identity()
        self.norm = nn.GroupNorm(1, out_ch) if use_gn else nn.Identity()
        self.act = nn.GELU()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        parts = [b(x) for b in self.branches]
        if not isinstance(self.tail, nn.Identity):
            parts.append(self.tail(x))
        y = torch.cat(parts, dim=1)
        return self.act(self.norm(y))


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 64, 32, 32).to(device)
    model = MSInit(64, 64).to(device)

    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)