import torch
import torch.nn as nn
import torch.nn.functional as F


class LayerNormFunction(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x, weight, bias, eps):
        ctx.eps = eps
        N, C, H, W = x.size()
        mu = x.mean(1, keepdim=True)
        var = (x - mu).pow(2).mean(1, keepdim=True)
        y = (x - mu) / (var + eps).sqrt()
        ctx.save_for_backward(y, var, weight)
        y = weight.view(1, C, 1, 1) * y + bias.view(1, C, 1, 1)
        return y

    @staticmethod
    def backward(ctx, grad_output):
        eps = ctx.eps

        N, C, H, W = grad_output.size()
        y, var, weight = ctx.saved_variables
        g = grad_output * weight.view(1, C, 1, 1)
        mean_g = g.mean(dim=1, keepdim=True)

        mean_gy = (g * y).mean(dim=1, keepdim=True)
        gx = 1. / torch.sqrt(var + eps) * (g - y * mean_gy - mean_g)
        return gx, (grad_output * y).sum(dim=3).sum(dim=2).sum(dim=0), grad_output.sum(dim=3).sum(dim=2).sum(
            dim=0), None


class LayerNorm2d(nn.Module):
    def __init__(self, channels, eps=1e-6):
        super(LayerNorm2d, self).__init__()
        self.register_parameter('weight', nn.Parameter(torch.ones(channels)))
        self.register_parameter('bias', nn.Parameter(torch.zeros(channels)))
        self.eps = eps

    def forward(self, x):
        return LayerNormFunction.apply(x, self.weight, self.bias, self.eps)


class MFIB(nn.Module):
    """
    多分支特征整合模块（Multibranch Feature Integration Block, MFIB）
    功能：多维度分支增强+动态权重融合，强化特征的空间-通道协同表达
    核心设计：
        - 四分支并行增强：HW（空间）、CH（通道-高度）、CW（通道-宽度）、点卷积分支，覆盖不同维度特征依赖
        - 动态权重分配：基于特征全局统计生成分支权重，自适应平衡各分支贡献
        - 轻量化增强：深度卷积+点卷积，降低计算成本
        - 残差融合：MLP增强后与原始特征残差相加，保留基础信息
    Args:
        dim: 输入/输出通道数
        x/y: 初始分支特征尺寸（默认8×8）
        bias: 卷积是否带偏置（默认False）
    """
    def __init__(self, dim, x=8, y=8, bias=False):
        super(MFIB, self).__init__()

        partial_dim = int(dim // 4)
        # 动态权重生成器
        self.weight_generator = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(dim, 4, kernel_size=1),
            nn.Softmax(dim=1)
        )
        self.hw = nn.Parameter(torch.ones(1, partial_dim, x, y), requires_grad=True)
        self.conv_hw = nn.Conv2d(partial_dim, partial_dim, kernel_size=3, padding=1, groups=partial_dim, bias=bias)

        self.ch = nn.Parameter(torch.ones(1, 1, partial_dim, x), requires_grad=True)
        self.conv_ch = nn.Conv1d(partial_dim, partial_dim, kernel_size=3, padding=1, groups=partial_dim, bias=bias)

        self.cw = nn.Parameter(torch.ones(1, 1, partial_dim, y), requires_grad=True)
        self.conv_cw = nn.Conv1d(partial_dim, partial_dim, kernel_size=3, padding=1, groups=partial_dim, bias=bias)

        self.conv_4 = nn.Conv2d(partial_dim, partial_dim, kernel_size=1, bias=bias)

        self.norm1 = LayerNorm2d(dim)
        self.norm2 = LayerNorm2d(dim)

        # 使用 Swish 激活函数代替 ReLU
        self.mlp = nn.Sequential(
            nn.Conv2d(dim, dim, kernel_size=3, padding=1, groups=dim, bias=bias),
            nn.SiLU(),
            nn.Conv2d(dim, dim, kernel_size=1, bias=bias),
        )


    def forward(self, x):
        input_ = x
        x = self.norm1(x)
        x1, x2, x3, x4 = torch.chunk(x, 4, dim=1)
        # 动态权重计算
        weights = self.weight_generator(x)  # [B,4,1,1]
        w1, w2, w3, w4 = torch.chunk(weights, 4, dim=1)
        # HW分支
        hw_scale = F.interpolate(self.hw, size=x1.shape[2:4], mode='bilinear')
        x1 = x1 * w1 * self.conv_hw(hw_scale)

        # CH分支
        x2 = x2.permute(0, 3, 1, 2)
        ch_scale = F.interpolate(self.ch, size=x2.shape[2:4], mode='bilinear').squeeze(0)
        x2 = x2 * w2 * self.conv_ch(ch_scale).unsqueeze(0)
        x2 = x2.permute(0, 2, 3, 1)

        # CW分支
        x3 = x3.permute(0, 2, 1, 3)
        cw_scale = F.interpolate(self.cw, size=x3.shape[2:4], mode='bilinear').squeeze(0)
        x3 = x3 * w3 * self.conv_cw(cw_scale).unsqueeze(0)
        x3 = x3.permute(0, 2, 1, 3)

        # 点卷积分支
        x4 = x4 * w4 * self.conv_4(x4)

        x = torch.cat([x1, x2, x3, x4], dim=1)
        x = self.norm2(x)
        x = self.mlp(x) + input_
        return x


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 64, 32, 32).to(device)
    model = MFIB(64).to(device)

    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN、小红书：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)