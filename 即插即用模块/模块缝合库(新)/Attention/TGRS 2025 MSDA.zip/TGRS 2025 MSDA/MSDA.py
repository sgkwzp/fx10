import torch
import torch.nn as nn
import pywt
from torch.nn import init
from torch.autograd import Function


def weights_init(m):
    if isinstance(m, nn.Conv2d):
        nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
        if m.bias is not None:
            nn.init.constant_(m.bias, 0)
    elif isinstance(m, nn.BatchNorm2d):
        nn.init.constant_(m.weight, 1)
        nn.init.constant_(m.bias, 0)
    return


class SEAttention(nn.Module):
    """
    通道注意力模块（Squeeze-and-Excitation Attention）
    功能：通过全局池化与MLP，生成通道注意力权重，筛选关键通道
    核心设计：
        - 轻量化MLP：通道压缩-恢复，降低计算成本
        - 自适应权重：基于特征全局统计生成权重，适配不同特征分布
    Args:
        channel: 输入通道数
        reduction: 通道压缩比例（默认4）
    """
    def __init__(self, channel, reduction=4):
        super().__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(
            nn.Linear(channel, channel // reduction, bias=False),
            nn.ReLU(inplace=True),
            nn.Linear(channel // reduction, channel, bias=False),
            nn.Sigmoid()
        )
        #  网络初始化
        self.fc.apply(weights_init)

    def forward(self, x):
        b, c, _, _ = x.size()
        y = self.avg_pool(x).view(b, c)
        y = self.fc(y).view(b, c, 1, 1)
        return x * y.expand_as(x)


class SpatialAttention(nn.Module):
    """
    空间注意力模块：生成空间注意力权重，定位关键空间区域
    Args:
        kernel_size: 卷积核大小（默认7）
    """
    def __init__(self, kernel_size=7):
        super().__init__()
        self.conv = nn.Conv2d(2, 1, kernel_size=kernel_size, padding=kernel_size // 2)
        self.sigmoid = nn.Sigmoid()
        #  网络初始化
        self.conv.apply(weights_init)

    def forward(self, x):
        max_result, _ = torch.max(x, dim=1, keepdim=True)
        avg_result = torch.mean(x, dim=1, keepdim=True)
        result = torch.cat([max_result, avg_result], 1)
        output = self.conv(result)
        output = self.sigmoid(output)
        return output


class LH_DWT_2D_attation(nn.Module):
    def __init__(self, wave):
        super(LH_DWT_2D_attation, self).__init__()
        w = pywt.Wavelet(wave)
        dec_hi = torch.Tensor(w.dec_hi[::-1])
        dec_lo = torch.Tensor(w.dec_lo[::-1])
        w_lh = dec_lo.unsqueeze(0) * dec_hi.unsqueeze(1)
        self.register_buffer('w_lh', w_lh.unsqueeze(0).unsqueeze(0))
        self.w_lh = self.w_lh.to(dtype=torch.float32)

    def forward(self, x):
        return LH_DWT_Function_attation.apply(x, self.w_lh)


class LH_DWT_Function_attation(Function):
    @staticmethod
    def forward(ctx, x, w_lh):
        x = x.contiguous()
        ctx.save_for_backward(w_lh)
        ctx.shape = x.shape
        dim = x.shape[1]
        x = torch.nn.functional.pad(x, (1, 0, 1, 0))
        x_lh = torch.nn.functional.conv2d(x, w_lh.expand(dim, -1, -1, -1), stride=1, padding=0, groups=dim)
        x = x_lh
        return x

    @staticmethod
    def backward(ctx, dx):
        if ctx.needs_input_grad[0]:
            w_lh = ctx.saved_tensors[0]
            B, C, H, W = ctx.shape
            dx = dx.view(B, 1, -1, H, W)
            dx = dx.transpose(1, 2).reshape(B, -1, H, W)
            filters = w_lh
            filters = filters.repeat(C, 1, 1, 1).to(dtype=torch.float16)
            dx = torch.nn.functional.conv_transpose2d(dx, filters, stride=1, groups=C)
            dx = torch.cat((dx[:, :, :0], dx[:, :, 1:]), dim=2)
            dx = torch.cat((dx[:, :, :, :0], dx[:, :, :, 1:]), dim=3)
        return dx, None


class HL_DWT_2D_attation(nn.Module):
    def __init__(self, wave):
        super(HL_DWT_2D_attation, self).__init__()
        w = pywt.Wavelet(wave)
        dec_hi = torch.Tensor(w.dec_hi[::-1])
        dec_lo = torch.Tensor(w.dec_lo[::-1])

        w_hl = dec_hi.unsqueeze(0) * dec_lo.unsqueeze(1)

        self.register_buffer('w_hl', w_hl.unsqueeze(0).unsqueeze(0))
        self.w_hl = self.w_hl.to(dtype=torch.float32)

    def forward(self, x):
        return HL_DWT_Function_attation.apply(x, self.w_hl)


class HL_DWT_Function_attation(Function):
    @staticmethod
    def forward(ctx, x, w_hl):
        x = x.contiguous()
        ctx.save_for_backward(w_hl)
        ctx.shape = x.shape
        dim = x.shape[1]
        x = torch.nn.functional.pad(x, (1, 0, 1, 0))
        x_hl = torch.nn.functional.conv2d(x, w_hl.expand(dim, -1, -1, -1), stride=1, padding=0, groups=dim)
        x = x_hl
        return x

    @staticmethod
    def backward(ctx, dx):
        if ctx.needs_input_grad[0]:
            w_hl = ctx.saved_tensors[0]
            B, C, H, W = ctx.shape
            dx = dx.view(B, 1, -1, H, W)
            dx = dx.transpose(1, 2).reshape(B, -1, H, W)
            filters = w_hl
            filters = filters.repeat(C, 1, 1, 1).to(dtype=torch.float16)
            dx = torch.nn.functional.conv_transpose2d(dx, filters, stride=1, groups=C)
            dx = torch.cat((dx[:, :, :0], dx[:, :, 1:]), dim=2)
            dx = torch.cat((dx[:, :, :, :0], dx[:, :, :, 1:]), dim=3)
        return dx, None

class HH_DWT_2D_attation(nn.Module):
    def __init__(self, wave):
        super(HH_DWT_2D_attation, self).__init__()
        w = pywt.Wavelet(wave)
        dec_hi = torch.Tensor(w.dec_hi[::-1])
        dec_lo = torch.Tensor(w.dec_lo[::-1])
        w_hh = dec_hi.unsqueeze(0) * dec_hi.unsqueeze(1)
        self.register_buffer('w_hh', w_hh.unsqueeze(0).unsqueeze(0))
        self.w_hh = self.w_hh.to(dtype=torch.float32)

    def forward(self, x):
        return HH_DWT_Function_attation.apply(x, self.w_hh)


class HH_DWT_Function_attation(Function):
    @staticmethod
    def forward(ctx, x, w_hh):
        x = x.contiguous()
        ctx.save_for_backward(w_hh)
        ctx.shape = x.shape
        dim = x.shape[1]
        x = torch.nn.functional.pad(x, (1, 0, 1, 0))
        x_hh = torch.nn.functional.conv2d(x, w_hh.expand(dim, -1, -1, -1), stride=1, padding=0,
                                          groups=dim)
        x = x_hh
        return x

    @staticmethod
    def backward(ctx, dx):
        if ctx.needs_input_grad[0]:
            w_hh = ctx.saved_tensors[0]
            B, C, H, W = ctx.shape
            dx = dx.view(B, 1, -1, H, W)
            dx = dx.transpose(1, 2).reshape(B, -1, H, W)
            filters = w_hh
            filters = filters.repeat(C, 1, 1, 1).to(dtype=torch.float16)
            dx = torch.nn.functional.conv_transpose2d(dx, filters, stride=1, groups=C)
            dx = torch.cat((dx[:, :, :0], dx[:, :, 1:]), dim=2)
            dx = torch.cat((dx[:, :, :, :0], dx[:, :, :, 1:]), dim=3)
        return dx, None


class LL_DWT_2D_attation(nn.Module):
    def __init__(self, wave):
        super(LL_DWT_2D_attation, self).__init__()
        w = pywt.Wavelet(wave)
        dec_hi = torch.Tensor(w.dec_hi[::-1])
        dec_lo = torch.Tensor(w.dec_lo[::-1])
        w_ll = dec_lo.unsqueeze(0) * dec_lo.unsqueeze(1)
        self.register_buffer('w_ll', w_ll.unsqueeze(0).unsqueeze(0))
        self.w_ll = self.w_ll.to(dtype=torch.float32)

    def forward(self, x):
        return LL_DWT_Function_attation.apply(x, self.w_ll)


class LL_DWT_Function_attation(Function):
    @staticmethod
    def forward(ctx, x, w_ll):
        x = x.contiguous()
        ctx.save_for_backward(w_ll)
        ctx.shape = x.shape
        dim = x.shape[1]
        x = torch.nn.functional.pad(x, (1, 0, 1, 0))
        x_ll = torch.nn.functional.conv2d(x, w_ll.expand(dim, -1, -1, -1), stride=1, padding=0,
                                          groups=dim)
        x = x_ll
        return x

    @staticmethod
    def backward(ctx, dx):
        if ctx.needs_input_grad[0]:
            w_ll = ctx.saved_tensors[0]
            B, C, H, W = ctx.shape
            dx = dx.view(B, 1, -1, H, W)
            dx = dx.transpose(1, 2).reshape(B, -1, H, W)
            filters = w_ll
            filters = filters.repeat(C, 1, 1, 1).to(dtype=torch.float16)
            dx = torch.nn.functional.conv_transpose2d(dx, filters, stride=1, groups=C)
            dx = torch.cat((dx[:, :, :0], dx[:, :, 1:]), dim=2)
            dx = torch.cat((dx[:, :, :, :0], dx[:, :, :, 1:]), dim=3)
        return dx, None


class FrequencyAttention(nn.Module):
    """
    频域方向注意力模块：基于小波分解，强化不同方向的频域特征
    核心设计：
        - 多方向分解：LL（低频）、LH（水平）、HL（垂直）、HH（对角线）
        - 空间注意力加权：每个频域分量单独经空间注意力筛选，精准强化关键方向
    Args:
        in_channel: 输入通道数
    """
    def __init__(self, in_channel):
        super().__init__()
        self.HH_reduce = SpatialAttention()
        self.LH_reduce = SpatialAttention()
        self.HL_reduce = SpatialAttention()
        self.LL_reduce = SpatialAttention()
        self.conv_res = nn.Sequential(
            nn.Conv2d(in_channel, in_channel, kernel_size=3, padding=1, stride=1),
            nn.BatchNorm2d(in_channel),
        )
        self.relu = nn.ReLU(inplace=False)
        self.LH_DWT_2D_attation = LH_DWT_2D_attation('haar')
        self.HL_DWT_2D_attation = HL_DWT_2D_attation('haar')
        self.HH_DWT_2D_attation = HH_DWT_2D_attation('haar')
        self.LL_DWT_2D_attation = LL_DWT_2D_attation('haar')
        self.init_weights()

    def forward(self, x):
        out_LH = self.LH_DWT_2D_attation(x)
        out_LH = self.LH_reduce(out_LH)
        x_LH = x * out_LH
        out_HL = self.HL_DWT_2D_attation(x)
        out_HL = self.HL_reduce(out_HL)
        x_HL = x * out_HL
        out_HH = self.HH_DWT_2D_attation(x)
        out_HH = self.HH_reduce(out_HH)
        x_HH = x * out_HH
        out_LL = self.LL_DWT_2D_attation(x)
        out_LL = self.LL_reduce(out_LL)
        x_LL = x * out_LL
        x_out = x_LH + x_HL + x_HH + x_LL
        x_out = self.relu(x + self.conv_res(x_out))
        return x_out

    def init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                init.kaiming_normal_(m.weight, mode='fan_out')
                if m.bias is not None:
                    init.constant_(m.bias, 0)
            elif isinstance(m, nn.BatchNorm2d):
                init.constant_(m.weight, 1)
                init.constant_(m.bias, 0)
            elif isinstance(m, nn.Linear):
                init.normal_(m.weight, std=0.001)
                if m.bias is not None:
                    init.constant_(m.bias, 0)


class DWT_2D(nn.Module):
    def __init__(self, wave):
        super(DWT_2D, self).__init__()
        w = pywt.Wavelet(wave)
        dec_hi = torch.Tensor(w.dec_hi[::-1])
        dec_lo = torch.Tensor(w.dec_lo[::-1])

        w_ll = dec_lo.unsqueeze(0) * dec_lo.unsqueeze(1)
        w_lh = dec_lo.unsqueeze(0) * dec_hi.unsqueeze(1)
        w_hl = dec_hi.unsqueeze(0) * dec_lo.unsqueeze(1)
        w_hh = dec_hi.unsqueeze(0) * dec_hi.unsqueeze(1)

        self.register_buffer('w_ll', w_ll.unsqueeze(0).unsqueeze(0))
        self.register_buffer('w_lh', w_lh.unsqueeze(0).unsqueeze(0))
        self.register_buffer('w_hl', w_hl.unsqueeze(0).unsqueeze(0))
        self.register_buffer('w_hh', w_hh.unsqueeze(0).unsqueeze(0))

        self.w_ll = self.w_ll.to(dtype=torch.float32)
        self.w_lh = self.w_lh.to(dtype=torch.float32)
        self.w_hl = self.w_hl.to(dtype=torch.float32)
        self.w_hh = self.w_hh.to(dtype=torch.float32)

    def forward(self, x):
        return DWT_Function.apply(x, self.w_ll, self.w_lh, self.w_hl, self.w_hh)


class DWT_Function(Function):
    @staticmethod
    def forward(ctx, x, w_ll, w_lh, w_hl, w_hh):
        x = x.contiguous()
        ctx.save_for_backward(w_ll, w_lh, w_hl, w_hh)
        ctx.shape = x.shape
        dim = x.shape[1]

        x_ll = torch.nn.functional.conv2d(x, w_ll.expand(dim, -1, -1, -1), stride=2, padding=0, groups=dim)
        x_lh = torch.nn.functional.conv2d(x, w_lh.expand(dim, -1, -1, -1), stride=2, padding=0, groups=dim)
        x_hl = torch.nn.functional.conv2d(x, w_hl.expand(dim, -1, -1, -1), stride=2, padding=0, groups=dim)
        x_hh = torch.nn.functional.conv2d(x, w_hh.expand(dim, -1, -1, -1), stride=2, padding=0,
                                          groups=dim)
        x = torch.cat([x_lh, x_hl, x_hh], dim=1)
        # x =  x_hh
        return x

    @staticmethod
    def backward(ctx, dx):
        if ctx.needs_input_grad[0]:
            w_ll, w_lh, w_hl, w_hh = ctx.saved_tensors
            B, C, H, W = ctx.shape

            dx = dx.view(B, 3, -1, H // 2, W // 2)
            dx = dx.transpose(1, 2).reshape(B, -1, H // 2, W // 2)
            filters = torch.cat([w_lh, w_hl, w_hh], dim=0)
            filters = filters.repeat(C, 1, 1, 1).to(dtype=torch.float16)
            dx = torch.nn.functional.conv_transpose2d(dx, filters, stride=2, groups=C)

        return dx, None, None, None, None


class BasicConv2d(nn.Module):
    def __init__(self, in_planes, out_planes, kernel_size, stride=1, padding=0, dilation=1):
        super(BasicConv2d, self).__init__()
        self.conv = nn.Conv2d(in_planes, out_planes,
                              kernel_size=kernel_size, stride=stride,
                              padding=padding, dilation=dilation, bias=False)
        self.bn = nn.BatchNorm2d(out_planes)
        self.relu = nn.ReLU(inplace=False)

    def forward(self, x):
        x = self.conv(x)
        x = self.bn(x)
        x = self.relu(x)
        return x


class MSDA(nn.Module):
    """
    多尺度方向感知模块（Multi-Scale Direction-Aware, MSDA）
    功能：多尺度卷积提取+频域方向增强+通道筛选，强化特征多维度表达
    核心设计：
        - 四分支多尺度提取：不同卷积核+膨胀率，覆盖不同尺度与感受野
        - 频域方向增强：FrequencyAttention捕捉多方向频域细节
        - 通道注意力筛选：SEAttention筛选关键通道，抑制冗余
        - 残差融合：保留原始特征，避免过度增强
    Args:
        in_channel: 输入通道数
        out_channel: 输出通道数
    """
    def __init__(self, in_channel, out_channel):
        super(MSDA, self).__init__()
        self.relu = nn.ReLU(inplace=False)
        self.branch0 = nn.Sequential(
            BasicConv2d(in_channel, out_channel, 1),
        )
        self.branch1 = nn.Sequential(
            BasicConv2d(in_channel, out_channel, 1),
            BasicConv2d(out_channel, out_channel, 3, padding=1, dilation=1)
        )

        self.branch2 = nn.Sequential(
            BasicConv2d(in_channel, out_channel, kernel_size=(3, 3), padding=1),
            BasicConv2d(out_channel, out_channel, 3, padding=3, dilation=3)
        )
        self.branch3 = nn.Sequential(
            BasicConv2d(in_channel, out_channel, kernel_size=(5, 5), padding=2),
            BasicConv2d(out_channel, out_channel, 3, padding=5, dilation=5)
        )

        self.conv_cat = BasicConv2d(4*out_channel, out_channel, 3, padding=1)
        self.conv_res = BasicConv2d(in_channel, out_channel, 3, padding=1)
        self.FrequencyAttention = FrequencyAttention(in_channel=out_channel)
        self.SEAttention = SEAttention(channel=out_channel, reduction=4)

    def forward(self, x):
        x0 = self.branch0(x)
        x1 = self.branch1(x)
        x2 = self.branch2(x)
        x3 = self.branch3(x)
        x_cat = self.conv_cat(torch.cat((x0, x1, x2, x3), 1))
        x_cat = self.FrequencyAttention(x_cat)
        x_cat = self.SEAttention(x_cat)
        x = self.relu(x+ self.conv_res(x_cat))
        return x


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 64, 32, 32).to(device)
    model = MSDA(64, 64).to(device)

    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN、小红书：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)