import torch
import torch.nn as nn
import torch.nn.functional as F


class LRDU(nn.Module):
    """
    轻量级残差密度上采样模块（Lightweight Residual Dense Upsampling, LRDU）
    功能：通过分离卷积+像素重排，实现高效特征上采样，兼顾效率与特征保留
    核心设计：
        - 分离卷积降维：1×7+7×1分组卷积，降低计算量，捕捉长距离依赖
        - 像素重排上采样：PixelShuffle实现factor倍上采样，无信息丢失
    Args:
        in_c: 输入通道数
        factor: 上采样倍数
    """
    def __init__(self,in_c,factor):
        super(LRDU,self).__init__()

        self.up_factor = factor
        self.factor1 = factor*factor//2
        self.factor2 = factor*factor
        self.up = nn.Sequential(
            nn.Conv2d(in_c, self.factor1*in_c, (1,7), padding=(0, 3), groups=in_c),
            nn.Conv2d(self.factor1*in_c, self.factor2*in_c, (7,1), padding=(3, 0), groups=in_c),
            nn.PixelShuffle(factor)
        )

    def forward(self,x):
        x = self.up(x)
        return x


class UpConv(nn.Module):
    def __init__(self,ch_in,ch_out):
        super(UpConv,self).__init__()
        self.up = nn.Sequential(
            LRDU(ch_in,2),
            nn.Conv2d(ch_in,ch_out,kernel_size=3,stride=1,padding=1,bias=True)
        )

    def forward(self,x):
        x = self.up(x)
        return x


class ConvBlock(nn.Module):
    def __init__(self,ch_in,ch_out):
        super(ConvBlock,self).__init__()

        self.conv = nn.Sequential(
            nn.Conv2d(ch_in, ch_out, kernel_size=3,stride=1,padding=1,bias=True),
            nn.BatchNorm2d(ch_out),
            nn.GELU()
        )

    def forward(self,x):
        x = self.conv(x)
        return x


class UncertaintyModule(nn.Module):
    """
    不确定性估计模块（Uncertainty Module）
    功能：基于变分推断，量化特征的置信度（不确定性），输出可靠度权重
    核心设计：
        - 变分推断建模：估计特征分布的均值（mu）和方差（logvar），通过重参数化采样生成预测
        - 不确定性量化：通过多次采样的方差衡量特征可靠性（方差越大，不确定性越高）
        - 归一化处理：不确定性值归一化至[0,1]，便于加权融合
    Args:
        dim: 输入特征通道数
        hidden_dim: 中间特征通道数
    """
    def __init__(self, dim, hidden_dim):
        super(UncertaintyModule,self).__init__()
        self.input_proj = nn.Sequential(nn.Conv2d(dim, hidden_dim, kernel_size=1, bias=False), nn.BatchNorm2d(hidden_dim), nn.GELU())
        self.mean_conv = nn.Conv2d(hidden_dim, 1, kernel_size=1, bias=False)
        self.std_conv  = nn.Conv2d(hidden_dim, 1, kernel_size=1, bias=False)

    def reparameterize(self, mu, logvar, k=1):
        std = logvar.mul(0.5).exp_()
        B, _, H, W = std.shape
        eps = torch.randn((B, k, H, W), device=std.device)
        sample_z = eps.mul(std).add_(mu)
        return sample_z

    def forward(self, x):
        x = self.input_proj(x)
        mean = self.mean_conv(x)
        std = self.std_conv(x)

        prob_x = self.reparameterize(mean, std, 1)
        prob_x = F.interpolate(prob_x, size=(512, 512), mode='bilinear', align_corners=True)
        prob_x = torch.sigmoid(prob_x)

        #uncertainty
        prob_out2 = self.reparameterize(mean, std, 50)
        prob_out2 = torch.sigmoid(prob_out2)
        uncertainty = prob_out2.var(dim=1, keepdim=True)
        uncertainty = (uncertainty - uncertainty.min()) / (uncertainty.max() - uncertainty.min())

        return uncertainty, prob_x


class UncertaintyAggregatedDecoder(nn.Module):
    """
    不确定性聚合解码器（Uncertainty-Aggregated Decoder, UAD）
    功能：全局-局部双路径特征融合，基于不确定性量化实现自适应加权，提升特征可靠性
    核心设计：
        - 特征适配：上采样将全局特征尺寸对齐局部特征，保证融合兼容性
        - 双不确定性评估：分别估计全局、局部特征的不确定性，量化可靠性
        - 自适应加权融合：(1-不确定性)作为权重，强化高置信度特征，抑制低置信度特征
        - 任务头（可选）：融合特征经多卷积增强，输出任务结果（如分割掩码）
    Args:
        out_dim: 特征通道配置，默认[64, 128, 256, 512]（对应不同阶段特征）
    """
    def __init__(self, out_dim=[64, 128, 256, 512]):
        super(UncertaintyAggregatedDecoder,self).__init__()
        self.upconv = nn.Sequential(UpConv(ch_in=out_dim[1], ch_out=out_dim[0]),
                                    ConvBlock(out_dim[0], out_dim[0]))
        self.unc_low = UncertaintyModule(dim = out_dim[0], hidden_dim = out_dim[0])
        self.unc_high = UncertaintyModule(dim = out_dim[0], hidden_dim = out_dim[0])
        self.conv_head = nn.Sequential(
            ConvBlock(out_dim[0], out_dim[0]),
            ConvBlock(out_dim[0], out_dim[0]),
            LRDU(out_dim[0],4),
            nn.Conv2d(out_dim[0], out_dim[0], kernel_size=3, stride=1, padding=1,groups=out_dim[0]),
            nn.Conv2d(out_dim[0], out_dim[0], kernel_size=3, stride=1, padding=1,groups=out_dim[0]),
            nn.Conv2d(out_dim[0], out_dim[0], kernel_size=3, stride=1, padding=1,groups=out_dim[0]),
            nn.Conv2d(out_dim[0], 2, kernel_size=1, stride=1, padding=0)
        )

    def forward(self, f_high, f_low):
        f_high = self.upconv(f_high)

        uncertainty_high, prob_high = self.unc_high(f_high)
        uncertainty_low, prob_low = self.unc_low(f_low)

        fusion_f = (1 - uncertainty_low) * f_low + (1 - uncertainty_high) * f_high

        return fusion_f

        # 去掉分割预测
        # output = self.conv_head(fusion_f)
        #
        # if self.training:
        #     return output, prob_high, prob_low
        # else:
        #     return output


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x_l = torch.randn(1, 128, 32, 32).to(device)
    x_g = torch.randn(1, 64, 64, 64).to(device)
    model = UncertaintyAggregatedDecoder().to(device)

    y = model(x_l, x_g)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN、小红书：十小大")

    print("输入局部特征维度：", x_l.shape)
    print("输入全局特征维度：", x_g.shape)
    print("输出特征维度：", y.shape)