import torch
import torch.nn as nn
import torch.nn.functional as F

import numpy as np
import functools
import math
import timm
from timm.models.layers import DropPath, to_2tuple
import einops
from fvcore.nn import FlopCountAnalysis


def num_trainable_params(model):
    nums = sum(p.numel() for p in model.parameters() if p.requires_grad) / 1e6
    return nums

class GlobalExtraction(nn.Module):
    """全局特征提取模块
    功能：通过通道级池化（平均+最大）捕捉全局空间统计信息，输出单通道全局描述图
    核心逻辑：
        - 对输入特征沿通道维度做平均池化和最大池化，压缩为单通道空间描述
        - 拼接两个池化结果，通过1×1卷积融合为统一的全局特征图
    输入：x (Tensor) - 形状 [B, C, H, W]（B=批量，C=通道数，H=高度，W=宽度）
    输出：proj (Tensor) - 形状 [B, 1, H, W]（单通道全局特征，保留空间维度）
    """
    def __init__(self, dim=None):  # dim：预留通道数参数，当前未实际使用
        super().__init__()
        # 定义通道级全局平均池化和最大池化方法
        self.avgpool = self.globalavgchannelpool
        self.maxpool = self.globalmaxchannelpool
        # 1×1卷积+批归一化：融合双池化特征，输出单通道全局描述
        self.proj = nn.Sequential(
            nn.Conv2d(2, 1, 1, 1),  # 输入2通道（平均池化+最大池化），输出1通道
            nn.BatchNorm2d(1)        # 批归一化稳定特征分布
        )

    # 通道级全局平均池化：每个通道的H×W特征压缩为1×1，保留全局统计信息
    def globalavgchannelpool(self, x):
        return x.mean(1, keepdim=True)  # dim=1为通道维度，输出[B,1,H,W]

    # 通道级全局最大池化：提取每个通道的显著特征，突出强响应区域
    def globalmaxchannelpool(self, x):
        return x.max(dim=1, keepdim=True)[0]  # 取最大值，输出[B,1,H,W]

    def forward(self, x):
        x_ = x.clone()  # 备份输入，避免池化操作修改原始数据
        x_avg = self.avgpool(x)    # 平均池化提取全局平滑特征
        x_max = self.maxpool(x_)   # 最大池化提取全局显著特征
        x_cat = torch.cat((x_avg, x_max), dim=1)  # 拼接双池化结果（[B,2,H,W]）
        proj = self.proj(x_cat)    # 融合为单通道全局特征图
        return proj

class ContextExtraction(nn.Module):
    """局部上下文提取模块
    功能：通过深度可分离卷积+空洞卷积捕捉局部多尺度上下文，结合通道压缩降低计算量
    核心逻辑：
        - 深度可分离卷积（分组=通道数）减少参数量，捕捉基础局部特征
        - 空洞卷积（dilation=2）扩大感受野至7×7，捕捉更大范围局部依赖
        - 1×1卷积压缩通道数，降低后续模块计算开销
    参数：
        dim: 输入/输出特征通道数
        reduction: 通道压缩系数（默认1，即不压缩；指定则压缩为dim//reduction）
    输入：x (Tensor) - [B, C, H, W]
    输出：x (Tensor) - [B, C//reduction, H, W]（局部上下文特征，通道数压缩）
    """
    def __init__(self, dim, reduction=None):
        super().__init__()
        self.reduction = 1 if reduction is None else 2  # 通道压缩系数
        # 深度可分离卷积+空洞卷积：提取局部上下文
        self.dconv = self.DepthWiseConv2dx2(dim)
        # 1×1卷积投影层：压缩通道数
        self.proj = self.Proj(dim)

    # 深度可分离卷积+空洞卷积组合：高效扩大感受野
    def DepthWiseConv2dx2(self, dim):
        return nn.Sequential(
            # 3×3深度可分离卷积：每组对应1个通道，参数量仅为普通卷积的1/dim
            nn.Conv2d(dim, dim, 3, padding=1, groups=dim),
            nn.BatchNorm2d(dim),
            nn.ReLU(inplace=True),
            # 3×3空洞卷积（dilation=2）：感受野从3×3→7×7，捕捉更广局部信息
            nn.Conv2d(dim, dim, 3, padding=2, dilation=2),
            nn.BatchNorm2d(dim),
            nn.ReLU(inplace=True)
        )

    # 1×1卷积投影：压缩通道数，降低计算量
    def Proj(self, dim):
        return nn.Sequential(
            nn.Conv2d(dim, dim // self.reduction, 1),  # 通道数压缩
            nn.BatchNorm2d(dim // self.reduction)       # 稳定压缩后特征
        )

    def forward(self, x):
        x = self.dconv(x)  # 提取局部上下文特征（[B,C,H,W]）
        x = self.proj(x)   # 通道压缩（[B,C//reduction,H,W]）
        return x

class MultiscaleFusion(nn.Module):
    """多尺度融合模块
    功能：整合局部上下文特征与全局特征，实现细节信息与宏观信息的互补增强
    核心逻辑：
        - 复用ContextExtraction提取局部细节特征
        - 复用GlobalExtraction提取全局宏观特征
        - 两者相加并批归一化，完成多尺度融合
    参数：
        dim: 输入特征通道数（与局部提取模块匹配）
    输入：
        x: 待提取局部特征的输入（[B,C,H,W]）
        g: 待提取全局特征的输入（[B,C,H,W]，通常为另一源特征）
    输出：fuse (Tensor) - [B, C//reduction, H, W]（多尺度融合特征）
    """
    def __init__(self, dim):
        super().__init__()
        self.local = ContextExtraction(dim)    # 局部特征提取
        self.global_ = GlobalExtraction()      # 全局特征提取
        self.bn = nn.BatchNorm2d(dim // self.local.reduction)  # 融合后归一化

    def forward(self, x, g):
        x_local = self.local(x)    # 提取x的局部上下文特征
        g_global = self.global_(g) # 提取g的全局特征（自动广播至x_local通道数）
        fuse = self.bn(x_local + g_global)  # 多尺度融合+归一化
        return fuse


class MultiScaleGatedAttn(nn.Module):
    """多尺度门控注意力模块（MASAG）
    功能：融合双输入特征（x和g），通过多尺度融合、门控注意力和双向交互，动态强化有效信息
    核心流程：
        1. 多尺度融合：x的局部特征 + g的全局特征
        2. 门控注意力：生成x和g的动态权重，差异化加权
        3. 双向交互：x与g互相调制，强化特征关联性
        4. 特征优化：投影与卷积调整，输出最终特征
    参数：
        dim: 输入特征通道数（x和g需保持通道数一致）
    输入：
        x: 第一输入特征（如当前层特征，[B,C,H,W]）
        g: 第二输入特征（如跨层特征，[B,C,H,W]）
    输出：y (Tensor) - [B,C,H,W]（融合增强后的特征，与输入尺寸一致）
    """
    def __init__(self, dim):
        super().__init__()
        self.multi = MultiscaleFusion(dim)    # 多尺度融合模块
        self.selection = nn.Conv2d(dim // self.multi.local.reduction, 2, 1)  # 权重生成（2通道对应x和g）
        self.proj = nn.Conv2d(dim, dim, 1)   # 交互特征投影（保持通道数）
        self.bn = nn.BatchNorm2d(dim)        # 投影后归一化
        self.bn_2 = nn.BatchNorm2d(dim)      # 最终输出归一化
        self.conv_block = nn.Sequential(     # 特征优化卷积
            nn.Conv2d(dim, dim, 1, 1)        # 1×1卷积调整特征表达
        )

    def forward(self, x, g):
        x_ = x.clone()  # 备份原始x，用于后续加权与残差增强
        g_ = g.clone()  # 备份原始g，用于注意力加权

        # 步骤1：多尺度融合（x的局部特征 + g的全局特征）
        multi_fuse = self.multi(x, g)

        # 步骤2：生成门控注意力权重（Softmax归一化，强制x与g权重和为1）
        weight_logits = self.selection(multi_fuse)  # 融合特征→2通道权重logits
        attn_weights = F.softmax(weight_logits, dim=1)  # 沿通道归一化（[B,2,H,W]）
        attn_x, attn_g = attn_weights.split(1, dim=1)  # 拆分x和g的权重（各[B,1,H,W]）

        # 步骤3：注意力加权与残差增强
        x_att = attn_x.expand_as(x_) * x_ + x_  # x加权 + 残差（避免信息丢失）
        g_att = attn_g.expand_as(g_) * g_ + g_  # g加权 + 残差

        # 步骤4：双向交互（x与g互相调制，强化关联性）
        x_sig = torch.sigmoid(x_att)  # x生成g的调制系数（0~1）
        g_att_mod = x_sig * g_att    # x调制g特征
        g_sig = torch.sigmoid(g_att)  # g生成x的调制系数（0~1）
        x_att_mod = g_sig * x_att    # g调制x特征

        # 步骤5：特征优化与输出
        interaction = x_att_mod * g_att_mod  # 交互特征融合
        proj = torch.sigmoid(self.bn(self.proj(interaction)))  # 投影为加权系数
        weighted = proj * x_  # 用系数强化原始x特征
        y = self.bn_2(self.conv_block(weighted))  # 最终优化与归一化

        return y

if __name__ == "__main__":
    xi = torch.randn(1, 192, 28, 28).cuda()
    #xi_1 = torch.randn(1, 384, 14, 14)
    g = torch.randn(1, 192, 28, 28).cuda()
    #ff = ContextBridge(dim=192)

    attn = MultiScaleGatedAttn(dim = xi.shape[1]).cuda()

    print("微信公众号：十小大的底层视觉工坊")
    print("知乎、CSDN：十小大")

    print("输入特征维度：", xi.shape, g.shape)
    print("输出特征维度：", attn(xi, g).shape)
