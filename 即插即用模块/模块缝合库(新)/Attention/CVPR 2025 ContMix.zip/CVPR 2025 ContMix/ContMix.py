'''
模块出处：OverLoCK: An Overview-first-Look-Closely-next ConvNet with Context-Mixing Dynamic Kernels
文章链接：https://arxiv.org/pdf/2502.20087
完整源码：https://github.com/LMMMEng/OverLoCK
运行条件：需要安装natten库

微信公众号：十小大的底层视觉工坊
知乎、CSDN：十小大
'''

import warnings
import torch
import torch.nn.functional as F
from torch import nn
from einops import rearrange, einsum
from timm.models.layers import DropPath, to_2tuple
from torch.utils.checkpoint import checkpoint

try:
    from natten.functional import na2d_av
    has_natten = True
except:
    has_natten = False
    warnings.warn("The efficiency may be reduced since 'natten' is not installed."
                  " It is recommended to install natten for better performance.")


def get_conv2d(in_channels, out_channels, kernel_size, stride, padding, dilation, groups, bias,
               attempt_use_lk_impl=True):
    """
    获取2D卷积层，支持大核卷积的iGEMM高效实现（来自UniRepLKNet）
    当卷积满足：正方形大核（>5）、同通道数（in=out=groups）、步长1、 dilation=1时，优先使用DepthWiseConv2dImplicitGEMM
    否则返回标准nn.Conv2d
    """
    kernel_size = to_2tuple(kernel_size)
    if padding is None:
        padding = (kernel_size[0] // 2, kernel_size[1] // 2)  # 默认same padding
    else:
        padding = to_2tuple(padding)

    # 判断是否需要大核优化实现
    need_large_impl = kernel_size[0] == kernel_size[1] and kernel_size[0] > 5 and padding == (
    kernel_size[0] // 2, kernel_size[1] // 2)
    if attempt_use_lk_impl and need_large_impl:
        try:
            from depthwise_conv2d_implicit_gemm import DepthWiseConv2dImplicitGEMM  # 大核高效实现
            if DepthWiseConv2dImplicitGEMM is not None and in_channels == out_channels and out_channels == groups and stride == 1 and dilation == 1:
                return DepthWiseConv2dImplicitGEMM(in_channels, kernel_size, bias=bias)
        except ImportError:
            pass  # fallback到标准卷积
    return nn.Conv2d(in_channels, out_channels, kernel_size=kernel_size, stride=stride, padding=padding,
                     dilation=dilation, groups=groups, bias=bias)

def get_bn(dim, use_sync_bn=False):
    if use_sync_bn:
        return nn.SyncBatchNorm(dim)
    else:
        return nn.BatchNorm2d(dim)

def fuse_bn(conv, bn):
    """融合卷积层与BN层（推理阶段优化）
    公式：conv_weight * (bn_weight / sqrt(bn_var+eps))，conv_bias = bn_bias + (conv_bias - bn_mean)*bn_weight/sqrt(bn_var+eps)
    """
    conv_bias = 0 if conv.bias is None else conv.bias
    std = (bn.running_var + bn.eps).sqrt()
    fused_weight = conv.weight * (bn.weight / std).reshape(-1, 1, 1, 1)
    fused_bias = bn.bias + (conv_bias - bn.running_mean) * bn.weight / std
    return fused_weight, fused_bias


def merge_dilated_into_large_kernel(large_kernel, dilated_kernel, dilated_r):
    """将扩张卷积核合并为等效大核（UniRepLKNet核心重参数化操作）
    通过conv_transpose2d将扩张卷积核转换为非扩张等效核，再与原始大核叠加
    """
    equivalent_kernel = convert_dilated_to_nondilated(dilated_kernel, dilated_r)  # 扩张核转非扩张核
    rows_to_pad = large_kernel.size(2) // 2 - equivalent_kernel.size(2) // 2  # 对齐padding
    merged_kernel = large_kernel + F.pad(equivalent_kernel, [rows_to_pad] * 4)  # 核叠加
    return merged_kernel


class DilatedReparamBlock(nn.Module):
    """扩张重参数化块（来自UniRepLKNet）
    训练时：大核卷积 + 多个不同 dilation 的小核卷积分支（带BN）
    推理时：通过merge_dilated_branches()合并为单个大核卷积，无额外计算开销
    """

    def __init__(self, channels, kernel_size, deploy, use_sync_bn=False, attempt_use_lk_impl=True):
        super().__init__()
        # 主大核卷积（depthwise）
        self.lk_origin = get_conv2d(channels, channels, kernel_size, stride=1, padding=kernel_size // 2, dilation=1,
                                    groups=channels, bias=deploy, attempt_use_lk_impl=attempt_use_lk_impl)
        self.attempt_use_lk_impl = attempt_use_lk_impl

        # 预定义不同大核对应的小核分支配置（dilation和kernel_size组合）
        if kernel_size == 19:
            self.kernel_sizes = [5, 7, 9, 9, 3, 3, 3]
            self.dilates = [1, 1, 1, 2, 4, 5, 7]
        if kernel_size == 19:
            self.kernel_sizes = [5, 7, 9, 9, 3, 3, 3]
            self.dilates = [1, 1, 1, 2, 4, 5, 7]
        elif kernel_size == 17:
            self.kernel_sizes = [5, 7, 9, 3, 3, 3]
            self.dilates = [1, 1, 2, 4, 5, 7]
        elif kernel_size == 15:
            self.kernel_sizes = [5, 7, 7, 3, 3, 3]
            self.dilates = [1, 1, 2, 3, 5, 7]
        elif kernel_size == 13:
            self.kernel_sizes = [5, 7, 7, 3, 3, 3]
            self.dilates = [1, 1, 2, 3, 4, 5]
        elif kernel_size == 11:
            self.kernel_sizes = [5, 7, 5, 3, 3, 3]
            self.dilates = [1, 1, 2, 3, 4, 5]
        elif kernel_size == 9:
            self.kernel_sizes = [5, 7, 5, 3, 3]
            self.dilates = [1, 1, 2, 3, 4]
        elif kernel_size == 7:
            self.kernel_sizes = [5, 3, 3, 3]
            self.dilates = [1, 1, 2, 3]
        elif kernel_size == 5:
            self.kernel_sizes = [3, 3]
            self.dilates = [1, 2]
        else:
            raise ValueError('Dilated Reparam Block requires kernel_size >= 5')

        # 训练阶段添加小核扩张卷积+BN分支
        if not deploy:
            self.origin_bn = get_bn(channels, use_sync_bn)
            for k, r in zip(self.kernel_sizes, self.dilates):
                # 扩张卷积（depthwise）
                self.__setattr__(f'dil_conv_k{k}_{r}',
                                 nn.Conv2d(channels, channels, kernel_size=k, stride=1, padding=(r * (k - 1) + 1) // 2,
                                           dilation=r, groups=channels, bias=False))
                self.__setattr__(f'dil_bn_k{k}_{r}', get_bn(channels, use_sync_bn))

    def forward(self, x):
        if not hasattr(self, 'origin_bn'):      # deploy mode
            return self.lk_origin(x)
        out = self.origin_bn(self.lk_origin(x))
        for k, r in zip(self.kernel_sizes, self.dilates):
            conv = self.__getattr__('dil_conv_k{}_{}'.format(k, r))
            bn = self.__getattr__('dil_bn_k{}_{}'.format(k, r))
            out = out + bn(conv(x))
        return out

    def merge_dilated_branches(self):
        """合并所有分支为单个大核卷积（推理前调用）
        1. 融合主分支conv+bn
        2. 逐个融合小核分支conv+bn，并转换为等效大核
        3. 叠加所有核权重和偏置，生成最终大核卷积
        """
        if hasattr(self, 'origin_bn'):
            origin_k, origin_b = fuse_bn(self.lk_origin, self.origin_bn)
            for k, r in zip(self.kernel_sizes, self.dilates):
                conv = self.__getattr__(f'dil_conv_k{k}_{r}')
                bn = self.__getattr__(f'dil_bn_k{k}_{r}')
                branch_k, branch_b = fuse_bn(conv, bn)
                origin_k = merge_dilated_into_large_kernel(origin_k, branch_k, r)  # 合并核
                origin_b += branch_b  # 累加偏置
            # 构建最终合并后的卷积层
            merged_conv = get_conv2d(origin_k.size(0), origin_k.size(0), origin_k.size(2), stride=1,
                                     padding=origin_k.size(2) // 2, dilation=1, groups=origin_k.size(0), bias=True,
                                     attempt_use_lk_impl=self.attempt_use_lk_impl)
            merged_conv.weight.data = origin_k
            merged_conv.bias.data = origin_b
            self.lk_origin = merged_conv
            # 删除训练阶段分支
            self.__delattr__('origin_bn')
            for k, r in zip(self.kernel_sizes, self.dilates):
                self.__delattr__(f'dil_conv_k{k}_{r}')
                self.__delattr__(f'dil_bn_k{k}_{r}')


class SEModule(nn.Module):
    """通道注意力模块（SE）
    流程：全局平均池化 → 1×1Conv降维 → 激活 → 1×1Conv升维 → Sigmoid → 通道权重乘输入
    """

    def __init__(self, dim, red=8, inner_act=nn.GELU, out_act=nn.Sigmoid):
        super().__init__()
        inner_dim = max(16, dim // red)  # 降维维度（至少16）
        self.proj = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),  # 全局平均池化 (B,C,H,W)→(B,C,1,1)
            nn.Conv2d(dim, inner_dim, kernel_size=1),  # 降维
            inner_act(),
            nn.Conv2d(inner_dim, dim, kernel_size=1),  # 升维
            out_act(),  # 生成通道权重
        )

    def forward(self, x):
        return x * self.proj(x)  # 注意力加权

class LayerScale(nn.Module):
    def __init__(self, dim, init_value=1e-5):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(dim, 1, 1, 1)*init_value,
                                   requires_grad=True)
        self.bias = nn.Parameter(torch.zeros(dim), requires_grad=True)

    def forward(self, x):

        x = F.conv2d(x, weight=self.weight, bias=self.bias, groups=x.shape[1])

        return x

class LayerNorm2d(nn.LayerNorm):
    def __init__(self, dim):
        super().__init__(normalized_shape=dim, eps=1e-6)

    def forward(self, x):
        x = rearrange(x, 'b c h w -> b h w c')
        x = super().forward(x)
        x = rearrange(x, 'b h w c -> b c h w')
        return x.contiguous()

class GRN(nn.Module):
    """全局响应归一化（ConvNeXt V2）
    作用：增强通道间竞争，提升模型泛化能力
    公式：(gamma * (Gx / (mean(Gx)+eps)) + 1) * x + beta（可选beta），其中Gx是空间维度L2范数
    """

    def __init__(self, dim, use_bias=True):
        super().__init__()
        self.use_bias = use_bias
        self.gamma = nn.Parameter(torch.zeros(1, dim, 1, 1))  # 缩放参数
        if self.use_bias:
            self.beta = nn.Parameter(torch.zeros(1, dim, 1, 1))  # 偏置参数

    def forward(self, x):
        Gx = torch.norm(x, p=2, dim=(-1, -2), keepdim=True)  # 空间维度L2范数 (B,C,H,W)→(B,C,1,1)
        Nx = Gx / (Gx.mean(dim=1, keepdim=True) + 1e-6)  # 通道归一化
        if self.use_bias:
            return (self.gamma * Nx + 1) * x + self.beta
        else:
            return (self.gamma * Nx + 1) * x

class ResDWConv(nn.Conv2d):
    '''
    Depthwise conv with residual connection
    '''
    def __init__(self, dim, kernel_size=3):
        super().__init__(dim, dim, kernel_size=kernel_size, padding=kernel_size//2, groups=dim)

    def forward(self, x):
        x = x + super().forward(x)
        return x

class ContMixBlock(nn.Module):
    """ContMix模块（动态卷积+FFN）
    核心：双分支动态卷积（小核smk+大核kernel）+ 重参数化大核LePE + SE注意力 + FFN
    支持梯度检查点（内存优化）、重参数化（推理加速）、iGEMM大核优化
    """

    def __init__(self, dim=64, kernel_size=7, smk_size=5, num_heads=2, mlp_ratio=4, res_scale=False, ls_init_value=None,
                 drop_path=0, norm_layer=LayerNorm2d, use_gemm=False, deploy=False, use_checkpoint=False, **kwargs):
        super().__init__()
        mlp_dim = int(dim * mlp_ratio)  # FFN隐藏层维度
        self.kernel_size = kernel_size  # 主分支大核尺寸
        self.res_scale = res_scale  # 残差连接是否使用LayerScale加权
        self.use_gemm = use_gemm  # 是否使用iGEMM大核实现
        self.smk_size = smk_size  # 次分支小核尺寸
        self.num_heads = num_heads * 2  # 动态卷积头数（翻倍适配双分支）
        self.head_dim = dim // self.num_heads  # 每个头的维度
        self.scale = self.head_dim ** -0.5  # 注意力缩放因子
        self.use_checkpoint = use_checkpoint  # 是否使用梯度检查点

        # 1. 残差深度卷积（预激活前）
        self.dwconv1 = ResDWConv(dim, kernel_size=3)
        self.norm1 = norm_layer(dim)  # 归一化

        # 2. 动态卷积权重生成（QKV结构）
        self.weight_query = nn.Sequential(nn.Conv2d(dim, dim // 2, 1, bias=False),
                                          nn.BatchNorm2d(dim // 2))  # Q: 输入特征→dim//2
        self.weight_key = nn.Sequential(nn.AdaptiveAvgPool2d(7), nn.Conv2d(dim, dim // 2, 1, bias=False),
                                        nn.BatchNorm2d(dim // 2))  # K: 全局特征→dim//2（AdaptivePool到7×7）
        self.weight_value = nn.Sequential(nn.Conv2d(dim, dim, 1, bias=False), nn.BatchNorm2d(dim))  # V: 输入特征→dim
        self.weight_proj = nn.Conv2d(49, kernel_size ** 2 + smk_size ** 2, 1)  # 将K的7×7特征投影为核权重（大核+小核）

        # 3. 特征融合与增强
        self.fusion_proj = nn.Sequential(nn.Conv2d(dim, dim, 1, bias=False), nn.BatchNorm2d(dim))  # 双分支融合
        self.lepe = nn.Sequential(DilatedReparamBlock(dim, kernel_size=kernel_size, deploy=deploy, use_sync_bn=False,
                                                      attempt_use_lk_impl=use_gemm), nn.BatchNorm2d(dim))  # 重参数化大核位置编码
        self.se_layer = SEModule(dim)  # 通道注意力
        self.gate = nn.Sequential(nn.Conv2d(dim, dim, 1, bias=False), nn.BatchNorm2d(dim), nn.SiLU())  # 门控机制（特征筛选）
        self.proj = nn.Sequential(nn.BatchNorm2d(dim), nn.Conv2d(dim, dim, 1))  # 输出投影

        # 4. FFN分支
        self.dwconv2 = ResDWConv(dim, kernel_size=3)  # 残差深度卷积
        self.norm2 = norm_layer(dim)  # 归一化

        self.mlp = nn.Sequential(
            nn.Conv2d(dim, mlp_dim, 1),  # 升维
            nn.GELU(),
            ResDWConv(mlp_dim, 3),  # 深度卷积增强
            GRN(mlp_dim),  # 全局响应归一化
            nn.Conv2d(mlp_dim, dim, 1)  # 降维
        )

        # 5. 训练稳定与正则化
        self.ls1 = LayerScale(dim, ls_init_value) if ls_init_value is not None else nn.Identity()  # 残差1 LayerScale
        self.ls2 = LayerScale(dim, ls_init_value) if ls_init_value is not None else nn.Identity()  # 残差2 LayerScale
        self.drop_path = DropPath(drop_path) if drop_path > 0 else nn.Identity()  # 随机深度（正则化）

        self.get_rpb()  # 初始化相对位置偏置（RPB）

    def get_rpb(self):
        """初始化相对位置偏置（RPB），用于动态卷积的位置感知"""
        self.rpb_size1 = 2 * self.smk_size - 1  # 小核RPB尺寸（覆盖所有相对位置）
        self.rpb1 = nn.Parameter(torch.empty(self.num_heads, self.rpb_size1, self.rpb_size1))  # 小核RPB参数
        self.rpb_size2 = 2 * self.kernel_size - 1  # 大核RPB尺寸
        self.rpb2 = nn.Parameter(torch.empty(self.num_heads, self.rpb_size2, self.rpb_size2))  # 大核RPB参数
        # 截断正态分布初始化
        nn.init.trunc_normal_(self.rpb1, std=0.02)
        nn.init.trunc_normal_(self.rpb2, std=0.02)

    @torch.no_grad()
    def generate_idx(self, kernel_size):
        """生成位置索引"""
        rpb_size = 2 * kernel_size - 1
        idx_h = torch.arange(0, kernel_size)
        idx_w = torch.arange(0, kernel_size)
        idx_k = ((idx_h.unsqueeze(-1) * rpb_size) + idx_w).view(-1)
        return (idx_h, idx_w, idx_k)

    def apply_rpb(self, attn, rpb, height, width, kernel_size, idx_h, idx_w, idx_k):
        """为动态卷积注意力添加相对位置偏置（RPB）
        作用：增强位置敏感性，解决自注意力位置信息缺失问题
        """
        # 计算偏置索引（适配不同特征图尺寸）
        num_repeat_h = torch.ones(kernel_size, dtype=torch.long)
        num_repeat_w = torch.ones(kernel_size, dtype=torch.long)
        num_repeat_h[kernel_size // 2] = height - (kernel_size - 1)  # 中心行重复次数（适配特征图高度）
        num_repeat_w[kernel_size // 2] = width - (kernel_size - 1)  # 中心列重复次数（适配特征图宽度）

        bias_hw = (idx_h.repeat_interleave(num_repeat_h).unsqueeze(-1) * (
                    2 * kernel_size - 1)) + idx_w.repeat_interleave(num_repeat_w)
        bias_idx = bias_hw.unsqueeze(-1) + idx_k
        bias_idx = bias_idx.reshape(-1, int(kernel_size ** 2))
        bias_idx = torch.flip(bias_idx, [0])

        # 提取对应位置的RPB并添加到注意力中
        rpb = torch.flatten(rpb, 1, 2)[:, bias_idx]
        rpb = rpb.reshape(1, int(self.num_heads), int(height), int(width), int(kernel_size ** 2))
        return attn + rpb

    def reparm(self):
        """调用所有DilatedReparamBlock的merge_dilated_branches()，完成重参数化（推理前）"""
        for m in self.modules():
            if isinstance(m, DilatedReparamBlock):
                m.merge_dilated_branches()

    def _forward_inner(self, x):
        """ContMix块前向传播核心逻辑（适配梯度检查点）"""
        input_resolution = x.shape[2:]  # 原始输入空间尺寸（用于后续插值恢复）
        B, C, H, W = x.shape

        # 1. 残差分支1：深度卷积 + 归一化
        x = self.dwconv1(x)
        identity = x  # 残差连接备份
        x = self.norm1(x)
        gate = self.gate(x)  # 门控权重
        lepe = self.lepe(x)  # 重参数化大核位置编码

        # 2. 动态卷积：处理小特征图（不足kernel_size时插值放大）
        is_pad = False
        if min(H, W) < self.kernel_size:
            is_pad = True
            # 按比例插值到至少kernel_size尺寸
            if H < W:
                size = (self.kernel_size, int(self.kernel_size / H * W))
            else:
                size = (int(self.kernel_size / W * H), self.kernel_size)
            x = F.interpolate(x, size=size, mode='bilinear', align_corners=False)
            H, W = size

        # 3. 生成动态卷积权重（QKV计算）
        query = self.weight_query(x) * self.scale  # Q: (B, C//2, H, W)
        key = self.weight_key(x)  # K: (B, C//2, 7, 7)（AdaptivePool后）
        value = self.weight_value(x)  # V: (B, C, H, W)

        # 4. 多头注意力维度重塑
        query = rearrange(query, 'b (g c) h w -> b g c (h w)', g=self.num_heads)  # (B, G, C//(2G), H*W)
        key = rearrange(key, 'b (g c) h w -> b g c (h w)', g=self.num_heads)  # (B, G, C//(2G), 49)
        weight = einsum(query, key, 'b g c n, b g c l -> b g n l')  # Q@K^T: (B, G, H*W, 49)
        weight = rearrange(weight, 'b g n l -> b l g n').contiguous()  # (B, 49, G, H*W)
        weight = self.weight_proj(weight)  # 投影为核权重: (B, K²+S², G, H*W)
        weight = rearrange(weight, 'b l g (h w) -> b g h w l', h=H, w=W)  # (B, G, H, W, K²+S²)

        # 5. 拆分双分支动态卷积权重（小核smk + 大核kernel）
        attn1, attn2 = torch.split(weight, split_size_or_sections=[self.smk_size ** 2, self.kernel_size ** 2], dim=-1)
        # 添加相对位置偏置（RPB）
        rpb1_idx = self.generate_idx(self.smk_size)
        rpb2_idx = self.generate_idx(self.kernel_size)
        attn1 = self.apply_rpb(attn1, self.rpb1, H, W, self.smk_size, *rpb1_idx)
        attn2 = self.apply_rpb(attn2, self.rpb2, H, W, self.kernel_size, *rpb2_idx)
        # 注意力归一化
        attn1 = torch.softmax(attn1, dim=-1)
        attn2 = torch.softmax(attn2, dim=-1)

        # 6. 双分支动态卷积计算（支持NATTEN高效实现或标准unfold）
        value = rearrange(value, 'b (m g c) h w -> m b g h w c', m=2,
                          g=self.num_heads)  # 拆分V为双分支: (2, B, G, H, W, C/(2G))
        if has_natten:
            # 使用NATTEN的高效邻域注意力计算（无unfold，速度更快）
            x1 = na2d_av(attn1, value[0], kernel_size=self.smk_size)  # 小核分支输出
            x2 = na2d_av(attn2, value[1], kernel_size=self.kernel_size)  # 大核分支输出
        else:
            # 标准unfold实现（兼容无NATTEN环境）
            pad1 = self.smk_size // 2
            pad2 = self.kernel_size // 2
            # 展开value为滑动窗口
            v1 = rearrange(value[0], 'b g h w c -> b (g c) h w')
            v2 = rearrange(value[1], 'b g h w c -> b (g c) h w')
            v1 = F.unfold(v1, kernel_size=self.smk_size).reshape(B, -1, H - 2 * pad1, W - 2 * pad1)
            v2 = F.unfold(v2, kernel_size=self.kernel_size).reshape(B, -1, H - 2 * pad2, W - 2 * pad2)
            # padding恢复尺寸
            v1 = F.pad(v1, (pad1, pad1, pad1, pad1), mode='replicate')
            v2 = F.pad(v2, (pad2, pad2, pad2, pad2), mode='replicate')
            # 重塑维度并计算注意力加权
            v1 = rearrange(v1, 'b (g c k) h w -> b g c h w k', g=self.num_heads, k=self.smk_size ** 2, h=H, w=W)
            v2 = rearrange(v2, 'b (g c k) h w -> b g c h w k', g=self.num_heads, k=self.kernel_size ** 2, h=H, w=W)
            x1 = einsum(attn1, v1, 'b g h w k, b g c h w k -> b g h w c')
            x2 = einsum(attn2, v2, 'b g h w k, b g c h w k -> b g h w c')

        # 7. 双分支融合与增强
        x = torch.cat([x1, x2], dim=1)  # 分支拼接: (B, G*2, H, W, C/(2G)) → (B, C, H, W)
        x = rearrange(x, 'b g h w c -> b (g c) h w', h=H, w=W)
        if is_pad:
            x = F.adaptive_avg_pool2d(x, input_resolution)  # 恢复原始输入尺寸
        x = self.fusion_proj(x)  # 特征融合
        x = x + lepe  # 叠加位置编码
        x = self.se_layer(x)  # 通道注意力
        x = gate * x  # 门控筛选
        x = self.proj(x)  # 输出投影

        # 8. 残差连接1（支持LayerScale）
        if self.res_scale:
            x = self.ls1(identity) + self.drop_path(x)
        else:
            x = identity + self.drop_path(self.ls1(x))

        # 9. FFN分支（深度卷积 + 归一化 + MLP）
        x = self.dwconv2(x)
        identity2 = x
        x = self.norm2(x)
        x = self.mlp(x)  # FFN计算

        # 10. 残差连接2（支持LayerScale）
        if self.res_scale:
            x = self.ls2(identity2) + self.drop_path(x)
        else:
            x = identity2 + self.drop_path(self.ls2(x))

        return x

    def forward(self, x):
        """前向传播入口（支持梯度检查点）"""
        if self.use_checkpoint and x.requires_grad:
            x = checkpoint(self._forward_inner, x, use_reentrant=False)  # 梯度检查点（内存换速度）
        else:
            x = self._forward_inner(x)
        return x

if __name__ == '__main__':
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    x = torch.randn(1, 64, 32, 32).to(device)
    model = ContMixBlock(dim=64,
                         num_heads=2,
                         kernel_size=13,
                         smk_size=5,
                         mlp_ratio=4,
                         res_scale=True,
                         ls_init_value=1,
                         drop_path=0,
                         norm_layer=LayerNorm2d,
                         use_gemm=True,
                         deploy=False,
                         use_checkpoint=False)
    model.to(device)
    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("知乎、CSDN：十小大")
    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)