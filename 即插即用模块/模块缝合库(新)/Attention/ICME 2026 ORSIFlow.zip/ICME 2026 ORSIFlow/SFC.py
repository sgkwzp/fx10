import torch
import torch.nn as nn

# -------------------------- SFC核心校准块 对应结构图右下角Salient Feature Calibrator全流程 --------------------------
class SalientFeatureCalibratorBlock(nn.Module):
    """
    显著特征校准核心块
    完整对应结构图SFC模块的内部流程，核心功能：双感受野多尺度特征提取+通道-空间联合校准，强化显著目标特征
    """
    def __init__(self, dim, r=16, L=32):
        super().__init__()
        d = max(dim // r, L)  # 通道压缩维度，保证最小维度L
        # 分支1：3×3深度卷积，捕捉局部小尺度显著特征
        self.conv0 = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)
        # 分支2：5×5空洞卷积（dilation=2），扩大感受野，捕捉大尺度显著特征
        self.conv_spatial = nn.Conv2d(dim, dim, 5, stride=1, padding=4, groups=dim, dilation=2)
        # 双分支通道降维，减少计算量
        self.conv1 = nn.Conv2d(dim, dim // 2, 1)
        self.conv2 = nn.Conv2d(dim, dim // 2, 1)
        # 空间注意力卷积，生成空间权重
        self.conv_squeeze = nn.Conv2d(2, 2, 7, padding=3)
        self.conv = nn.Conv2d(dim // 2, dim, 1)
        # 全局池化模块 对应结构图GAP/GMP
        self.global_pool = nn.AdaptiveAvgPool2d(1)
        self.global_maxpool = nn.AdaptiveMaxPool2d(1)
        # 通道注意力MLP，生成通道权重
        self.fc1 = nn.Sequential(
            nn.Conv2d(dim, d, 1, bias=False),
            nn.BatchNorm2d(d),
            nn.ReLU(inplace=True)
        )
        self.fc2 = nn.Conv2d(d, dim, 1, 1, bias=False)
        self.softmax = nn.Softmax(dim=1)

    def forward(self, x):
        batch_size = x.size(0)
        dim = x.size(1)
        # -------------------------- 步骤1：双感受野多尺度特征提取 --------------------------
        attn1 = self.conv0(x)  # 3×3局部特征分支
        attn2 = self.conv_spatial(attn1)  # 5×5空洞大感受野分支
        # 双分支通道降维
        attn1 = self.conv1(attn1)  # [B, dim/2, H, W]
        attn2 = self.conv2(attn2)  # [B, dim/2, H, W]
        attn = torch.cat([attn1, attn2], dim=1)  # 拼接双分支特征

        # -------------------------- 步骤2：空间注意力计算 对应结构图空间分支 --------------------------
        avg_attn = torch.mean(attn, dim=1, keepdim=True)  # 通道平均池化
        max_attn, _ = torch.max(attn, dim=1, keepdim=True)  # 通道最大池化
        agg = torch.cat([avg_attn, max_attn], dim=1)  # 拼接生成空间特征图 [B, 2, H, W]

        # -------------------------- 步骤3：通道注意力计算 对应结构图通道分支 --------------------------
        ch_attn1 = self.global_pool(attn)  # 全局平均池化
        z = self.fc1(ch_attn1)
        a_b = self.fc2(z)
        # 通道权重拆分为两个分支的权重，分别对应3×3和5×5分支
        a_b = a_b.reshape(batch_size, 2, dim // 2, -1)
        a_b = self.softmax(a_b)
        a1, a2 = a_b.chunk(2, dim=1)
        a1 = a1.reshape(batch_size, dim // 2, 1, 1)
        a2 = a2.reshape(batch_size, dim // 2, 1, 1)

        # -------------------------- 步骤4：通道-空间联合校准 --------------------------
        # 空间权重拆分为两个分支，与通道权重相乘，实现联合校准
        w1 = a1 * agg[:, 0, :, :].unsqueeze(1)
        w2 = a2 * agg[:, 1, :, :].unsqueeze(1)
        # 双分支特征加权融合
        attn = attn1 * w1 + attn2 * w2
        # 生成最终注意力图
        attn = self.conv(attn).sigmoid()
        # 注意力加权原始特征
        return x * attn

# -------------------------- SFC完整模块 对应结构图Salient Feature Calibrator --------------------------
class SalientFeatureCalibrator(nn.Module):
    """
    SFC: Salient Feature Calibrator 显著特征校准器
    完整对应结构图SFC模块，核心功能：残差结构+核心校准块，实现显著目标特征的自适应增强
    输入：[B, C, H, W]，输出：[B, C, H, W]，即插即用
    """
    def __init__(self, dim):
        super().__init__()
        self.proj_1 = nn.Conv2d(dim, dim, 1)  # 输入投影卷积
        self.activation = nn.GELU()  # 激活函数
        self.spatial_gating_unit = SalientFeatureCalibratorBlock(dim)  # 核心校准块
        self.proj_2 = nn.Conv2d(dim, dim, 1)  # 输出投影卷积

    def forward(self, x):
        shorcut = x.clone()
        x = self.proj_1(x)
        x = self.activation(x)
        x = self.spatial_gating_unit(x)
        x = self.proj_2(x)
        # 全局残差连接，保证输入输出尺寸一致
        x = x + shorcut
        return x


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    x = torch.randn(2, 64, 32, 32).to(device)  # 含BN，batch_size需>1
    model = SalientFeatureCalibrator(64).to(device)
    y = model(x)
    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("小红书：十小大，主页获取往期全部即插即用代码，200+大合集")
    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)