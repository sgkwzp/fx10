# 相位整合模块（Phase Integration Module, PIM）与颜色增强模块（Color Enhancement Module, CEM）
# 核心设计：针对RGB与YCbCr双颜色空间特征，通过频域相位融合（PIM）和空间颜色注意力增强（CEM），
# 充分利用不同颜色空间的互补信息，提升视觉特征的颜色一致性与细节表达能力

import torch
import torch.nn as nn
import torch.nn.functional as F


# Phase integration module
class PIM(nn.Module):
    """
    相位整合模块（Phase Integration Module, PIM）
    功能：在频域中融合RGB与YCbCr颜色空间的相位信息，保留各自幅度特征，强化跨颜色空间的特征一致性
    核心设计：
        - 频域分解：通过FFT将空间域特征转换为频域，拆分幅度（结构）与相位（位置/颜色）信息
        - 双分支特征处理：独立卷积优化RGB与YCbCr的幅度和相位，提升特征表达
        - 相位融合策略：直接相加融合双空间相位，保留双方位置与颜色关联信息
        - 逆FFT重建：频域特征转回空间域，输出增强后的双颜色空间特征
    """
    def __init__(self, channel):
        super(PIM, self).__init__()

        self.processmag = nn.Sequential(
            nn.Conv2d(channel, channel, 1, 1, 0),
            nn.LeakyReLU(0.1, inplace=True),
            nn.Conv2d(channel, channel, 1, 1, 0))

        self.processpha = nn.Sequential(
            nn.Conv2d(channel, channel, 1, 1, 0),
            nn.LeakyReLU(0.1, inplace=True),
            nn.Conv2d(channel, channel, 1, 1, 0))

    def forward(self, rgb_x, ycbcr_x):
        rgb_fft = torch.fft.rfft2(rgb_x, norm='backward')
        ycbcr_fft = torch.fft.rfft2(ycbcr_x, norm='backward')
        rgb_amp = torch.abs(rgb_fft)
        rgb_phase = torch.angle(rgb_fft)

        ycbcr_amp = torch.abs(ycbcr_fft)
        ycbcr_phase = torch.angle(ycbcr_fft)

        rgb_amp = self.processmag(rgb_amp)
        rgb_phase = self.processmag(rgb_phase)

        ycbcr_amp = self.processmag(ycbcr_amp)
        ycbcr_phase = self.processmag(ycbcr_phase)

        mix_phase = rgb_phase + ycbcr_phase

        out_rgb = torch.fft.irfft2(rgb_amp * torch.exp(1j * mix_phase), norm='backward')
        out_ycbcr = torch.fft.irfft2(ycbcr_amp * torch.exp(1j * mix_phase), norm='backward')
        return out_rgb, out_ycbcr


class CEM(nn.Module):
    """
    颜色增强模块（Color Enhancement Module, CEM）
    功能：基于YCbCr空间的亮度统计特征，生成自适应注意力权重，增强RGB与YCbCr的颜色融合效果
    核心设计：
        - 亮度差异建模：通过均值减法捕捉YCbCr空间的亮度变化信息
        - 全局注意力生成：自适应平均池化+Softmax，生成全局颜色注意力权重
        - 残差融合：RGB特征加权后与YCbCr特征残差连接，保留原始颜色信息
    """
    def __init__(self):
        super(CEM, self).__init__()
        self.adaptive_avg_pool = nn.AdaptiveAvgPool2d(output_size=(1, 1))

    def forward(self, x_ycbcr, x_rgb):
        res = x_ycbcr
        x1_amp1 = torch.mean(x_ycbcr, dim=1, keepdim=True)
        x1_amp1 = x_ycbcr - x1_amp1
        att = self.adaptive_avg_pool(x1_amp1)
        att = F.softmax(att, 1)
        out = x_rgb * att
        out = res + out
        return out


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x_ycbcr = torch.randn(1, 64, 32, 32).to(device)
    x_rgb = torch.randn(1, 64, 32, 32).to(device)

    model1 = PIM(64).to(device)
    model2 = CEM().to(device)

    y_rgb, y_ycbcr = model1(x_ycbcr, x_rgb)
    y = model2(x_ycbcr, x_rgb)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN、小红书：十小大")

    print("输入特征1维度：", x_ycbcr.shape)
    print("输入特征2维度：", x_rgb.shape)
    print("输出特征1维度：", y_rgb.shape)
    print("输出特征2维度：", y_ycbcr.shape)
    print("CEM输出特征维度：", y.shape)