import math
import torch
import torch.nn as nn
import torch.nn.functional as F


class FAAFusion(nn.Module):
    """
    轻量级傅里叶角度对齐融合模块，基于通道降维+折叠归一化实现跨分辨率特征融合
    核心改进：单通道降维投影、折叠输出重叠计数归一化、空间旋转对齐、LayerScale特征增强
    Args:
        m (int): 局部窗口尺寸（必须为奇数），默认7
        c_mid (int): 1×1卷积投影后的中间通道维度，默认16
        eps (float): 数值稳定性小值，默认1e-8
        layer_scale_init_value (float): LayerScale初始化值，默认1e-5
    Inputs:
        x_high (Tensor): 高分辨率特征 [B, C, H_h, W_h]
        x_low (Tensor): 低分辨率特征 [B, C, H_l, W_l]（融合基准）
    Output:
        fused (Tensor): 融合后的低分辨率特征 [B, C, H_l, W_l]
    """
    def __init__(
            self,
            m: int = 7,
            c_mid: int = 16,
            eps: float = 1e-8,
            layer_scale_init_value: float = 1e-5,
    ):
        super().__init__()
        self.m = m  # 局部特征窗口尺寸
        self.c_mid = c_mid  # 中间降维通道数
        self.eps = eps  # 防止除零的数值稳定项
        # 可学习LayerScale：逐通道标量，初始值较小避免初始融合过度
        self.layer_scale = nn.Parameter(
            torch.full((1, 1, 1, 1), layer_scale_init_value),
            requires_grad=True
        )
        # 通道投影：将256维高/低频特征统一降维到c_mid，减少计算量（仅一次投影，非逐通道）
        self.proj_low = nn.Conv2d(in_channels=256, out_channels=c_mid, kernel_size=1, bias=False)
        self.proj_high = nn.Conv2d(in_channels=256, out_channels=c_mid, kernel_size=1, bias=False)
        # 通道恢复：将对齐后的c_mid维特征还原为原始256维
        self.recon = nn.Conv2d(in_channels=c_mid, out_channels=256, kernel_size=1, bias=False)
        self._init_freq_grids(m)  # 初始化傅里叶频率网格，预计算极坐标参数

    def _init_freq_grids(self, m: int):
        """初始化傅里叶频率网格，计算极坐标(ρ:极径, θ:极角)，仅在初始化时执行一次"""
        # 计算m×m窗口的傅里叶频率
        h_freq = torch.fft.fftfreq(m, d=1.0) * m
        w_freq = torch.fft.fftfreq(m, d=1.0) * m
        h_grid, w_grid = torch.meshgrid(h_freq, w_freq)  # 生成[m, m]频率网格
        rho = torch.sqrt(h_grid ** 2 + w_grid ** 2)  # 计算极径（频率幅值）
        theta = torch.atan2(h_grid, w_grid)  # 计算极角（频率方向）
        theta = (theta + 2 * math.pi) % (2 * math.pi)  # 极角归一化到[0,2π)
        mask = rho > self.eps  # 过滤零频率（直流分量），仅保留有效频率
        # 注册为缓冲区（不参与训练），供后续角度估计使用
        self.register_buffer('valid_thetas', theta[mask])
        self.register_buffer('valid_rhos', rho[mask])
        self.register_buffer('mask_flat', mask.view(-1))

    def _estimate_main_direction(self, x_local: torch.Tensor) -> torch.Tensor:
        """从局部特征块的傅里叶幅度谱估计**主方向（优势取向）**
        x_local: [Bn, 1, m, m] 批量局部特征块
        Returns: [Bn] 每个特征块对应的主方向极角
        """
        Bn, _, m, _ = x_local.shape
        device = x_local.device
        x_fft = torch.fft.fft2(x_local.squeeze(1), norm='ortho')  # 2D傅里叶变换
        x_fft_shifted = torch.fft.fftshift(x_fft, dim=(-2, -1))  # 频域中心移到窗口中心
        mag = x_fft_shifted.abs() + self.eps  # 计算幅度谱，加eps避免零
        mag_flat = mag.view(Bn, -1)  # 展平幅度谱
        mag_valid = mag_flat[:, self.mask_flat]  # 过滤零频率的有效幅度
        rho_valid = self.valid_rhos.to(device)  # 有效频率的极径
        weighted_energy = mag_valid * rho_valid.unsqueeze(0)  # 极径加权能量（突出高频主方向）
        max_idx = torch.argmax(weighted_energy, dim=1)  # 取加权能量最大的索引
        theta_e = self.valid_thetas.to(device)[max_idx]  # 索引对应主方向极角
        return theta_e

    def _rotate_spatial_patch(self, patch: torch.Tensor, theta: torch.Tensor) -> torch.Tensor:
        """根据估计的角度旋转局部特征块，实现**空间方向对齐**
        patch: [K, 1, m, m] 待旋转特征块
        theta: [K] 每个特征块的旋转角度
        Returns: [K, 1, m, m] 旋转对齐后的特征块
        """
        K, _, m, _ = patch.shape
        device = patch.device
        cos_t = torch.cos(theta).view(K, 1, 1)  # 余弦值，维度适配
        sin_t = torch.sin(theta).view(K, 1, 1)  # 正弦值，维度适配
        center = (m - 1) / 2.0  # 窗口中心坐标（奇数窗口）
        # 初始化仿射旋转矩阵 [K, 2, 3]，适配torch.nn.functional.affine_grid
        rot_mat = torch.zeros(K, 2, 3, device=device)
        rot_mat[:, 0, 0] = cos_t.squeeze()  # 旋转矩阵第一行第一列
        rot_mat[:, 0, 1] = -sin_t.squeeze() # 旋转矩阵第一行第二列
        rot_mat[:, 1, 0] = sin_t.squeeze()  # 旋转矩阵第二行第一列
        rot_mat[:, 1, 1] = cos_t.squeeze()  # 旋转矩阵第二行第二列
        # 平移量：保证旋转后特征块中心不变
        rot_mat[:, 0, 2] = center - cos_t.squeeze() * center + sin_t.squeeze() * center
        rot_mat[:, 1, 2] = center - sin_t.squeeze() * center - cos_t.squeeze() * center
        # 生成仿射变换网格
        grid = F.affine_grid(rot_mat, patch.size(), align_corners=False)
        # 双线性插值旋转，零填充边缘
        rotated = F.grid_sample(patch, grid, mode='bilinear', padding_mode='zeros', align_corners=False)
        return rotated

    def forward(self, x_high: torch.Tensor, x_low: torch.Tensor) -> torch.Tensor:
        """FAAFusion前向传播：高分辨率特征上采样→通道降维→局部块傅里叶角度估计→
        高维特征旋转对齐→折叠归一化→通道恢复→LayerScale增强→跨分辨率融合"""
        B, C, H_l, W_l = x_low.shape  # 低分辨率特征尺寸（融合基准）
        _, _, H_h, W_h = x_high.shape # 高分辨率特征尺寸
        device = x_low.device

        # 步骤1：高分辨率特征上采样到低分辨率尺寸，作为融合基础
        if (H_h, W_h) != (H_l, W_l):
            x_high_up = F.interpolate(x_high, size=(H_l, W_l), mode='bilinear', align_corners=False)
        else:
            x_high_up = x_high

        # 步骤2：高/低特征统一通道降维到c_mid，大幅减少后续计算量
        xl_proj = self.proj_low(x_low)  # [B, c_mid, H_l, W_l]
        xh_proj = self.proj_high(x_high_up)  # [B, c_mid, H_l, W_l]

        pad = 0  # 无填充，保证局部块不重叠边缘
        # 计算有效局部特征块数量（m×m窗口滑窗步长1）
        N = (H_l - self.m + 1) * (W_l - self.m + 1)
        # 初始化高特征对齐后的中间张量
        xh_aligned_cmid = torch.zeros_like(xh_proj)  # [B, c_mid, H_l, W_l]

        # 步骤3：逐中间通道处理，实现**通道级的精细角度对齐**
        for c in range(self.c_mid):
            # 提取单通道特征（降维后）
            xl_c = xl_proj[:, c:c + 1]  # [B, 1, H_l, W_l]
            xh_c = xh_proj[:, c:c + 1]  # [B, 1, H_l, W_l]
            # 滑窗展开为局部特征块 [B, m*m, N]
            xl_unfold = F.unfold(xl_c, kernel_size=self.m, stride=1, padding=pad)
            xh_unfold = F.unfold(xh_c, kernel_size=self.m, stride=1, padding=pad)
            # 重塑为批量局部块，适配傅里叶变换 [B*N, 1, m, m]
            xl_patches = xl_unfold.transpose(1, 2).reshape(B * N, 1, self.m, self.m)
            xh_patches = xh_unfold.transpose(1, 2).reshape(B * N, 1, self.m, self.m)

            # 傅里叶域估计主方向极角
            theta_low = self._estimate_main_direction(xl_patches)  # [B*N] 低特征块主方向
            theta_high = self._estimate_main_direction(xh_patches) # [B*N] 高特征块主方向
            # 极角归一化到[0,π)，消除方向冗余（旋转π与原方向一致）
            theta_low_norm = torch.remainder(theta_low, math.pi)
            theta_high_norm = torch.remainder(theta_high, math.pi)
            theta_ = theta_low_norm - theta_high_norm  # 计算高特征需要旋转的角度

            # 空间域旋转高特征块，与低特征块主方向对齐
            xh_rotated = self._rotate_spatial_patch(xh_patches, theta_)  # [B*N, 1, m, m]
            # 展平旋转后的特征块，准备折叠回原尺寸
            xh_rotated_flat = xh_rotated.reshape(B, N, -1).transpose(1, 2)  # [B, m*m, N]
            # 折叠回特征图尺寸 [B, 1, H_l, W_l]
            xh_aligned_map = F.fold(
                xh_rotated_flat,
                output_size=(H_l, W_l),
                kernel_size=self.m,
                stride=1,
                padding=pad
            )
            # 折叠归一化：根据滑窗重叠计数归一化，避免重叠区域特征值累积
            ones = torch.ones(1, 1, H_l, W_l, device=device)
            ones_unfold = F.unfold(ones, kernel_size=self.m, stride=1, padding=pad)
            ones_fold = F.fold(ones_unfold, output_size=(H_l, W_l), kernel_size=self.m, stride=1, padding=pad)
            xh_aligned_map = xh_aligned_map / (ones_fold + self.eps)

            # 保存当前通道的对齐结果
            xh_aligned_cmid[:, c:c + 1] = xh_aligned_map

        # 步骤4：将对齐后的c_mid维特征恢复为原始C维
        xh_recon = self.recon(xh_aligned_cmid)  # [B, C, H_l, W_l]

        # 步骤5：LayerScale可学习增强，再与原上采样高特征融合
        x_high_modulated = self.layer_scale * xh_recon + x_high_up
        # 最终融合：低分辨率基准特征 + 对齐增强后的高分辨率特征
        fused = x_low + x_high_modulated
        return fused


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x_low = torch.randn(1, 256, 32, 32).to(device)
    x_high = torch.randn(1, 256, 64, 64).to(device)
    model = FAAFusion(7, 64).to(device)

    y = model(x_high, x_low)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("小红书：十小大，主页获取往期全部即插即用代码，200+大合集")

    print("输入高频特征维度：", x_high.shape)
    print("输入低频特征维度：", x_low.shape)
    print("输出特征维度：", y.shape)