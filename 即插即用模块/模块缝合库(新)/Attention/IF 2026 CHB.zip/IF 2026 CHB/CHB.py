import math
import torch.nn.functional as F
import torch
import torch.nn as nn
from timm.models.layers import DropPath, to_2tuple, trunc_normal_

class GCE(nn.Module):
    """
    全局上下文估计模块（对应结构图(c)的Global Context Prior, GCP）
    核心：下采样+方差统计+可学习缩放偏移，高效建模全局上下文信息
    Args:
        dim: 输入通道数
        down_scale: 全局下采样倍率，默认8
    """
    def __init__(self, dim, down_scale=8):
        super().__init__()
        self.dw_conv = nn.Conv2d(dim, dim, 3, 1, 1, groups=dim)  # 深度卷积增强全局特征
        self.conv_1 = nn.Conv2d(dim, dim, 1, 1, 0)  # 1×1卷积通道变换
        self.gelu = nn.GELU()
        self.down_scale = down_scale
        # 可学习参数：全局特征缩放系数和偏移量
        self.alpha = nn.Parameter(torch.ones((1, dim, 1, 1)))
        self.belt = nn.Parameter(torch.zeros((1, dim, 1, 1)))

    def forward(self, x):
        _, _, h, w = x.shape
        # 步骤1：自适应最大池化下采样，提取全局粗粒度特征
        x_s = self.dw_conv(F.adaptive_max_pool2d(x, (h // self.down_scale, w // self.down_scale)))
        # 步骤2：计算全局特征方差，捕捉全局统计信息
        x_v = torch.var(x, dim=(-2, -1), keepdim=True)
        # 步骤3：可学习缩放+偏移，融合全局均值和方差信息
        enhanced_features = x_s * self.alpha + x_v * self.belt
        # 步骤4：上采样回原尺寸，与原特征逐元素相乘，实现全局引导
        x_l = x * F.interpolate(
            self.gelu(self.conv_1(enhanced_features)),
            size=(h, w), align_corners=False, mode='bilinear'
        )
        return x_l

class LA(nn.Sequential):
    """
    局部聚合模块（对应结构图(b)的Local Aggregation, LA）
    核心：1×1扩展通道+分组深度卷积+1×1压缩，捕捉局部细节特征
    Args:
        dim: 输入通道数
        mlp_ration: 通道扩展倍率，默认2
    """
    def __init__(self, dim: int, mlp_ration=2):
        super().__init__(
            nn.Conv2d(dim, int(dim * mlp_ration), 1),  # 通道扩展
            nn.GELU(),
            # 分组深度卷积：每组6个通道，平衡计算量和特征交互
            nn.Conv2d(int(dim * mlp_ration), int(dim * mlp_ration), 3, 1, 1,
                      groups=int(dim * mlp_ration) // 6),
            nn.GELU(),
            nn.Conv2d(int(dim * mlp_ration), dim, 1)  # 通道压缩
        )
        trunc_normal_(self[-1].weight, std=0.02)  # 权重初始化

class InceptionStyleDWConv2d(nn.Module):
    """
    Inception风格多尺度大核深度卷积（对应结构图(b)的Multi-scale Receptive Field Expansion, MRFE）
    核心：四分支并行深度卷积，覆盖5×5/11×11/17×17多尺度感受野
    Args:
        in_channels: 输入通道数
        branch_ratio: 分支数，默认4
        kernel_sizes: 各分支卷积核尺寸，[0,5,11,17]对应恒等/5×5/11×11/17×17
    """
    def __init__(self, in_channels, branch_ratio=4, kernel_sizes=[0, 5, 11, 17]):
        super().__init__()
        assert in_channels % branch_ratio == 0, "输入通道数必须能被分支数整除"
        gc = in_channels // branch_ratio  # 每个分支的通道数
        # 分支1：恒等映射（0核）
        # 分支2：5×5深度卷积（捕捉中尺度特征）
        self.dwconv_hw = nn.Conv2d(gc, gc, kernel_size=kernel_sizes[1], padding=kernel_sizes[1]//2, groups=gc)
        # 分支3：11×11深度卷积（捕捉大尺度特征）
        self.dwconv_w = nn.Conv2d(gc, gc, kernel_size=kernel_sizes[2], padding=kernel_sizes[2]//2, groups=gc)
        # 分支4：17×17深度卷积（捕捉超大尺度特征）
        self.dwconv_h = nn.Conv2d(gc, gc, kernel_size=kernel_sizes[3], padding=kernel_sizes[3]//2, groups=gc)
        self.split_indexes = (gc, gc, gc, gc)

    def forward(self, x):
        x_id, x_5, x_11, x_17 = torch.split(x, self.split_indexes, dim=1)
        # 四分支并行处理后拼接
        return torch.cat(
            (x_id, self.dwconv_hw(x_5), self.dwconv_w(x_11), self.dwconv_h(x_17)),
            dim=1,
        )

class ElementScale(nn.Module):
    """可学习元素级缩放层，用于特征分解的自适应调整"""
    def __init__(self, embed_dims, init_value=0., requires_grad=True):
        super().__init__()
        self.scale = nn.Parameter(init_value * torch.ones((1, embed_dims, 1, 1)), requires_grad=requires_grad)

    def forward(self, x):
        return x * self.scale

class ChannelAggregationFFN(nn.Module):
    """
    通道聚合前馈网络（对应结构图(b)的FFN）
    核心：深度卷积+特征分解机制，增强FFN的特征表达能力
    Args:
        embed_dims: 输入通道数
        kernel_size: 深度卷积核尺寸，默认3
        act_type: 激活函数类型，默认GELU
        mlp_ration: 通道扩展倍率，默认2
        ffn_drop: dropout率
    """
    def __init__(self, embed_dims, kernel_size=3, act_type='GELU', mlp_ration=2., ffn_drop=0.):
        super().__init__()
        self.feedforward_channels = int(embed_dims * mlp_ration)
        self.fc1 = nn.Conv2d(embed_dims, self.feedforward_channels, 1)  # 通道扩展
        self.dwconv = nn.Conv2d(
            self.feedforward_channels, self.feedforward_channels, kernel_size,
            stride=1, padding=kernel_size//2, bias=True, groups=self.feedforward_channels
        )  # 深度卷积捕捉空间信息
        self.act = nn.GELU() if act_type == 'GELU' else nn.ReLU() if act_type == 'ReLU' else nn.SiLU()
        self.fc2 = nn.Conv2d(self.feedforward_channels, embed_dims, 1)  # 通道压缩
        self.drop = nn.Dropout(ffn_drop)
        # 特征分解分支：将特征分解为全局和残差部分
        self.decompose = nn.Conv2d(self.feedforward_channels, 1, kernel_size=1)
        self.sigma = ElementScale(self.feedforward_channels, init_value=1e-5)
        self.decompose_act = nn.GELU()

    def feat_decompose(self, x):
        """特征分解：自适应增强残差特征，提升表达能力"""
        x_decomp = self.decompose_act(self.decompose(x))  # 全局分量
        x = x + self.sigma(x - x_decomp)  # 残差分量自适应增强
        return x

    def forward(self, x):
        x = self.fc1(x)
        x = self.dwconv(x)
        x = self.act(x)
        x = self.drop(x)
        x = self.feat_decompose(x)  # 特征分解增强
        x = self.fc2(x)
        x = self.drop(x)
        return x

class HybridInceptionBlock(nn.Module):
    """
    Context-harnessing Block (CHB) 核心实现
    对应结构图(b)的完整流程：局部聚合→多尺度扩展+全局上下文→通道聚合FFN→残差输出
    核心创新："局部-多尺度-全局"三级上下文融合架构
    Args:
        hidden_dim: 输入/输出通道数
        drop_path: DropPath概率
        mlp_ratio: FFN通道扩展倍率
        split_ration: 多尺度分支数，默认4
        kernel_sizes: 多尺度卷积核尺寸
    """
    def __init__(
            self,
            hidden_dim: int = 0,
            drop_path: float = 0,
            mlp_ratio: float = 2,
            split_ration=4,
            kernel_sizes=[0, 5, 11, 17]
    ):
        super().__init__()
        self.hidden_dim = hidden_dim
        self.norm1 = nn.BatchNorm2d(hidden_dim)
        self.norm2 = nn.BatchNorm2d(hidden_dim)
        # 1. 局部聚合模块
        self.CEB = LA(hidden_dim, mlp_ration=mlp_ratio)
        # 2. 全局上下文先验模块
        self.EGEM = GCE(hidden_dim, down_scale=8)
        # 3. 多尺度大核扩展模块
        self.ISBlock = InceptionStyleDWConv2d(
            in_channels=hidden_dim, branch_ratio=split_ration, kernel_sizes=kernel_sizes
        )
        # 4. 通道聚合前馈网络
        self.CAFFN = ChannelAggregationFFN(
            embed_dims=hidden_dim, ffn_drop=drop_path, mlp_ration=mlp_ratio
        )
        # 可学习残差缩放系数，平衡多尺度和全局分支的贡献
        self.skip_scale = nn.Parameter(1e-1 * torch.ones(hidden_dim))
        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()

    def forward(self, input):
        # 步骤1：归一化+局部聚合，捕捉局部细节
        x = self.norm1(input.contiguous())
        x = self.CEB(x).contiguous()
        # 步骤2：双分支并行处理
        convs = self.EGEM(x).contiguous()  # 分支1：全局上下文先验
        x_isb = self.ISBlock(x).contiguous()  # 分支2：多尺度大核扩展
        # 步骤3：双分支加权融合
        x_combined = x_isb + convs * self.skip_scale.view(1, self.hidden_dim, 1, 1)
        # 步骤4：归一化+通道聚合FFN
        x_fused = self.CAFFN(self.norm2(x_combined))
        # 步骤5：残差连接输出
        x = input + self.drop_path(x_fused)
        return x


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    x = torch.randn(1, 180, 32, 32).to(device)
    model = HybridInceptionBlock(180).to(device)
    y = model(x)
    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)
