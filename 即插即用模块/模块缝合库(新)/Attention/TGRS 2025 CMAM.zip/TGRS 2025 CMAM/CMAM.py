import torch
import torch.nn as nn
import torch.nn.functional as F


class Offset_Generator(nn.Module):
    """
    多尺度膨胀偏移生成器（Multiscale Dilated Offset Generator）
    功能：生成双模态空间对齐所需的偏移量，捕捉多尺度空间依赖
    核心设计：
        - 双膨胀卷积分支： dilation=1（细粒度）与dilation=2（粗粒度），覆盖不同尺度空间错位
        - 轻量化融合：1×1卷积降维+GELU激活，降低计算成本
        - 偏移量维度适配：输出2×32通道（对应32组特征的x/y方向偏移）
    Args:
        in_channels: 输入特征通道数（默认256）
    """
    def __init__(self, in_channels=256):
        super(Offset_Generator, self).__init__()

        self.branch1 = nn.Conv2d(in_channels=in_channels, out_channels=in_channels // 2, kernel_size=3, dilation=1,
                                 padding=1)
        self.branch2 = nn.Conv2d(in_channels=in_channels, out_channels=in_channels // 2, kernel_size=3, dilation=2,
                                 padding=2)

        self.combine = nn.Sequential(
            nn.Conv2d(in_channels, in_channels // 2, kernel_size=1, bias=False),
            nn.BatchNorm2d(in_channels // 2),
            nn.GELU(),
            nn.Conv2d(in_channels // 2, 2 * 32, kernel_size=3, padding=1, bias=False),
        )

        self.apply(self.init_conv_kaiming)

    def init_conv_kaiming(self, module):
        if isinstance(module, nn.Conv2d):
            nn.init.kaiming_uniform_(module.weight, a=1)

            if module.bias is not None:
                nn.init.constant_(module.bias, 0)

    def forward(self, x):
        x1 = self.branch1(x)
        x2 = self.branch2(x)

        x = torch.cat((x1, x2), dim=1)
        out = self.combine(x)

        return out


class Dual_Alignment_Module(nn.Module):
    """
    跨模态对齐模块（Cross-Modal Alignment Module, CMAM）
    功能：整合空间对齐与通道调制，实现双模态特征精准融合
    核心设计：
        - 双模态独立偏移学习：为RGB和红外分别生成偏移量，针对性修正空间错位
        - 分组空间对齐：32组特征独立对齐，降低模态内特征干扰
        - 通道调制优化：通过MLP生成通道权重，平衡双模态通道响应
    Args:
        in_channels: 单模态输入通道数（默认256）
    """
    def __init__(self, in_channels=256):
        super(Dual_Alignment_Module, self).__init__()

        self.in_channels = in_channels

        # spatial group alignment  32 groups
        self.delta_gen_rgb = Offset_Generator(in_channels=in_channels * 2)
        self.delta_gen_ir = Offset_Generator(in_channels=in_channels * 2)

        self.conv_rgb = nn.Conv2d(in_channels, in_channels, kernel_size=3, padding=1)

        self.conv_ir = nn.Conv2d(in_channels, in_channels, kernel_size=3, padding=1)

        self.conv = nn.Sequential(
            nn.Conv2d(in_channels, in_channels, kernel_size=3, padding=1),
            nn.ReLU()
        )

        # channel modulation
        self.GAP = nn.AdaptiveAvgPool2d(1)
        self.channel_mlp = nn.Sequential(
            nn.Linear(in_features=in_channels * 2, out_features=in_channels, bias=True),
            nn.ReLU(),
            nn.Linear(in_features=in_channels, out_features=in_channels * 2, bias=True),
            nn.Tanh()
        )
        # lyf: init
        self.apply(self.init_conv_RandomNormal)

    def init_conv_RandomNormal(self, module, std=0.01):
        if isinstance(module, nn.Conv2d):
            nn.init.kaiming_normal_(module.weight, mode='fan_in', nonlinearity='relu')
            if module.bias is not None:
                nn.init.constant_(module.bias, 0)

    def bilinear_interpolate_torch_gridsample(self, input, delta=0):
        n, c, h, w = input.shape
        s = 1.0

        norm = torch.tensor([[[[h / s, w / s]]]]).type_as(input).to(input.device)
        w_list = torch.linspace(-1.0, 1.0, h).view(-1, 1).repeat(1, w)
        h_list = torch.linspace(-1.0, 1.0, w).repeat(h, 1)

        grid = torch.cat((h_list.unsqueeze(2), w_list.unsqueeze(2)), 2)
        grid = grid.repeat(n, 1, 1, 1).type_as(input).to(input.device)
        grid = grid + delta.permute(0, 2, 3, 1) / norm

        output = F.grid_sample(input, grid, align_corners=True)

        del grid
        del norm

        return output

    def forward(self, f_rgb, f_ir):
        batch, C, H, W = f_rgb.size()

        #
        fuse_f = torch.cat((f_rgb, f_ir), dim=1)
        rgb_offset = self.delta_gen_rgb(fuse_f)
        ir_offset = self.delta_gen_ir(fuse_f)
        #
        f_rgb_chunks = list(torch.chunk(f_rgb, 32, dim=1))
        f_ir_chunks = list(torch.chunk(f_ir, 32, dim=1))
        rgb_offset_chunks = list(torch.chunk(rgb_offset, 32, dim=1))
        ir_offset_chunks = list(torch.chunk(ir_offset, 32, dim=1))

        for i in range(len(f_rgb_chunks)):
            f_rgb_chunks[i] = self.bilinear_interpolate_torch_gridsample(f_rgb_chunks[i], rgb_offset_chunks[i])
            f_ir_chunks[i] = self.bilinear_interpolate_torch_gridsample(f_ir_chunks[i], ir_offset_chunks[i])

        f_rgb = torch.cat(f_rgb_chunks, dim=1)
        f_ir = torch.cat(f_ir_chunks, dim=1)

        f_rgb = self.conv_rgb(f_rgb)
        f_ir = self.conv_ir(f_ir)

        # channel modulation
        rgb_channel_weights = self.GAP(f_rgb)
        ir_channel_weights = self.GAP(f_ir)
        channel_weights = self.channel_mlp(
            torch.cat((rgb_channel_weights, ir_channel_weights), dim=1).view(batch, 2 * C).contiguous())

        channel_weights_chunks = torch.chunk(channel_weights, 2, dim=1)
        rgb_channel_weights = channel_weights_chunks[0].view(batch, C, 1, 1).contiguous()
        ir_channel_weights = channel_weights_chunks[1].view(batch, C, 1, 1).contiguous()
        f_rgb = f_rgb * (1 + rgb_channel_weights)
        f_ir = f_ir * (1 + ir_channel_weights)

        final_f = f_rgb + f_ir

        final_f = self.conv(final_f)

        return final_f


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    rgb = torch.randn(1, 64, 32, 32).to(device)
    ir = torch.randn(1, 64, 32, 32).to(device)
    model = Dual_Alignment_Module(64).to(device)

    y = model(rgb, ir)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN、小红书：十小大")

    print("输入RGB特征维度：", rgb.shape)
    print("输入IR特征维度：", ir.shape)
    print("输出特征维度：", y.shape)