import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision.models import convnext_base


# SCPM
class ChannelSelectAndExpandConvWithConvNeXt(nn.Module):
    def __init__(self, channels, reduction=8, keep_ratio=0.7, alpha_init=1.0, max_epoch=30, use_convnext=True):
        super().__init__()
        self.channels = channels
        self.keep_channels = int(channels * keep_ratio)
        self.max_epoch = max_epoch
        self.use_convnext = use_convnext

        self.global_pool = nn.AdaptiveAvgPool2d(1)

        self.fc = nn.Sequential(
            nn.Linear(channels, channels // reduction),
            nn.ReLU(inplace=True),
            nn.Linear(channels // reduction, channels),
            nn.Sigmoid()
        )

        if use_convnext:
            convnext = convnext_base(pretrained=True)
            self.convnext = nn.Sequential(*list(convnext.children())[:-2])
            self.convnext_fc = nn.Linear(1024, channels)
        else:
            self.convnext = None
            self.convnext_fc = None

        self.expand_conv = nn.Conv2d(self.keep_channels, channels, kernel_size=1, bias=False)
        self.suo_conv = nn.Conv2d(channels, 3, kernel_size=1, bias=False)

        self.alpha = nn.Parameter(torch.tensor(alpha_init), requires_grad=True)

    def forward(self, x):
        b, c, h, w = x.size()

        squeeze = self.global_pool(x).view(b, -1)  # [B, C]
        channel_weights = self.fc(squeeze)          # [B, C]

        if self.use_convnext is not None:
            x_conv = self.suo_conv(x)
            x_resized = F.interpolate(x_conv, size=(224, 224), mode='bilinear', align_corners=False)
            with torch.no_grad():
                convnext_feat = self.convnext(x_resized)
                convnext_feat = convnext_feat.flatten(2).mean(dim=2)  # global average pooling [B, 1024]

            convnext_weights = self.convnext_fc(convnext_feat)    # [B, C]

            channel_weights = channel_weights + self.alpha * torch.sigmoid(convnext_weights)

        _, indices = torch.topk(channel_weights, self.keep_channels, dim=1)  # [B, keep_C]
        indices = indices.unsqueeze(-1).unsqueeze(-1).expand(-1, -1, h, w)   # [B, keep_C, H, W]

        selected_feat = x.gather(1, indices)                                # [B, keep_C, H, W]

        expanded_feat = self.expand_conv(selected_feat)              # [B, C, H, W]

        return expanded_feat


# GAM
class GeometricResidualBlock(nn.Module):
    def __init__(self, channels):
        super().__init__()
        self.avgpool = nn.AdaptiveAvgPool2d(1)
        self.affine_fc = nn.Sequential(
            nn.Conv2d(channels, channels, 1),
            nn.ReLU(),
            nn.Conv2d(channels, channels * 2, 1),  # gamma & beta
        )

    def forward(self, fused_feat, orig_feat):
        guide = self.avgpool(orig_feat)  # [B, C, 1, 1]
        affine = self.affine_fc(guide)   # [B, 2C, 1, 1]
        gamma, beta = torch.chunk(affine, 2, dim=1)
        return fused_feat * (1 + gamma) + beta


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x1 = torch.randn(1, 64, 32, 32).to(device)
    model1 = ChannelSelectAndExpandConvWithConvNeXt(64).to(device)

    y1 = model1(x1)

    x2 = torch.randn(1, 64, 32, 32).to(device)
    model2 = GeometricResidualBlock(64).to(device)

    y2 = model2(x2, y1)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN、小红书：十小大")

    print("### SCPM ###")
    print("输入特征维度：", x1.shape)
    print("输出特征维度：", y1.shape)

    print("### GAM ###")
    print("输入特征维度：", x2.shape)
    print("输出特征维度：", y2.shape)