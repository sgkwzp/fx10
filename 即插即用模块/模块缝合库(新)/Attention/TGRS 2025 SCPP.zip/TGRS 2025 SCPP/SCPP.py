# 尺度感知金字塔池化模块（Scale-aware Pyramid Pooling, SCPP）
# 核心设计：整合局部特征提取、多尺度膨胀卷积、全局特征聚合与注意力融合，
# 通过“多分支尺度建模+自适应注意力加权+三特征融合”，在不改变空间尺寸的前提下，
# 强化特征的多尺度表达能力与全局一致性，提升特征辨识度

import torch
import torch.nn as nn
import torch.nn.functional as F


class SELayer(nn.Module):
    """
    通道注意力模块（Squeeze-and-Excitation, SE）
    功能：通过全局平均池化捕捉通道依赖，生成通道权重，筛选关键通道特征
    核心设计：
        - 挤压（Squeeze）：全局平均池化聚合空间信息，得到通道统计特征
        - 激励（Excitation）：MLP压缩-激活-恢复，生成通道注意力权重
        - 轻量化：仅含两个线性层，参数量少，计算效率高
    """
    def __init__(self, channel, reduction=16):
        super(SELayer, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(
            nn.Linear(channel, channel // reduction, bias=False),
            nn.ReLU(inplace=True),
            nn.Linear(channel // reduction, channel, bias=False),
            nn.Sigmoid()
        )

    def forward(self, x):
        b, c, _, _ = x.size()
        y = self.avg_pool(x).view(b, c)
        y = self.fc(y).view(b, c, 1, 1)
        return x * y.expand_as(x)


class ScaleAwareModule(nn.Module):
    """
    尺度感知模块：多尺度膨胀卷积分支+自适应注意力融合
    功能：通过不同膨胀率的卷积捕捉多尺度空间依赖，用注意力加权融合最优尺度特征
    核心设计：
        - 多膨胀率分支：1/3/5膨胀率，覆盖从局部到全局的感受野
        - 分支内SE增强：每个分支后插入SE模块，强化分支内关键通道
        - 自适应注意力融合：基于分支特征总和生成注意力权重，动态平衡多尺度贡献
    """

    def __init__(self, channels, dilation_rates=(1, 3, 5), se_reduction=16):
        super().__init__()
        self.channels = channels
        self.dil_rates = dilation_rates  # 多尺度膨胀率（默认1、3、5）
        self.branches = nn.ModuleList()  # 多尺度分支容器

        # 构建多膨胀率分支
        for d in dilation_rates:
            branch = nn.Sequential(
                nn.Conv2d(channels, channels, kernel_size=3, padding=d, dilation=d, bias=False),  # 膨胀卷积
                nn.BatchNorm2d(channels),  # 归一化
                nn.ReLU(inplace=True),  # 激活
                SELayer(channels, reduction=se_reduction),  # 通道注意力增强
                nn.Conv2d(channels, channels, kernel_size=1, bias=False),  # 特征投影
                nn.BatchNorm2d(channels),  # 归一化
                nn.ReLU(inplace=True)  # 激活
            )
            self.branches.append(branch)

        # 注意力权重生成卷积（基于分支特征总和）
        self.attn_conv = nn.Conv2d(channels, len(dilation_rates), kernel_size=1, bias=True)

    def forward(self, x):
        # 多分支特征提取
        outs = []
        for br in self.branches:
            outs.append(br(x))  # 每个分支输出：[b, c, h, w]

        # 生成注意力权重：基于分支特征总和
        sum_feats = outs[0]
        for o in outs[1:]:
            sum_feats = sum_feats + o  # 分支特征求和：[b, c, h, w]
        logits = self.attn_conv(sum_feats)  # 投影为权重对数：[b, num_branches, h, w]
        attn = F.softmax(logits, dim=1)  # 归一化生成注意力权重

        # 注意力加权融合多尺度特征
        fused = 0
        for i, o in enumerate(outs):
            a = attn[:, i:i + 1, :, :]  # 第i个分支的注意力权重
            fused = fused + o * a  # 加权累加

        return fused, outs, attn  # 返回融合特征、分支特征、注意力权重


class SCPP(nn.Module):
    """
    尺度感知金字塔池化模块（Scale-aware Pyramid Pooling, SCPP）
    功能：融合局部特征、多尺度特征、全局特征，强化特征的多维度表达
    核心设计：
        - 三特征分支：局部特征（1×1卷积）、多尺度特征（ScaleAwareModule）、全局特征（全局池化+MLP）
        - 特征拼接融合：三分支特征沿通道维度拼接，经1×1卷积压缩，避免维度膨胀
        - 无下采样设计：保持输入输出空间尺寸一致，支持即插即用
    """

    def __init__(self, in_channels, out_channels=None, se_reduction=16, dilation_rates=(1, 3, 5)):
        super().__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels or in_channels  # 输出通道数（默认与输入一致）

        # 1. 局部特征提取分支（1×1卷积，强化局部细节）
        self.conv1x1 = nn.Sequential(
            nn.Conv2d(in_channels, in_channels, kernel_size=1, bias=False),
            nn.BatchNorm2d(in_channels),
            nn.ReLU(inplace=True)
        )

        # 2. 多尺度特征提取分支（尺度感知模块）
        self.scale_module = ScaleAwareModule(in_channels, dilation_rates=dilation_rates, se_reduction=se_reduction)

        # 3. 全局特征聚合分支（全局池化+MLP，强化全局一致性）
        self.global_fc = nn.Sequential(
            nn.Linear(in_channels, in_channels, bias=True),
            nn.ReLU(inplace=True)
        )

        # 4. 三特征融合与输出投影（3C→out_channels）
        self.out_conv = nn.Sequential(
            nn.Conv2d(in_channels * 3, self.out_channels, kernel_size=1, bias=False),
            nn.BatchNorm2d(self.out_channels),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        """
        前向传播：SCPP三特征融合流程
        Args:
            x: 输入特征，shape=[b, in_channels, h, w]
        Returns:
            增强后的特征，shape=[b, out_channels, h, w]（与输入空间尺寸一致）
        """
        B, C, H, W = x.shape

        # 1. 局部特征提取：[b, C, h, w]→[b, C, h, w]
        local_feat = self.conv1x1(x)

        # 2. 多尺度特征提取与注意力融合：[b, C, h, w]→[b, C, h, w]
        scale_fused, _, _ = self.scale_module(x)

        # 3. 全局特征聚合：[b, C, h, w]→[b, C, h, w]
        gap = F.adaptive_avg_pool2d(x, 1).view(B, C)  # 全局平均池化：[b, C]
        global_feat = self.global_fc(gap)  # MLP增强：[b, C]
        global_feat = global_feat.view(B, C, 1, 1).expand(-1, -1, H, W)  # 广播至空间尺寸

        # 4. 三特征拼接融合：[b, 3C, h, w]→[b, out_channels, h, w]
        cat_feat = torch.cat([scale_fused, local_feat, global_feat], dim=1)  # 通道拼接
        out = self.out_conv(cat_feat)  # 特征压缩与增强

        return out


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 64, 32, 32).to(device)
    model = SCPP(64, 64).to(device)

    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN、小红书：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)