# 空间-通道特征调制器（Spatial-Channel Feature Modulator, SCFM）
# 核心设计：基于“归一化+双注意力并行调制”的架构，
# 通过LayerNorm稳定特征分布，并行引入通道注意力（Channel Attention）与空间注意力（Spatial Attention），
# 分别强化关键通道特征与空间关键区域，再经独立卷积投影融合，实现特征的精准调制与增强，
# 提升特征的辨识度与鲁棒性，且轻量化设计适配各类视觉模型


import torch
import torch.nn as nn
import torch.autograd
import numbers
from einops import rearrange


def to_3d(x):
    return rearrange(x, 'b c h w -> b (h w) c')


def to_4d(x, h, w):
    return rearrange(x, 'b (h w) c -> b c h w', h=h, w=w)


class WithBias_LayerNorm(nn.Module):
    def __init__(self, normalized_shape):
        super(WithBias_LayerNorm, self).__init__()
        if isinstance(normalized_shape, numbers.Integral):
            normalized_shape = (normalized_shape,)
        normalized_shape = torch.Size(normalized_shape)

        assert len(normalized_shape) == 1

        self.weight = nn.Parameter(torch.ones(normalized_shape))
        self.bias = nn.Parameter(torch.zeros(normalized_shape))
        self.normalized_shape = normalized_shape

    def forward(self, x):
        return x * torch.rsqrt(x.pow(2).mean(-1, keepdim=True) + 1e-6) * self.weight + self.bias


class LayerNorm(nn.Module):
    def __init__(self, dim):
        super(LayerNorm, self).__init__()

        self.body = WithBias_LayerNorm(dim)

    def forward(self, x):
        h, w = x.shape[-2:]
        return to_4d(self.body(to_3d(x)), h, w)


class ChannelAttention(nn.Module):
    def __init__(self, in_planes, ratio=16):
        super(ChannelAttention, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)

        self.fc = nn.Sequential(nn.Conv2d(in_planes, in_planes // ratio, 1, bias=False),
                                nn.ReLU(),
                                nn.Conv2d(in_planes // ratio, in_planes, 1, bias=False))
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = self.fc(self.avg_pool(x))
        max_out = self.fc(self.max_pool(x))
        out = avg_out + max_out
        return self.sigmoid(out)


class SpatialAttention(nn.Module):
    def __init__(self, kernel_size=7):
        super(SpatialAttention, self).__init__()

        self.conv1 = nn.Conv2d(2, 1, kernel_size, padding=kernel_size // 2, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = torch.mean(x, dim=1, keepdim=True)
        max_out, _ = torch.max(x, dim=1, keepdim=True)
        x = torch.cat([avg_out, max_out], dim=1)
        x = self.conv1(x)
        return self.sigmoid(x)


class SCFM(nn.Module):
    """
    空间-通道特征调制器（Spatial-Channel Feature Modulator, SCFM）
    功能：并行空间注意力与通道注意力，双路径调制特征，提升特征表达精准度
    核心设计：
        - 归一化先行：LayerNorm稳定特征分布，为注意力调制打基础
        - 双注意力并行：通道注意力强化关键通道，空间注意力强化关键区域，互补增强
        - 独立投影融合：双注意力调制后的特征经独立1×1卷积投影，避免信息干扰，融合更高效
        - 轻量化架构：无复杂组件，计算成本低，即插即用
    Args:
        feature_dim: 输入/输出特征通道数（需保持一致）
    """
    def __init__(self, feature_dim):
        super().__init__()
        self.norm = LayerNorm(feature_dim)
        self.chan_attn = ChannelAttention(feature_dim)
        self.spat_attn = SpatialAttention()
        self.conv_1 = nn.Conv2d(feature_dim, feature_dim, 1, 1, 0)
        self.conv_2 = nn.Conv2d(feature_dim, feature_dim, 1, 1, 0)

    def forward(self, x):
        x_norm = self.norm(x)
        x_attn = self.conv_1(self.chan_attn(x_norm) * x_norm) + self.conv_2(self.spat_attn(x_norm) * x_norm)
        return x_attn


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 64, 32, 32).to(device)
    model = SCFM(64).to(device)

    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("小红书：十小大，主页获取往期全部即插即用代码，200+大合集")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)
