import torch
import torch.nn as nn


class ChannelAttention(nn.Module):
    """
    CBAM风格通道注意力模块：强化重要通道特征，抑制冗余通道
    Args:
        in_channels (int): 输入通道数
        reduction (int): 通道降维比例，默认16
    Input: x - 待增强特征 [B, C, H, W]
    Output: 通道调制后的特征 [B, C, H, W]
    """
    def __init__(self, in_channels: int, reduction: int = 16):
        super().__init__()
        hidden_channels = max(1, in_channels // reduction)  # 降维后的隐藏通道数（最小为1）
        self.avg_pool = nn.AdaptiveAvgPool2d(1)  # 全局平均池化提取通道统计信息
        # MLP通道投影：降维→激活→升维，学习通道依赖
        self.mlp = nn.Sequential(
            nn.Conv2d(in_channels, hidden_channels, 1, bias=False),
            nn.ReLU(inplace=True),
            nn.Conv2d(hidden_channels, in_channels, 1, bias=False),
        )
        self.sigmoid = nn.Sigmoid()  # 生成通道注意力掩码（[0,1]）

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # 生成通道注意力权重：全局池化→MLP→Sigmoid
        weight = self.sigmoid(self.mlp(self.avg_pool(x)))
        return x * weight  # 通道级逐元素调制

class SpatialAttention(nn.Module):
    """
    CBAM风格空间注意力模块：强化重要空间区域特征，聚焦关键结构
    Args:
        kernel_size (int): 卷积核尺寸，仅支持3或7（保证尺寸守恒）
    Input: x - 待增强特征 [B, C, H, W]
    Output: 空间调制后的特征 [B, C, H, W]
    """
    def __init__(self, kernel_size: int = 7):
        super().__init__()
        assert kernel_size in (3, 7), "空间注意力卷积核仅支持3或7"
        padding = 3 if kernel_size == 7 else 1  # 等宽填充，保证输出尺寸与输入一致
        # 单通道卷积学习空间依赖（输入为通道平均后的单通道特征）
        self.conv = nn.Conv2d(1, 1, kernel_size=kernel_size, padding=padding, bias=False)
        self.sigmoid = nn.Sigmoid()  # 生成空间注意力掩码（[0,1]）

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # 通道平均池化提取空间特征（压缩通道维度）
        avg_map = torch.mean(x, dim=1, keepdim=True)
        # 生成空间注意力权重：卷积→Sigmoid
        weight = self.sigmoid(self.conv(avg_map))
        return x * weight  # 空间级逐元素调制

class CascadeFusionBlock(nn.Module):
    """
    级联交叉融合块（CSSP核心模块）：通过双向交叉相关性建模+级联优化，实现谱-空特征联合感知
    核心：先对双分支特征做专属注意力精修，再通过级联交叉融合实现双向增强，最后拼接融合
    Args:
        channels (int): 输入特征通道数（双分支通道数需一致）
    Inputs:
        f_h (Tensor): 高维/光谱特征 [B, C, H, W]
        f_s (Tensor): 空间/结构特征 [B, C, H, W]（与f_h尺寸、通道数一致）
    Output: 级联融合后的特征 [B, C, H, W]
    """
    def __init__(self, channels: int):
        super().__init__()
        self.channel_att = ChannelAttention(channels)  # 高维/光谱特征专属通道注意力
        self.spatial_att = SpatialAttention()  # 空间/结构特征专属空间注意力
        # 拼接融合后通道压缩+精修：2C→C，保证输出通道数一致
        self.fuse_conv = nn.Sequential(
            nn.Conv2d(channels * 2, channels, kernel_size=1, bias=False),
            nn.BatchNorm2d(channels),
            nn.ReLU(inplace=True),
        )

    def _normalize(self, x: torch.Tensor, eps: float = 1e-6) -> torch.Tensor:
        """L2归一化：避免特征幅值差异过大，提升相关性计算稳定性"""
        norm = torch.norm(x, p=2)
        return x / (norm + eps)

    def forward(self, f_h: torch.Tensor, f_s: torch.Tensor) -> torch.Tensor:
        # 步骤1：双分支专属注意力精修（通道注意力→高维特征，空间注意力→空间特征）
        f_h = f_h + self.channel_att(f_h)  # 残差连接，保留原始特征
        f_s = f_s + self.spatial_att(f_s)

        # 步骤2：特征展平，适配交叉相关性计算
        B, C, H, W = f_h.shape
        f_h_flat = f_h.view(B, C, -1)  # [B, C, H*W] 展平为通道×空间点矩阵
        f_s_flat = f_s.view(B, C, -1)

        # 步骤3：级联双向交叉融合（第一级：f_h引导f_s精修）
        M1 = torch.matmul(f_h_flat.transpose(1, 2), f_s_flat)  # [B, H*W, H*W] 交叉相关性矩阵
        M1 = torch.tanh(self._normalize(M1))  # 归一化+激活，增强非线性表达
        f_s_refine = torch.matmul(f_h_flat, M1) + f_s_flat  # [B, C, H*W] f_h引导f_s精修（残差）

        # 步骤4：级联双向交叉融合（第二级：精修后的f_s引导f_h精修）
        M2 = torch.matmul(f_s_refine.transpose(1, 2), f_h_flat)  # 反向交叉相关性矩阵
        M2 = torch.tanh(self._normalize(M2))
        f_h_refine = torch.matmul(f_s_refine, M2) + f_h_flat  # [B, C, H*W] f_s引导f_h精修（残差）

        # 步骤5：恢复特征尺寸，拼接融合+通道压缩
        f_h_refine = f_h_refine.view(B, C, H, W)
        f_s_refine = f_s_refine.view(B, C, H, W)
        out = torch.cat([f_h_refine, f_s_refine], dim=1)  # [B, 2C, H, W] 拼接
        return self.fuse_conv(out)  # [B, C, H, W] 通道压缩+精修


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    f_h = torch.randn(1, 64, 32, 32).to(device)
    f_s = torch.randn(1, 64, 32, 32).to(device)
    model = CascadeFusionBlock(64).to(device)

    y = model(f_h, f_s)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("小红书：十小大，主页获取往期全部即插即用代码，200+大合集")

    print("输入特征维度：", f_h.shape)
    print("输入特征维度：", f_s.shape)
    print("输出特征维度：", y.shape)