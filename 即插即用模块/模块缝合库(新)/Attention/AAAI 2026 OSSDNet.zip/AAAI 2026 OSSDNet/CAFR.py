import torch
import torch.nn as nn
import torch.nn.functional as F


class FeatureEnhancementModule(nn.Module):
    """
    跨谱注意力特征精修模块（CAFR）核心实现
    核心：通过通道级交叉注意力建模低/高分辨率特征的跨通道交互，结合全局描述符调制特征，最终融合增强
    Args:
        channels (int): 输入特征通道数（低/高分辨率特征通道数需一致）
    Inputs:
        feat_low: 低层级（高分辨率）特征 [B, C, H, W]
        feat_high: 高层级（低分辨率）特征 [B, C, H/2, W/2]
    Output:
        融合增强后的特征 [B, C, H/2, W/2]（与高层级特征尺寸一致）
    """
    def __init__(self, channels: int):
        super().__init__()
        # 低层级特征下采样：将高分辨率feat_low降维至feat_high的尺寸（H/2, W/2），保证分辨率对齐
        self.downsample = nn.Conv2d(
            channels, channels, kernel_size=3, stride=2, padding=1, bias=False
        )
        # 全局平均池化：提取通道级全局描述符（捕捉全局特征统计信息）
        self.global_pool = nn.AdaptiveAvgPool2d(1)
        # 通道投影：对全局描述符做线性变换，增强表达能力
        self.fc_low = nn.Conv2d(channels, channels, kernel_size=1, bias=False)
        self.fc_high = nn.Conv2d(channels, channels, kernel_size=1, bias=False)
        # 融合卷积：对调制后的特征做进一步精修，保证融合特征的一致性
        self.fuse = nn.Sequential(
            nn.Conv2d(channels, channels, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(channels),
            nn.ReLU(inplace=True),
        )

    def _channel_cross_attention(
        self, low_desc: torch.Tensor, high_desc: torch.Tensor
    ):
        """
        计算通道级交叉注意力：建模低/高特征通道间的依赖关系，生成通道调制权重
        Args:
            low_desc: 低层级特征全局描述符 [B, C, 1, 1]
            high_desc: 高层级特征全局描述符 [B, C, 1, 1]
        Returns:
            low_refined: 低层级特征通道调制权重 [B, C, 1, 1]
            high_refined: 高层级特征通道调制权重 [B, C, 1, 1]
        """
        B, C, _, _ = low_desc.shape
        # 重塑为向量形式，适配矩阵乘法计算交叉注意力
        low_vec = low_desc.reshape(B, C, 1)
        high_vec = high_desc.reshape(B, C, 1)
        # 计算通道交叉相似度矩阵：衡量低/高特征各通道间的相关性 [B, C, C]
        weight = torch.matmul(low_vec, high_vec.transpose(1, 2))
        weight = F.softmax(weight, dim=-1)  # 对列归一化，得到注意力权重
        # 基于交叉注意力精炼通道描述符，生成最终调制权重
        low_refined = torch.matmul(weight, low_vec).reshape(B, C, 1, 1)
        high_refined = torch.matmul(weight.transpose(1, 2), high_vec).reshape(B, C, 1, 1)
        return low_refined, high_refined

    def forward(self, feat_low: torch.Tensor, feat_high: torch.Tensor) -> torch.Tensor:
        """CAFR前向传播：分辨率对齐→全局描述符提取→通道交叉注意力→特征调制→融合精修"""
        # 步骤1：低层级特征下采样，与高层级特征分辨率对齐 [B,C,H,W]→[B,C,H/2,W/2]
        feat_low = self.downsample(feat_low)
        # 步骤2：提取低/高特征的全局通道描述符（全局池化+通道投影）
        low_desc = self.fc_low(self.global_pool(feat_low))
        high_desc = self.fc_high(self.global_pool(feat_high))
        # 步骤3：计算通道交叉注意力，生成通道调制权重
        low_weight, high_weight = self._channel_cross_attention(low_desc, high_desc)
        # 步骤4：通道权重调制特征，强化有效通道，抑制冗余通道
        feat_low = feat_low * low_weight
        feat_high = feat_high * high_weight
        # 步骤5：特征相加融合+卷积精修，输出增强特征
        out = self.fuse(feat_low + feat_high)
        return out


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    f_l = torch.randn(1, 64, 32, 32).to(device)
    f_h = torch.randn(1, 64, 16, 16).to(device)
    model = FeatureEnhancementModule(64).to(device)

    y = model(f_l, f_h)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("小红书：十小大，主页获取往期全部即插即用代码，200+大合集")

    print("输入高分辨特征维度：", f_l.shape)
    print("输入低分辨率特征维度：", f_h.shape)
    print("输出特征维度：", y.shape)