import torch
import torch.nn as nn
import torch.nn.functional as F


class AdaptiveSpectralFeatureRefinementEuclidean(nn.Module):
    """
    基于欧氏距离的自适应光谱特征精修模块(ASFR-Eu)
    核心：通过局部patch的欧氏距离相似度加权融合，精修光谱特征的细节表达
    Args:
        patch_size: 局部特征块尺寸，默认3
    Inputs:
        fe_lv: 待精修的基础光谱特征 [B, C, H, W]
        fused_features: 参考光谱特征 [B, C, H, W]
    Output:
        残差连接的精修后光谱特征 [B, C, H, W]
    """
    def __init__(self, patch_size: int = 3):
        super().__init__()
        self.patch_size = patch_size
        self.unfold = nn.Unfold(kernel_size=patch_size, padding=patch_size // 2)  # 滑窗提取局部patch，保持尺寸不变

    def forward(self, fe_lv: torch.Tensor, fused_features: torch.Tensor) -> torch.Tensor:
        B, C, H, W = fe_lv.shape
        # 滑窗展开为局部patch：[B, C*k*k, H*W] → 重塑为[B, C, k*k, H*W]
        patches = self.unfold(fused_features).reshape(B, C, self.patch_size * self.patch_size, H * W)
        fe_lv_flat = fe_lv.reshape(B, C, H * W)  # 基础特征展平 [B, C, H*W]

        # 计算每个像素与周围patch的欧氏距离，衡量特征相似性
        distances = torch.norm(
            patches.permute(0, 3, 2, 1) - fe_lv_flat.permute(0, 2, 1).unsqueeze(2),
            dim=-1
        )  # [B, H*W, k*k]
        weights = F.softmax(-distances, dim=-1)  # 距离取负做softmax，相似patch权重更高

        # 加权融合局部patch特征，精修基础特征
        refined = torch.matmul(weights.unsqueeze(2),
                               patches.permute(0, 3, 2, 1).reshape(B, H * W, self.patch_size * self.patch_size, C))
        # 重塑为原特征尺寸并添加残差连接，保留原始特征信息
        refined = refined.squeeze(2).permute(0, 2, 1).reshape(B, C, H, W)
        return refined + fe_lv

class AdaptiveSpectralFeatureRefinementCosine(nn.Module):
    """
    基于余弦相似度的自适应光谱特征精修模块(ASFR-Cos)
    核心：通过局部patch的余弦相似度加权融合，聚焦光谱特征的方向一致性精修
    参数/输入输出与ASFR-Eu一致
    """
    def __init__(self, patch_size: int = 3):
        super().__init__()
        self.patch_size = patch_size
        self.unfold = nn.Unfold(kernel_size=patch_size, padding=patch_size // 2)

    def forward(self, fe_lv: torch.Tensor, fused_features: torch.Tensor) -> torch.Tensor:
        B, C, H, W = fe_lv.shape
        patches = self.unfold(fused_features).reshape(B, C, self.patch_size * self.patch_size, H * W)
        fe_lv_flat = fe_lv.reshape(B, C, H * W)

        # 特征L2归一化，计算余弦相似度（衡量特征方向相似性）
        patches_norm = F.normalize(patches, dim=1)
        fe_lv_norm = F.normalize(fe_lv_flat, dim=1)
        cosine_sim = torch.einsum('bhkc,bhc->bhk', patches_norm.permute(0, 3, 2, 1), fe_lv_norm.permute(0, 2, 1))
        weights = F.softmax(cosine_sim, dim=-1)  # 相似度越高，权重越大

        # 加权融合+残差连接
        refined = torch.matmul(weights.unsqueeze(2),
                               patches.permute(0, 3, 2, 1).reshape(B, H * W, self.patch_size * self.patch_size, C))
        refined = refined.squeeze(2).permute(0, 2, 1).reshape(B, C, H, W)
        return refined + fe_lv

class AdaptiveSpectralFeatureRefinementCombined(nn.Module):
    """
    融合欧氏距离+余弦相似度的自适应光谱特征精修模块(ASFR-Com)
    核心：结合距离（特征幅值）和余弦（特征方向）的双重相似性，更全面精修光谱特征
    Args:
        fusion_method: 权重融合方式，add(加权相加)/concat(拼接后softmax)
        alpha: add模式下余弦相似度的权重系数，默认0.5
    其他参数/输入输出与ASFR-Eu一致
    """
    def __init__(self, patch_size: int = 3, fusion_method: str = 'add', alpha: float = 0.5):
        super().__init__()
        self.patch_size = patch_size
        self.unfold = nn.Unfold(kernel_size=patch_size, padding=patch_size // 2)
        self.fusion_method = fusion_method
        self.alpha = alpha  # 余弦权重系数

    def forward(self, fe_lv: torch.Tensor, fused_features: torch.Tensor) -> torch.Tensor:
        B, C, H, W = fe_lv.shape
        patches = self.unfold(fused_features).reshape(B, C, self.patch_size * self.patch_size, H * W)
        fe_lv_flat = fe_lv.reshape(B, C, H * W)

        # 余弦相似度分支
        patches_norm = F.normalize(patches, dim=1)
        fe_lv_norm = F.normalize(fe_lv_flat, dim=1)
        cosine_sim = torch.einsum('bhkc,bhc->bhk', patches_norm.permute(0, 3, 2, 1), fe_lv_norm.permute(0, 2, 1))
        cosine_weights = F.softmax(cosine_sim, dim=-1)

        # 欧氏距离分支
        distances = torch.norm(patches.permute(0, 3, 2, 1) - fe_lv_flat.permute(0, 2, 1).unsqueeze(2), dim=-1)
        euclidean_weights = F.softmax(-distances, dim=-1)

        # 双重权重融合
        patches_reshaped = patches.permute(0, 3, 2, 1).reshape(B, H * W, self.patch_size * self.patch_size, C)
        if self.fusion_method == 'add':
            weights = self.alpha * cosine_weights + (1 - self.alpha) * euclidean_weights
            refined = torch.matmul(weights.unsqueeze(2), patches_reshaped)
        else:  # concat模式
            refined_cos = torch.matmul(cosine_weights.unsqueeze(2), patches_reshaped)
            refined_euc = torch.matmul(euclidean_weights.unsqueeze(2), patches_reshaped)
            refined = torch.cat([refined_cos, refined_euc], dim=-1)

        refined = refined.squeeze(2).permute(0, 2, 1).reshape(B, -1, H, W)
        return refined + fe_lv

class StripConvBlock(nn.Module):
    """
    条带卷积块：水平+垂直分离卷积，提取空间方向特征，为边缘增强做基础
    Args:
        in_channels/out_channels: 输入/输出通道数
        kernel_size: 卷积核尺寸，默认3
    """
    def __init__(self, in_channels: int, out_channels: int, kernel_size: int = 3):
        super().__init__()
        self.h_conv = nn.Conv2d(in_channels, out_channels, (1, kernel_size), padding=(0, kernel_size//2), bias=False)  # 水平卷积
        self.v_conv = nn.Conv2d(in_channels, out_channels, (kernel_size, 1), padding=(kernel_size//2, 0), bias=False)  # 垂直卷积

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.h_conv(x) + self.v_conv(x)  # 水平+垂直特征融合

class EdgeEnhanceSpatialFeatureRefinement(nn.Module):
    """
    边缘增强的空间特征精修模块(ESFR)
    核心：分离特征的低频（全局结构）和高频（边缘细节），对高频做注意力增强，融合后精修空间特征
    Args:
        in_channels: 输入通道数
    Input: x - 待精修的空间特征 [B, C, H, W]
    Output: 残差连接的边缘增强后空间特征 [B, C, H, W]
    """
    def __init__(self, in_channels: int):
        super().__init__()
        self.avgpool = nn.AvgPool2d(3, stride=2, padding=1)  # 下采样提取低频
        self.conv3 = nn.Conv2d(in_channels, in_channels, 3, padding=1, bias=False)  # 低频特征精修
        self.conv1_1 = nn.Conv2d(in_channels, 1, 1, bias=False)  # 高频注意力掩码生成
        self.conv1_2 = nn.Conv2d(in_channels * 2, in_channels, 1, bias=False)  # 高低频融合卷积

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # 提取低频特征：下采样→卷积精修→上采样恢复尺寸（保留全局结构）
        F_L = self.avgpool(x)
        F_L = F.interpolate(self.conv3(F_L), size=x.shape[2:], mode='bilinear', align_corners=True)
        # 提取高频特征：原始特征 - 下采样再上采样的特征（保留边缘细节）
        F_H = x - F.interpolate(self.avgpool(x), size=x.shape[2:], mode='bilinear', align_corners=True)
        # 高频注意力增强：生成空间注意力掩码，强化有效边缘细节
        weight = torch.sigmoid(self.conv1_1(F_H))
        F_H = F_H * weight + F_H
        # 高低频融合+残差连接
        out = self.conv1_2(torch.cat([F_H, F_L], dim=1))
        return out + x

class SpectralSpatialAdaptiveFusion(nn.Module):
    """
    光谱-空间自适应融合模块(SSAF)，即SACF核心模块
    核心：先分别精修光谱特征（ASFR）和空间特征（ESFR），再通过自适应权重实现跨层/跨模态特征融合
    Args:
        in_channels: 输入通道数
        patch_size: ASFR的局部patch尺寸，默认3
    Inputs:
        fh: 高光谱/低分辨率跨层特征 [B, C, Hh, Wh]
        fs: 空间/高分辨率跨层特征 [B, C, Hs, Ws]
    Output:
        自适应融合后的特征 [B, C, Hs, Ws]
    """
    def __init__(self, in_channels: int, patch_size: int = 3):
        super().__init__()
        self.asfr = AdaptiveSpectralFeatureRefinementEuclidean(patch_size=patch_size)  # 光谱特征精修
        self.esfr = EdgeEnhanceSpatialFeatureRefinement(in_channels)  # 空间特征精修
        self.adp_conv = nn.Conv2d(2, 2, 1, bias=False)  # 自适应权重生成卷积
        self.fuse_conv = nn.Sequential(  # 融合后特征精修
            nn.Conv2d(in_channels, in_channels, 1, bias=False),
            nn.BatchNorm2d(in_channels),
            nn.ReLU(inplace=True)
        )

    def forward(self, fh: torch.Tensor, fs: torch.Tensor) -> torch.Tensor:
        # 步骤1：光谱特征精修+尺寸对齐，将fh上采样至fs的尺寸
        fh = self.asfr(fh, fh)
        fh = F.interpolate(fh, size=fs.shape[2:], mode='bilinear', align_corners=True)
        # 步骤2：空间特征边缘增强精修
        fs = self.esfr(fs)
        # 步骤3：生成自适应融合权重，基于特征的通道平均池化
        fh_avg, fs_avg = fh.mean(1, keepdim=True), fs.mean(1, keepdim=True)  # [B,1,H,W]
        weights = torch.sigmoid(self.adp_conv(torch.cat([fh_avg, fs_avg], dim=1)))  # [B,2,H,W]
        # 步骤4：权重加权融合光谱和空间特征
        out = weights[:, 0:1] * fh + weights[:, 1:2] * fs
        # 步骤5：融合后特征精修，提升特征表达一致性
        return self.fuse_conv(out)


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    f_l = torch.randn(1, 64, 32, 32).to(device)
    f_h = torch.randn(1, 64, 16, 16).to(device)
    model = SpectralSpatialAdaptiveFusion(64).to(device)

    y = model(f_h, f_l)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("小红书：十小大，主页获取往期全部即插即用代码，200+大合集")

    print("输入高分辨特征维度：", f_l.shape)
    print("输入低分辨率特征维度：", f_h.shape)
    print("输出特征维度：", y.shape)