import torch
import torch.nn as nn


def autopad(k, p=None):  # kernel, padding
    # Pad to 'same'
    if p is None:
        p = k // 2 if isinstance(k, int) else [x // 2 for x in k]  # auto-pad
    return p


class Conv(nn.Module):
    # Standard convolution with args(ch_in, ch_out, kernel, stride, padding, groups, dilation, activation)
    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, act=True):  # ch_in, ch_out, kernel, stride, padding, groups
        super(Conv, self).__init__()
        self.conv = nn.Conv2d(c1, c2, k, s, autopad(k, p), groups=g, bias=False)
        self.bn = nn.BatchNorm2d(c2)
        self.act = nn.SiLU() if act is True else (act if isinstance(act, nn.Module) else nn.Identity())

    def forward(self, x):
        return self.act(self.bn(self.conv(x)))

    def fuseforward(self, x):
        return self.act(self.conv(x))


# Cross-modal Global Modeling Module (CGMM), 图4
class NLFEM(nn.Module):
    def __init__(self, in_channels):
        super(NLFEM, self).__init__()
        self.conv = nn.Conv2d(in_channels=in_channels, out_channels=in_channels, kernel_size=1)
        self.key = Conv(in_channels, 1, 1, 1)
        self.value = Conv(in_channels, in_channels, 1, 1)
        self.convb = nn.Conv2d(in_channels=in_channels, out_channels=in_channels, kernel_size=1, bias=False)
        self.conv_half = Conv(2, 1, 1, 1)

        self.avg_pool = nn.AdaptiveAvgPool2d(1)  # GAP
        self.max_pool = nn.AdaptiveMaxPool2d(1)  # GMP
        self.layernorm = nn.LayerNorm([in_channels, 1, 1])

    def forward(self, x):
        rgb_fea = x[0]
        ir_fea = x[1]
        #print('in NLFEM rgb_fea shape: ', rgb_fea.shape)
        #print('in NLFEM ir_fea shape: ', ir_fea.shape)

        N, C, H, W = rgb_fea.shape
        rgb_fea_conv = self.conv(rgb_fea)
        ir_fea_conv = self.conv(ir_fea)
        # RGB
        # avg max: [N, 1, 1, C]
        rgb_avg = self.avg_pool(rgb_fea_conv).softmax(1).contiguous().view(N, 1, 1, C)
        rgb_max = self.max_pool(rgb_fea_conv).softmax(1).contiguous().view(N, 1, 1, C)

        # key: [N, 1, HW, 1]
        rgb_key = self.key(rgb_fea).contiguous().view(N, 1, -1, 1).softmax(2)

        # value: [N, 1, C, HW]
        rgb_value = self.value(rgb_fea).contiguous().view(N, 1, C, -1)

        # IR
        # avg max: [N, 1, 1, C]
        ir_avg = self.avg_pool(ir_fea_conv).softmax(1).contiguous().view(N, 1, 1, C)
        ir_max = self.max_pool(ir_fea_conv).softmax(1).contiguous().view(N, 1, 1, C)

        # key: [N, 1, HW, 1]
        ir_key = self.key(ir_fea).contiguous().view(N, 1, -1, 1).softmax(2)

        # value: [N, 1, C, HW]
        ir_value = self.value(ir_fea).contiguous().view(N, 1, C, -1)

        # RGB
        # [N, C, 1, 1]
        rgb_fea_ = torch.matmul(ir_value, rgb_key).contiguous().view(N, C, 1, 1)

        # [N, 1, H, W]
        rgb_fea_avg = torch.matmul(rgb_avg, ir_value).contiguous().view(N, 1, H, W)
        rgb_fea_max = torch.matmul(rgb_max, ir_value).contiguous().view(N, 1, H, W)

        # [N, 2, H, W]
        rgb_fea_cat = torch.cat([rgb_fea_avg, rgb_fea_max], 1)

        # [N, C, H, W]
        out_rgb_fea = self.layernorm(self.convb(rgb_fea_)).sigmoid() * self.conv_half(rgb_fea_cat)

        # IR
        # [N, C, 1, 1]
        ir_fea_ = torch.matmul(rgb_value, ir_key).contiguous().view(N, C, 1, 1)

        # [N, 1, H, W]
        ir_fea_avg = torch.matmul(ir_avg, rgb_value).contiguous().view(N, 1, H, W)
        ir_fea_max = torch.matmul(ir_max, rgb_value).contiguous().view(N, 1, H, W)

        # [N, 2, H, W]
        ir_fea_cat = torch.cat([ir_fea_avg, ir_fea_max], 1)
        out_ir_fea = self.layernorm(self.convb(ir_fea_)).sigmoid() * self.conv_half(ir_fea_cat)

        out_rgb = out_rgb_fea + rgb_fea
        out_ir = out_ir_fea + ir_fea

        return [out_rgb, out_ir]


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    rgb = torch.randn(1, 64, 32, 32).to(device)
    ir = torch.randn(1, 64, 32, 32).to(device)
    x = [rgb, ir]
    model = NLFEM(64).to(device)

    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("小红书：十小大，主页获取往期全部即插即用代码，200+大合集")

    print("输入RGB特征维度：", x[0].shape)
    print("输入IR特征维度：", x[1].shape)
    print("输出增强后RGB特征维度：", y[0].shape)
    print("输出增强后IR特征维度：", y[1].shape)