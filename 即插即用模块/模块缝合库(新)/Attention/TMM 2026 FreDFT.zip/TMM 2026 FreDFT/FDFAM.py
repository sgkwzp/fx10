import torch
import torch.nn as nn
import numbers
from einops import rearrange

# -------------------------- 维度变换工具函数 适配LayerNorm与频域操作 --------------------------
def to_3d(x):
    """将4D图像特征[B,C,H,W]转为3D序列特征[B,N,C]，适配LayerNorm计算"""
    return rearrange(x, 'b c h w -> b (h w) c')

def to_4d(x, h, w):
    """将3D序列特征还原为4D图像特征，适配卷积与频域操作"""
    return rearrange(x, 'b (h w) c -> b c h w', h=h, w=w)

# -------------------------- 适配图像的LayerNorm模块 对应结构图LayerNorm模块 --------------------------
class BiasFree_LayerNorm(nn.Module):
    """无偏置层归一化，适配频域特征的通道级归一化"""
    def __init__(self, normalized_shape):
        super(BiasFree_LayerNorm, self).__init__()
        if isinstance(normalized_shape, numbers.Integral):
            normalized_shape = (normalized_shape,)
        normalized_shape = torch.Size(normalized_shape)
        assert len(normalized_shape) == 1
        self.weight = nn.Parameter(torch.ones(normalized_shape))
        self.normalized_shape = normalized_shape

    def forward(self, x):
        sigma = x.var(-1, keepdim=True, unbiased=False)
        return x / torch.sqrt(sigma + 1e-5) * self.weight

class WithBias_LayerNorm(nn.Module):
    """带偏置层归一化，Transformer标准归一化实现"""
    def __init__(self, normalized_shape):
        super(WithBias_LayerNorm, self).__init__()
        if isinstance(normalized_shape, numbers.Integral):
            normalized_shape = (normalized_shape,)
        normalized_shape = torch.Size(normalized_shape)
        assert len(normalized_shape) == 1
        self.weight = nn.Parameter(torch.ones(normalized_shape))
        self.bias = nn.Parameter(torch.zeros(normalized_shape))
        self.normalized_shape = normalized_shape

    def forward(self, x):
        mu = x.mean(-1, keepdim=True)
        sigma = x.var(-1, keepdim=True, unbiased=False)
        return (x - mu) / torch.sqrt(sigma + 1e-5) * self.weight + self.bias

class LayerNorm(nn.Module):
    """图像特征统一LayerNorm封装，支持带偏置/无偏置两种模式，适配4D图像输入"""
    def __init__(self, dim, LayerNorm_type):
        super(LayerNorm, self).__init__()
        if LayerNorm_type == 'BiasFree':
            self.body = BiasFree_LayerNorm(dim)
        else:
            self.body = WithBias_LayerNorm(dim)

    def forward(self, x):
        h, w = x.shape[-2:]
        return to_4d(self.body(to_3d(x)), h, w)

class Concat(nn.Module):
    """特征拼接模块 对应结构图中的C拼接符号"""
    def __init__(self, dimension=1):
        super(Concat, self).__init__()
        self.d = dimension

    def forward(self, x):
        return torch.cat(x, self.d)

# -------------------------- 对应结构图右侧【FDFFL】频域前馈层模块 --------------------------
class FDFFN(nn.Module):
    """
    FDFFN: Frequency Domain Feed-Forward Network 频域前馈网络
    完整对应结构图右侧FDFFL全流程，核心功能：多尺度空域卷积+频域跨分支交互，捕捉多尺度频域结构与细节信息
    """
    def __init__(self, dim, ffn_expansion_factor, bias):
        super(FDFFN, self).__init__()
        self.patch_size = 2
        hidden_features = int(dim * ffn_expansion_factor)
        # 输入1×1卷积升维
        self.project_in = nn.Conv2d(dim, hidden_features, kernel_size=1, bias=bias)
        # 多尺度深度卷积分支 对应结构图3/5/7-Dw-Conv
        self.dwconv3x3 = nn.Conv2d(hidden_features, hidden_features, kernel_size=3, stride=1, padding=1,
                                   groups=hidden_features, bias=bias)
        self.dwconv5x5 = nn.Conv2d(hidden_features, hidden_features, kernel_size=5, stride=1, padding=2,
                                   groups=hidden_features, bias=bias)
        self.dwconv7x7 = nn.Conv2d(hidden_features, hidden_features, kernel_size=7, stride=1, padding=3,
                                   groups=hidden_features, bias=bias)
        self.relu3 = nn.ReLU()
        self.relu5 = nn.ReLU()
        self.relu7 = nn.ReLU()
        # 频域交互后的二次深度卷积
        self.dwconv3x3_1 = nn.Conv2d(hidden_features, hidden_features, kernel_size=3, stride=1, padding=1,
                                     groups=hidden_features, bias=bias)
        self.dwconv5x5_1 = nn.Conv2d(hidden_features, hidden_features, kernel_size=5, stride=1, padding=2,
                                     groups=hidden_features, bias=bias)
        self.dwconv7x7_1 = nn.Conv2d(hidden_features, hidden_features, kernel_size=7, stride=1, padding=3,
                                     groups=hidden_features, bias=bias)
        self.relu3_1 = nn.ReLU()
        self.relu5_1 = nn.ReLU()
        self.relu7_1 = nn.ReLU()
        # 输出1×1卷积降维
        self.project_out = nn.Conv2d(hidden_features * 3, dim, kernel_size=1, bias=bias)

    def forward(self, x):
        # 步骤1：输入升维
        x = self.project_in(x)
        # 步骤2：多尺度深度卷积分支 对应结构图3/5/7-Dw-Conv
        x3 = self.relu3(self.dwconv3x3(x))
        x5 = self.relu5(self.dwconv5x5(x))
        x7 = self.relu7(self.dwconv7x7(x))
        # 步骤3：FFT变换到频域 对应结构图FFT模块
        x3_patch_fft = torch.fft.rfft2(x3.float())
        x5_patch_fft = torch.fft.rfft2(x5.float())
        x7_patch_fft = torch.fft.rfft2(x7.float())
        # 步骤4：通道拆分与跨分支频带重组 对应结构图Split+C跨分支交互
        x1_3, x2_3, x3_3 = x3_patch_fft.chunk(3, dim=1)
        x1_5, x2_5, x3_5 = x5_patch_fft.chunk(3, dim=1)
        x1_7, x2_7, x3_7 = x7_patch_fft.chunk(3, dim=1)
        # 跨分支频带拼接，实现多尺度频域信息交互
        x3_patch_fft = torch.cat([x1_3, x1_5, x1_7], dim=1)
        x5_patch_fft = torch.cat([x2_3, x2_5, x2_7], dim=1)
        x7_patch_fft = torch.cat([x3_3, x3_5, x3_7], dim=1)
        # 步骤5：IFFT逆变换回空域 对应结构图IFFT模块
        x3 = torch.fft.irfft2(x3_patch_fft, s=(x3.shape[2], x3.shape[3]))
        x5 = torch.fft.irfft2(x5_patch_fft, s=(x5.shape[2], x5.shape[3]))
        x7 = torch.fft.irfft2(x7_patch_fft, s=(x7.shape[2], x7.shape[3]))
        # 步骤6：二次深度卷积增强
        x3 = self.relu3_1(self.dwconv3x3_1(x3))
        x5 = self.relu5_1(self.dwconv5x5_1(x5))
        x7 = self.relu7_1(self.dwconv7x7_1(x7))
        # 步骤7：多分支拼接与输出降维
        x = torch.cat([x3, x5, x7], dim=1)
        x = self.project_out(x)
        return x

# -------------------------- 对应结构图左侧【Multimodal Frequency Domain Attention】模块 --------------------------
class FDCA(nn.Module):
    """
    FDCA: Multimodal Frequency Domain Cross-Attention 多模态频域交叉注意力
    完整对应结构图左侧全流程，核心功能：在频域实现红外与可见光的双向全局交互与互补增强
    """
    def __init__(self, dim, bias):
        super(FDCA, self).__init__()
        self.norm1 = LayerNorm(dim, LayerNorm_type='WithBias')
        # QKV生成：1×1卷积+深度可分离卷积
        self.to_hidden = nn.Conv2d(dim, dim * 6, kernel_size=1, bias=bias)
        self.to_hidden_dw = nn.Conv2d(dim * 6, dim * 6, kernel_size=3, stride=1, padding=1, groups=dim * 6, bias=bias)
        self.project_out = nn.Conv2d(dim * 2, dim, kernel_size=1, bias=bias)
        self.norm = LayerNorm(dim * 2, LayerNorm_type='WithBias')
        self.patch_size = 2

    def forward(self, x):
        # 输入双模态特征：rgb_fea=可见光特征E^G_RGB，ir_fea=红外特征E^G_IR
        rgb_fea = x[0]
        ir_fea = x[1]
        # 步骤1：层归一化 对应结构图LayerNorm模块
        rgb_fea_norm = self.norm1(rgb_fea)
        ir_fea_norm = self.norm1(ir_fea)
        # 步骤2：QKV特征映射 对应结构图Conv+Dw-Conv模块
        rgb_hidden = self.to_hidden(rgb_fea_norm)
        ir_hidden = self.to_hidden(ir_fea_norm)
        # 拆分Q/K/V，每个模态各生成一组QKV
        rgb_q, rgb_k, rgb_v = self.to_hidden_dw(rgb_hidden).chunk(3, dim=1)
        ir_q, ir_k, ir_v = self.to_hidden_dw(ir_hidden).chunk(3, dim=1)
        # 步骤3：FFT变换到频域 对应结构图FFT模块
        rgb_q_fft = torch.fft.rfft2(rgb_q.float())
        rgb_k_fft = torch.fft.rfft2(rgb_k.float())
        ir_q_fft = torch.fft.rfft2(ir_q.float())
        ir_k_fft = torch.fft.rfft2(ir_k.float())
        # 步骤4：频域注意力计算 对应结构图⊙元素乘模块
        rgb_out = rgb_q_fft * rgb_k_fft  # 可见光模态频域自注意力
        ir_out = ir_q_fft * ir_k_fft    # 红外模态频域自注意力
        # 步骤5：IFFT逆变换回空域 对应结构图IFFT模块
        rgb_out = torch.fft.irfft2(rgb_out, s=(rgb_q.shape[2], rgb_q.shape[3]))
        ir_out = torch.fft.irfft2(ir_out, s=(ir_q.shape[2], ir_q.shape[3]))
        # 步骤6：层归一化
        rgb_out = self.norm(rgb_out)
        ir_out = self.norm(ir_out)
        # 步骤7：跨模态双向加权 对应结构图跨模态V加权环节
        rgb_output = ir_v * rgb_out  # 红外V加权可见光特征，补充结构信息
        ir_output = rgb_v * ir_out  # 可见光V加权红外特征，补充细节信息
        # 步骤8：输出投影
        rgb_output = self.project_out(rgb_output)
        ir_output = self.project_out(ir_output)
        return rgb_output, ir_output

# -------------------------- FDFAM核心模块 完整对应结构图全流程 --------------------------
class FDFTM(nn.Module):
    """
    FDFAM: Frequency Domain Feature Aggregation Module 频域特征聚合模块（代码中命名为FDFTM）
    完整对应结构图全流程，核心功能：频域跨模态注意力+多尺度频域前馈网络，实现红外-可见光双模态特征的精准聚合与增强
    输入：[可见光特征, 红外特征]，输出：融合后的聚合特征
    """
    def __init__(self, dim):
        super(FDFTM, self).__init__()
        bias = False
        LayerNorm_type = 'WithBias'
        ffn_expansion_factor = 3
        # 多模态频域交叉注意力模块
        self.attn = FDCA(dim, bias)
        self.norm2 = LayerNorm(dim, LayerNorm_type)
        # 多尺度频域前馈网络
        self.ffn = FDFFN(dim, ffn_expansion_factor, bias)
        # 特征拼接与融合
        self.concat = Concat(dimension=1)
        self.conv = nn.Conv2d(dim * 2, dim, kernel_size=1, bias=bias)
        self.relu = nn.ReLU()

    def forward(self, x):
        # 输入双模态特征
        rgb_fea = x[0]
        ir_fea = x[1]
        # 步骤1：频域跨模态注意力增强
        rgb_fea_out, ir_fea_out = self.attn([rgb_fea, ir_fea])
        # 注意力残差连接
        rgb_att_out = rgb_fea + rgb_fea_out
        ir_att_out = ir_fea + ir_fea_out
        # 步骤2：频域前馈网络特征增强
        rgb_fea = rgb_att_out + self.ffn(self.norm2(rgb_att_out))
        ir_fea = ir_att_out + self.ffn(self.norm2(ir_att_out))
        # 步骤3：双模态特征拼接与融合
        fea_cat = self.concat([rgb_fea, ir_fea])
        out_fea = self.relu(self.conv(fea_cat))
        return out_fea

# 模块测试代码
if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    rgb = torch.randn(1, 64, 32, 32).to(device)
    ir = torch.randn(1, 64, 32, 32).to(device)
    x = [rgb, ir]
    model = FDFTM(64).to(device)
    y = model(x)
    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("小红书：十小大，主页获取往期全部即插即用代码，200+大合集")
    print("输入RGB特征维度：", x[0].shape)
    print("输入IR特征维度：", x[1].shape)
    print("输出融合后特征维度：", y.shape)