import torch
import torch.nn as nn


class ASPPConv(nn.Sequential):
    """
    空洞卷积模块：基于ASPP（Atrous Spatial Pyramid Pooling）的单速率空洞卷积
    核心作用：通过不同空洞率扩大感受野，捕捉特定尺度的全局/局部特征
    输入：特征图 [B, in_channels, H, W]
    输出：空洞卷积增强特征 [B, out_channels, H, W]（与输入尺寸一致）
    """
    def __init__(self, in_channels, out_channels, dilation):
        modules = [
            # 空洞卷积：padding=dilation确保输出尺寸与输入一致
            nn.Conv2d(in_channels, out_channels, 3, padding=dilation, dilation=dilation, bias=False),
            nn.BatchNorm2d(out_channels),  # 批归一化，稳定训练
            nn.ReLU()  # 非线性激活，增强特征表达
        ]
        super(ASPPConv, self).__init__(*modules)

class oneConv(nn.Module):
    """
    单卷积模块：简化的1×1卷积，用于生成特征权重
    核心作用：对全局池化后的特征降维，生成动态权重系数
    输入：全局池化特征 [B, in_channels, 1, 1]
    输出：权重系数 [B, out_channels, 1, 1]
    """
    def __init__(self, in_channels, out_channels, kernel_sizes, paddings, dilations):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(
                in_channels, out_channels,
                kernel_size=kernel_sizes, padding=paddings, dilation=dilations, bias=False
            )
        )

    def forward(self, x):
        x = self.conv(x)
        return x

class MFEblock(nn.Module):
    """
    多尺度特征增强模块（MFE）：通过多速率空洞卷积+动态权重融合，实现多尺度特征增强
    核心创新：
        1. 多速率空洞卷积：4个分支覆盖不同感受野，捕捉从局部到全局的多尺度特征；
        2. 动态权重融合：基于全局特征统计生成权重，自适应融合多分支特征；
        3. 残差递进连接：分支间残差融合，强化特征传递；
        4. 轻量化设计：通道数保持一致，无冗余计算，适配多任务。
    输入：特征图 [B, in_channels, H, W]
    输出：多尺度增强特征 [B, in_channels, H, W]（与输入维度一致）
    """
    def __init__(self, in_channels, atrous_rates):
        super(MFEblock, self).__init__()
        out_channels = in_channels  # 输出通道数与输入一致，支持残差连接
        rate1, rate2, rate3 = tuple(atrous_rates)  # 3个空洞率（需与分支2/3/4对应）

        # 分支1：普通3×3卷积（空洞率1），捕捉局部特征
        self.layer1 = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, 3, padding=1, dilation=1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU()
        )

        # 分支2-4：不同空洞率的空洞卷积，捕捉中/大尺度特征
        self.layer2 = ASPPConv(in_channels, out_channels, rate1)  # 小空洞率（如2），中尺度感受野
        self.layer3 = ASPPConv(in_channels, out_channels, rate2)  # 中空洞率（如4），大尺度感受野
        self.layer4 = ASPPConv(in_channels, out_channels, rate3)  # 大空洞率（如8），超大尺度感受野

        # 融合投影层：融合多分支特征后，进一步增强特征表达
        self.project = nn.Sequential(
            nn.Conv2d(out_channels, out_channels, 1, bias=False),  # 1×1卷积，通道融合
            nn.BatchNorm2d(out_channels),
            nn.ReLU(),
        )

        # 全局平均池化：提取各分支的全局特征统计，用于生成权重
        self.gap = nn.AdaptiveAvgPool2d(1)
        # 激活函数：用于权重归一化
        self.softmax = nn.Softmax(dim=2)  # 多分支权重归一化
        self.softmax_1 = nn.Sigmoid()    # 单个权重激活（映射至[0,1]）

        # 权重生成模块：1×1卷积生成各分支的动态权重
        self.SE1 = oneConv(in_channels, in_channels, 1, 0, 1)  # 分支1权重
        self.SE2 = oneConv(in_channels, in_channels, 1, 0, 1)  # 分支2权重
        self.SE3 = oneConv(in_channels, in_channels, 1, 0, 1)  # 分支3权重
        self.SE4 = oneConv(in_channels, in_channels, 1, 0, 1)  # 分支4权重

    def forward(self, x):
        """
        前向传播流程：多分支特征提取→动态权重生成→加权融合→残差输出
        """
        # 步骤1：多分支特征提取（递进残差连接）
        y0 = self.layer1(x)                  # 分支1（局部特征）
        y1 = self.layer2(y0 + x)             # 分支2（中尺度）+ 残差（x+y0）
        y2 = self.layer3(y1 + x)             # 分支3（大尺度）+ 残差（x+y1）
        y3 = self.layer4(y2 + x)             # 分支4（超大尺度）+ 残差（x+y2）

        # 步骤2：动态权重生成（基于全局特征统计）
        # 全局平均池化+1×1卷积生成各分支权重
        y0_weight = self.SE1(self.gap(y0))  # [B, C, 1, 1]
        y1_weight = self.SE2(self.gap(y1))
        y2_weight = self.SE3(self.gap(y2))
        y3_weight = self.SE4(self.gap(y3))

        # 权重归一化：拼接→Sigmoid→Softmax
        weight = torch.cat([y0_weight, y1_weight, y2_weight, y3_weight], dim=2)  # [B, C, 4, 1]
        weight = self.softmax(self.softmax_1(weight))  # 归一化权重（各分支权重和为1）

        # 步骤3：多分支特征加权融合
        y0_weight = torch.unsqueeze(weight[:, :, 0], 2)  # 分支1权重 [B, C, 1, 1]
        y1_weight = torch.unsqueeze(weight[:, :, 1], 2)  # 分支2权重
        y2_weight = torch.unsqueeze(weight[:, :, 2], 2)  # 分支3权重
        y3_weight = torch.unsqueeze(weight[:, :, 3], 2)  # 分支4权重
        x_att = y0_weight * y0 + y1_weight * y1 + y2_weight * y2 + y3_weight * y3  # 加权融合

        # 步骤4：融合投影+残差连接（原始输入x）
        return self.project(x_att + x)

if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 64, 32, 32).to(device)
    model = MFEblock(64, [2, 4, 8])

    model.to(device)
    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)