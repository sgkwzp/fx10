import torch
import torch.nn as nn
import torch.nn.functional as F


class AttentionMacthcing(nn.Module):
    """
    余弦注意力匹配模块（ABM）：基于余弦相似度的跨特征匹配与自适应融合模块
    核心功能：
        1. 计算空间前景特征（spt）与查询前景特征（qry）的余弦相关性；
        2. 根据频段类型（low/high/other）动态调整加权策略；
        3. 通过MLP投影与拼接融合，输出统一维度的增强特征；
    适用场景：多光谱融合、跨模态特征匹配、图像检索中的前景特征对齐任务
    输入：
        spt_fg_fts: 空间前景特征 [B, C, L]（B=批次，C=通道数，L=序列长度）
        qry_fg_fts: 查询前景特征 [B, C, L]（需与空间特征维度一致）
        band: 频段类型（'low'/'high'/'other'，控制加权策略）
    输出：
        fused_tensor: 融合后特征 [B, C, L]（与输入维度完全一致）
    """

    def __init__(self, feature_dim=512, seq_len=5000):
        """
        参数初始化：
            feature_dim: 输入/输出通道数（默认512）
            seq_len: 特征序列长度（默认5000，需与输入特征的序列长度匹配）
        """
        super(AttentionMacthcing, self).__init__()

        # 空间特征投影MLP：增强空间前景特征的判别性（L→L//10→L）
        self.fc_spt = nn.Sequential(
            nn.Linear(seq_len, seq_len // 10),  # 降维：压缩序列维度，提取关键特征
            nn.ReLU(),  # 非线性激活，增强表达
            nn.Linear(seq_len // 10, seq_len),  # 升维：恢复原始序列长度
        )

        # 查询特征投影MLP：增强查询前景特征的判别性（结构与空间特征投影一致）
        self.fc_qry = nn.Sequential(
            nn.Linear(seq_len, seq_len // 10),
            nn.ReLU(),
            nn.Linear(seq_len // 10, seq_len),
        )

        # 融合MLP：拼接后的特征降维融合（2L→L//5→L）
        self.fc_fusion = nn.Sequential(
            nn.Linear(seq_len * 2, seq_len // 5),  # 降维：压缩拼接后的冗余维度
            nn.ReLU(),
            nn.Linear(seq_len // 5, seq_len),  # 升维：恢复原始序列长度
        )

        self.sigmoid = nn.Sigmoid()  # 相关性分数归一化（映射至[0,1]）

    def correlation_matrix(self, spt_fg_fts, qry_fg_fts):
        """
        计算余弦相似度矩阵：衡量空间特征与查询特征的前景匹配程度
        参数：
            spt_fg_fts: 空间前景特征 [B, C, L]
            qry_fg_fts: 查询前景特征 [B, C, L]
        返回：
            cosine_similarity: 余弦相似度矩阵 [B, 1, L]（每个序列位置的匹配分数）
        """
        # L2归一化：将特征沿通道维度归一化，确保余弦相似度计算的公平性
        spt_fg_fts_norm = F.normalize(spt_fg_fts, p=2, dim=1)  # [B, C, L]
        qry_fg_fts_norm = F.normalize(qry_fg_fts, p=2, dim=1)  # [B, C, L]

        # 余弦相似度计算：通道维度求和（等价于点积），得到每个序列位置的匹配分数
        cosine_similarity = torch.sum(spt_fg_fts_norm * qry_fg_fts_norm, dim=1, keepdim=True)  # [B, 1, L]
        return cosine_similarity

    def forward(self, spt_fg_fts, qry_fg_fts, band):
        """
        前向传播流程：特征投影→余弦相似度计算→频段自适应加权→拼接融合→输出
        """
        # 步骤1：特征投影增强（空间特征+查询特征）
        spt_proj = F.relu(self.fc_spt(spt_fg_fts))  # [B, C, L]→[B, C, L]
        qry_proj = F.relu(self.fc_qry(qry_fg_fts))  # [B, C, L]→[B, C, L]

        # 步骤2：计算余弦相似度并归一化（映射至[0,1]）
        similarity_matrix = self.sigmoid(self.correlation_matrix(spt_fg_fts, qry_fg_fts))  # [B, 1, L]

        # 步骤3：频段自适应加权（核心逻辑）
        if band == 'low' or band == 'high':
            # 低频/高频频段：用（1-相似度）加权，突出差异特征
            weighted_spt = (1 - similarity_matrix) * spt_proj  # [B, C, L]
            weighted_qry = (1 - similarity_matrix) * qry_proj  # [B, C, L]
        else:
            # 其他频段：用相似度加权，突出一致特征
            weighted_spt = similarity_matrix * spt_proj  # [B, C, L]
            weighted_qry = similarity_matrix * qry_proj  # [B, C, L]

        # 步骤4：特征拼接与融合
        combined = torch.cat((weighted_spt, weighted_qry), dim=2)  # 序列维度拼接→[B, C, 2L]
        fused_tensor = F.relu(self.fc_fusion(combined))  # MLP融合→[B, C, L]

        return fused_tensor

if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    s = torch.randn(1, 64, 32 * 32).to(device)
    q = torch.randn(1, 64, 32 * 32).to(device)
    model = AttentionMacthcing(64, 32*32)

    model.to(device)
    y = model(s, q, 'low')

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN：十小大")

    print("空间前景特征维度：", s.shape)
    print("查询前景特征维度：", q.shape)
    print("融合后特征维度：", y.shape)