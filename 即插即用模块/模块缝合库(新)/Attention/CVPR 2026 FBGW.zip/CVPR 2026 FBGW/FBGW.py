import torch
import torch.nn as nn


class ChannelAttention(nn.Module):
    """
    频域通道注意力模块（对应FBGW结构图中生成Wb的权重分支）
    核心作用：对频域特征的不同通道做自适应加权，强化任务相关的频带分量，抑制无效分量
    """
    def __init__(self, in_channels, reduction_ratio=16):
        super(ChannelAttention, self).__init__()
        # 频域特征的空间特征预卷积
        self.conv = nn.Conv2d(in_channels, in_channels, 3, 1, 1)
        # 全局平均/最大池化，聚合频域全局信息
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)
        # 通道压缩-激活-还原+Sigmoid，生成通道注意力权重
        self.fc = nn.Sequential(
            nn.Conv2d(in_channels, in_channels // reduction_ratio, 1, bias=False),
            nn.ReLU(inplace=True),
            nn.Conv2d(in_channels // reduction_ratio, in_channels, 1, bias=False),
            nn.Sigmoid()
        )

    def forward(self, x):
        x = self.conv(x)
        # 平均池化分支与最大池化分支分别生成权重，相加融合
        avg_out = self.fc(self.avg_pool(x))
        max_out = self.fc(self.max_pool(x))
        return avg_out + max_out


class FourierUnit(nn.Module):
    """
    FBGW (Frequency Band-Guided Weighting) 频带引导加权核心模块
    完整对应结构图中FBGW的全流程：空域→RFFT频域→频带特征建模→解耦加权→耦合→IRFFT空域
    """
    def __init__(self, in_channels, out_channels):
        super(FourierUnit, self).__init__()
        # 频带解耦1x1卷积：对拼接坐标后的频域特征做通道变换（对应结构图Band Decoupling的Conv-1）
        self.conv_layer = torch.nn.Conv2d(in_channels=in_channels * 2 + 2, out_channels=out_channels * 2,
                                          kernel_size=1, stride=1, padding=0, bias=False)
        self.bn = torch.nn.BatchNorm2d(out_channels * 2)
        self.relu = torch.nn.ReLU(inplace=True)
        # 频域通道注意力：生成频带自适应加权权重（对应结构图中Wb生成分支）
        self.channel_attn = ChannelAttention(out_channels * 2)
        # 频带耦合1x1卷积：对加权后的频域特征做特征融合（对应结构图Band Coupling的Conv-1）
        self.conv_layer2 = torch.nn.Conv2d(out_channels * 2, out_channels=out_channels * 2,
                                           kernel_size=1, stride=1, padding=0, bias=False)

    def forward(self, x):
        batch = x.shape[0]
        fft_dim = (-2, -1)
        # -------------------------- 步骤1：空域→频域RFFT变换 对应结构图RFFT --------------------------
        # 对H、W维度做实值快速傅里叶变换，得到复数频域特征，正交归一化保证数值稳定性
        ffted = torch.fft.rfftn(x, dim=fft_dim, norm='ortho')
        # 拆分复数的实部、虚部，在通道维度堆叠，完整保留频域幅值+相位信息
        ffted = torch.stack((ffted.real, ffted.imag), dim=-1)
        # 维度重整，将实虚部合并到通道维度，shape从[B,C,H,W/2+1,2]→[B,C*2,H,W/2+1]
        ffted = ffted.permute(0, 1, 4, 2, 3).contiguous()
        ffted = ffted.view((batch, -1,) + ffted.size()[3:])

        # -------------------------- 步骤2：频带特征建模 对应结构图Band Characteristic --------------------------
        height, width = ffted.shape[-2:]
        # 生成频域坐标嵌入，编码频带的位置信息（对应结构图Band Position）
        coords_vert = torch.linspace(0, 1, height)[None, None, :, None].expand(batch, 1, height, width).to(ffted)
        coords_hor = torch.linspace(0, 1, width)[None, None, None, :].expand(batch, 1, height, width).to(ffted)
        # 频带内容（原频域特征）+ 频带位置（坐标嵌入）拼接，完成频带特征建模
        ffted = torch.cat((coords_vert, coords_hor, ffted), dim=1)

        # -------------------------- 步骤3：频带解耦与自适应加权 对应结构图Band Decoupling --------------------------
        # 1x1卷积做频带解耦与通道映射
        ffted = self.conv_layer(ffted)
        ffted = self.relu(self.bn(ffted))
        # 通道注意力生成频带加权权重，逐元素相乘实现频带引导加权
        attn = self.channel_attn(ffted)
        ffted = ffted * attn

        # -------------------------- 步骤4：频带耦合与逆变换 对应结构图Band Coupling+IRFFT --------------------------
        # 1x1卷积完成频带信息耦合融合
        ffted = self.conv_layer2(ffted)
        # 维度还原，拆分实部和虚部，重构复数频域特征
        ffted = ffted.view((batch, -1, 2,) + ffted.size()[2:]).permute(
            0, 1, 3, 4, 2).contiguous()
        ffted = torch.complex(ffted[..., 0], ffted[..., 1])

        # 逆傅里叶变换，将频域特征转换回空域，输出与输入同尺寸的增强特征
        ifft_shape_slice = x.shape[-2:]
        output = torch.fft.irfftn(ffted, s=ifft_shape_slice, dim=fft_dim, norm='ortho')
        return output


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 64, 32, 32).to(device)
    model = FourierUnit(64, 64).to(device)

    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("小红书：十小大，主页获取往期全部即插即用代码，200+大合集")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)