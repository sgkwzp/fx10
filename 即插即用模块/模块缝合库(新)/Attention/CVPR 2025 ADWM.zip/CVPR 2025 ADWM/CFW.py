import torch
import torch.nn as nn
import torch.nn.functional as F
from einops import rearrange

class CovBlock(nn.Module):
    """
    协方差加权模块（CovBlock）：基于特征协方差矩阵学习权重，捕捉特征内部关联
    核心作用：通过协方差分析特征通道间的相关性，生成通道/特征层权重，突出关键信息
    输入：特征矩阵 [B, N, D]（B=批次，N=空间/特征数量，D=特征维度）
    输出：权重向量 [B, K]（K=目标权重数量，如通道数/特征层数）
    """

    def __init__(self, feature_dimension, features_num, hidden_dim, dropout=0.05):
        """
        参数说明：
            feature_dimension: 输入特征维度（D，如通道数）
            features_num: 输出权重数量（K，如单个特征层的通道数）
            hidden_dim: MLP中间层维度（通常设为特征维度的0.6倍，平衡精度与效率）
            dropout: MLP的dropout概率（默认0.05，防止过拟合）
        """
        super().__init__()
        # 协方差加权MLP：从协方差矩阵中学习权重
        self.cov_mlp = nn.Sequential(
            nn.Linear(feature_dimension, feature_dimension),  # 维度保持，增强特征表达
            nn.Dropout(dropout, inplace=True),  # 正则化，避免过拟合
            nn.LeakyReLU(inplace=True),  # 非线性激活，增强梯度流动
            nn.Linear(feature_dimension, hidden_dim),  # 维度压缩，降低计算量
            nn.LeakyReLU(inplace=True),  # 非线性激活
            nn.Linear(hidden_dim, features_num)  # 维度映射，输出目标权重数量
        )

    def forward(self, x):
        """
        前向传播流程：特征中心化→协方差计算→协方差归一化→MLP权重生成
        """
        # 步骤1：特征中心化（减去均值），消除全局偏移对协方差的影响
        x = x - x.mean(dim=-1, keepdim=True)  # [B, N, D]→[B, N, D]

        # 步骤2：计算协方差矩阵（通道间相关性）→[B, D, D]
        cov = x.transpose(-2, -1) @ x  # 转置后矩阵乘法，捕捉通道间关联

        # 步骤3：协方差归一化（除以L2范数的外积），避免特征幅值影响
        cov_norm = torch.norm(x, p=2, dim=-2, keepdim=True)  # [B, 1, D]（通道维度L2范数）
        cov_norm = cov_norm.transpose(-2, -1) @ cov_norm  # [B, D, D]（范数外积）
        cov /= cov_norm  # 归一化协方差矩阵，确保权重学习不受幅值干扰

        # 步骤4：MLP学习权重（从协方差矩阵中提取关键关联，生成权重）
        weight = self.cov_mlp(cov)  # [B, D, D]→[B, D, K]→[B, K]（自动压缩中间维度）
        return weight

class BandSelectBlock(nn.Module):
    """
    跨特征加权模块（CFW核心实现）：结合协方差加权与全局融合，实现多特征层的动态选择与融合
    核心创新：
        1.  intra-特征加权：单特征层内通过协方差学习通道权重；
        2.  cross-特征加权：多特征层间通过全局协方差学习层权重；
        3.  动态融合：权重加权后求和，突出关键特征层与通道。
    输入：特征层列表 [F1, F2, ..., Fn]（每个Fi为[B, C, H, W]，n=特征层数）
    输出：融合后特征 [B, C, H, W]（与单特征层维度一致，支持即插即用）
    """

    def __init__(self, feature_dimension, features_num):
        """
        参数说明：
            feature_dimension: 单特征层的通道数（C，如64）
            features_num: 输入特征层数（n，如3）
        """
        super().__init__()
        # 1.  Intra-特征加权模块列表：每个特征层对应1个CovBlock（学习通道权重）
        self.CovBlockList = nn.ModuleList([])
        for _ in range(features_num):
            # 每个CovBlock输出1个通道权重向量（hidden_dim=0.6×feature_dimension）
            self.CovBlockList.append(
                CovBlock(feature_dimension, 1, round(feature_dimension * 0.6), 0)
            )

        # 2.  Cross-特征加权模块：学习特征层全局权重
        self.global_covblock = CovBlock(features_num, 1, features_num, 0)
        # 3.  全局平均池化：压缩空间维度，提取特征层全局信息
        self.global_pool = nn.AdaptiveAvgPool2d(1)

    def forward(self, feature_maps):
        """
        前向传播流程：intra-特征通道加权→cross-特征层加权→全局融合输出
        """
        # 解析单特征层的空间尺寸（所有特征层尺寸一致）
        H = feature_maps[0].shape[2]  # 高度
        W = feature_maps[0].shape[3]  # 宽度
        C_weights = []  # 存储每个特征层的通道权重

        # -------------------------- 1. Intra-特征加权：学习每个特征层的通道权重 --------------------------
        for feature_map, block in zip(feature_maps, self.CovBlockList):
            # 维度重排：[B, C, H, W]→[B, H×W, C]（将空间维度合并为特征数量维度）
            # 除以(H×W-1)：协方差计算的无偏估计（样本数=N-1）
            input = rearrange(feature_map, 'B C H W -> B (H W) C', H=H) / (H * W - 1)
            # 学习通道权重：[B, H×W, C]→[B, C, 1]→[B, C]（挤压最后一维）
            C_weights.append(block(input).squeeze_(-1))

        # 合并通道权重：[B, C] × n → [B, n, C]（n=特征层数）
        weight_matrix = torch.stack(C_weights, dim=1)
        # 合并特征层：[B, C, H, W] × n → [B, n, C, H, W]
        feature_maps = torch.stack(feature_maps, dim=1)

        # 通道权重应用：[B, n, C] → [B, n, C, 1, 1]（扩展空间维度）× [B, n, C, H, W]
        output = weight_matrix.unsqueeze_(-1).unsqueeze_(-1) * feature_maps  # [B, n, C, H, W]

        # -------------------------- 2. Cross-特征加权：学习特征层全局权重 --------------------------
        # 全局池化：[B, n, C, H, W]→[B, n, C, 1, 1]→[B, n, C]（压缩空间维度）
        global_weight = self.global_pool(feature_maps).squeeze_(-1).squeeze_(-1)
        # 协方差加权：[B, n, C]→[B, C, n]（转置）→[B, C, 1]（学习层权重）→[B, n, 1]（转置回原维度）
        # Softmax归一化：层权重∈[0,1]，确保权重和为1
        global_weight = F.softmax(
            self.global_covblock(global_weight.transpose_(-1, -2)),
            dim=-2
        )

        # -------------------------- 3. 全局融合：通道加权特征 × 层权重 → 求和输出 --------------------------
        # 层权重应用：[B, n, 1]→[B, n, 1, 1, 1] × [B, n, C, H, W]
        # 按特征层维度求和：[B, n, C, H, W]→[B, C, H, W]（融合多特征层）
        output = torch.sum(output * global_weight.unsqueeze(-1).unsqueeze(-1), dim=1)

        return output

if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    # 假设多个待加权融合的特征
    feature_list = [torch.randn(1, 64, 32, 32).to(device) for _ in range(3)]

    model = BandSelectBlock(64, 3)
    model.to(device)

    y = model(feature_list)

    print("微信公众号：十小大的底层视觉工坊")
    print("知乎、CSDN：十小大")
    print("单个输入特征层维度：", feature_list[0].shape)
    print("融合后输出维度：", y.shape)