import torch
import torch.nn as nn
import torch.nn.functional as F


def batched_index_select(input, dim, index):
    """
    批量索引选择：在指定维度上按索引提取特征，支持批量处理
    Args:
        input: 输入特征，shape=[B, ..., dim, ...]
        dim: 索引操作的维度
        index: 索引张量，shape=[B, N]（N为每个样本的选择数量）
    Returns:
        按索引提取后的特征，shape与input一致（指定维度长度变为N）
    """
    for ii in range(1, len(input.shape)):
        if ii != dim:
            index = index.unsqueeze(ii)  # 扩展索引维度，适配input形状
    expanse = list(input.shape)
    expanse[0] = -1
    expanse[dim] = -1
    index = index.expand(expanse)  # 广播索引至input尺寸
    return torch.gather(input, dim, index)  # 按索引提取特征


def neirest_neighbores(input_maps, candidate_maps, distances, num_matches):
    """
    最近邻匹配：基于距离矩阵选择最相似的候选特征
    Args:
        input_maps: 输入特征（查询特征），shape=[B, N, C]
        candidate_maps: 候选特征，shape=[B, M, C]
        distances: 相关性距离矩阵，shape=[B, N, M]
        num_matches: 每个查询特征选择的候选特征数量
    Returns:
        filtered_candidate_maps: 匹配后的候选特征，shape=[B, num_matches, C]
    """
    batch_size = input_maps.size(0)
    if num_matches is None or num_matches == -1:
        num_matches = input_maps.size(1)
    # 选择距离最小的1个候选（最近邻）
    topk_values, topk_indices = distances.topk(k=1, largest=False)
    topk_values = topk_values.squeeze(-1)
    topk_indices = topk_indices.squeeze(-1)
    # 按距离排序，筛选前num_matches个候选
    sorted_values, sorted_values_indices = torch.sort(topk_values, dim=1)
    sorted_indices, sorted_indices_indices = torch.sort(sorted_values_indices, dim=1)
    # 生成筛选掩码
    mask = torch.stack(
        [
            torch.where(sorted_indices_indices[i] < num_matches, True, False)
            for i in range(batch_size)
        ]
    )
    # 按掩码选择候选特征索引
    topk_indices_selected = topk_indices.masked_select(mask)
    topk_indices_selected = topk_indices_selected.reshape(batch_size, num_matches)
    # 提取匹配后的候选特征
    filtered_candidate_maps = batched_index_select(
        candidate_maps, 1, topk_indices_selected
    )
    return filtered_candidate_maps


def neirest_neighbores_on_l2(input_maps, candidate_maps, num_matches):
    """
    基于L2距离的最近邻匹配：计算输入与候选特征的L2距离，选择最相似特征
    Args:
        input_maps: 查询特征，shape=[B, H×W, C]
        candidate_maps: 候选特征，shape=[B, H×W, C]
        num_matches: 匹配特征数量
    Returns:
        filtered_candidate_maps: 匹配后的特征，shape=[B, num_matches, C]
    """
    distances = torch.cdist(input_maps, candidate_maps)  # 计算L2距离矩阵
    return neirest_neighbores(input_maps, candidate_maps, distances, num_matches)


class Matching(nn.Module):
    """
    相关性匹配模块：基于L2距离选择最相似的候选特征
    核心设计：
        - 特征展平：将2D特征图展平为序列，适配相关性计算
        - 最近邻匹配：筛选与输入特征最相似的候选特征，强化关键信息
    """
    def __init__(self, dim=32, match_factor=1):
        super(Matching, self).__init__()
        self.num_matching = int(dim/match_factor)

    def forward(self, x, perception):
        b, c, h, w = x.size()
        x = x.flatten(2, 3)
        perception = perception.flatten(2, 3)
        # print('x, perception1', x.size(), perception.size())
        filtered_candidate_maps = neirest_neighbores_on_l2(x, perception, self.num_matching)
        # filtered_input_maps = filtered_input_maps.reshape(b, self.num_matching, h, w)
        filtered_candidate_maps = filtered_candidate_maps.reshape(b, self.num_matching, h, w)
        return filtered_candidate_maps


class Matching_transformation(nn.Module):
    """
    双路径相关性匹配变换模块（DCMT）核心载体
    功能：整合感知融合、双路径匹配、动态特征变换，建立高低分辨率特征关联
    核心设计：
        - 双路径匹配：基于最大池化和平均池化的候选特征，分别匹配关键与全局特征
        - 深度卷积优化：通过1×1卷积+深度卷积+GELU，动态变换匹配特征
        - 残差式特征融合：匹配特征与原始特征加权融合，保留基础信息
    """

    def __init__(self, dim=32, match_factor=1, ffn_expansion_factor=2, scale_factor=8, bias=True):
        super(Matching_transformation, self).__init__()
        self.num_matching = int(dim / match_factor)  # 每条路径匹配特征数量
        self.channel = dim  # 输出通道数
        hidden_features = int(self.channel * ffn_expansion_factor)  # 中间特征维度

        self.matching = Matching(dim=dim, match_factor=match_factor)  # 相关性匹配
        self.perception = nn.Conv2d(3 * dim, dim, 1, bias=bias)  # 感知特征投影（适配匹配维度）
        self.max = nn.MaxPool2d(scale_factor, scale_factor)  # 最大池化（提取关键特征）
        self.mean = nn.AvgPool2d(scale_factor, scale_factor)  # 平均池化（提取全局特征）

        # 动态特征变换：1×1卷积+深度卷积+GELU+1×1卷积
        self.dwconv = nn.Sequential(
            nn.Conv2d(2 * self.num_matching, hidden_features, 1, bias=bias),
            nn.Conv2d(hidden_features, hidden_features, kernel_size=3, stride=1, padding=1,
                      groups=hidden_features, bias=bias),  # 深度卷积（轻量化）
            nn.GELU(),  # 激活增强
            nn.Conv2d(hidden_features, 2 * self.num_matching, 1, bias=bias)
        )
        self.conv12 = nn.Conv2d(2 * self.num_matching, self.channel, 1, bias=bias)  # 输出投影

    def forward(self, x, perception):
        """
        前向传播：DCMT双路径匹配变换流程
        Args:
            x: 低分辨率查询特征，shape=[B, C, H/8, W/8]
            perception: 高分辨率感知特征，shape=[B, 3C, H, W]
        Returns:
            变换后的特征，shape=[B, C, H/8, W/8]
        """
        # 1. 感知特征投影与下采样（适配低分辨率特征尺寸）
        perception = self.perception(perception)  # [B, 3C, H, W]→[B, C, H, W]
        perception1 = self.max(perception)  # 最大池化：提取关键特征，[B, C, H/8, W/8]
        perception2 = self.mean(perception)  # 平均池化：提取全局特征，[B, C, H/8, W/8]

        # 2. 双路径相关性匹配
        filtered_candidate_maps1 = self.matching(x, perception1)  # 关键特征匹配
        filtered_candidate_maps2 = self.matching(x, perception2)  # 全局特征匹配

        # 3. 双路径特征拼接：[B, num_matching×2, H/8, W/8]
        concat = torch.cat([filtered_candidate_maps1, filtered_candidate_maps2], dim=1)

        # 4. 动态特征变换：深度卷积优化
        dwconv = self.dwconv(concat)
        out = self.conv12(dwconv * concat)  # 残差式加权融合

        return out

# ACM
class Perception_fusion(nn.Module):
    """
    感知融合模块（Adaptive Channel Modulator, ACM）
    功能：聚合多源高分辨率特征，生成增强的感知特征
    核心设计：
        - 多特征拼接：融合3路高分辨率特征，丰富信息来源
        - 动态通道调制：通过深度卷积拆分权重与偏移，自适应增强特征
        - Softmax加权：对通道维度加权，筛选关键特征
    """
    def __init__(self, dim=32):
        super(Perception_fusion, self).__init__()
        self.channel = dim
        self.conv11 = nn.Conv2d(3 * self.channel, 3 * self.channel, 1, 1)  # 特征投影
        # 深度卷积：拆分权重（dwconv1）与偏移（dwconv2）
        self.dwconv = nn.Conv2d(3 * self.channel, 6 * self.channel, kernel_size=3, stride=1, padding=1,
                                groups=3 * self.channel)

    def forward(self, feature1, feature2, feature3):
        # 多特征拼接：[B, C, H, W]×3→[B, 3C, H, W]
        concat = torch.cat([feature1, feature2, feature3], dim=1)
        conv11 = self.conv11(concat)  # 特征投影
        # 动态调制：拆分权重与偏移
        dwconv1, dwconv2 = self.dwconv(conv11).chunk(2, dim=1)  # 各[B, 3C, H, W]
        b, c, h, w = dwconv1.size()
        # 权重归一化：通道维度Softmax
        dwconv1 = dwconv1.flatten(2, 3)  # [B, 3C, H×W]
        dwconv1 = F.softmax(dwconv1, dim=1)  # 通道加权
        dwconv1 = dwconv1.reshape(b, c, h, w)
        # 特征调制：权重×输入 + 偏移
        perception = torch.mul(dwconv1, concat) + dwconv2
        return perception


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x1 = torch.randn(1, 64, 32, 32).to(device)  # H, W, C
    x2 = torch.randn(1, 64, 32, 32).to(device)
    x3 = torch.randn(1, 64, 32, 32).to(device)

    Q = torch.randn(1, 64, 4, 4).to(device)    # H/8, W/8, C

    acm = Perception_fusion(dim=64).to(device)
    model = Matching_transformation(dim=64, match_factor=1).to(device)

    x_acm = acm(x1, x2, x3)     # H, W, 3C
    y = model(Q, x_acm)         # H/8, W/8, C

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN、小红书：十小大")

    print("输入特征维度：", x1.shape)
    print("输出特征维度：", y.shape)