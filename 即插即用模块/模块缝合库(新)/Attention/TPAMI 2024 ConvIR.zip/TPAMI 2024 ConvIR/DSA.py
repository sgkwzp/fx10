import torch
import torch.nn as nn
import torch.nn.functional as F

class dynamic_filter(nn.Module):
    """
    动态分离注意力模块（DSA）：通过动态生成滤波器分离高低频特征，实现针对性增强
    核心创新：
        1. 动态分组滤波器：基于输入特征生成分组卷积核，适配特征分布；
        2. 高低频分离增强：独立优化低频全局结构与高频细节，兼顾完整性与清晰度；
        3. 可学习权重平衡：通过参数控制高低频贡献，适配不同任务；
        4. 数值稳定设计：反射填充+BatchNorm，避免边缘失真与训练震荡。
    输入：特征图 [B, inchannels, H, W]（B≥2，需满足BatchNorm统计需求）
    输出：动态增强特征 [B, inchannels, H, W]（与输入维度完全一致）
    """
    def __init__(self, inchannels, kernel_size=3, stride=1, group=8):
        """
        参数初始化：
            inchannels: 输入/输出通道数（需能被group整除）
            kernel_size: 动态滤波器核大小（默认3×3，需为奇数）
            stride: 卷积步长（默认1，确保输出尺寸与输入一致）
            group: 分组数（默认8，控制动态滤波器的精细度）
        """
        super(dynamic_filter, self).__init__()

        self.stride = stride
        self.kernel_size = kernel_size
        self.group = group

        self.conv = nn.Conv2d(inchannels, group * kernel_size ** 2, kernel_size=1, stride=1, bias=False)
        self.bn = nn.BatchNorm2d(group * kernel_size ** 2)
        self.act = nn.Tanh()

        nn.init.kaiming_normal_(self.conv.weight, mode='fan_out', nonlinearity='relu')
        self.lamb_l = nn.Parameter(torch.zeros(inchannels), requires_grad=True)
        self.lamb_h = nn.Parameter(torch.zeros(inchannels), requires_grad=True)
        self.pad = nn.ReflectionPad2d(kernel_size // 2)

        self.ap = nn.AdaptiveAvgPool2d((1, 1))
        self.gap = nn.AdaptiveAvgPool2d(1)

        self.inside_all = nn.Parameter(torch.zeros(inchannels, 1, 1), requires_grad=True)

    def forward(self, x):
        identity_input = x
        # the Conv_{3x3} layer in eq.3 is included in DeepPoolLayer.convs
        low_filter = self.ap(x)
        low_filter = self.conv(low_filter)
        low_filter = self.bn(low_filter)

        n, c, h, w = x.shape
        x = F.unfold(self.pad(x), kernel_size=self.kernel_size).reshape(n, self.group, c // self.group,
                                                                        self.kernel_size ** 2, h * w)

        n, c1, p, q = low_filter.shape
        low_filter = low_filter.reshape(n, c1 // self.kernel_size ** 2, self.kernel_size ** 2, p * q).unsqueeze(2)
        low_filter = self.act(low_filter)
        low_part = torch.sum(x * low_filter, dim=3).reshape(n, c, h, w)

        # the variables here are slightly different from the paper: (code) --> (paper)
        # low_filter --> A (eq.3)
        # In Eq.7, X*A'= X*(A_{l} + WA_{h})
        #              = X*A_{l} + WX*(A - A_{l})
        #              = X*A_{l} + WX*A - WX*A_{l}
        #              = WX*A - X*A_{l}(W-1)
        # we substitute gap for A_{l} for simplicity, which is a coarser low-frequency filter
        out_low = low_part * (self.inside_all + 1.) - self.inside_all * self.gap(identity_input)

        out_low = out_low * self.lamb_l[None, :, None, None]
        out_high = (identity_input) * (self.lamb_h[None, :, None, None] + 1.)

        return out_low + out_high

if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    # 有BN，batch_size > 1
    x = torch.randn(2, 64, 32, 32).to(device)
    model = dynamic_filter(64)

    model.to(device)
    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("知乎、CSDN：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)