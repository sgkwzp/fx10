import torch
import torch.nn as nn
import torch.nn.functional as F


class CPCA_ChannelAttention(nn.Module):
    """
    跨模态通道注意力模块（Cross-modal PCA Channel Attention）
    功能：基于全局池化与MLP，生成通道注意力权重，筛选双模态融合后的关键通道
    核心设计：
        - 双池化引导：平均池化捕捉全局统计、最大池化捕捉局部峰值，双路径融合提升注意力鲁棒性
        - 轻量化MLP：1×1卷积构成的简易MLP，通道压缩-恢复，降低计算成本
        - 跨模态适配：适配双模态差异特征，强化模态互补通道
    Args:
        input_channels: 输入通道数（双模态融合后的通道数）
        internal_neurons: MLP中间层通道数（通道压缩后的维度）
    """
    def __init__(self, input_channels, internal_neurons):
        super(CPCA_ChannelAttention, self).__init__()
        self.fc1 = nn.Conv2d(in_channels=input_channels, out_channels=internal_neurons, kernel_size=1, stride=1,
                             bias=True)
        self.fc2 = nn.Conv2d(in_channels=internal_neurons, out_channels=input_channels, kernel_size=1, stride=1,
                             bias=True)
        self.input_channels = input_channels

    def forward(self, inputs):
        x1 = F.adaptive_avg_pool2d(inputs, output_size=(1, 1))
        x1 = self.fc1(x1)
        x1 = F.relu(x1, inplace=True)
        x1 = self.fc2(x1)
        x1 = torch.sigmoid(x1)
        x2 = F.adaptive_max_pool2d(inputs, output_size=(1, 1))
        x2 = self.fc1(x2)
        x2 = F.relu(x2, inplace=True)
        x2 = self.fc2(x2)
        x2 = torch.sigmoid(x2)
        x = x1 + x2
        x = x.view(-1, self.input_channels, 1, 1)
        return inputs * x #通道层的结果（权重X与原输入相乘）


class GatedMultimodalLayer(nn.Module)  :# AG模块
    """
    门控跨模态融合层（Gated Multimodal Layer）
    功能：通过门控机制动态平衡双模态特征贡献，实现自适应跨域融合
    核心设计：
        - 双模态独立增强：各自通过1×1卷积+Tanh激活，强化单模态特征
        - 门控信号生成：拼接双模态特征生成门控，动态调整模态权重
        - 加权融合：门控权重×模态1 + (1-门控权重)×模态2，平衡跨域信息
    Args:
        in_channels: 单模态输入通道数
        out_channels: 输出通道数（默认64）
    """
    def __init__(self, in_channels, out_channels=64):
        super(GatedMultimodalLayer, self).__init__()
        self.hidden1 = nn.Conv2d(in_channels, out_channels, kernel_size=1 ,padding=0,  bias=False)
        self.hidden2 = nn.Conv2d(in_channels, out_channels, kernel_size=1 ,padding=0, bias=False)
        self.hidden_sigmoid = nn.Conv2d(out_channels * 2, 1, kernel_size=1, bias=False)

        # Activation functions
        self.tanh_f = nn.Tanh()
        self.sigmoid_f = nn.Sigmoid()

    def forward(self, x1, x2):
        # 应用卷积层和激活函数
        h1 = self.tanh_f(self.hidden1(x1))
        h2 = self.tanh_f(self.hidden2(x2))

        # 将结果拼接
        x = torch.cat((x1, x2), dim=1)

        # 计算门控信号
        z = self.sigmoid_f(self.hidden_sigmoid(x))

        # 计算加权和
        return z * h1 + (1 - z) * h2


# 频率处理
class Freprocess(nn.Module):
    """
    频域跨模态处理模块（Frequency Processing）
    功能：对双模态特征进行频域分解与融合，增强跨域差异互补信息
    核心设计：
        - 频域分离融合：拆分幅度（强度）与相位（结构），分别跨模态融合
        - 差异增强：融合频域特征与原始模态特征相减，突出互补信息
        - 通道注意力优化：双模态差异特征分别经通道注意力筛选，提升纯度
    Args:
        channels: 输入/输出通道数
    """
    def __init__(self, channels):
        super(Freprocess, self).__init__()
        self.channels = channels
        self.pre1 = nn.Conv2d(channels, channels, kernel_size=(1, 1))
        self.pre2 = nn.Conv2d(channels, channels, kernel_size=(1, 1))
        self.amp_fuse = nn.Sequential(nn.Conv2d(channels ,channels//2 ,1 ,1 ,0) ,nn.LeakyReLU(0.1 ,inplace=False),
                                      nn.Conv2d(channels//2 ,channels ,1 ,1 ,0))
        self.pha_fuse = nn.Sequential(nn.Conv2d(channels ,channels//2 ,1 ,1 ,0) ,nn.LeakyReLU(0.1 ,inplace=False),
                                      nn.Conv2d(channels//2 ,channels ,1 ,1 ,0))
        self.conv = nn.Conv2d(channels *2, channels, kernel_size=(1, 1))
        self.amp_fuse_tpami = nn.Sequential(nn.Conv2d(2 * channels, channels, 1, 1, 0), nn.LeakyReLU(0.1, inplace=False),
                                            nn.Conv2d(channels, channels, 1, 1, 0))
        self.pha_fuse_tpami = nn.Sequential(nn.Conv2d(2 * channels, channels, 1, 1, 0), nn.LeakyReLU(0.1, inplace=False),
                                            nn.Conv2d(channels, channels, 1, 1, 0))
        self.post1 = nn.Conv2d(channels ,channels ,1 ,1 ,0)
        self.post2 = nn.Conv2d(channels, channels, 1, 1, 0)
        self.ca1 = CPCA_ChannelAttention(input_channels=channels, internal_neurons=channels // 4)
        self.ca2 = CPCA_ChannelAttention(input_channels=channels, internal_neurons=channels // 4)
        self.act = nn.GELU()

    def forward(self, vis0, ir0):

        _, _, H, W = vis0.shape

        vis = torch.fft.rfft2((self.pre1(vis0) + 1e-8).to(torch.float32), dim=(-2, -1))# 可见光FFT
        ir = torch.fft.rfft2((self.pre2(ir0) + 1e-8).to(torch.float32), dim=(-2, -1))# 红外FFT
        vis_pha = torch.angle(vis)
        vis_amp = torch.abs(vis)
        ir_amp = torch.abs(ir)
        ir_pha = torch.angle(ir)

        # TPAMI的思想#############################################
        amp_fuse = self.amp_fuse_tpami(torch.cat([vis_amp, ir_amp], 1))
        pha_fuse = self.pha_fuse_tpami(torch.cat([vis_pha, ir_pha], 1))

        real = amp_fuse * torch.cos(pha_fuse) + 1e-8
        imag = amp_fuse * torch.sin(pha_fuse) + 1e-8
        out = torch.complex(real, imag) + 1e-8
        out = torch.abs(torch.fft.irfft2(out, s=(H, W), norm='backward'))
        vis_out =out -vis0
        ir_out = out -ir0

        vis_out = self.post1(vis_out)
        ir_out = self.post2(ir_out)
        return vis_out,ir_out


class CGSA(nn.Module):###########################串联(只要通道注意力机制)#############################################
    """
    跨域门控自注意力模块（Cross-domain Gated Self-Attention, CGSA）
    功能：整合频域增强、通道自注意力、门控跨域融合，实现双模态深度交互
    核心设计：
        - 频域-空域协同：频域增强差异特征，空域自注意力筛选通道，双域协同优化
        - 通道自注意力：双模态独立计算通道注意力，强化域内关键特征
        - 门控跨域交互：GatedMultimodalLayer动态平衡跨模态贡献，避免单模态主导
        - 可学习权重：自适应调整双模态分支重要性，适配不同跨域场景
    Args:
        channel: 单模态输入通道数（默认64）
        out_channels: 输出通道数（默认64）
    """
    def __init__(self, channel=64, out_channels=64):
        super().__init__()
        self.ch_wv = nn.Conv2d(channel, channel // 2, kernel_size=(1, 1))
        self.ch_wq = nn.Conv2d(channel, 1, kernel_size=(1, 1))
        self.softmax_channel = nn.Softmax(1)
        self.softmax_spatial = nn.Softmax(-1)
        self.ch_wz = nn.Conv2d(channel // 2, channel, kernel_size=(1, 1))
        self.ln = nn.LayerNorm(channel)
        self.sigmoid = nn.Sigmoid()

        self.sp_wv = nn.Conv2d(channel, channel // 2, kernel_size=(1, 1))
        self.sp_wq = nn.Conv2d(channel, channel // 2, kernel_size=(1, 1))
        self.agp = nn.AdaptiveAvgPool2d((1, 1))
        self.conv1 = nn.Conv2d(2, 1, kernel_size=(1, 1))
        self.conv2 = nn.Conv2d(channel, channel // 2, kernel_size=(1, 1))
        self.conv=nn.Conv2d(channel*2, channel, kernel_size=(1, 1))
        self.w = nn.Parameter(torch.ones(
            2))  # 2个分支, 每个分支设置一个自适应学习权重, 初始化为1, nn.Parameter需放入Tensor类型的数据 通过 nn.Parameter 定义的，它将作为模型的一部分进行学习和更新self.w 初始化为1，初始时 w1 和 w2 都将是0.5，表示两个模态在开始时具有相同的重要性。随着训练的进行，根据模型在数据上的表现，这些权重将被调整。
        self.ww = nn.Parameter(torch.ones(2))
        self.ga1=GatedMultimodalLayer(channel,channel)
        self.ga2 = GatedMultimodalLayer(channel, channel)
        self.fre_process = Freprocess(channel)
    def forward(self, x):


        rgb, ir = x[0], x[1] #（1.64.32，32）
        b, c, h, w = x[0].size()#1,64,32,32
        # rgb=torch.tensor(rgb, dtype=torch.float32)
        # ir = torch.tensor(ir, dtype=torch.float32)
        # print("rgb.,dtype",rgb.dtype)
        # print("ir.,dtype", ir.dtype)

        rgb, ir=self.fre_process(rgb, ir)

        # Channel-only Self-Attention
        channel_wv_rgb = self.ch_wv(rgb)  # bs,c//2,h,w  1,32,32,32
        channel_wq_rgb = self.ch_wq(rgb)  # bs,1,h,w 1,32,32,32
        channel_wv_rgb = channel_wv_rgb.reshape(b, c // 2, -1)  # bs,c//2,h*w 1,32,1024
        channel_wq_rgb = channel_wq_rgb.reshape(b, -1, 1)  # bs,h*w,1 1,64*64=1024,1

        channel_wv_ir = self.ch_wv(ir)  # bs,c//2,h,w  （1,32,32，32）
        channel_wq_ir = self.ch_wq(ir)  # bs,1,h,w（1,1,32，32）
        channel_wv_ir = channel_wv_ir.reshape(b, c // 2, -1)  # bs,c//2,h*w （1，32，1024）
        channel_wq_ir = channel_wq_ir.reshape(b, -1, 1)  # bs,h*w,1 （1，1024，1）

        channel_wq_rgb_ir=channel_wq_rgb+channel_wq_ir #(1，1024，1)
        # channel_wq_rgb_ir=torch.cat((channel_wq_rgb,channel_wq_ir),2) #（1，1024，2）相当于做了特征图级联
        # channel_wq_rgb_ir=(self.conv1(channel_wq_rgb_ir.reshape(b,2,h,w))).reshape(b,h*w,1)
        channel_wq_rgb_ir = self.softmax_channel(channel_wq_rgb_ir)  #(1，1024，1)

        channel_wz_rgb = torch.matmul(channel_wv_rgb, channel_wq_rgb_ir).unsqueeze(-1)  # bs,c//2,1,1 （1,32,1024）*(1，1024，1)=（1，32，1，1）


        channel_weight_rgb = self.sigmoid(self.ln(self.ch_wz(channel_wz_rgb).reshape(b, c, 1).permute(0, 2, 1))).permute(0, 2, 1).reshape(b, c, 1, 1)  # bs,c,1,1（1，64，1，1）

        channel_wz_ir = torch.matmul(channel_wv_ir, channel_wq_rgb_ir).unsqueeze(-1)  # bs,c//2,1,1 （1，32，1，1）

        channel_weight_ir = self.sigmoid(self.ln(self.ch_wz(channel_wz_ir).reshape(b, c, 1).permute(0, 2, 1))).permute(0, 2, 1).reshape(b, c, 1,1)  # bs,c,1,1 （1，64，1，1）
        out_rgb=channel_weight_rgb * rgb #（1，64，1，1）*（1，64，32，32）=（1，64，32，32）
        out_ir = channel_weight_ir * ir#（1，64，32，32）
        #out=torch.add(out_rgb, out_ir) #源码PSA的方式，残差相乘后双模态ADD相加输出 （1，64，32，32）

        # 按LSTM里GUM设计
        channel_out_rgb=self.ga1(out_ir,rgb)#
        channel_out_ir=self.ga2(out_rgb,ir)

        out = torch.cat((channel_out_rgb, channel_out_ir), 1)  # (1,128,32,32)
        out = self.conv(out)  # 为了不改变通道数，用卷积通道数减半 (1,64,32,32)

        return out


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    visible = torch.randn(1, 64, 32, 32).to(device)
    infarad = torch.randn(1, 64, 32, 32).to(device)
    model = CGSA(64, 64).to(device)

    x = [visible, infarad]

    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN、小红书：十小大")

    print("输入visible特征维度：", x[0].shape)
    print("输入infarad特征维度：", x[1].shape)
    print("输出特征维度：", y.shape)