import torch
import torch.nn as nn
import torch.nn.functional as F


class CPCA_ChannelAttention(nn.Module):
    """
    跨模态通道注意力模块（Cross-modal PCA Channel Attention）
    功能：基于全局池化与MLP，生成通道注意力权重，筛选双模态融合后的关键通道
    核心设计：
        - 双池化引导：平均池化捕捉全局统计、最大池化捕捉局部峰值，双路径融合提升注意力鲁棒性
        - 轻量化MLP：1×1卷积构成的简易MLP，通道压缩-恢复，降低计算成本
        - 跨模态适配：适配双模态差异特征，强化模态互补通道
    Args:
        input_channels: 输入通道数（双模态融合后的通道数）
        internal_neurons: MLP中间层通道数（通道压缩后的维度）
    """
    def __init__(self, input_channels, internal_neurons):
        super(CPCA_ChannelAttention, self).__init__()
        self.fc1 = nn.Conv2d(in_channels=input_channels, out_channels=internal_neurons, kernel_size=1, stride=1,
                             bias=True)
        self.fc2 = nn.Conv2d(in_channels=internal_neurons, out_channels=input_channels, kernel_size=1, stride=1,
                             bias=True)
        self.input_channels = input_channels

    def forward(self, inputs):
        x1 = F.adaptive_avg_pool2d(inputs, output_size=(1, 1))
        x1 = self.fc1(x1)
        x1 = F.relu(x1, inplace=True)
        x1 = self.fc2(x1)
        x1 = torch.sigmoid(x1)
        x2 = F.adaptive_max_pool2d(inputs, output_size=(1, 1))
        x2 = self.fc1(x2)
        x2 = F.relu(x2, inplace=True)
        x2 = self.fc2(x2)
        x2 = torch.sigmoid(x2)
        x = x1 + x2
        x = x.view(-1, self.input_channels, 1, 1)
        return inputs * x #通道层的结果（权重X与原输入相乘）



class CDFIM(nn.Module):
    """
    跨模态深度滤波交互模块（Cross-modal DF Interaction Module, CDFIM）
    功能：融合双模态特征，通过模态差异感知、通道注意力、多尺度深度卷积滤波，强化跨模态互补信息
    核心设计：
        - 模态差异感知：通过双模态特征相减，捕捉模态间互补信息，为融合提供引导
        - 多尺度深度滤波：不同长宽比的深度卷积（1×7/7×1等），捕捉多方向空间依赖
        - 通道注意力筛选：CPCA_ChannelAttention筛选关键通道，抑制模态冗余
        - 残差式融合：多尺度滤波特征与初始特征相加，保留基础信息
    Args:
        channels: 单模态输入通道数（双模态通道数相同）
        out_channels: 输出通道数
        channelAttention_reduce: 通道注意力压缩比例（默认4）
    """
    def __init__(self, channels, out_channels, channelAttention_reduce=4):
        super().__init__()
        self.conv1 = nn.Conv2d(channels, channels, kernel_size=(1, 1), padding=0)
        self.ca = CPCA_ChannelAttention(input_channels=channels, internal_neurons=channels // channelAttention_reduce)
        self.dconv5_5 = nn.Conv2d(channels, channels, kernel_size=5, padding=2, groups=channels)
        self.dconv1_7 = nn.Conv2d(channels, channels, kernel_size=(1, 7), padding=(0, 3), groups=channels)
        self.dconv7_1 = nn.Conv2d(channels, channels, kernel_size=(7, 1), padding=(3, 0), groups=channels)
        self.dconv1_11 = nn.Conv2d(channels, channels, kernel_size=(1, 11), padding=(0, 5), groups=channels)
        self.dconv11_1 = nn.Conv2d(channels, channels, kernel_size=(11, 1), padding=(5, 0), groups=channels)
        self.dconv1_21 = nn.Conv2d(channels, channels, kernel_size=(1, 21), padding=(0, 10), groups=channels)
        self.dconv21_1 = nn.Conv2d(channels, channels, kernel_size=(21, 1), padding=(10, 0), groups=channels)
        self.conv2 = nn.Conv2d(channels, out_channels, kernel_size=(1, 1), padding=0)
        self.act = nn.GELU()

    def forward(self, x):

        #####原版###########################################
        #inputs = torch.cat((x[0], x[1]), dim=1) #把输入的可见光、红外图像通道级联
        #   Global Perceptron 全局感知

        #inputs =x[0]-x[1]
        inputs=x[0]-x[1]
        inputs = self.conv1(inputs)
        inputs = self.act(inputs)

        inputs = self.ca(inputs)
        inputs0=inputs+x[0]
        inputs1 = inputs + x[1]
        inputs=inputs0+inputs1

        x_init = self.dconv5_5(inputs)
        x_1 = self.dconv1_7(x_init)
        x_1 = self.dconv7_1(x_1)
        x_2 = self.dconv1_11(x_init)
        x_2 = self.dconv11_1(x_2)
        x_3 = self.dconv1_21(x_init)
        x_3 = self.dconv21_1(x_3)
        x = x_1 + x_2 + x_3 + x_init
        spatial_att = self.conv1(x)
        out = spatial_att * inputs
        out = self.conv2(out)
        return out


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    visible = torch.randn(1, 64, 32, 32).to(device)
    infarad = torch.randn(1, 64, 32, 32).to(device)
    model = CDFIM(64, 64).to(device)

    x = [visible, infarad]

    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN、小红书：十小大")

    print("输入visible特征维度：", x[0].shape)
    print("输入infarad特征维度：", x[1].shape)
    print("输出特征维度：", y.shape)