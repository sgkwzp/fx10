import torch
from torch import nn
from torch.nn import functional as F


class Gate(nn.Module):
    """
    自适应门控模块（Attention Gate）：动态平衡双输入特征贡献
    核心设计：基于双特征融合生成门控掩码，加权融合后输出，比固定权重更具针对性
    Args:
        in_channels: 输入特征通道数
    """
    def __init__(self, in_channels):
        super(Gate, self).__init__()
        self.psi = nn.Sequential(
            nn.Conv2d(in_channels, 1, kernel_size=1, stride=1, padding=0, bias=True),
            nn.BatchNorm2d(1), nn.Sigmoid())
        self.relu = nn.ReLU(inplace=True)

    def forward(self, g, x):
        mid = g + x
        mid = self.relu(mid)
        mid = self.psi(mid)
        up = g * mid
        down = x * up
        out = up + down

        return out


class ConvBnRelu(nn.Module):
    def __init__(self, in_planes, out_planes, ksize, stride, pad, dilation=1,
                 groups=1, has_bn=True, norm_layer=nn.BatchNorm2d,
                 has_relu=True, inplace=True, has_bias=False):
        super(ConvBnRelu, self).__init__()
        self.conv = nn.Conv2d(in_planes, out_planes, kernel_size=ksize,
                              stride=stride, padding=pad,
                              dilation=dilation, groups=groups, bias=has_bias)
        self.has_bn = has_bn
        if self.has_bn:
            self.bn = nn.BatchNorm2d(out_planes)
        self.has_relu = has_relu
        if self.has_relu:
            self.relu = nn.ReLU(inplace=inplace)

    def forward(self, x):
        x = self.conv(x)
        if self.has_bn:
            x = self.bn(x)
        if self.has_relu:
            x = self.relu(x)

        return x


class SAFM(nn.Module):
    """
    尺度感知自适应融合模块（Scale-aware Adaptive Fusion Module, SAFM）
    功能：多尺度膨胀特征提取+自适应门控融合，实现尺度自适应增强
    核心设计：
        - 共享权重多膨胀卷积：4组不同膨胀率（1/2/4/8），共享卷积核权重，降低计算成本
        - 三级门控融合：逐步融合多尺度特征，动态平衡各尺度贡献
        - 残差增强：融合特征与原始输入残差连接，保留基础信息
        - 可学习融合因子：gamma参数自适应调整融合强度
    Args:
        in_channels: 输入/输出通道数
    """
    def __init__(self, in_channels):
        super(SAFM, self).__init__()
        self.conv3x3 = nn.Conv2d(in_channels=in_channels, out_channels=in_channels, dilation=1, kernel_size=3,
                                 padding=1)
        self.AG1 = Gate(in_channels)
        self.AG2 = Gate(in_channels)
        self.AG3 = Gate(in_channels)
        self.bn = nn.ModuleList([nn.BatchNorm2d(in_channels), nn.BatchNorm2d(in_channels), nn.BatchNorm2d(in_channels), nn.BatchNorm2d(in_channels)])
        self.conv1x1 = nn.ModuleList(
            [nn.Conv2d(in_channels=2 * in_channels, out_channels=in_channels, dilation=1, kernel_size=1, padding=0),
             nn.Conv2d(in_channels=2 * in_channels, out_channels=in_channels, dilation=1, kernel_size=1, padding=0)])
        self.conv3x3_1 = nn.ModuleList(
            [nn.Conv2d(in_channels=in_channels, out_channels=in_channels // 2, dilation=1, kernel_size=3, padding=1),
             nn.Conv2d(in_channels=in_channels, out_channels=in_channels // 2, dilation=1, kernel_size=3, padding=1)])
        self.conv3x3_2 = nn.ModuleList(
            [nn.Conv2d(in_channels=in_channels // 2, out_channels=2, dilation=1, kernel_size=3, padding=1),
             nn.Conv2d(in_channels=in_channels // 2, out_channels=2, dilation=1, kernel_size=3, padding=1)])
        self.conv_last = ConvBnRelu(in_planes=in_channels, out_planes=in_channels, ksize=1, stride=1, pad=0, dilation=1)
        self.norm = nn.Sigmoid()
        self.conv1 = nn.Conv2d(in_channels * 2, in_channels, kernel_size=1, padding=0)
        self.dconv1 = nn.Conv2d(in_channels * 2, in_channels, kernel_size=1, padding=0)
        self.gamma = nn.Parameter(torch.zeros(1))

        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        branches_1 = self.conv3x3(x)
        branches_1 = self.bn[0](branches_1)

        branches_2 = F.conv2d(x, self.conv3x3.weight, padding=2, dilation=2)  # share weight
        branches_2 = self.bn[1](branches_2)

        branches_3 = F.conv2d(x, self.conv3x3.weight, padding=4, dilation=4)  # share weight
        branches_3 = self.bn[2](branches_3)

        branches_4 = F.conv2d(x, self.conv3x3.weight, padding=8, dilation=8)  # share weight
        branches_4 = self.bn[3](branches_4)

        fusion_1_2 = self.AG1(branches_1, branches_2)

        fusion_2_3 = self.AG2(fusion_1_2, branches_3)

        fusion_3_4 = self.AG3(fusion_2_3, branches_4)

        alpha = self.norm(self.gamma)
        ax = self.relu(alpha * fusion_3_4 + (1 - alpha) * x)
        ax = self.conv_last(ax)

        return ax


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 64, 32, 32).to(device)
    model = SAFM(64).to(device)

    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN、小红书：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)