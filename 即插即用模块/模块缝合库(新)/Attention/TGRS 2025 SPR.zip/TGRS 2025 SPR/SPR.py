# 显著性比例协调模块（Saliency Proportion Reconciler, SPR）
# 核心设计：针对双输入特征（如双模态、双尺度），通过“差异提取→显著性识别→比例协调融合”的流程，
# 自动区分特征差异中的显著性与非显著性成分，动态平衡两者贡献比例，实现精准高效的特征融合，提升融合特征的针对性与辨识度

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F


class BasicConv2d(nn.Module):
    """
    基础卷积块：Conv2d + BatchNorm2d + ReLU，简化特征提取流程
    Args:
        in_planes: 输入通道数
        out_planes: 输出通道数
        kernel_size: 卷积核大小
        stride: 步长（默认1）
        padding: 填充量（默认0）
        dilation: 膨胀率（默认1）
    """
    def __init__(self, in_planes, out_planes, kernel_size, stride=1, padding=0, dilation=1):
        super(BasicConv2d, self).__init__()
        self.conv = nn.Conv2d(in_planes, out_planes,
                              kernel_size=kernel_size, stride=stride,
                              padding=padding, dilation=dilation, bias=False)
        self.bn = nn.BatchNorm2d(out_planes)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        x = self.conv(x)
        x = self.bn(x)
        x = self.relu(x)
        return x

class SF(torch.nn.Module):
    """
    空间滤波模块（Spatial Filter, SF）：基于统计特征的空间显著性增强
    核心设计：通过均值与方差计算特征差异的显著性，生成自适应空间权重
    Args:
        in_ch: 输入通道数（无需显式指定，自动适配）
    """
    def __init__(self, in_ch):
        super(SF, self).__init__()

    def forward(self, x):
        _, _, h, w = x.size()
        # 计算特征均值（全局统计）
        q = x.mean(dim=[2, 3], keepdim=True)
        k = x
        # 计算平方差与方差
        square = (k - q).pow(2)
        sigma = square.sum(dim=[2, 3], keepdim=True) / (h * w)  # 方差
        # 生成显著性分数与权重
        att_score = square / (2 * sigma + np.finfo(np.float32).eps) + 0.5
        att_weight = nn.Sigmoid()(att_score)  # 权重归一化至[0,1]
        return x * att_weight  # 空间加权增强


class CMM(nn.Module):
    """
    上下文记忆模块（Context Memory Module, CMM）：识别特征差异中的显著性与非显著性成分
    核心设计：
        - 局部-全局特征拆分：拆分特征为局部细节与全局结构，协同判断显著性
        - 轻量化MLP分类：通过MLP生成显著性/非显著性权重，实现端到端识别
        - 记忆单元预留：支持扩展多组记忆单元，强化上下文依赖
    Args:
        in_channels: 输入特征通道数
        embed_dim: 嵌入维度（MLP输入维度）
        memory_size: 记忆单元数量（默认4，当前未启用）
    """
    def __init__(self, in_channels, embed_dim, memory_size=4):
        super(CMM, self).__init__()
        # 预留记忆单元（当前未在forward中使用，支持扩展）
        self.memory_units = nn.ModuleList([
            nn.Conv2d(in_channels, in_channels, kernel_size=1, stride=1) for _ in range(memory_size)
        ])
        # 输入特征预处理MLP
        self.in_conv = nn.Sequential(
            nn.LayerNorm(embed_dim),
            nn.Linear(embed_dim, embed_dim),
            nn.GELU()
        )
        # 显著性分类MLP（输出2类权重：显著性/非显著性）
        self.out_conv = nn.Sequential(
            nn.Linear(embed_dim, embed_dim // 2),
            nn.GELU(),
            nn.Linear(embed_dim // 2, embed_dim // 4),
            nn.GELU(),
            nn.Linear(embed_dim // 4, 2),
            nn.LogSoftmax(dim=-1)
        )

    def forward(self, x):
        # 维度适配：特征图→序列格式（b, n, c）
        if len(x.shape) == 4:
            B, C, H, W = x.size()
            x_rs = x.reshape(B, C, -1).permute(0, 2, 1)
        else:
            B, N, C = x.size()
            H = int(N**0.5)
            x_rs = x

        # 特征预处理
        x_rs = self.in_conv(x_rs)
        B, N, C = x_rs.size()
        window_scale = int(H//2)

        # 局部-全局特征拆分与融合
        local_x = x_rs[:, :, :C // 2]  # 局部特征（前半通道）
        global_x = x_rs[:, :, C // 2:].view(B, H, -1, C // 2).permute(0, 3, 1, 2)  # 全局特征（后半通道）
        global_x_avg = F.adaptive_avg_pool2d(global_x, (2, 2))  # 全局平均池化（降维）
        global_x_avg_concat = F.interpolate(global_x_avg, scale_factor=window_scale)  # 上采样至原尺度
        global_x_avg_concat = global_x_avg_concat.view(B, C // 2, -1).permute(0, 2, 1).contiguous()  # 序列格式还原

        # 局部-全局特征融合→分类生成权重
        x_rs = torch.cat([local_x, global_x_avg_concat], dim=-1)
        x_score = self.out_conv(x_rs)  # 分类分数（b, n, 2）
        mapping = x_score.permute(0, 2, 1).reshape(B, 2, H, -1)  # 维度还原为特征图格式

        # 拆分显著性与非显著性权重
        significant_weight = mapping[:, 0:1, :, :]  # 显著性权重（b, 1, h, w）
        nonsignificant_weight = mapping[:, 1:2, :, :]  # 非显著性权重（b, 1, h, w）

        return significant_weight, nonsignificant_weight


class SPR(nn.Module):
    """
    显著性比例协调模块（Saliency Proportion Reconciler, SPR）
    功能：双特征差异分析→显著性识别→比例协调融合，实现精准特征融合
    核心设计：
        - 差异提取：计算双特征绝对差异，聚焦融合关键点
        - 显著性识别：CMM模块区分显著性/非显著性成分，SF模块增强差异特征
        - 比例协调：可学习参数动态平衡两类成分贡献，比固定比例更自适应
        - 轻量化融合：1×1卷积整合双特征，GELU激活增强非线性
    Args:
        dim: 单输入特征通道数
        hidden_dim: 融合中间通道数
        embed_dim: CMM模块嵌入维度
        memory_size: CMM模块记忆单元数量（默认4）
    """
    def __init__(self, dim, hidden_dim, embed_dim, memory_size=4):
        super(SPR, self).__init__()
        self.hidden_dim = hidden_dim
        self.cmm = CMM(dim, embed_dim, memory_size)  # 显著性识别
        self.conv_gates = nn.Conv2d(2 * dim, 2 * hidden_dim, kernel_size=1)  # 双特征融合卷积
        self.alpha_param = nn.Parameter(torch.tensor(0.5))  # 显著性成分比例参数
        self.beta_param = nn.Parameter(torch.tensor(0.5))    # 非显著性成分比例参数
        self.fusion_activation = nn.GELU()  # 融合后激活
        self.spfilter = SF(dim)  # 差异特征空间滤波

    def forward(self, x, y):
        """
        前向传播：差异提取→显著性识别→比例协调→融合输出
        Args:
            x: 输入特征1，shape=[b, dim, h, w]
            y: 输入特征2，shape=[b, dim, h, w]
        Returns:
            融合特征，shape=[b, hidden_dim, h, w]
        """
        # 1. 双特征差异提取与增强
        diff_fea = torch.abs(x - y)  # 绝对差异特征（聚焦融合关键点）
        diff_sp = self.spfilter(diff_fea)  # 空间滤波增强差异

        # 2. 显著性与非显著性权重识别
        significant_weight, nonsignificant_weight = self.cmm(diff_fea)

        # 3. 双特征融合与成分拆分
        fused_fea = torch.cat([x, y], dim=1)  # 双特征拼接（b, 2dim, h, w）
        fuse_conv = self.conv_gates(fused_fea)  # 1×1卷积整合（b, 2hidden_dim, h, w）
        salien_fea, nonsalien_fea = torch.split(fuse_conv, self.hidden_dim, dim=1)  # 拆分两类成分

        # 4. 权重加权与比例协调
        salien_fea = salien_fea * significant_weight  # 显著性成分加权
        nonsalien_fea = nonsalien_fea * nonsignificant_weight  # 非显著性成分加权
        # 可学习比例参数（Softmax归一化）
        alpha, beta = torch.softmax(torch.cat([self.alpha_param.unsqueeze(0), self.beta_param.unsqueeze(0)], dim=0), dim=0)
        final_fuse = alpha * salien_fea + beta * nonsalien_fea  # 比例协调融合

        # 5. 激活输出
        return self.fusion_activation(final_fuse)


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    f1 = torch.randn(1, 64, 32, 32).to(device)
    f2 = torch.randn(1, 64, 32, 32).to(device)
    model = SPR(64, 64, 64).to(device)

    y = model(f1, f2)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN、小红书：十小大")

    print("输入F1特征维度：", f1.shape)
    print("输入F2特征维度：", f2.shape)
    print("输出特征维度：", y.shape)