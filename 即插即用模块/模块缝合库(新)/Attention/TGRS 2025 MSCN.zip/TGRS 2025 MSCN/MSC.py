import torch
import torch.nn as nn
from einops import rearrange
from math import sqrt

class MSC(nn.Module):
    """
    多尺度注意力融合模块（Multi-Scale Attention Fusion Module）
    核心功能：通过多尺度池化提取特征，结合Top-k注意力筛选关键信息，实现特征融合
    """
    def __init__(self, dim, num_heads=8, topk=True, kernel=[3, 5, 7], s=[1, 1, 1], pad=[1, 2, 3],
                 qkv_bias=False, qk_scale=None, attn_drop_ratio=0., proj_drop_ratio=0., k1=2, k2=3):
        """
        初始化MSC模块参数
        Args:
            dim: 输入特征通道数（如64、128），需保证能被num_heads整除
            num_heads: 多头注意力的头数，用于并行捕捉不同维度特征
            topk: 是否启用Top-k注意力筛选（默认True，核心机制）
            kernel: 3个平均池化核大小，对应多尺度（小、中、大），默认[3,5,7]
            s: 3个池化的步长，默认全为1（保证池化后特征图尺寸不变）
            pad: 3个池化的填充数，与kernel匹配（kernel//2），确保尺寸不变
            qkv_bias: 线性层是否添加偏置，默认False（减少参数冗余）
            qk_scale: 注意力缩放因子，默认None（自动用head_dim^-0.5）
            attn_drop_ratio: 注意力权重的dropout概率，默认0（防止过拟合）
            proj_drop_ratio: 输出投影层的dropout概率，默认0
            k1/k2: Top-k筛选的比例分母，如k1=2表示取前N1/2个关键信息
        """
        super(MSC, self).__init__()
        self.num_heads = num_heads
        self.head_dim = dim // num_heads  # 单个注意力头的通道数
        # 注意力缩放因子：避免内积结果过大导致softmax梯度消失
        self.scale = qk_scale or self.head_dim ** -0.5

        # 线性层定义：Q（查询）从x生成，KV（键值）从多尺度处理后的y生成
        self.q = nn.Linear(dim, dim, bias=qkv_bias)  # Q: [B, N, C] -> [B, N, C]
        self.kv = nn.Linear(dim, dim * 2, bias=qkv_bias)  # KV: [B, N1, C] -> [B, N1, 2C]

        # Dropout层：正则化，防止过拟合
        self.attn_drop = nn.Dropout(attn_drop_ratio)
        self.proj = nn.Linear(dim, dim)  # 输出投影层：恢复特征维度
        self.proj_drop = nn.Dropout(proj_drop_ratio)

        self.k1 = k1  # Top-k1的比例分母
        self.k2 = k2  # Top-k2的比例分母

        # 注意力权重参数：可学习，用于融合两个Top-k分支结果
        self.attn1 = torch.nn.Parameter(torch.tensor([0.5]), requires_grad=True)  # 分支1权重
        self.attn2 = torch.nn.Parameter(torch.tensor([0.5]), requires_grad=True)  # 分支2权重

        # 多尺度平均池化层：提取y的小、中、大尺度特征（尺寸不变）
        self.avgpool1 = nn.AvgPool2d(kernel_size=kernel[0], stride=s[0], padding=pad[0])  # 3x3池化
        self.avgpool2 = nn.AvgPool2d(kernel_size=kernel[1], stride=s[1], padding=pad[1])  # 5x5池化
        self.avgpool3 = nn.AvgPool2d(kernel_size=kernel[2], stride=s[2], padding=pad[2])  # 7x7池化

        self.layer_norm = nn.LayerNorm(dim)  # 对y的特征进行层归一化：稳定训练
        self.topk = topk  # 控制是否启用Top-k注意力（调试用）

    def forward(self, x, y):
        """
        前向传播：输入两个特征图x（待增强）和y（多尺度特征源），输出增强后的x
        Args:
            x: 主输入特征，形状[B, C, H, W]（B=批次，C=通道，H/W=高/宽）
            y: 辅助输入特征，形状与x一致，用于提供多尺度信息
        Returns:
            x: 融合后输出特征，形状与输入x一致
        """
        # 1. 多尺度池化：对y进行3个尺度的平均池化，保留空间结构
        y1 = self.avgpool1(y)  # [B, C, H, W] -> [B, C, H, W]（3x3池化）
        y2 = self.avgpool2(y)  # [B, C, H, W] -> [B, C, H, W]（5x5池化）
        y3 = self.avgpool3(y)  # [B, C, H, W] -> [B, C, H, W]（7x7池化）

        # 2. 多尺度特征融合：求和融合3个尺度的y特征，减少冗余
        y = y1 + y2 + y3  # [B, C, H, W]
        # 3. 维度重塑：将y从「通道优先」转为「序列优先」，适配注意力计算
        y = y.flatten(-2, -1)  # [B, C, H, W] -> [B, C, H*W]（展平空间维度）
        y = y.transpose(1, 2)  # [B, C, H*W] -> [B, H*W, C]（转为[B, N1, C]，N1=H*W）
        y = self.layer_norm(y)  # 层归一化：稳定y的特征分布

        # 4. 重塑x维度：与y一致，适配Q的生成
        x = rearrange(x, 'b c h w -> b (h w) c')  # [B, C, H, W] -> [B, N, C]（N=H*W）

        # 5. 生成KV（键值对）：从y中提取，适配多头注意力
        B, N1, C = y.shape  # N1：y的序列长度（H*W）
        # KV线性层 -> 拆分维度 -> 转置为多头格式：[2, B, num_heads, N1, head_dim]
        kv = self.kv(y).reshape(B, N1, 2, self.num_heads, C // self.num_heads).permute(2, 0, 3, 1, 4)
        k, v = kv[0], kv[1]  # K: [B, num_heads, N1, head_dim]；V: [B, num_heads, N1, head_dim]

        # 6. 生成Q（查询）：从x中提取，适配多头注意力
        B, N, C = x.shape  # N：x的序列长度（与N1一致，因x/y尺寸相同）
        # Q线性层 -> 转置为多头格式：[B, num_heads, N, head_dim]
        q = self.q(x).reshape(B, N, self.num_heads, C // self.num_heads).permute(0, 2, 1, 3)

        # 7. 计算原始注意力权重：Q与K的内积，再缩放
        attn = (q @ k.transpose(-2, -1)) * self.scale  # [B, num_heads, N, N1]

        # 8. Top-k注意力分支1：筛选前N1/k1个关键信息（保留更多全局信息）
        # 生成掩码：初始全0，仅Top-k位置设为1
        mask1 = torch.zeros(B, self.num_heads, N, N1, device=x.device, requires_grad=False)

        # 获取Top-k的索引：按最后一维（N1）取最大的N1/k1个值
        index = torch.topk(attn, k=int(N1 / self.k1), dim=-1, largest=True)[1]
        mask1.scatter_(-1, index, 1.)  # 掩码赋值：Top-k位置为1

        # 注意力筛选：非Top-k位置设为-∞，softmax后权重趋近于0
        attn1 = torch.where(mask1 > 0, attn, torch.full_like(attn, float('-inf')))
        attn1 = attn1.softmax(dim=-1)  # 归一化：得到注意力权重
        attn1 = self.attn_drop(attn1)  # Dropout：正则化
        out1 = (attn1 @ v)  # 分支1输出：注意力加权V，[B, num_heads, N, head_dim]

        # 9. Top-k注意力分支2：筛选前N1/k2个关键信息（保留更核心的局部信息）
        mask2 = torch.zeros(B, self.num_heads, N, N1, device=x.device, requires_grad=False)
        index = torch.topk(attn, k=int(N1 / self.k2), dim=-1, largest=True)[1]
        mask2.scatter_(-1, index, 1.)
        attn2 = torch.where(mask2 > 0, attn, torch.full_like(attn, float('-inf')))
        attn2 = attn2.softmax(dim=-1)
        attn2 = self.attn_drop(attn2)
        out2 = (attn2 @ v)  # 分支2输出：[B, num_heads, N, head_dim]

        # 10. 双分支融合：用可学习权重attn1/attn2融合两个分支结果
        out = out1 * self.attn1 + out2 * self.attn2  # [B, num_heads, N, head_dim]

        # 11. 维度恢复：将多头注意力结果重塑为原始特征维度
        x = out.transpose(1, 2).reshape(B, N, C)  # [B, N, C]（恢复序列优先格式）
        x = self.proj(x)  # 投影层：调整特征分布，增强表达能力
        x = self.proj_drop(x)  # Dropout：正则化

        # 12. 最终维度重塑：从「序列优先」转回「通道优先」，匹配输入格式
        hw = int(sqrt(N))  # 恢复空间尺寸（因N=H*W，hw=H=W）
        x = rearrange(x, 'b (h w) c -> b c h w', h=hw, w=hw)  # [B, C, H, W]

        return x

if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    x = torch.randn(1, 64, 32, 32).to(device)
    y = torch.randn(1, 64, 32, 32).to(device)
    model = MSC(64)
    model.to(device)
    out = model(x, y)

    print("微信公众号：十小大的底层视觉工坊")
    print("知乎、CSDN：十小大")
    print("输入特征1维度：", x.shape)
    print("输入特征2维度：", y.shape)
    print("输出特征维度：", out.shape)