import torch
import torch.nn as nn
import torch.nn.functional as F
from mmcv.runner import BaseModule  # 导入MMCV框架的基础模块类（适配深度学习训练流程）

class MonaOp(nn.Module):
    def __init__(self, in_features):
        super().__init__()
        # 1. 多尺度深度可分离卷积（Depthwise Conv）：分别使用3×3、5×5、7×7核
        # 深度可分离卷积（groups=in_features）：每个输入通道单独卷积，降低计算量
        self.conv1 = nn.Conv2d(
            in_features, in_features,
            kernel_size=3, padding=3//2,  # padding=1：保证输入输出特征图尺寸一致（3×3核）
            groups=in_features  # 分组卷积数=输入通道数→深度可分离模式
        )
        self.conv2 = nn.Conv2d(
            in_features, in_features,
            kernel_size=5, padding=5//2,  # padding=2：保证5×5核输入输出尺寸一致
            groups=in_features
        )
        self.conv3 = nn.Conv2d(
            in_features, in_features,
            kernel_size=7, padding=7//2,  # padding=3：保证7×7核输入输出尺寸一致
            groups=in_features
        )
        # 2. 1×1卷积投影层：融合多尺度卷积结果的通道信息（无分组，实现通道交互）
        self.projector = nn.Conv2d(in_features, in_features, kernel_size=1)

    def forward(self, x):
        # 输入特征图格式：默认(b, c, h, w)（批量大小，通道数，高度，宽度）
        identity = x  # 残差连接：保留原始输入特征，缓解梯度消失
        # 1. 多尺度卷积计算
        conv1_x = self.conv1(x)  # 3×3深度可分离卷积：捕捉细粒度局部特征
        conv2_x = self.conv2(x)  # 5×5深度可分离卷积：捕捉中尺度局部特征
        conv3_x = self.conv3(x)  # 7×7深度可分离卷积：捕捉大尺度局部特征
        # 2. 多尺度结果平均融合 + 残差连接（避免多尺度融合导致的特征强度衰减）
        x = (conv1_x + conv2_x + conv3_x) / 3.0 + identity  # 平均池化式融合：平衡各尺度权重
        identity = x  # 更新残差连接的基准特征
        # 3. 1×1卷积投影：融合通道信息（深度可分离卷积无通道交互，需1×1补充）
        x = self.projector(x)
        # 4. 输出：投影结果 + 残差连接（进一步保留融合后的特征）
        return identity + x

class Mona(BaseModule):  # 继承MMCV的BaseModule，支持权重初始化、断点续训等功能
    def __init__(self,
                 in_dim,  # 输入特征的通道维度（如64）
                 factor=4):  # 通道缩放因子（未直接使用，预留用于后续扩展）
        super().__init__()
        # 1. 通道下投影层：将输入特征从in_dim压缩到64维（降低计算量，聚焦关键特征）
        self.project1 = nn.Linear(in_dim, 64)
        # 2. 非线性激活函数：GELU（高斯误差线性单元，比ReLU更平滑，缓解梯度消失）
        self.nonlinear = F.gelu
        # 3. 通道上投影层：将64维特征恢复到原in_dim维度（与输入通道匹配，支持残差连接）
        self.project2 = nn.Linear(64, in_dim)
        # 4.  dropout层：随机失活10%的神经元，防止过拟合
        self.dropout = nn.Dropout(p=0.1)
        # 5. 多尺度卷积适配器：使用MonaOp处理64维中间特征（增强局部特征捕捉能力）
        self.adapter_conv = MonaOp(64)
        # 6. 层归一化（LayerNorm）：对通道维度归一化，加速训练，稳定特征分布
        self.norm = nn.LayerNorm(in_dim)
        # 7. 可训练缩放参数：平衡归一化特征与原始特征的权重
        self.gamma = nn.Parameter(torch.ones(in_dim) * 1e-6)  # 归一化特征的初始权重（极小值，避免初期干扰）
        self.gammax = nn.Parameter(torch.ones(in_dim))  # 原始特征的初始权重（1.0，保证初期特征有效性）

    def forward(self, x, hw_shapes=None):  # hw_shapes：预留参数，用于记录特征图高宽，暂未使用
        # 输入特征格式：默认(b, h, w, c)或(b, seq_len, c)（Transformer常用的通道后置格式）
        identity = x  # 主残差连接：保留原始输入，确保训练稳定性
        # 1. 特征归一化与权重平衡：LayerNorm + 双参数缩放（兼顾归一化与原始特征）
        x = self.norm(x) * self.gamma + x * self.gammax  # 自适应调整归一化特征的贡献度
        # 2. 通道下投影：将高维特征压缩到64维（减少MonaOp的计算量）
        project1 = self.project1(x)
        # 3. 维度转换：Linear层输出为(b, h, w, 64)，需转为Conv2d要求的(b, 64, h, w)
        # 注：此处隐含特征格式转换逻辑，需确保输入x的维度顺序可支持转置（如(b, h, w, 64)→(b, 64, h, w)）
        project1 = project1.permute(0, 3, 1, 2)  # 维度重排：(b, h, w, c)→(b, c, h, w)
        # 4. 多尺度卷积增强：使用MonaOp捕捉局部多尺度特征
        project1 = self.adapter_conv(project1)
        # 5. 维度回传：将Conv2d输出的(b, 64, h, w)转回Linear要求的(b, h, w, 64)
        project1 = project1.permute(0, 2, 3, 1)  # 维度重排：(b, c, h, w)→(b, h, w, c)
        # 6. 非线性激活 + dropout：引入非线性表达，防止过拟合
        nonlinear = self.nonlinear(project1)
        nonlinear = self.dropout(nonlinear)
        # 7. 通道上投影：将64维特征恢复到原in_dim维度（与输入通道匹配）
        project2 = self.project2(nonlinear)
        # 8. 输出：主残差连接（原始输入 + 增强后特征），保证特征不衰减
        return identity + project2


if __name__ == '__main__':
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    x = torch.randn(1, 64, 64, 64).to(device)
    mona = Mona(64).to(device)
    y = mona(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("知乎、CSDN：十小大")
    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)