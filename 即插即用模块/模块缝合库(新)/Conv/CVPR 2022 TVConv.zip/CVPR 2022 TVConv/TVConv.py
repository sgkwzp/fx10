import torch
import torch.nn as nn


class _ConvBlock(nn.Sequential):
    """
    基础卷积块：卷积+层归一化+ReLU激活，为TVConv的权重生成与偏置生成提供特征提取能力
    核心作用：逐步提升特征维度、增强非线性表达，确保生成的动态权重具有足够判别性
    输入：特征图 [B, in_planes, h, w]（B=批次，in_planes=输入通道，h/w=高/宽）
    输出：增强后特征 [B, out_planes, h, w]（与输入空间尺寸一致，通道数调整为out_planes）
    """

    def __init__(self, in_planes, out_planes, h, w, kernel_size=3, stride=1, bias=False):
        padding = (kernel_size - 1) // 2  # 计算padding，确保卷积后空间尺寸不变
        super(_ConvBlock, self).__init__(
            # 卷积层：提取局部特征，通道数从in_planes调整为out_planes
            nn.Conv2d(in_planes, out_planes, kernel_size, stride, padding, bias=bias),
            # 层归一化：在通道维度归一化，稳定训练过程（适配空间维度h×w）
            nn.LayerNorm([out_planes, h, w]),
            # ReLU激活：增强非线性表达，缓解梯度消失
            nn.ReLU(inplace=True)
        )


class TVConv(nn.Module):
    """
    张量可变卷积（TVConv）：通过动态生成卷积权重，替代传统固定权重卷积
    核心创新：
        1. 位置感知动态权重：基于位置映射（posi_map）生成空间自适应权重，适配目标形状；
        2. 分层权重生成：通过多卷积块逐步提升维度，确保权重判别性；
        3. 轻量化设计：复用位置映射生成权重/偏置，避免全连接层的参数冗余；
        4. 即插即用：输入输出维度一致，可直接替换传统卷积。
    输入：特征图 [B, channels, H, W]（H/W需与初始化时h/w一致）
    输出：卷积增强特征 [B, channels, H, W]（与输入维度完全一致）
    """

    def __init__(self,
                 channels,  # 输入/输出特征通道数（需保持一致）
                 TVConv_k=3,  # 卷积核大小（默认3×3，需为奇数）
                 stride=1,  # 卷积步长（默认1，确保输出尺寸不变）
                 TVConv_posi_chans=4,  # 位置映射（posi_map）的通道数（默认4，控制权重生成的基础维度）
                 TVConv_inter_chans=16,  # 权重生成网络的中间通道数（默认16，平衡精度与效率）
                 TVConv_inter_layers=1,  # 权重生成网络的中间卷积块数量（默认1，控制非线性深度）
                 TVConv_Bias=False,  # 是否生成偏置（默认False，轻量化优先）
                 h=3,  # 特征图高度（需与输入特征高度一致）
                 w=3,  # 特征图宽度（需与输入特征宽度一致）
                 **kwargs):
        super(TVConv, self).__init__()
        # 注册缓冲区（不参与梯度更新）：存储固定参数（卷积核大小、步长等）
        self.register_buffer("TVConv_k", torch.as_tensor(TVConv_k))  # 卷积核大小k
        self.register_buffer("TVConv_k_square", torch.as_tensor(TVConv_k ** 2))  # k²（展开后每个像素的邻域数量）
        self.register_buffer("stride", torch.as_tensor(stride))  # 步长
        self.register_buffer("channels", torch.as_tensor(channels))  # 通道数
        self.register_buffer("h", torch.as_tensor(h))  # 特征图高度
        self.register_buffer("w", torch.as_tensor(w))  # 特征图宽度

        self.bias_layers = None  # 偏置生成网络（可选，TVConv_Bias=True时初始化）

        # 计算权重生成网络的输出通道数：k²×channels（每个通道的每个像素对应k²个权重）
        out_chans = self.TVConv_k_square * self.channels

        # 位置映射（posi_map）：可学习的基础位置特征，为权重生成提供空间信息
        self.posi_map = nn.Parameter(torch.Tensor(1, TVConv_posi_chans, h, w))  # [1, posi_chans, h, w]
        nn.init.ones_(self.posi_map)  # 初始化为全1，确保初始权重分布均匀

        # 权重生成网络：从posi_map生成动态卷积权重
        self.weight_layers = self._make_layers(
            in_chans=TVConv_posi_chans,
            inter_chans=TVConv_inter_chans,
            out_chans=out_chans,
            num_inter_layers=TVConv_inter_layers,
            h=h, w=w
        )

        # 偏置生成网络（可选）：与权重生成网络结构一致，输出通道数为channels
        if TVConv_Bias:
            self.bias_layers = self._make_layers(
                in_chans=TVConv_posi_chans,
                inter_chans=TVConv_inter_chans,
                out_chans=channels,
                num_inter_layers=TVConv_inter_layers,
                h=h, w=w
            )

        # 张量展开模块（Unfold）：将每个像素的k×k邻域展开为k²长度的向量
        self.unfold = nn.Unfold(
            kernel_size=TVConv_k,
            dilation=1,
            padding=(TVConv_k - 1) // 2,  # 确保展开后每个像素对应k²个邻域像素
            stride=stride
        )

    def _make_layers(self, in_chans, inter_chans, out_chans, num_inter_layers, h, w):
        """
        构建权重/偏置生成网络：基础卷积块→中间卷积块×N→输出卷积
        参数：
            in_chans：输入通道数（posi_map的通道数）
            inter_chans：中间通道数
            out_chans：输出通道数（权重：k²×channels；偏置：channels）
            num_inter_layers：中间卷积块数量
            h/w：特征图尺寸（适配LayerNorm）
        返回：序列化的卷积网络
        """
        layers = []
        # 第一层：将输入通道从in_chans提升至inter_chans
        layers.append(_ConvBlock(in_chans, inter_chans, h, w, bias=False))
        # 中间层：增强非线性表达，通道数保持inter_chans
        for _ in range(num_inter_layers):
            layers.append(_ConvBlock(inter_chans, inter_chans, h, w, bias=False))
        # 输出层：将通道数从inter_chans调整为目标out_chans（无激活，确保权重数值范围灵活）
        layers.append(nn.Conv2d(
            in_channels=inter_chans,
            out_channels=out_chans,
            kernel_size=3,
            padding=1,
            bias=False
        ))
        return nn.Sequential(*layers)

    def forward(self, x):
        """
        前向传播流程：动态权重生成→输入特征展开→张量加权→偏置融合（可选）→输出
        """
        # 步骤1：生成动态卷积权重
        # 位置映射输入权重网络：[1, posi_chans, h, w]→[1, k²×channels, h, w]
        weight = self.weight_layers(self.posi_map)
        # 权重维度重排：[1, k²×channels, h, w]→[1, channels, k², h, w]
        # 维度含义：[批次, 输入通道, 邻域权重数, 输出高度, 输出宽度]
        weight = weight.view(1, self.channels, self.TVConv_k_square, self.h, self.w)

        # 步骤2：展开输入特征（将每个像素的k×k邻域展开为k²长度向量）
        # Unfold操作：[B, channels, H, W]→[B, channels×k², H×W]（H×W为像素总数）
        # 维度重排：→[B, channels, k², H, W]（与权重维度对齐）
        out = self.unfold(x).view(x.shape[0], self.channels, self.TVConv_k_square, self.h, self.w)

        # 步骤3：张量加权（权重×展开特征）+ 邻域求和
        # 逐元素乘法：[B, channels, k², H, W] × [1, channels, k², H, W] → [B, channels, k², H, W]
        # 沿k²维度求和：融合邻域信息，得到最终卷积结果→[B, channels, H, W]
        out = (weight * out).sum(dim=2)

        # 步骤4：偏置融合（可选）
        if self.bias_layers is not None:
            # 从位置映射生成偏置：[1, posi_chans, h, w]→[1, channels, h, w]
            bias = self.bias_layers(self.posi_map)
            out = out + bias  # 偏置叠加

        return out


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    x = torch.randn(1, 64, 32, 32).to(device)

    model = TVConv(64, h=32, w=32)
    model.to(device)

    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("知乎、CSDN：十小大")
    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)