import torch
import torch.nn as nn
from pytorch_wavelets import DWTForward
import math


def autopad(k, p=None, d=1):  # kernel, padding, dilation
    """Pad to 'same' shape outputs."""
    if d > 1:
        k = d * (k - 1) + 1 if isinstance(k, int) else [d * (x - 1) + 1 for x in k]  # actual kernel-size
    if p is None:
        p = k // 2 if isinstance(k, int) else [x // 2 for x in k]  # auto-pad
    return p


class Conv(nn.Module):
    """Standard convolution with args(ch_in, ch_out, kernel, stride, padding, groups, dilation, activation)."""

    default_act = nn.SiLU()  # default activation

    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, d=1, act=True):
        """Initialize Conv layer with given arguments including activation."""
        super().__init__()
        self.conv = nn.Conv2d(c1, c2, k, s, autopad(k, p, d), groups=g, dilation=d, bias=False)
        self.bn = nn.BatchNorm2d(c2)
        self.act = self.default_act if act is True else act if isinstance(act, nn.Module) else nn.Identity()

    def forward(self, x):
        """Apply convolution, batch normalization and activation to input tensor."""
        return self.act(self.bn(self.conv(x)))

    def forward_fuse(self, x):
        """Perform transposed convolution of 2D data."""
        return self.act(self.conv(x))

class SEBlock(nn.Module):
    def __init__(self, channel, reduction=16):
        super(SEBlock, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(
            nn.Linear(channel, channel // reduction, bias=False),
            nn.ReLU(inplace=True),
            nn.Linear(channel // reduction, channel, bias=False),
            nn.Sigmoid()
        )

    def forward(self, x):
        b, c, _, _ = x.size()
        y = self.avg_pool(x).view(b, c)
        y = self.fc(y).view(b, c, 1, 1)
        return x * y

class FSConv(nn.Module):
    """
    频域-空域卷积模块（Frequency–Spatial Convolution, FSConv）
    功能：频域分解与空域卷积并行增强，实现频域-空域协同特征优化
    核心设计：
        - 通道拆分并行：将输入通道拆分为两路，分别用于空域增强与频域分解
        - 小波频域分解：Haar小波拆分低频（结构）与高频（细节）特征，分离处理
        - 频域-空域融合：高频特征与空域特征加权交互，低频特征单独增强，再聚合优化
        - 通道注意力筛选：SE模块强化融合后特征的关键通道，提升特征纯度
    Args:
        c1: 输入通道数
        c2: 输出通道数
        k: 卷积核大小（默认3）
        s: 步长（默认1）
        p: 填充量（默认None，自动计算）
        d: 膨胀率（默认1）
    """
    def __init__(self, c1, c2, k=3, s=1, p=None, d=1):
        super().__init__()
        self.c1 = c1

        self.conv1 = Conv(c1, 2 * c1, 1, g=c1)
        self.wt = DWTForward(J=1, mode='zero', wave='haar')
        self.conv2 = Conv(c1, c2, k, 2, g=c1)
        self.conv3 = Conv(c1 * 3, c2, 3, d=1, g=math.gcd(c1 * 3, c2))
        self.se = SEBlock(c2)
        self.conv4 = Conv(c1, c2, 3, g=c1)
        self.conv5 = Conv(2 * c2, c2, 1)

    def forward(self, x):
        x0 = self.conv1(x)
        x1, x2 = torch.split(x0, self.c1, dim=1)
        conv_spatial = self.conv2(x1)

        yL, yH = self.wt(x2)

        # Extract the high-frequency subbands
        y_HL = yH[0][:, :, 0, :]
        y_LH = yH[0][:, :, 1, :]
        y_HH = yH[0][:, :, 2, :]

        high_frequency_fused = torch.cat([y_HL, y_LH, y_HH], dim=1)
        high_frequency_fused_output = self.conv3(high_frequency_fused)

        # Apply SE attention
        high_frequency_fused_output = self.se(high_frequency_fused_output)

        low_frequency_fused_output = self.conv4(yL)

        spatial_output = conv_spatial * high_frequency_fused_output

        fused = torch.cat([spatial_output, low_frequency_fused_output], dim=1)
        out = self.conv5(fused)

        return out


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 64, 32, 32).to(device)
    model = FSConv(64, 64).to(device)

    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN、小红书：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)
