import torch
import torch.nn as nn


class ARConv(nn.Module):
    def __init__(self, inc, outc, kernel_size=3, padding=1, stride=1, l_max=9, w_max=9, flag=False, modulation=True):
        super(ARConv, self).__init__()
        # 1. 基础参数初始化：输入输出通道数、卷积核尺寸、步长等
        self.lmax = l_max  # 高度方向最大采样点数
        self.wmax = w_max  # 宽度方向最大采样点数
        self.inc = inc  # 输入特征图通道数
        self.outc = outc  # 输出特征图通道数
        self.kernel_size = kernel_size  # 基础卷积核尺寸
        self.padding = padding  # 零填充大小
        self.stride = stride  # 步长
        self.zero_padding = nn.ZeroPad2d(padding)  # 零填充层
        self.flag = flag  # 预留标志位（未使用）
        self.modulation = modulation  # 是否启用特征调制（默认启用）

        # 2. 候选卷积核配置：存储 (高度, 宽度) 组合（如 33→(3,3)、35→(3,5) 等）
        self.i_list = [33, 35, 53, 37, 73, 55, 57, 75, 77]
        # 生成候选卷积核列表：每个元素对应一种 (kh, kw) 的 Conv2d
        self.convs = nn.ModuleList(
            [
                nn.Conv2d(inc, outc, kernel_size=(i // 10, i % 10), stride=(i // 10, i % 10), padding=0)
                for i in self.i_list
            ]
        )

        # 3. 特征调制分支（M）：生成卷积核权重的调制系数（输出范围 [-1,1]，通过 Tanh 激活）
        self.m_conv = nn.Sequential(
            nn.Conv2d(inc, outc, kernel_size=3, padding=1, stride=stride),
            nn.LeakyReLU(),  # 非线性激活，缓解梯度消失
            nn.Dropout2d(0.3),  # 2D  dropout：防止过拟合
            nn.Conv2d(outc, outc, kernel_size=3, padding=1, stride=stride),
            nn.LeakyReLU(),
            nn.Dropout2d(0.3),
            nn.Conv2d(outc, outc, kernel_size=3, padding=1, stride=stride),
            nn.Tanh()  # 输出 [-1,1]，用于调制卷积结果
        )

        # 4. 偏置分支（B）：生成卷积结果的偏置项（无 Tanh，输出任意实数）
        self.b_conv = nn.Sequential(
            nn.Conv2d(inc, outc, kernel_size=3, padding=1, stride=stride),
            nn.LeakyReLU(),
            nn.Dropout2d(0.3),
            nn.Conv2d(outc, outc, kernel_size=3, padding=1, stride=stride),
            nn.LeakyReLU(),
            nn.Dropout2d(0.3),
            nn.Conv2d(outc, outc, kernel_size=3, padding=1, stride=stride)
        )

        # 5. 偏移量预测分支（P）：生成采样点偏移的基础特征
        self.p_conv = nn.Sequential(
            nn.Conv2d(inc, inc, kernel_size=3, padding=1, stride=stride),
            nn.BatchNorm2d(inc),  # 批量归一化：加速训练，稳定梯度
            nn.LeakyReLU(),
            nn.Dropout2d(0),  # 无 dropout：保留偏移量特征完整性
            nn.Conv2d(inc, inc, kernel_size=3, padding=1, stride=stride),
            nn.BatchNorm2d(inc),
            nn.LeakyReLU(),
        )

        # 6. 高度采样点数预测分支（L）：输出 [0,1] 归一化值，对应高度方向采样点数量
        self.l_conv = nn.Sequential(
            nn.Conv2d(inc, 1, kernel_size=3, padding=1, stride=stride),
            nn.BatchNorm2d(1),
            nn.LeakyReLU(),
            nn.Dropout2d(0),
            nn.Conv2d(1, 1, 1),  # 1x1 卷积：压缩通道数到 1
            nn.BatchNorm2d(1),
            nn.Sigmoid()  # 输出 [0,1]，用于计算高度采样点数
        )

        # 7. 宽度采样点数预测分支（W）：输出 [0,1] 归一化值，对应宽度方向采样点数量
        self.w_conv = nn.Sequential(
            nn.Conv2d(inc, 1, kernel_size=3, padding=1, stride=stride),
            nn.BatchNorm2d(1),
            nn.LeakyReLU(),
            nn.Dropout2d(0),
            nn.Conv2d(1, 1, 1),
            nn.BatchNorm2d(1),
            nn.Sigmoid()  # 输出 [0,1]，用于计算宽度采样点数
        )

        # 8. 正则化层：防止过拟合
        self.dropout1 = nn.Dropout(0.3)  # 1D dropout（未直接使用）
        self.dropout2 = nn.Dropout2d(0.3)  # 2D dropout：用于采样后特征

        # 9. 钩子函数：为关键层设置梯度缩放（降低 10 倍，稳定训练）
        self.hook_handles = []
        # 为 M/B/P/L/W 分支的前两层注册反向传播钩子
        for module in [self.m_conv[0], self.m_conv[1], self.b_conv[0], self.b_conv[1],
                       self.p_conv[0], self.p_conv[1], self.l_conv[0], self.l_conv[1],
                       self.w_conv[0], self.w_conv[1]]:
            self.hook_handles.append(module.register_full_backward_hook(self._set_lr))

        # 10. 预留采样点数参数：存储训练后期固定的 (N_X, N_Y)（高度/宽度采样点数）
        self.reserved_NXY = nn.Parameter(torch.tensor([3, 3], dtype=torch.int32), requires_grad=False)

    @staticmethod
    def _set_lr(module, grad_input, grad_output):
        # 反向传播时将梯度缩小 10 倍：防止关键分支梯度爆炸，稳定训练
        grad_input = tuple(g * 0.1 if g is not None else None for g in grad_input)
        grad_output = tuple(g * 0.1 if g is not None else None for g in grad_output)
        return grad_input
 
    def remove_hooks(self):
        for handle in self.hook_handles:
            handle.remove()  # 移除钩子函数
        self.hook_handles.clear()  # 清空句柄列表

    def forward(self, x, epoch, hw_range):
        # 输入校验：hw_range 需为 [h_min, h_max] 列表，定义采样点数范围
        assert isinstance(hw_range, list) and len(hw_range) == 2, "hw_range should be [h_min, h_max]"
        scale = hw_range[1] // 9  # 采样点数缩放系数（适配不同输入尺寸）
        if hw_range[0] == 1 and hw_range[1] == 3:
            scale = 1  # 特殊场景：强制缩放系数为 1

        # 1. 计算调制系数（m）、偏置（bias）、偏移量基础特征（offset）
        m = self.m_conv(x)  # 调制系数：(b, outc, h, w)
        bias = self.b_conv(x)  # 偏置项：(b, outc, h, w)
        offset = self.p_conv(x * 100)  # 偏移量特征：放大输入以增强细节

        # 2. 预测高度/宽度采样点数（L/W）：从 [0,1] 映射到 [1, hw_range[1]]
        l = self.l_conv(offset) * (hw_range[1] - 1) + 1  # (b, 1, h, w)：高度采样点预测值
        w = self.w_conv(offset) * (hw_range[1] - 1) + 1  # (b, 1, h, w)：宽度采样点预测值

        # 3. 动态确定采样点数（N_X: 高度方向，N_Y: 宽度方向）
        if epoch <= 100:
            # 训练前期（前 100 轮）：动态调整采样点数
            mean_l = l.mean(dim=0).mean(dim=1).mean(dim=1)  # 全局平均高度预测值
            mean_w = w.mean(dim=0).mean(dim=1).mean(dim=1)  # 全局平均宽度预测值
            N_X = int(mean_l // scale)  # 缩放后高度采样点数（整数）
            N_Y = int(mean_w // scale)  # 缩放后宽度采样点数（整数）

            # 辅助函数：确保采样点数为奇数（适配对称卷积核）
            def phi(x):
                if x % 2 == 0:
                    x -= 1  # 偶数→奇数（如 4→3）
                return x

            N_X, N_Y = phi(N_X), phi(N_Y)  # 转为奇数
            N_X, N_Y = max(N_X, 3), max(N_Y, 3)  # 最小采样点数：3（避免核过小）
            N_X, N_Y = min(N_X, 7), min(N_Y, 7)  # 最大采样点数：7（避免核过大）

            # 第 100 轮：固定采样点数（训练后期不再调整）
            if epoch == 100:
                self.reserved_NXY = nn.Parameter(
                    torch.tensor([N_X, N_Y], dtype=torch.int32, device=x.device),
                    requires_grad=False
                )
        else:
            # 训练后期（>100 轮）：使用固定的采样点数
            N_X = self.reserved_NXY[0]
            N_Y = self.reserved_NXY[1]

        N = N_X * N_Y  # 单像素总采样点数（卷积核总大小）
        # 扩展 L/W 维度：匹配采样点数（从 1 通道→N 通道）
        l = l.repeat([1, N, 1, 1])
        w = w.repeat([1, N, 1, 1])
        offset = torch.cat((l, w), dim=1)  # 合并偏移量：(b, 2*N, h, w)（2 对应 x/y 方向）

        # 4. 零填充：确保采样不越界
        dtype = offset.data.type()
        if self.padding:
            x = self.zero_padding(x)

        # 5. 计算采样点坐标（p）：基于偏移量生成动态采样位置
        p = self._get_p(offset, dtype, N_X, N_Y)  # (b, 2*N, h, w)
        p = p.contiguous().permute(0, 2, 3, 1)  # 维度重排：(b, h, w, 2*N)（适配后续索引）

        # 6. 双线性插值：处理采样点非整数坐标（4 个邻域点加权）
        # 计算 4 个邻域点的整数坐标（q_lt: 左上，q_rb: 右下，q_lb: 左下，q_rt: 右上）
        q_lt = p.detach().floor()  # 向下取整
        q_rb = q_lt + 1  # 向上取整
        # 坐标裁剪：确保在特征图范围内（0 ≤ x < H, 0 ≤ y < W）
        q_lt = torch.cat(
            [torch.clamp(q_lt[..., :N], 0, x.size(2) - 1),
             torch.clamp(q_lt[..., N:], 0, x.size(3) - 1)],
            dim=-1
        ).long()
        q_rb = torch.cat(
            [torch.clamp(q_rb[..., :N], 0, x.size(2) - 1),
             torch.clamp(q_rb[..., N:], 0, x.size(3) - 1)],
            dim=-1
        ).long()
        q_lb = torch.cat([q_lt[..., :N], q_rb[..., N:]], dim=-1)  # 左下：(x_lt, y_rb)
        q_rt = torch.cat([q_rb[..., :N], q_lt[..., N:]], dim=-1)  # 右上：(x_rb, y_lt)

        # 7. 计算插值权重（基于采样点与邻域点的距离）
        g_lt = (1 + (q_lt[..., :N].type_as(p) - p[..., :N])) * (1 + (q_lt[..., N:].type_as(p) - p[..., N:]))
        g_rb = (1 - (q_rb[..., :N].type_as(p) - p[..., :N])) * (1 - (q_rb[..., N:].type_as(p) - p[..., N:]))
        g_lb = (1 + (q_lb[..., :N].type_as(p) - p[..., :N])) * (1 - (q_lb[..., N:].type_as(p) - p[..., N:]))
        g_rt = (1 - (q_rt[..., :N].type_as(p) - p[..., :N])) * (1 + (q_rt[..., N:].type_as(p) - p[..., N:]))

        # 8. 提取邻域点特征并加权求和（双线性插值核心）
        x_q_lt = self._get_x_q(x, q_lt, N)  # 左上点特征：(b, c, h, w, N)
        x_q_rb = self._get_x_q(x, q_rb, N)  # 右下点特征
        x_q_lb = self._get_x_q(x, q_lb, N)  # 左下点特征
        x_q_rt = self._get_x_q(x, q_rt, N)  # 右上点特征
        # 加权合并：得到动态采样后的特征
        x_offset = g_lt.unsqueeze(dim=1) * x_q_lt + g_rb.unsqueeze(dim=1) * x_q_rb + g_lb.unsqueeze(
            dim=1) * x_q_lb + g_rt.unsqueeze(dim=1) * x_q_rt

        # 9. 特征重排与卷积：适配候选卷积核尺寸
        x_offset = self._reshape_x_offset(x_offset, N_X, N_Y)  # 重排为 (b, inc, h*N_X, w*N_Y)
        x_offset = self.dropout2(x_offset)  # 正则化
        # 选择匹配 (N_X, N_Y) 的卷积核进行卷积
        x_offset = self.convs[self.i_list.index(N_X * 10 + N_Y)](x_offset)

        # 10. 最终输出：调制系数 * 卷积结果 + 偏置
        out = x_offset * m + bias
        return out

    def _get_p_n(self, N, dtype, n_x, n_y):
        # 生成卷积核的基础采样网格（对称分布，如 3x3 核：[-1,0,1]×[-1,0,1]）
        p_n_x, p_n_y = torch.meshgrid(
            torch.arange(-(n_x - 1) // 2, (n_x - 1) // 2 + 1),
            torch.arange(-(n_y - 1) // 2, (n_y - 1) // 2 + 1),
        )
        p_n = torch.cat([torch.flatten(p_n_x), torch.flatten(p_n_y)], 0)  # 展平为 2*N 向量
        p_n = p_n.view(1, 2 * N, 1, 1).type(dtype)  # 适配批量维度：(1, 2*N, 1, 1)
        return p_n

    def _get_p_0(self, h, w, N, dtype):
        # 生成特征图的基础采样坐标（步长对齐，如 stride=1 时为每个像素位置）
        p_0_x, p_0_y = torch.meshgrid(
            torch.arange(1, h * self.stride + 1, self.stride),
            torch.arange(1, w * self.stride + 1, self.stride),
        )
        # 扩展维度以匹配采样点数 N
        p_0_x = torch.flatten(p_0_x).view(1, 1, h, w).repeat(1, N, 1, 1)
        p_0_y = torch.flatten(p_0_y).view(1, 1, h, w).repeat(1, N, 1, 1)
        p_0 = torch.cat([p_0_x, p_0_y], 1).type(dtype)  # 合并为 (1, 2*N, h, w)
        return p_0

    def _get_p(self, offset, dtype, n_x, n_y):
        # 计算最终采样坐标：基础坐标 + 偏移量（适配卷积核尺寸）
        N, h, w = offset.size(1) // 2, offset.size(2), offset.size(3)
        L, W = offset.split([N, N], dim=1)  # 拆分高度/宽度偏移量
        L = L / n_x  # 高度偏移量归一化（适配核尺寸）
        W = W / n_y  # 宽度偏移量归一化
        offsett = torch.cat([L, W], dim=1)  # 合并偏移量
        p_n = self._get_p_n(N, dtype, n_x, n_y).repeat([1, 1, h, w])  # 扩展基础网格
        p_0 = self._get_p_0(h, w, N, dtype)  # 基础坐标
        p = p_0 + offsett * p_n  # 最终采样坐标：动态调整
        return p

    def _get_x_q(self, x, q, N):
        # 根据坐标 q 提取特征图 x 中的对应像素
        b, h, w, _ = q.size()
        padded_w = x.size(3)  # 填充后的宽度（用于计算索引）
        c = x.size(1)  # 输入通道数
        x = x.contiguous().view(b, c, -1)  # 展平为 (b, c, h*w)
        # 计算索引：将 2D 坐标 (x,y) 转为 1D 索引（x*w + y）
        index = q[..., :N] * padded_w + q[..., N:]
        # 扩展索引维度以匹配输入通道数
        index = index.contiguous().unsqueeze(dim=1).expand(-1, c, -1, -1, -1).contiguous().view(b, c, -1)
        # 提取特征：(b, c, h*w*N) → 重排为 (b, c, h, w, N)
        x_offset = x.gather(dim=-1, index=index).contiguous().view(b, c, h, w, N)
        return x_offset

    @staticmethod
    def _reshape_x_offset(x_offset, n_x, n_y):
        # 重排采样后的特征：从 (b, c, h, w, N) 转为 (b, c, h*n_x, w*n_y)（适配卷积核）
        b, c, h, w, N = x_offset.size()
        # 按宽度方向拆分并合并（如 3x3 核：将 N=9 拆分为 3 组，每组 3 个宽度像素）
        x_offset = torch.cat([x_offset[..., s:s + n_y].contiguous().view(b, c, h, w * n_y) for s in range(0, N, n_y)],
                             dim=-1)
        x_offset = x_offset.contiguous().view(b, c, h * n_x, w * n_y)  # 合并高度维度
        return x_offset

if __name__ == '__main__':
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    x = torch.randn(1, 64, 64, 64).to(device)
    arconv = ARConv(64, 64).to(device)

    # 探索长宽的轮数 epoch
    # ARConv 中卷积核长宽所能变化的范围
    y = arconv(x, 100, [1, 18])

    print("微信公众号：十小大的底层视觉工坊")
    print("知乎、CSDN：十小大")
    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)
