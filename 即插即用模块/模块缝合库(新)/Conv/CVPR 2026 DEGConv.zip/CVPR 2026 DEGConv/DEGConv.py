# 方向引导边缘门控卷积模块（Direction-guided Edge Gated Convolution, DEGConv）
# 核心设计：基于“补丁划分+边缘特征提取+方向门控调制”的流程，
# 通过2×2补丁划分扩展感受野，水平/垂直双分支卷积捕捉方向依赖，
# 边缘特征引导门控动态调制卷积输出，强化目标边缘与结构细节，提升特征的方向辨识度与结构完整性


import torch
import torch.nn as nn
import torch.nn.functional as F
import einops


def image2patches(x):
    """b c (hg h) (wg w) -> (hg wg b) c h w"""
    x = einops.rearrange(x, 'b c (hg h) (wg w) -> (hg wg b) c h w', hg=2, wg=2)
    return x


def patches2image(x):
    """(hg wg b) c h w -> b c (hg h) (wg w)"""
    x = einops.rearrange(x, '(hg wg b) c h w -> b c (hg h) (wg w)', hg=2, wg=2)
    return x


class EdgeConv(nn.Module):
    """
    边缘卷积模块：DEGConv的核心组件，负责方向特征提取与边缘门控调制
    核心设计：
        - 输入投影：1×1卷积降维，降低后续计算成本
        - 方向分支卷积：水平(1×k) + 垂直(k×1)深度卷积，分别捕捉水平/垂直方向依赖
        - 边缘门控：基于输入特征生成边缘掩码，动态调制双分支卷积输出
        - 输出投影：融合双分支特征，还原目标通道数
    Args:
        in_channels: 输入通道数
        mid_channels: 中间通道数（输入投影后的维度）
        out_channels: 输出通道数
        kernel_size: 方向卷积核尺寸（默认3，水平为1×3，垂直为3×1）
        bias: 卷积层是否带偏置（默认True）
    """
    def __init__(self,
                 in_channels,
                 mid_channels,
                 out_channels,
                 kernel_size=3,
                 bias=True):
        super().__init__()

        self.in_proj = nn.Conv2d(
            in_channels=in_channels,
            out_channels=mid_channels,
            kernel_size=1,
            bias=bias)
        self.w_conv = nn.Conv2d(
            mid_channels,
            mid_channels,
            kernel_size=(1, kernel_size),
            stride=1,
            padding=(0, kernel_size // 2),
            groups=mid_channels)

        self.h_conv = nn.Conv2d(
            mid_channels,
            mid_channels,
            kernel_size=(kernel_size, 1),
            stride=1,
            padding=(kernel_size // 2, 0),
            groups=mid_channels
        )

        self.out_proj = nn.Conv2d(
            in_channels=mid_channels * 2,
            out_channels=out_channels,
            kernel_size=1,
            bias=True
        )

    def forward(self, x):
        x = self.in_proj(x)
        x_w = self.w_conv(x)
        x_h = self.h_conv(x)
        x = torch.cat([x_w, x_h], dim=1)
        x = self.out_proj(x)
        return x


class DEGConv(nn.Module):
    """
    方向引导边缘门控卷积模块（Direction-guided Edge Gated Convolution, DEGConv）
    功能：补丁划分扩展感受野+方向卷积+边缘门控，强化结构细节与方向依赖
    核心设计：
        - 2×2补丁划分：将特征图拆分为4个补丁，间接扩展感受野（相当于增大卷积核）
        - 边缘卷积集成：每个补丁经EdgeConv提取方向+边缘特征
        - 补丁还原融合：重组补丁为原始尺寸，保留全局结构完整性
    Args:
        in_channels: 输入通道数
        out_channels: 输出通道数（默认与输入通道数一致）
        mid_channels: 中间通道数（默认输入通道数//2，平衡效率与性能）
        kernel_size: 方向卷积核尺寸（默认3）
        bias: 卷积层是否带偏置（默认True）
    """
    def __init__(self,
                 in_dim,
                 nbins,
                 cell_size=(8, 8)):
        super().__init__()

        self.nbins = nbins
        self.cell_size = cell_size

        self.hog_feat = nn.Sequential(
            nn.Conv2d(nbins, in_dim, kernel_size=1),
            nn.Conv2d(in_dim, in_dim, kernel_size=3, padding=1, groups=in_dim, bias=False),
            nn.GroupNorm(in_dim // 8, in_dim),
            nn.ReLU(inplace=True),
            nn.AdaptiveAvgPool2d((1, 1))
        )

        self.weight = nn.Sequential(
            EdgeConv(in_channels=in_dim, mid_channels=in_dim // 2, out_channels=in_dim),
            nn.GroupNorm(in_dim // 8, in_dim)
        )

        self.conv = nn.Sequential(
            nn.Conv2d(in_channels=in_dim, out_channels=in_dim, kernel_size=1, stride=1),
            nn.GroupNorm(in_dim // 8, in_dim)
        )

        self.fuse_block = nn.Sequential(
            EdgeConv(in_channels=in_dim, mid_channels=in_dim // 2, out_channels=in_dim, kernel_size=3),
            nn.GroupNorm(in_dim // 8, in_dim)
        )

        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        residual = x

        x = image2patches(x)

        x_hog = self.get_hog_feature(x)
        x_hog = self.hog_feat(x_hog)

        x1 = self.sigmoid(self.weight(x + x_hog))
        x2 = self.conv(x)
        x = x1 * x2

        x = patches2image(x)

        x = x + residual
        x = self.fuse_block(x)

        return x

    def get_hog_feature(self, x):
        x_mean = x.mean(dim=1, keepdim=True)
        B, _, H, W = x_mean.shape
        device = x_mean.device

        sobel_x = torch.tensor([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]],
                               dtype=torch.float32).view(1, 1, 3, 3).to(device)
        sobel_y = torch.tensor([[-1, -2, -1], [0, 0, 0], [1, 2, 1]],
                               dtype=torch.float32).view(1, 1, 3, 3).to(device)
        dx = F.conv2d(x_mean.float(), sobel_x, padding=1)  # b, 1, h, w
        dy = F.conv2d(x_mean.float(), sobel_y, padding=1)

        # direction
        gradient_dir = torch.atan2(dy, dx)  # [-π，π]
        gradient_dir = torch.abs(gradient_dir)  # [0，π]

        # cells
        cell_h, cell_w = self.cell_size
        H_cells = int(H / cell_h)
        W_cells = int(W / cell_w)

        #
        dirs_crop = gradient_dir[:, :, :H_cells * cell_h, :W_cells * cell_w]

        # [B, H_cells, W_cells, cell_h*cell*w]
        dirs = dirs_crop.view(B, H_cells, W_cells, -1)

        bin_with = torch.pi / self.nbins
        bin_indices = (dirs / bin_with).floor().long()
        bin_indices = torch.clamp(bin_indices, 0, self.nbins - 1)

        bin_indices_flat = bin_indices.view(B * H_cells * W_cells, dirs.shape[-1])
        weight = []
        for i in range(bin_indices_flat.shape[0]):
            bins = bin_indices_flat[i]
            count = torch.bincount(bins, minlength=self.nbins)
            weight.append(count)

        weight = torch.stack(weight, dim=0).view(B, H_cells, W_cells, -1) / 64  # B, H_cells , W_cells, self.bins

        start = torch.pi / (2 * self.nbins)
        hog_feature = torch.linspace(start, torch.pi - start, self.nbins).to(device).repeat(B, H_cells, W_cells,
                                                                                            1) * weight

        return hog_feature.permute(0, 3, 1, 2)



if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 64, 32, 32).to(device)
    model = DEGConv(64,90).to(device)

    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("小红书：十小大，主页获取往期全部即插即用代码，200+大合集")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)