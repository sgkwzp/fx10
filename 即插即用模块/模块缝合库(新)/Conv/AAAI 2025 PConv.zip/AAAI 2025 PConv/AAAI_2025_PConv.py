import torch
import torch.nn as nn


def autopad(k, p=None, d=1):  # kernel, padding, dilation
    """
    自动计算padding函数：确保卷积后输出特征图尺寸与输入一致（"same" padding）
    参数：
        k: 卷积核大小（int或列表，如3或[3,3]）
        p: 手动指定的padding（默认None，自动计算）
        d: 卷积扩张率（默认1，扩张卷积时需调整有效核大小）
    返回：
        p: 计算后的padding（int或列表，与k维度匹配）
    """
    if d > 1:
        # 扩张卷积时，计算有效核大小（dilation*(k-1)+1）
        k = d * (k - 1) + 1 if isinstance(k, int) else [d * (x - 1) + 1 for x in k]
    if p is None:
        # 自动padding：核大小//2（确保same输出）
        p = k // 2 if isinstance(k, int) else [x // 2 for x in k]
    return p


class Conv(nn.Module):
    """
    标准卷积块：卷积+批归一化（BN）+激活函数，为PConv提供基础特征提取能力
    核心作用：标准化卷积流程，支持分组卷积、扩张卷积，适配PConv的定向特征提取需求
    输入：特征图 [B, c1, H, W]（B=批次，c1=输入通道，H/W=高/宽）
    输出：增强后特征 [B, c2, H', W']（H'/W'由卷积步长决定，默认same尺寸）
    """
    default_act = nn.SiLU()  # 默认激活函数（SiLU，适配轻量化任务）

    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, d=1, act=True):
        """
        参数初始化：
            c1: 输入通道数
            c2: 输出通道数
            k: 卷积核大小（默认1×1）
            s: 卷积步长（默认1）
            p: padding（默认None，自动计算）
            g: 分组数（默认1，=c1时为深度可分离卷积）
            d: 扩张率（默认1）
            act: 激活函数（True=默认SiLU，False=无激活，或指定自定义激活）
        """
        super().__init__()
        # 卷积层：支持分组、扩张，无偏置（BN已包含偏置功能）
        self.conv = nn.Conv2d(c1, c2, k, s, autopad(k, p, d), groups=g, dilation=d, bias=False)
        # 批归一化：稳定训练，加速收敛
        self.bn = nn.BatchNorm2d(c2)
        # 激活函数：根据参数选择默认SiLU、自定义激活或无激活
        self.act = self.default_act if act is True else act if isinstance(act, nn.Module) else nn.Identity()

    def forward(self, x):
        """标准前向传播：卷积→BN→激活"""
        return self.act(self.bn(self.conv(x)))

    def forward_fuse(self, x):
        """融合前向传播：跳过BN（推理阶段可选，用于加速）"""
        return self.act(self.conv(x))


class PConv(nn.Module):
    '''
    风车形卷积（PConv）：基于非对称padding实现定向特征提取，模拟"风车"式感受野
    核心创新：
        1. 非对称padding：4个方向的定向padding，聚焦不同方位的局部特征；
        2. 定向卷积：水平（(k,1)）与垂直（(1,k)）卷积结合，捕捉多方向关联；
        3. 特征融合：4路定向特征拼接后再卷积，增强全局关联性；
        4. 轻量化设计：无额外参数冗余，计算量与传统k×k卷积相当。
    输入：特征图 [B, c1, H, W]
    输出：融合后特征 [B, c2, H, W]（与输入空间尺寸一致）
    '''

    def __init__(self, c1, c2, k, s):
        """
        参数初始化：
            c1: 输入通道数
            c2: 输出通道数（需为4的倍数，4路特征各占c2//4）
            k: 定向卷积核的长度（如3，对应(1,3)或(3,1)核）
            s: 卷积步长（默认1，确保输出尺寸与输入一致）
        """
        super().__init__()
        # 4个方向的非对称padding配置：(left, right, top, bottom)
        # 分别对应：右侧padding、左侧padding、下侧padding、上侧padding
        p = [(k, 0, 1, 0), (0, k, 0, 1), (0, 1, k, 0), (1, 0, 0, k)]
        # 生成4个方向的ZeroPadding2d模块（每路特征对应1个padding）
        self.pad = [nn.ZeroPad2d(padding=(p[g])) for g in range(4)]

        # 垂直方向卷积（(1,k)核）：处理水平方向的局部关联（如图像的水平边缘）
        # 输出通道数：c2//4（4路特征之一），无padding（已通过非对称padding确保same输出）
        self.cw = Conv(c1, c2 // 4, (1, k), s=s, p=0)

        # 水平方向卷积（(k,1)核）：处理垂直方向的局部关联（如图像的垂直边缘）
        self.ch = Conv(c1, c2 // 4, (k, 1), s=s, p=0)

        # 特征融合卷积：2×2核融合4路拼接特征，增强全局关联性
        self.cat = Conv(c2, c2, 2, s=1, p=0)

    def forward(self, x):
        """
        前向传播流程：4路定向特征提取→特征拼接→融合卷积
        """
        # 路1：右侧padding（k个像素）+ 垂直卷积（(1,k)）→ 捕捉左侧特征关联
        yw0 = self.cw(self.pad[0](x))
        # 路2：左侧padding（k个像素）+ 垂直卷积（(1,k)）→ 捕捉右侧特征关联
        yw1 = self.cw(self.pad[1](x))
        # 路3：下侧padding（k个像素）+ 水平卷积（(k,1)）→ 捕捉上侧特征关联
        yh0 = self.ch(self.pad[2](x))
        # 路4：上侧padding（k个像素）+ 水平卷积（(k,1)）→ 捕捉下侧特征关联
        yh1 = self.ch(self.pad[3](x))

        # 特征拼接：4路特征沿通道维度拼接→[B, c2//4×4, H, W] = [B, c2, H, W]
        # 融合卷积：2×2核融合4路特征，增强全局关联性→[B, c2, H, W]
        return self.cat(torch.cat([yw0, yw1, yh0, yh1], dim=1))


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    x = torch.randn(1, 64, 32, 32).to(device)

    model = PConv(c1=64, c2=64, k=3, s=1)
    model.to(device)

    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("知乎、CSDN：十小大")
    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)