import math
import torch
from torch import nn
from einops.layers.torch import Rearrange


class Conv2d_cd(nn.Module):
    """中心差异卷积（Central Difference Convolution）
    功能：通过增强卷积核中心与周边像素的权重差异，强化对图像中心区域细节（如小尺度边缘、纹理）的捕捉
    核心逻辑：
        - 基于普通3x3卷积核，保持周边8个位置权重不变
        - 调整中心位置（第5个元素，索引4）权重：中心权重 = 原中心权重 - 周边8个权重之和
        - 使卷积核对“中心像素与周边像素的差异”更敏感，突出局部细节
    参数：
        in_channels: 输入特征图通道数
        out_channels: 输出特征图通道数
        kernel_size: 卷积核大小（默认3，固定为3x3以匹配差异卷积逻辑）
        stride: 卷积步长（默认1）
        padding: 填充大小（默认1，保证输入输出尺寸一致）
        dilation: 膨胀率（默认1，控制感受野）
        groups: 分组卷积数（默认1，1为普通卷积，>1为深度可分离卷积）
        bias: 是否使用偏置（默认False）
        theta: 权重调整系数（默认1.0，当前版本未实际使用，预留扩展接口）
    输入：x (Tensor) - 形状 [B, in_channels, H, W]（B=批量，H=高度，W=宽度）
    输出：通过get_weight()返回调整后的卷积核与偏置，供后续融合使用
    """

    def __init__(self, in_channels, out_channels, kernel_size=3, stride=1,
                 padding=1, dilation=1, groups=1, bias=False, theta=1.0):
        super(Conv2d_cd, self).__init__()
        # 基础普通卷积（用于初始化权重）
        self.conv = nn.Conv2d(in_channels, out_channels, kernel_size=kernel_size, stride=stride,
                              padding=padding, dilation=dilation, groups=groups, bias=bias)
        self.theta = theta  # 预留系数，当前未参与计算

    def get_weight(self):
        conv_weight = self.conv.weight  # 获取基础卷积核（形状：[in_channels, out_channels, k1, k2]）
        conv_shape = conv_weight.shape  # 保存卷积核原始形状

        # 步骤1：将卷积核从 [c_in, c_out, k1, k2] 展平为 [c_in, c_out, k1*k2]（便于调整权重）
        conv_weight = Rearrange('c_in c_out k1 k2 -> c_in c_out (k1 k2)')(conv_weight)

        # 步骤2：初始化CDC卷积核（全0），尺寸与原始卷积核一致
        conv_weight_cd = torch.cuda.FloatTensor(conv_shape[0], conv_shape[1], 3 * 3).fill_(0)
        # 复制原始卷积核的所有权重（先继承普通卷积的基础特征提取能力）
        conv_weight_cd[:, :, :] = conv_weight[:, :, :]
        # 核心调整：修改中心位置（索引4，对应3x3卷积核的中心）权重
        # 逻辑：中心权重 = 原中心权重 - 周边8个位置权重之和，增强中心与周边的差异敏感性
        conv_weight_cd[:, :, 4] = conv_weight[:, :, 4] - conv_weight[:, :, :].sum(2)

        # 步骤3：将展平的卷积核恢复为原始4维形状 [c_in, c_out, k1, k2]
        conv_weight_cd = Rearrange('c_in c_out (k1 k2) -> c_in c_out k1 k2',
                                   k1=conv_shape[2], k2=conv_shape[3])(conv_weight_cd)

        # 返回调整后的卷积核和偏置（偏置直接沿用基础卷积的偏置）
        return conv_weight_cd, self.conv.bias


class Conv2d_ad(nn.Module):
    """角度差异卷积（Angular Difference Convolution）
    功能：通过对卷积核权重进行“角度对称反转”并加权，强化对图像中“斜向边缘”（如45°、135°）的捕捉
    核心逻辑：
        - 定义3x3卷积核的“角度对称位置”（如左上角与右下角、右上角与左下角等）
        - 新权重 = 原权重 - theta * 对称位置权重，突出斜向像素的差异
    参数：与Conv2d_cd一致，theta为对称权重的调整系数（默认1.0）
    """

    def __init__(self, in_channels, out_channels, kernel_size=3, stride=1,
                 padding=1, dilation=1, groups=1, bias=False, theta=1.0):
        super(Conv2d_ad, self).__init__()
        self.conv = nn.Conv2d(in_channels, out_channels, kernel_size=kernel_size, stride=stride,
                              padding=padding, dilation=dilation, groups=groups, bias=bias)
        self.theta = theta  # 对称权重的衰减系数

    def get_weight(self):
        conv_weight = self.conv.weight
        conv_shape = conv_weight.shape

        # 展平卷积核为 [c_in, c_out, k1*k2]
        conv_weight = Rearrange('c_in c_out k1 k2 -> c_in c_out (k1 k2)')(conv_weight)

        # 核心调整：角度对称位置权重计算
        # 3x3卷积核索引对应（按行展开）：
        # 0(左上) 1(上) 2(右上)
        # 3(左)   4(中) 5(右)
        # 6(左下) 7(下) 8(右下)
        # 对称规则：[0,1,2,3,4,5,6,7,8] ↔ [3,0,1,6,4,2,7,8,5]（斜向对称映射）
        conv_weight_ad = conv_weight - self.theta * conv_weight[:, :, [3, 0, 1, 6, 4, 2, 7, 8, 5]]

        # 恢复卷积核为4维形状
        conv_weight_ad = Rearrange('c_in c_out (k1 k2) -> c_in c_out k1 k2',
                                   k1=conv_shape[2], k2=conv_shape[3])(conv_weight_ad)

        return conv_weight_ad, self.conv.bias


class Conv2d_rd(nn.Module):
    """径向差异卷积（Radial Difference Convolution）
    功能：通过5x5卷积核捕捉“径向距离相关的差异”（如从中心到周边的像素梯度变化），扩大感受野并强化全局细节
    核心逻辑：
        - 将3x3基础卷积核的权重重新分配到5x5卷积核的“径向位置”（中心、近邻、远邻）
        - 近邻位置权重为正，远邻位置权重为负，形成“中心-近邻-远邻”的梯度差异，突出径向细节
    特殊设计：
        - 当theta=0时，退化为普通3x3卷积（避免极端参数下性能下降）
        - padding=2（5x5卷积保持输入输出尺寸一致的必要填充）
    """

    def __init__(self, in_channels, out_channels, kernel_size=3, stride=1,
                 padding=2, dilation=1, groups=1, bias=False, theta=1.0):
        super(Conv2d_rd, self).__init__()
        self.conv = nn.Conv2d(in_channels, out_channels, kernel_size=kernel_size, stride=stride,
                              padding=padding, dilation=dilation, groups=groups, bias=bias)
        self.theta = theta  # 远邻位置权重的衰减系数

    def forward(self, x):
        # 当theta=0时，直接返回普通卷积结果（退化模式，保证鲁棒性）
        if math.fabs(self.theta - 0.0) < 1e-8:
            out_normal = self.conv(x)
            return out_normal
        else:
            conv_weight = self.conv.weight  # 基础3x3卷积核
            conv_shape = conv_weight.shape  # [c_in, c_out, 3, 3]

            # 初始化5x5的RDC卷积核（根据输入设备分配CPU/GPU内存）
            if conv_weight.is_cuda:
                conv_weight_rd = torch.cuda.FloatTensor(conv_shape[0], conv_shape[1], 5 * 5).fill_(0)
            else:
                conv_weight_rd = torch.zeros(conv_shape[0], conv_shape[1], 5 * 5)

            # 展平3x3卷积核为 [c_in, c_out, 9]
            conv_weight = Rearrange('c_in c_out k1 k2 -> c_in c_out (k1 k2)')(conv_weight)

            # 核心调整：将3x3权重分配到5x5卷积核的径向位置
            # 5x5卷积核索引（按行展开）对应的径向角色：
            # 0(左上远邻) 1(上远邻) 2(右上远邻) 3(左远邻) 4(右远邻)
            # 5(左下远邻) 6(左近邻) 7(中近邻) 8(右近邻) 9(下远邻)
            # 10(中心) 11(左中近邻) 12(中心) 13(右中近邻) 14(下中近邻)
            # 15(...) 16(左下近邻) 17(下近邻) 18(右下近邻) 19(...)
            # 简化逻辑：近邻位置（索引6-8,11,13,16-18）用原权重，远邻位置（索引0-2,4,5,9,15,19）用-theta*原权重
            conv_weight_rd[:, :, [0, 2, 4, 10, 14, 20, 22, 24]] = conv_weight[:, :, 1:]  # 近邻位置（正权重）
            conv_weight_rd[:, :, [6, 7, 8, 11, 13, 16, 17, 18]] = -conv_weight[:, :, 1:] * self.theta  # 远邻位置（负权重）
            conv_weight_rd[:, :, 12] = conv_weight[:, :, 0] * (1 - self.theta)  # 中心位置（平衡权重）

            # 恢复5x5卷积核为4维形状 [c_in, c_out, 5, 5]
            conv_weight_rd = conv_weight_rd.view(conv_shape[0], conv_shape[1], 5, 5)

            # 用调整后的5x5卷积核进行前向计算
            out_diff = nn.functional.conv2d(input=x, weight=conv_weight_rd, bias=self.conv.bias,
                                            stride=self.conv.stride, padding=self.conv.padding,
                                            groups=self.conv.groups)
            return out_diff


class Conv2d_hd(nn.Module):
    """水平差异卷积（Horizontal Difference Convolution）
    功能：通过对卷积核“水平方向”权重进行正负交替，强化对图像中“水平边缘”（如地平线、文字横线）的捕捉
    核心逻辑：
        - 基于1x3水平卷积核（仅关注水平方向像素），扩展为3x3卷积核
        - 水平左半部分（列0）权重为正，右半部分（列2）权重为负，中间列（列1）为0，形成水平梯度差异
    注意：基础卷积使用nn.Conv1d（仅处理水平方向），最终输出3x3卷积核
    """

    def __init__(self, in_channels, out_channels, kernel_size=3, stride=1,
                 padding=1, dilation=1, groups=1, bias=False, theta=1.0):
        super(Conv2d_hd, self).__init__()
        # 基础1x3水平卷积（仅捕捉水平方向特征）
        self.conv = nn.Conv1d(in_channels, out_channels, kernel_size=kernel_size, stride=stride,
                              padding=padding, dilation=dilation, groups=groups, bias=bias)

    def get_weight(self):
        conv_weight = self.conv.weight  # 1x3卷积核（形状：[c_in, c_out, 3]）
        conv_shape = conv_weight.shape  # [c_in, c_out, 3]

        # 初始化3x3的HDC卷积核（全0）
        conv_weight_hd = torch.cuda.FloatTensor(conv_shape[0], conv_shape[1], 3 * 3).fill_(0)
        # 核心调整：水平方向权重分配
        # 3x3卷积核列索引0（左列）：复制1x3卷积核权重（正权重，捕捉左半水平特征）
        conv_weight_hd[:, :, [0, 3, 6]] = conv_weight[:, :, :]
        # 3x3卷积核列索引2（右列）：复制1x3卷积核权重并取负（负权重，捕捉右半水平特征）
        conv_weight_hd[:, :, [2, 5, 8]] = -conv_weight[:, :, :]
        # 列索引1（中间列）保持0，形成水平方向的正负梯度

        # 恢复3x3卷积核为4维形状 [c_in, c_out, 3, 3]
        conv_weight_hd = Rearrange('c_in c_out (k1 k2) -> c_in c_out k1 k2',
                                   k1=conv_shape[2], k2=conv_shape[2])(conv_weight_hd)

        return conv_weight_hd, self.conv.bias


class Conv2d_vd(nn.Module):
    """垂直差异卷积（Vertical Difference Convolution）
    功能：通过对卷积核“垂直方向”权重进行正负交替，强化对图像中“垂直边缘”（如建筑立柱、文字竖线）的捕捉
    核心逻辑：
        - 基于1x3垂直卷积核（仅关注垂直方向像素），扩展为3x3卷积核
        - 垂直上半部分（行0）权重为正，下半部分（行2）权重为负，中间行（行1）为0，形成垂直梯度差异
    与HDC的区别：HDC关注水平方向，VDC关注垂直方向，互补捕捉横竖边缘
    """

    def __init__(self, in_channels, out_channels, kernel_size=3, stride=1,
                 padding=1, dilation=1, groups=1, bias=False):
        super(Conv2d_vd, self).__init__()
        # 基础1x3垂直卷积（仅捕捉垂直方向特征）
        self.conv = nn.Conv1d(in_channels, out_channels, kernel_size=kernel_size, stride=stride,
                              padding=padding, dilation=dilation, groups=groups, bias=bias)

    def get_weight(self):
        conv_weight = self.conv.weight  # 1x3卷积核（形状：[c_in, c_out, 3]）
        conv_shape = conv_weight.shape  # [c_in, c_out, 3]

        # 初始化3x3的VDC卷积核（全0）
        conv_weight_vd = torch.cuda.FloatTensor(conv_shape[0], conv_shape[1], 3 * 3).fill_(0)
        # 核心调整：垂直方向权重分配
        # 3x3卷积核行索引0（上行）：复制1x3卷积核权重（正权重，捕捉上半垂直特征）
        conv_weight_vd[:, :, [0, 1, 2]] = conv_weight[:, :, :]
        # 3x3卷积核行索引2（下行）：复制1x3卷积核权重并取负（负权重，捕捉下半垂直特征）
        conv_weight_vd[:, :, [6, 7, 8]] = -conv_weight[:, :, :]
        # 行索引1（中间行）保持0，形成垂直方向的正负梯度

        # 恢复3x3卷积核为4维形状 [c_in, c_out, 3, 3]
        conv_weight_vd = Rearrange('c_in c_out (k1 k2) -> c_in c_out k1 k2',
                                   k1=conv_shape[2], k2=conv_shape[2])(conv_weight_vd)

        return conv_weight_vd, self.conv.bias


class DEConv(nn.Module):
    """细节增强卷积（Detail-enhanced Convolution）
    功能：融合5个并行卷积分支的特征提取能力，同时捕捉中心、角度、径向、水平、垂直维度的细节
    分支构成：
        1. Conv2d_cd (CDC)：中心差异卷积，捕捉中心区域细节
        2. Conv2d_hd (HDC)：水平差异卷积，捕捉水平边缘
        3. Conv2d_vd (VDC)：垂直差异卷积，捕捉垂直边缘
        4. Conv2d_ad (ADC)：角度差异卷积，捕捉斜向边缘
        5. nn.Conv2d (VC)：普通卷积，提供基础特征提取能力（保证泛化性）
    融合逻辑：
        - 各分支输出相同尺寸的卷积核（3x3或5x5，通过padding保证输入输出尺寸一致）
        - 直接将5个分支的卷积核权重相加、偏置相加，形成“融合卷积核”
        - 用融合卷积核对输入特征图进行一次卷积，实现多维度细节的高效融合
    参数：
        dim: 输入/输出特征图的通道数（保证各分支通道数一致，便于融合）
    输入：x (Tensor) - [B, dim, H, W]
    输出：res (Tensor) - [B, dim, H, W]（融合多维度细节的特征图）
    """

    def __init__(self, dim):
        super(DEConv, self).__init__()
        # 初始化5个并行卷积分支（通道数均为dim，保证融合兼容性）
        self.conv1_1 = Conv2d_cd(dim, dim, 3, bias=True)  # CDC分支
        self.conv1_2 = Conv2d_hd(dim, dim, 3, bias=True)  # HDC分支
        self.conv1_3 = Conv2d_vd(dim, dim, 3, bias=True)  # VDC分支
        self.conv1_4 = Conv2d_ad(dim, dim, 3, bias=True)  # ADC分支
        self.conv1_5 = nn.Conv2d(dim, dim, 3, padding=1, bias=True)  # VC分支（普通3x3卷积）

    def forward(self, x):
        # 步骤1：获取每个分支调整后的卷积核（weight）和偏置（bias）
        w1, b1 = self.conv1_1.get_weight()  # CDC分支参数
        w2, b2 = self.conv1_2.get_weight()  # HDC分支参数
        w3, b3 = self.conv1_3.get_weight()  # VDC分支参数
        w4, b4 = self.conv1_4.get_weight()  # ADC分支参数
        w5, b5 = self.conv1_5.weight, self.conv1_5.bias  # VC分支参数（直接获取，无需调整）

        # 步骤2：融合各分支参数（权重相加，偏置相加）
        w = w1 + w2 + w3 + w4 + w5  # 融合卷积核（形状：[dim, dim, 3, 3]）
        b = b1 + b2 + b3 + b4 + b5  # 融合偏置（形状：[dim]）

        # 步骤3：用融合后的参数进行卷积计算（一次卷积实现多细节融合）
        res = nn.functional.conv2d(input=x, weight=w, bias=b, stride=1, padding=1, groups=1)

        return res


if __name__ == '__main__':
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    x = torch.randn(1, 64, 32, 32).to(device)

    deconv = DEConv(64).to(device)
    y = deconv(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("知乎、CSDN：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)
