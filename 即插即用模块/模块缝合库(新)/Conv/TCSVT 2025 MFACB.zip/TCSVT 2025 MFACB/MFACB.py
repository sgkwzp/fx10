# 多尺度融合膨胀卷积块（Multi-Scale Fusion Atrous Convolutional Block, MFACB）
# 核心设计：基于STDC架构改编，通过“多膨胀率卷积提取→特征拼接→双路径融合”的流程，
# 快速扩大感受野的同时保留多尺度特征信息，实现多尺度上下文的高效聚合，提升特征的全局-局部协同表达能力

import torch
import torch.nn as nn
import torch.nn.functional as F

BatchNorm2d = nn.BatchNorm2d
bn_mom = 0.1

# Conv2d + BatchNorm2d + ReLU
class ConvX(nn.Module):
    def __init__(self, in_planes, out_planes, kernel=3, stride=1, dilation=1):
        super(ConvX, self).__init__()
        if dilation == 1:
            self.conv = nn.Conv2d(in_planes, out_planes, kernel_size=kernel, stride=stride, bias=False)
        else:
            self.conv = nn.Conv2d(in_planes, out_planes, kernel_size=kernel, stride=stride, dilation=dilation,
                                  padding=dilation, bias=False)
        self.bn = BatchNorm2d(out_planes, momentum=bn_mom)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        out = self.relu(self.bn(self.conv(x)))
        return out


# 一个快速聚拢感受野的方法，改编自STDC：https://github.com/MichaelFan01/STDC-Seg
class MFACB(nn.Module):
    """
        多尺度融合膨胀卷积块（Multi-Scale Fusion Atrous Convolutional Block, MFACB）
        功能：多膨胀率卷积提取多尺度上下文，双路径融合提升特征表达
        核心设计：
            - 三分支膨胀卷积：固定3个分支，支持自定义膨胀率，快速扩大感受野
            - 双路径融合：原始特征直接投影路径 + 多尺度卷积拼接路径，兼顾基础信息与多尺度细节
            - 轻量化解构：仅通过卷积与拼接实现多尺度融合，无复杂注意力机制，计算成本低
            - 适配性强：支持 stride 调整，可灵活嵌入不同网络阶段
        改编自：STDC（Spatially Transformed Dilated Convolution）架构
        Args:
            in_planes: 输入通道数
            inter_planes: 中间卷积分支的输出通道数
            out_planes: 最终输出通道数
            block_num: 卷积分支数量（默认3，固定为3）
            stride: 卷积步长（默认1）
            dilation: 三分支的膨胀率列表（默认[2,2,2]）
        """
    def __init__(self, in_planes, inter_planes, out_planes, block_num=3, stride=1, dilation=[2, 2, 2]):
        super(MFACB, self).__init__()
        assert block_num > 1, print("block number should be larger than 1.")
        self.conv_list = nn.ModuleList()
        self.stride = stride
        self.conv_list.append(ConvX(in_planes, inter_planes, stride=stride, dilation=dilation[0]))
        self.conv_list.append(ConvX(inter_planes, inter_planes, stride=stride, dilation=dilation[1]))
        self.conv_list.append(ConvX(inter_planes, inter_planes, stride=stride, dilation=dilation[2]))
        self.process1 = nn.Sequential(
            nn.Conv2d(in_planes, out_planes, kernel_size=1, padding=0, bias=False),
            BatchNorm2d(out_planes, momentum=bn_mom),
            nn.ReLU(inplace=True)
        )
        self.process2 = nn.Sequential(
            nn.Conv2d(inter_planes * 3, out_planes, kernel_size=1, padding=0, bias=False),
            BatchNorm2d(out_planes, momentum=bn_mom),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        out_list = []
        out = x
        out1 = self.process1(x)
        # out1 = self.conv_list[0](x)
        for idx in range(3):
            out = self.conv_list[idx](out)
            out_list.append(out)
        out = torch.cat(out_list, dim=1)
        return self.process2(out) + out1


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 64, 32, 32).to(device)
    model = MFACB(64, 64, 64).to(device)

    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN、小红书：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)