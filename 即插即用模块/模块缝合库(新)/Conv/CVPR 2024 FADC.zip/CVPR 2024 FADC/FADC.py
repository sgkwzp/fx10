# 频率自适应膨胀卷积模块（Frequency Adaptive Dilated Convolution, FADC）
# 核心设计：整合频率选择（FS）、自适应核注意力（OmniAttention）与调制可变形卷积，
# 通过“频率特征分解→自适应核调制→动态膨胀卷积”的流程，让卷积核与膨胀率随输入特征的频率分布自适应调整，
# 兼顾高频细节捕捉与全局依赖建模，提升复杂场景下的特征表达能力

import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.fft
from mmcv.ops.deform_conv import DeformConv2dPack
from mmcv.ops.modulated_deform_conv import ModulatedDeformConv2d, modulated_deform_conv2d, ModulatedDeformConv2dPack, \
    CONV_LAYERS
import torch_dct as dct

class OmniAttention(nn.Module):
    """
    全维度注意力模块（OmniAttention）：为FADC提供多维度自适应权重
    功能：生成通道、滤波器、空间、核注意力，调制卷积核与特征响应
    核心设计：
        - 轻量化能量压缩：通过全局平均池化+小通道MLP，降低计算成本
        - 多维度注意力生成：同时输出4类注意力，覆盖通道、滤波器、空间、核维度
        - 温度参数调节：可动态调整注意力分布的尖锐程度，适配不同任务
        - 条件跳过机制：根据卷积类型（深度/点卷积）自动跳过无关注意力计算
    """

    def __init__(self, in_planes, out_planes, kernel_size, groups=1, reduction=0.0625, kernel_num=4, min_channel=16):
        super(OmniAttention, self).__init__()
        attention_channel = max(int(in_planes * reduction), min_channel)  # 注意力通道数（压缩后）
        self.kernel_size = kernel_size
        self.kernel_num = kernel_num
        self.temperature = 1.0  # 注意力温度参数（控制分布平滑度）

        # 能量压缩与特征提取
        self.avgpool = nn.AdaptiveAvgPool2d(1)  # 全局平均池化
        self.fc = nn.Conv2d(in_planes, attention_channel, 1, bias=False)  # 通道压缩
        self.bn = nn.BatchNorm2d(attention_channel)  # 归一化
        self.relu = nn.ReLU(inplace=True)  # 激活

        # 通道注意力生成
        self.channel_fc = nn.Conv2d(attention_channel, in_planes, 1, bias=True)
        self.func_channel = self.get_channel_attention

        # 滤波器注意力生成（深度卷积时跳过）
        if in_planes == groups and in_planes == out_planes:  # 深度卷积标识
            self.func_filter = self.skip  # 跳过滤波器注意力
        else:
            self.filter_fc = nn.Conv2d(attention_channel, out_planes, 1, bias=True)
            self.func_filter = self.get_filter_attention

        # 空间注意力生成（1×1卷积时跳过）
        if kernel_size == 1:  # 点卷积标识
            self.func_spatial = self.skip  # 跳过空间注意力
        else:
            self.spatial_fc = nn.Conv2d(attention_channel, kernel_size * kernel_size, 1, bias=True)
            self.func_spatial = self.get_spatial_attention

        # 核注意力生成（核数=1时跳过）
        if kernel_num == 1:
            self.func_kernel = self.skip  # 跳过核注意力
        else:
            self.kernel_fc = nn.Conv2d(attention_channel, kernel_num, 1, bias=True)
            self.func_kernel = self.get_kernel_attention

        self._initialize_weights()  # 参数初始化

    def _initialize_weights(self):
        """参数初始化：卷积层Kaiming正态，BN层常数初始化"""
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            if isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)

    def update_temperature(self, temperature):
        """更新注意力温度参数（训练中动态调整）"""
        self.temperature = temperature

    @staticmethod
    def skip(_):
        """跳过注意力计算（返回1.0，不影响后续乘法）"""
        return 1.0

    def get_channel_attention(self, x):
        """生成通道注意力权重（筛选关键通道）"""
        channel_attention = torch.sigmoid(self.channel_fc(x).view(x.size(0), -1, 1, 1) / self.temperature)
        return channel_attention

    def get_filter_attention(self, x):
        """生成滤波器注意力权重（调制卷积核响应）"""
        filter_attention = torch.sigmoid(self.filter_fc(x).view(x.size(0), -1, 1, 1) / self.temperature)
        return filter_attention

    def get_spatial_attention(self, x):
        """生成空间注意力权重（定位关键空间区域）"""
        spatial_attention = self.spatial_fc(x).view(x.size(0), 1, 1, 1, self.kernel_size, self.kernel_size)
        spatial_attention = torch.sigmoid(spatial_attention / self.temperature)
        return spatial_attention

    def get_kernel_attention(self, x):
        """生成核注意力权重（加权融合多组卷积核）"""
        kernel_attention = self.kernel_fc(x).view(x.size(0), -1, 1, 1, 1, 1)
        kernel_attention = F.softmax(kernel_attention / self.temperature, dim=1)
        return kernel_attention

    def forward(self, x):
        """前向传播：全局池化→特征压缩→多维度注意力生成"""
        x = self.avgpool(x)
        x = self.fc(x)
        x = self.bn(x)
        x = self.relu(x)
        return self.func_channel(x), self.func_filter(x), self.func_spatial(x), self.func_kernel(x)


def generate_laplacian_pyramid(input_tensor, num_levels, size_align=True, mode='bilinear'):
    """"
    a alternative way for feature frequency decompose
    """
    pyramid = []
    current_tensor = input_tensor
    _, _, H, W = current_tensor.shape
    for _ in range(num_levels):
        b, _, h, w = current_tensor.shape
        downsampled_tensor = F.interpolate(current_tensor, (h // 2 + h % 2, w // 2 + w % 2), mode=mode,
                                           align_corners=(H % 2) == 1)  # antialias=True
        if size_align:
            # upsampled_tensor = F.interpolate(downsampled_tensor, (h, w), mode='bilinear', align_corners=(H%2) == 1)
            # laplacian = current_tensor - upsampled_tensor
            # laplacian = F.interpolate(laplacian, (H, W), mode='bilinear', align_corners=(H%2) == 1)
            upsampled_tensor = F.interpolate(downsampled_tensor, (H, W), mode=mode, align_corners=(H % 2) == 1)
            laplacian = F.interpolate(current_tensor, (H, W), mode=mode, align_corners=(H % 2) == 1) - upsampled_tensor
            # print(laplacian.shape)
        else:
            upsampled_tensor = F.interpolate(downsampled_tensor, (h, w), mode=mode, align_corners=(H % 2) == 1)
            laplacian = current_tensor - upsampled_tensor
        pyramid.append(laplacian)
        current_tensor = downsampled_tensor
    if size_align: current_tensor = F.interpolate(current_tensor, (H, W), mode=mode, align_corners=(H % 2) == 1)
    pyramid.append(current_tensor)
    return pyramid


class FrequencySelection(nn.Module):
    """
    频率选择模块（FrequencySelection, FS）：FADC的频率自适应核心
    功能：分解输入特征的频率成分，通过注意力加权筛选关键频率，强化高频细节或低频结构
    核心设计：
        - 多频率分解方式：支持平均池化、拉普拉斯金字塔、频域（FFT）三种分解模式
        - 频率注意力加权：为不同频率成分生成自适应权重，动态平衡高低频贡献
        - 分组卷积轻量化：空间注意力采用分组卷积，降低计算量
        - 全局频率选择：支持频域全局注意力，精准调制频域特征
    """

    def __init__(self,
                 in_channels,
                 k_list=[2],
                 lowfreq_att=True,
                 fs_feat='feat',
                 lp_type='freq',
                 act='sigmoid',
                 spatial='conv',
                 spatial_group=1,
                 spatial_kernel=3,
                 init='zero',
                 global_selection=False,
                 ):
        super().__init__()
        self.k_list = k_list  # 频率分解尺度列表
        self.lp_list = nn.ModuleList()  # 频率分解模块列表
        self.freq_weight_conv_list = nn.ModuleList()  # 频率注意力卷积列表
        self.fs_feat = fs_feat
        self.lp_type = lp_type  # 频率分解类型（avgpool/laplacian/freq）
        self.in_channels = in_channels
        self.spatial_group = spatial_group  # 空间注意力分组数
        self.lowfreq_att = lowfreq_att  # 是否对低频成分施加注意力

        # 初始化空间注意力卷积（为每个频率成分分配一个卷积）
        if spatial == 'conv':
            _n = len(k_list)
            if lowfreq_att:
                _n += 1  # 额外为低频成分添加注意力卷积
            for i in range(_n):
                freq_weight_conv = nn.Conv2d(in_channels=in_channels,
                                             out_channels=self.spatial_group,
                                             stride=1,
                                             kernel_size=spatial_kernel,
                                             groups=self.spatial_group,
                                             padding=spatial_kernel // 2,
                                             bias=True)
                if init == 'zero':
                    freq_weight_conv.weight.data.zero_()
                    freq_weight_conv.bias.data.zero_()
                self.freq_weight_conv_list.append(freq_weight_conv)
        else:
            raise NotImplementedError

        # 初始化频率分解模块
        if self.lp_type == 'avgpool':
            for k in k_list:
                self.lp_list.append(nn.Sequential(
                    nn.ReplicationPad2d(padding=k // 2),
                    nn.AvgPool2d(kernel_size=k, padding=0, stride=1)
                ))
        elif self.lp_type == 'laplacian':
            pass  # 依赖外部generate_laplacian_pyramid函数
        elif self.lp_type == 'freq':
            pass  # 依赖FFT频域分解
        else:
            raise NotImplementedError

        self.act = act  # 注意力激活函数（sigmoid/softmax）
        self.global_selection = global_selection  # 是否启用全局频率选择

        # 全局频率选择卷积（频域实部/虚部分别调制）
        if self.global_selection:
            self.global_selection_conv_real = nn.Conv2d(in_channels=in_channels,
                                                        out_channels=self.spatial_group,
                                                        stride=1,
                                                        kernel_size=1,
                                                        groups=self.spatial_group,
                                                        padding=0,
                                                        bias=True)
            self.global_selection_conv_imag = nn.Conv2d(in_channels=in_channels,
                                                        out_channels=self.spatial_group,
                                                        stride=1,
                                                        kernel_size=1,
                                                        groups=self.spatial_group,
                                                        padding=0,
                                                        bias=True)
            if init == 'zero':
                self.global_selection_conv_real.weight.data.zero_()
                self.global_selection_conv_real.bias.data.zero_()
                self.global_selection_conv_imag.weight.data.zero_()
                self.global_selection_conv_imag.bias.data.zero_()

    def sp_act(self, freq_weight):
        """注意力激活：根据配置应用sigmoid或softmax"""
        if self.act == 'sigmoid':
            freq_weight = freq_weight.sigmoid() * 2  # 缩放至0~2
        elif self.act == 'softmax':
            freq_weight = freq_weight.softmax(dim=1) * freq_weight.shape[1]  # 归一化并缩放
        else:
            raise NotImplementedError
        return freq_weight

    def forward(self, x, att_feat=None):
        """
        前向传播：频率分解→注意力加权→频率融合
        Args:
            x: 输入特征，shape=[b, c, h, w]
            att_feat: 注意力生成用特征（默认=输入x）
        Returns:
            频率筛选后的特征，shape=[b, c, h, w]
        """
        if att_feat is None:
            att_feat = x
        x_list = []  # 存储各频率成分加权后的特征

        # 1. 平均池化分解模式（简单高低频拆分）
        if self.lp_type == 'avgpool':
            pre_x = x
            b, _, h, w = x.shape
            for idx, avg in enumerate(self.lp_list):
                low_part = avg(x)  # 低频成分（平均池化）
                high_part = pre_x - low_part  # 高频成分（残差）
                pre_x = low_part
                # 频率注意力加权
                freq_weight = self.freq_weight_conv_list[idx](att_feat)
                freq_weight = self.sp_act(freq_weight)
                tmp = freq_weight.reshape(b, self.spatial_group, -1, h, w) * high_part.reshape(b, self.spatial_group,
                                                                                               -1, h, w)
                x_list.append(tmp.reshape(b, -1, h, w))
            # 低频成分注意力（可选）
            if self.lowfreq_att:
                freq_weight = self.freq_weight_conv_list[len(x_list)](att_feat)
                tmp = freq_weight.reshape(b, self.spatial_group, -1, h, w) * pre_x.reshape(b, self.spatial_group, -1, h,
                                                                                           w)
                x_list.append(tmp.reshape(b, -1, h, w))
            else:
                x_list.append(pre_x)

        # 2. 拉普拉斯金字塔分解模式（多尺度频率）
        elif self.lp_type == 'laplacian':
            b, _, h, w = x.shape
            pyramids = generate_laplacian_pyramid(x, len(self.k_list), size_align=True)  # 拉普拉斯金字塔分解
            for idx, _ in enumerate(self.k_list):
                high_part = pyramids[idx]  # 各层高频成分
                freq_weight = self.freq_weight_conv_list[idx](att_feat)
                freq_weight = self.sp_act(freq_weight)
                tmp = freq_weight.reshape(b, self.spatial_group, -1, h, w) * high_part.reshape(b, self.spatial_group,
                                                                                               -1, h, w)
                x_list.append(tmp.reshape(b, -1, h, w))
            # 低频成分注意力（可选）
            if self.lowfreq_att:
                freq_weight = self.freq_weight_conv_list[len(x_list)](att_feat)
                tmp = freq_weight.reshape(b, self.spatial_group, -1, h, w) * pyramids[-1].reshape(b, self.spatial_group,
                                                                                                  -1, h, w)
                x_list.append(tmp.reshape(b, -1, h, w))
            else:
                x_list.append(pyramids[-1])

        # 3. FFT频域分解模式（精准频域调制）
        elif self.lp_type == 'freq':
            pre_x = x.clone()
            b, _, h, w = x.shape
            x_fft = torch.fft.fftshift(torch.fft.fft2(x, norm='ortho'))  # 时域→频域+移位
            # 全局频域注意力（可选）
            if self.global_selection:
                x_real = x_fft.real
                x_imag = x_fft.imag
                # 实部注意力调制
                global_att_real = self.global_selection_conv_real(x_real)
                global_att_real = self.sp_act(global_att_real).reshape(b, self.spatial_group, -1, h, w)
                # 虚部注意力调制
                global_att_imag = self.global_selection_conv_imag(x_imag)
                global_att_imag = self.sp_act(global_att_imag).reshape(b, self.spatial_group, -1, h, w)
                # 应用全局注意力
                x_real = x_real.reshape(b, self.spatial_group, -1, h, w) * global_att_real
                x_imag = x_imag.reshape(b, self.spatial_group, -1, h, w) * global_att_imag
                x_fft = torch.complex(x_real, x_imag).reshape(b, -1, h, w)
            # 多尺度频域筛选
            for idx, freq in enumerate(self.k_list):
                # 低频掩码生成（中心区域为1，抑制低频）
                mask = torch.zeros_like(x[:, 0:1, :, :], device=x.device)
                mask[:, :, round(h / 2 - h / (2 * freq)):round(h / 2 + h / (2 * freq)),
                round(w / 2 - w / (2 * freq)):round(w / 2 + w / (2 * freq))] = 1.0
                low_part = torch.fft.ifft2(torch.fft.ifftshift(x_fft * mask), norm='ortho').real  # 低频成分
                high_part = pre_x - low_part  # 高频成分
                pre_x = low_part
                # 频率注意力加权
                freq_weight = self.freq_weight_conv_list[idx](att_feat)
                freq_weight = self.sp_act(freq_weight)
                tmp = freq_weight.reshape(b, self.spatial_group, -1, h, w) * high_part.reshape(b, self.spatial_group,
                                                                                               -1, h, w)
                x_list.append(tmp.reshape(b, -1, h, w))
            # 低频成分注意力（可选）
            if self.lowfreq_att:
                freq_weight = self.freq_weight_conv_list[len(x_list)](att_feat)
                tmp = freq_weight.reshape(b, self.spatial_group, -1, h, w) * pre_x.reshape(b, self.spatial_group, -1, h,
                                                                                           w)
                x_list.append(tmp.reshape(b, -1, h, w))
            else:
                x_list.append(pre_x)

        # 融合所有频率成分
        x = sum(x_list)
        return x


# @CONV_LAYERS.register_module('AdaDilatedConv')
class AdaptiveDilatedConv(ModulatedDeformConv2d):
    """
    频率自适应膨胀卷积模块（Frequency Adaptive Dilated Convolution, FADC）
    功能：整合频率选择、自适应核调制与动态膨胀，实现频率感知的特征提取
    核心设计：
        - 频率感知预处理：通过FS模块分解并筛选频率特征，强化关键频率
        - 双路注意力核调制：OmniAttention分路调制低频核与高频核，适配不同频率特征
        - 动态膨胀率调整：通过偏移量计算，让膨胀率随特征分布自适应变化
        - 调制可变形卷积：结合偏移量与掩码，精准捕捉空间变形与频率响应
        - 多配置兼容：支持DCT变换、零膨胀、不同频率分解模式，适配多样任务
    """
    _version = 2

    def __init__(self, *args,
                 padding_mode='repeat',
                 kernel_decompose='both',
                 conv_type='conv',
                 sp_att=False,
                 pre_fs=True,
                 epsilon=1e-4,
                 use_zero_dilation=False,
                 use_dct=False,
                 fs_cfg={
                     'k_list': [2, 4, 8],
                     'fs_feat': 'feat',
                     'lowfreq_att': False,
                     'lp_type': 'freq',
                     'act': 'sigmoid',
                     'spatial': 'conv',
                     'spatial_group': 1,
                 },
                 **kwargs):
        super().__init__(*args, **kwargs)
        # 填充模式（零填充/重复填充）
        if padding_mode == 'zero':
            self.PAD = nn.ZeroPad2d(self.kernel_size[0] // 2)
        elif padding_mode == 'repeat':
            self.PAD = nn.ReplicationPad2d(self.kernel_size[0] // 2)
        else:
            self.PAD = nn.Identity()

        self.kernel_decompose = kernel_decompose  # 核分解模式（both/high/low）
        self.use_dct = use_dct  # 是否启用DCT核变换
        self.conv_type = conv_type  # 卷积类型
        self.epsilon = epsilon  # 数值稳定性参数
        self.use_zero_dilation = use_zero_dilation  # 是否启用零膨胀约束
        self.pre_fs = pre_fs  # 频率选择是否在卷积前执行

        # 初始化双路OmniAttention（核分解为高低频）
        if kernel_decompose == 'both':
            self.OMNI_ATT1 = OmniAttention(in_planes=self.in_channels, out_planes=self.out_channels, kernel_size=1,
                                           groups=1, reduction=0.0625, kernel_num=1, min_channel=16)  # 低频核注意力
            self.OMNI_ATT2 = OmniAttention(in_planes=self.in_channels, out_planes=self.out_channels,
                                           kernel_size=self.kernel_size[0] if self.use_dct else 1, groups=1,
                                           reduction=0.0625, kernel_num=1, min_channel=16)  # 高频核注意力
        elif kernel_decompose == 'high' or kernel_decompose == 'low':
            self.OMNI_ATT = OmniAttention(in_planes=self.in_channels, out_planes=self.out_channels, kernel_size=1,
                                          groups=1, reduction=0.0625, kernel_num=1, min_channel=16)

        # 偏移量生成卷积（控制膨胀率）
        if conv_type == 'conv':
            self.conv_offset = nn.Conv2d(
                self.in_channels,
                self.deform_groups * 1,
                kernel_size=self.kernel_size,
                stride=self.stride,
                padding=self.kernel_size[0] // 2 if isinstance(self.PAD, nn.Identity) else 0,
                dilation=1,
                bias=True)

        # 掩码生成卷积（控制特征响应强度）
        self.conv_mask = nn.Conv2d(
            self.in_channels,
            self.deform_groups * 1 * self.kernel_size[0] * self.kernel_size[1],
            kernel_size=self.kernel_size,
            stride=self.stride,
            padding=self.kernel_size[0] // 2 if isinstance(self.PAD, nn.Identity) else 0,
            dilation=1,
            bias=True)

        # 空间注意力（可选）
        if sp_att:
            self.conv_mask_mean_level = nn.Conv2d(
                self.in_channels,
                self.deform_groups * 1,
                kernel_size=self.kernel_size,
                stride=self.stride,
                padding=self.kernel_size[0] // 2 if isinstance(self.PAD, nn.Identity) else 0,
                dilation=1,
                bias=True)

        # 初始化频率选择模块
        if fs_cfg is not None:
            if pre_fs:
                self.FS = FrequencySelection(self.in_channels, **fs_cfg)
            else:
                self.FS = FrequencySelection(1, **fs_cfg)

        # 初始化膨胀偏移量（固定偏移模板）
        offset = [-1, -1, -1, 0, -1, 1, 0, -1, 0, 0, 0, 1, 1, -1, 1, 0, 1, 1]
        self.register_buffer('dilated_offset', torch.Tensor(offset[None, None, ..., None, None]))

        self.init_weights()  # 参数初始化

    def freq_select(self, x):
        """频率选择兼容接口（默认返回输入）"""
        return x

    def init_weights(self):
        """参数初始化：偏移量卷积偏置初始化适配膨胀率"""
        super().init_weights()
        if hasattr(self, 'conv_offset') and self.conv_type == 'conv':
            self.conv_offset.weight.data.zero_()
            self.conv_offset.bias.data.fill_((self.dilation[0] - 1) / self.dilation[0] + self.epsilon)
        if hasattr(self, 'conv_mask'):
            self.conv_mask.weight.data.zero_()
            self.conv_mask.bias.data.zero_()
        if hasattr(self, 'conv_mask_mean_level'):
            self.conv_mask.weight.data.zero_()
            self.conv_mask.bias.data.zero_()

    def forward(self, x):
        """
        前向传播：频率选择→注意力核调制→动态膨胀卷积→输出
        Args:
            x: 输入特征，shape=[b, c_in, h, w]
        Returns:
            频率自适应增强特征，shape=[b, c_out, h, w]
        """
        b = x.shape[0]

        # 1. 频率选择预处理
        if hasattr(self, 'FS') and self.pre_fs:
            x = self.FS(x)

        # 2. 双路注意力核调制（高低频核分离）
        if hasattr(self, 'OMNI_ATT1') and hasattr(self, 'OMNI_ATT2'):
            c_att1, f_att1, _, _ = self.OMNI_ATT1(x)  # 低频核注意力
            c_att2, f_att2, spatial_att2, _, = self.OMNI_ATT2(x)  # 高频核注意力
        elif hasattr(self, 'OMNI_ATT'):
            c_att, f_att, _, _ = self.OMNI_ATT(x)  # 单路核注意力

        # 3. 动态偏移量生成（控制膨胀率）
        if self.conv_type == 'conv':
            offset = self.conv_offset(self.PAD(self.freq_select(x)))
        else:
            offset = self.conv_offset(self.freq_select(x))

        # 4. 膨胀率调整（确保非负）
        if self.use_zero_dilation:
            offset = (F.relu(offset + 1, inplace=True) - 1) * self.dilation[0]
        else:
            offset = offset.abs() * self.dilation[0]

        # 5. 后频率选择（可选）
        if hasattr(self, 'FS') and not self.pre_fs:
            x = self.FS(x, F.interpolate(offset, x.shape[-2:], mode='bilinear', align_corners=(x.shape[-1] % 2) == 1))

        # 6. 偏移量重塑（适配可变形卷积）
        b, _, h, w = offset.shape
        offset = offset.reshape(b, self.deform_groups, -1, h, w) * self.dilated_offset
        offset = offset.reshape(b, -1, h, w)

        # 7. 掩码生成（控制特征响应）
        mask = self.conv_mask(x).sigmoid()
        if hasattr(self, 'conv_mask_mean_level'):
            mask_mean_level = torch.sigmoid(self.conv_mask_mean_level(x)).reshape(b, self.deform_groups, -1, h, w)
            mask = mask * mask_mean_level
        mask = mask.reshape(b, -1, h, w)

        # 8. 自适应核生成（高低频核融合）
        x_pad = self.PAD(x)
        if hasattr(self, 'OMNI_ATT1') and hasattr(self, 'OMNI_ATT2'):
            # 卷积核分解为均值（低频）和残差（高频）
            adaptive_weight = self.weight.unsqueeze(0).repeat(b, 1, 1, 1, 1)  # [b, c_out, c_in, k, k]
            adaptive_weight_mean = adaptive_weight.mean(dim=(-1, -2), keepdim=True)  # 低频核（均值）
            adaptive_weight_res = adaptive_weight - adaptive_weight_mean  # 高频核（残差）

            # DCT核变换（可选，强化高频核）
            if self.use_dct:
                dct_coefficients = dct.dct_2d(adaptive_weight_res)
                spatial_att2 = spatial_att2.reshape(b, 1, 1, self.kernel_size[0], self.kernel_size[1])
                dct_coefficients = dct_coefficients * (spatial_att2 * 2)
                adaptive_weight_res = dct.idct_2d(dct_coefficients)

            # 注意力调制核（低频核+高频核）
            adaptive_weight = adaptive_weight_mean * (c_att1.unsqueeze(1) * 2) * (f_att1.unsqueeze(2) * 2) + \
                              adaptive_weight_res * (c_att2.unsqueeze(1) * 2) * (f_att2.unsqueeze(2) * 2)
            adaptive_weight = adaptive_weight.reshape(-1, self.in_channels // self.groups, self.kernel_size[0],
                                                      self.kernel_size[1])

            # 偏置处理
            if self.bias is not None:
                bias = self.bias.repeat(b)
            else:
                bias = self.bias

            # 调制可变形卷积前向
            x = modulated_deform_conv2d(x_pad, offset, mask, adaptive_weight, bias,
                                        self.stride,
                                        (0, 0) if not isinstance(self.PAD, nn.Identity) else (
                                        self.kernel_size[0] // 2, self.kernel_size[1] // 2),
                                        (1, 1),
                                        self.groups * b, self.deform_groups * b)

        # 9. 单路核调制（仅高频或仅低频）
        elif hasattr(self, 'OMNI_ATT'):
            adaptive_weight = self.weight.unsqueeze(0).repeat(b, 1, 1, 1, 1)
            adaptive_weight_mean = adaptive_weight.mean(dim=(-1, -2), keepdim=True)
            if self.kernel_decompose == 'high':
                adaptive_weight = adaptive_weight_mean + (adaptive_weight - adaptive_weight_mean) * (
                            c_att.unsqueeze(1) * 2) * (f_att.unsqueeze(2) * 2)
            elif self.kernel_decompose == 'low':
                adaptive_weight = adaptive_weight_mean * (c_att.unsqueeze(1) * 2) * (f_att.unsqueeze(2) * 2) + (
                            adaptive_weight - adaptive_weight_mean)
            adaptive_weight = adaptive_weight.reshape(-1, self.in_channels // self.groups, self.kernel_size[0],
                                                      self.kernel_size[1])

            # 调制可变形卷积前向
            x = modulated_deform_conv2d(x_pad, offset, mask, adaptive_weight, self.bias,
                                        self.stride,
                                        (0, 0) if not isinstance(self.PAD, nn.Identity) else (
                                        self.kernel_size[0] // 2, self.kernel_size[1] // 2),
                                        (1, 1),
                                        self.groups * b, self.deform_groups * b)

        # 10. 原始可变形卷积（无核调制）
        else:
            x = modulated_deform_conv2d(x_pad, offset, mask, self.weight, self.bias,
                                        self.stride,
                                        (0, 0) if not isinstance(self.PAD, nn.Identity) else (
                                        self.kernel_size[0] // 2, self.kernel_size[1] // 2),
                                        (1, 1),
                                        self.groups, self.deform_groups)

        # 11. 输出重塑
        return x.reshape(b, -1, h, w)


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    x = torch.randn(1, 64, 32, 32).to(device)
    model = AdaptiveDilatedConv(in_channels=64, out_channels=64, kernel_size=3).to(device)

    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN、小红书：十小大")

    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)
