import torch
import torch.nn as nn 
import torch.nn.functional as F

class GroupBatchnorm2d(nn.Module):
    """自定义分组批归一化模块：将通道分组后计算均值和方差，增强通道独立性
    作用：相比标准BN，通过分组降低通道间统计信息的耦合，适配后续分组相关操作（如SRU的分组归一化）
    Args:
        c_num (int): 输入通道总数
        group_num (int): 分组数量，默认16（需满足c_num ≥ group_num）
        eps (float): 避免分母为0的微小值，默认1e-10
    """
    def __init__(self, c_num:int,
                 group_num:int = 16,
                 eps:float = 1e-10
                 ):
        super(GroupBatchnorm2d,self).__init__()
        assert c_num >= group_num, "通道数必须大于等于分组数"
        self.group_num = group_num
        # 可学习的缩放权重和偏置（对应每个通道）
        self.weight = nn.Parameter(torch.randn(c_num, 1, 1))  # 形状：(C,1,1)，适配4D特征图
        self.bias = nn.Parameter(torch.zeros(c_num, 1, 1))    # 形状：(C,1,1)
        self.eps = eps

    def forward(self, x):
        N, C, H, W = x.size()  # N=批量，C=通道，H=高度，W=宽度
        # 步骤1：按分组重塑特征（N,C,H,W）→（N, group_num, C//group_num * H * W）
        x = x.view(N, self.group_num, -1)
        # 步骤2：计算每组的均值和方差（沿特征维度，保留维度用于广播）
        mean = x.mean(dim=2, keepdim=True)
        std = x.std(dim=2, keepdim=True)
        # 步骤3：归一化操作
        x = (x - mean) / (std + self.eps)
        # 步骤4：恢复原始形状并应用可学习权重和偏置
        x = x.view(N, C, H, W)
        return x * self.weight + self.bias

class SRU(nn.Module):
    """空间重构单元（Spatial Reconstruction Unit）：通过分组归一化、门控筛选与特征重构，优化空间特征
    核心逻辑：先对特征进行分组归一化与权重校准，再通过门控机制分离重要/次要空间特征，最后重构特征增强空间关联性
    Args:
        oup_channels (int): 输入/输出通道数
        group_num (int): 分组归一化的组数，默认16
        gate_treshold (float): 门控阈值，默认0.5（区分重要/次要特征）
        torch_gn (bool): 是否使用PyTorch官方GroupNorm，默认True（False时使用自定义GroupBatchnorm2d）
    """

    def __init__(self,
                 oup_channels: int,
                 group_num: int = 16,
                 gate_treshold: float = 0.5,
                 torch_gn: bool = True
                 ):
        super().__init__()
        # 分组归一化层（可选官方或自定义实现）
        self.gn = nn.GroupNorm(num_channels=oup_channels, num_groups=group_num) if torch_gn else GroupBatchnorm2d(
            c_num=oup_channels, group_num=group_num)
        self.gate_treshold = gate_treshold  # 门控筛选阈值
        self.sigomid = nn.Sigmoid()  # 激活函数，生成0-1之间的权重

    def forward(self, x):
        # 步骤1：分组归一化，稳定特征分布
        gn_x = self.gn(x)
        # 步骤2：计算通道权重（基于分组归一化的权重，归一化后作为校准系数）
        w_gamma = self.gn.weight / sum(self.gn.weight)  # 通道权重归一化
        w_gamma = w_gamma.view(1, -1, 1, 1)  # 重塑为(1,C,1,1)，适配4D特征图广播
        # 步骤3：生成空间权重图（校准后的归一化特征经Sigmoid激活）
        reweigts = self.sigomid(gn_x * w_gamma)

        # 步骤4：门控筛选：分离重要（w1）和次要（w2）空间特征
        # w1：权重>阈值的设为1（完全保留重要特征），否则保留原值
        w1 = torch.where(reweigts > self.gate_treshold, torch.ones_like(reweigts), reweigts)
        # w2：权重>阈值的设为0（过滤重要特征），否则保留原值（仅保留次要特征）
        w2 = torch.where(reweigts > self.gate_treshold, torch.zeros_like(reweigts), reweigts)

        # 步骤5：应用门控权重，分离特征
        x_1 = w1 * x  # 重要空间特征
        x_2 = w2 * x  # 次要空间特征

        # 步骤6：特征重构，增强空间关联性
        y = self.reconstruct(x_1, x_2)
        return y

    def reconstruct(self, x_1, x_2):
        """特征重构函数：将重要/次要特征各拆分为两部分，交叉拼接增强空间交互
        Args:
            x_1 (torch.Tensor): 重要空间特征 (B, C, H, W)
            x_2 (torch.Tensor): 次要空间特征 (B, C, H, W)
        Returns:
            torch.Tensor: 重构后的空间优化特征 (B, C, H, W)
        """
        # 各特征按通道拆分为两部分（C→C/2 + C/2）
        x_11, x_12 = torch.split(x_1, x_1.size(1) // 2, dim=1)
        x_21, x_22 = torch.split(x_2, x_2.size(1) // 2, dim=1)
        # 交叉拼接：重要特征第一部分+次要特征第二部分，重要特征第二部分+次要特征第一部分
        return torch.cat([x_11 + x_22, x_12 + x_21], dim=1)

class CRU(nn.Module):
    '''通道重构单元（Channel Reconstruction Unit）：通过通道拆分、变换与融合，优化通道特征
    核心逻辑：将通道分为高/低优先级两组，分别进行特征压缩与变换，最后通过自适应池化加权融合，增强通道区分度
    Args:
        op_channel (int): 输入/输出通道数
        alpha (float): 高优先级通道占比（0<alpha<1），默认1/2（高/低通道数各占50%）
        squeeze_radio (int): 通道压缩系数，默认2（降低计算量）
        group_size (int): 分组卷积的组数，默认2
        group_kernel_size (int): 分组卷积核大小，默认3
    '''

    def __init__(self,
                 op_channel: int,
                 alpha: float = 1 / 2,
                 squeeze_radio: int = 2,
                 group_size: int = 2,
                 group_kernel_size: int = 3,
                 ):
        super().__init__()
        # 计算高/低优先级通道数
        self.up_channel = up_channel = int(alpha * op_channel)  # 高优先级通道
        self.low_channel = low_channel = op_channel - up_channel  # 低优先级通道

        # 通道压缩卷积（1×1，降低维度减少计算量）
        self.squeeze1 = nn.Conv2d(up_channel, up_channel // squeeze_radio, kernel_size=1, bias=False)  # 高优先级压缩
        self.squeeze2 = nn.Conv2d(low_channel, low_channel // squeeze_radio, kernel_size=1, bias=False)  # 低优先级压缩

        # 高优先级通道变换：分组卷积（GWC）+ 点卷积（PWC），增强通道关联性
        self.GWC = nn.Conv2d(
            up_channel // squeeze_radio,
            op_channel,
            kernel_size=group_kernel_size,
            stride=1,
            padding=group_kernel_size // 2,  # SAME padding，保持尺寸
            groups=group_size  # 分组卷积，增强通道独立性
        )
        self.PWC1 = nn.Conv2d(up_channel // squeeze_radio, op_channel, kernel_size=1, bias=False)  # 点卷积融合分组特征

        # 低优先级通道变换：点卷积扩展通道，与原始低优先级通道拼接
        self.PWC2 = nn.Conv2d(
            low_channel // squeeze_radio,
            op_channel - low_channel // squeeze_radio,  # 扩展后通道数=总通道数-压缩后低通道数
            kernel_size=1,
            bias=False
        )
        self.advavg = nn.AdaptiveAvgPool2d(1)  # 自适应全局平均池化，提取通道全局信息

    def forward(self, x):
        # 步骤1：通道拆分：按高/低优先级分为两组
        up, low = torch.split(x, [self.up_channel, self.low_channel], dim=1)
        # 步骤2：通道压缩：降低两组通道数，减少计算量
        up, low = self.squeeze1(up), self.squeeze2(low)

        # 步骤3：特征变换：高/低优先级通道分别处理
        # 高优先级：分组卷积+点卷积，增强通道与空间关联
        Y1 = self.GWC(up) + self.PWC1(up)
        # 低优先级：点卷积扩展通道后，与原始压缩低通道拼接
        Y2 = torch.cat([self.PWC2(low), low], dim=1)

        # 步骤4：特征融合：自适应池化加权（基于通道全局重要性）
        out = torch.cat([Y1, Y2], dim=1)  # 拼接两组变换特征
        # 计算通道权重（全局平均池化+Softmax归一化）
        out = F.softmax(self.advavg(out), dim=1) * out
        # 步骤5：通道重构：拆分为两部分并相加，增强通道交互
        out1, out2 = torch.split(out, out.size(1) // 2, dim=1)
        return out1 + out2


class ScConv(nn.Module):
    """SCConv（Spatial and Channel reconstruction Convolution）：整合SRU与CRU，实现空间-通道双维度特征优化
    核心逻辑：先通过SRU优化空间特征（定位重要区域），再通过CRU优化通道特征（筛选关键通道），双维度协同提升特征表达
    Args:
        op_channel (int): 输入/输出通道数
        group_num (int): SRU中分组归一化的组数，默认4
        gate_treshold (float): SRU中的门控阈值，默认0.5
        alpha (float): CRU中高优先级通道占比，默认1/2
        squeeze_radio (int): CRU中通道压缩系数，默认2
        group_size (int): CRU中分组卷积的组数，默认2
        group_kernel_size (int): CRU中分组卷积核大小，默认3
    """

    def __init__(self,
                 op_channel: int,
                 group_num: int = 4,
                 gate_treshold: float = 0.5,
                 alpha: float = 1 / 2,
                 squeeze_radio: int = 2,
                 group_size: int = 2,
                 group_kernel_size: int = 3,
                 ):
        super().__init__()
        # 空间重构单元：优化空间特征
        self.SRU = SRU(
            op_channel,
            group_num=group_num,
            gate_treshold=gate_treshold
        )
        # 通道重构单元：优化通道特征
        self.CRU = CRU(
            op_channel,
            alpha=alpha,
            squeeze_radio=squeeze_radio,
            group_size=group_size,
            group_kernel_size=group_kernel_size
        )

    def forward(self, x):
        # 步骤1：空间特征优化（SRU）
        x = self.SRU(x)
        # 步骤2：通道特征优化（CRU）
        x = self.CRU(x)
        return x


if __name__ == '__main__':
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    x = torch.randn(1, 32, 64, 64).to(device)
    scconv = ScConv(32).to(device)
    y = scconv(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("知乎、CSDN：十小大")
    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)

