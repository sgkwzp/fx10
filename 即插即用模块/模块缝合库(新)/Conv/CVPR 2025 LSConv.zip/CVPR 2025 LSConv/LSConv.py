import torch
from torch.autograd import Function  # 用于自定义自动求导函数
import triton  # 用于编写高效GPU内核的框架
import triton.language as tl  # Triton的内置语言，用于定义GPU计算逻辑
from torch.amp import custom_fwd, custom_bwd  # 用于自定义混合精度训练的前向/反向传播
import math
import torch.nn as nn  # 用于构建神经网络层

def _grid(numel: int, bs: int) -> tuple:
    """
    生成Triton内核的网格尺寸（用于并行计算任务划分）
    Args:
        numel (int): 总元素数量（如输出张量的总元素数）
        bs (int): 每个线程块（block）处理的元素数（block size）
    Returns:
        tuple: 网格尺寸，格式为 (num_blocks,)，num_blocks=总元素数//block size（向上取整）
    """
    return (triton.cdiv(numel, bs),)

@triton.jit
def _idx(i, n: int, c: int, h: int, w: int):
    """
    Triton内核中的索引转换函数：将扁平索引i转换为4D张量的（批次数、通道数、高度、宽度）索引
    Args:
        i (tl.int32): 扁平索引（0~numel-1）
        n (int): 批次数（B）
        c (int): 通道数（C）
        h (int): 高度（H）
        w (int): 宽度（W）
    Returns:
        ni (tl.int32): 批次数索引（0~n-1）
        ci (tl.int32): 通道数索引（0~c-1）
        hi (tl.int32): 高度索引（0~h-1）
        wi (tl.int32): 宽度索引（0~w-1）
        m (tl.bool): 掩码（判断索引i是否在有效范围内，避免越界）
    """
    ni = i // (c * h * w)  # 批次数索引：i除以（C×H×W）取商
    ci = (i // (h * w)) % c  # 通道数索引：(i除以H×W取商) 对C取余
    hi = (i // w) % h        # 高度索引：(i除以W取商) 对H取余
    wi = i % w               # 宽度索引：i对W取余
    m = i < (n * c * h * w)  # 掩码：仅当i在有效范围内（<B×C×H×W）时为True
    return ni, ci, hi, wi, m


@triton.jit
def ska_fwd(
        x_ptr, w_ptr, o_ptr,
        n, ic, h, w, ks, pad, wc,
        BS: tl.constexpr,
        CT: tl.constexpr, AT: tl.constexpr
):
    """
    Triton内核：实现小核聚合（Small Kernel Aggregation, SKA）的前向传播
    功能：对输入特征图x应用动态生成的小卷积核w，计算输出特征图o（类似动态卷积）

    Args:
        x_ptr (tl.pointer): 输入特征图x的GPU内存指针（形状：[B, IC, H, W]）
        w_ptr (tl.pointer): 动态卷积核w的GPU内存指针（形状：[B, WC, KS², H, W]）
        o_ptr (tl.pointer): 输出特征图o的GPU内存指针（形状：[B, IC, H, W]）
        n (int): 批次数（B）
        ic (int): 输入特征图的通道数（IC）
        h (int): 特征图高度（H）
        w (int): 特征图宽度（W）
        ks (int): 小卷积核的尺寸（如3表示3×3核）
        pad (int): 填充大小（确保输出尺寸与输入一致，pad=(ks-1)//2）
        wc (int): 卷积核的分组通道数（每个分组对应IC//WC个输入通道）
        BS (tl.constexpr): 每个线程块处理的元素数（编译期常量）
        CT (tl.constexpr): 计算精度类型（如tl.float16/tl.float32，编译期常量）
        AT (tl.constexpr): 累加精度类型（通常比CT高，避免精度损失，编译期常量）
    """
    pid = tl.program_id(0)  # 当前线程块的ID（从0到num_blocks-1）
    start = pid * BS  # 当前线程块处理的第一个元素的扁平索引
    offs = start + tl.arange(0, BS)  # 当前线程块处理的所有元素的扁平索引（长度=BS）

    # 将扁平索引转换为4D索引（n, ic, h, w），并获取有效掩码m
    ni, ci, hi, wi, m = _idx(offs, n, ic, h, w)
    val = tl.zeros((BS,), dtype=AT)  # 初始化累加器（用AT类型避免精度损失）

    # 遍历小卷积核的每个位置（kh=核高度，kw=核宽度）
    for kh in range(ks):
        hin = hi - pad + kh  # 输入特征图的高度索引（考虑填充）
        hb = (hin >= 0) & (hin < h)  # 高度有效性掩码（避免输入越界）
        for kw in range(ks):
            win = wi - pad + kw  # 输入特征图的宽度索引（考虑填充）
            b = hb & (win >= 0) & (win < w)  # 整体有效性掩码（高度+宽度均有效）

            # 计算输入特征x的内存偏移量（4D索引→扁平索引）
            x_off = ((ni * ic + ci) * h + hin) * w + win
            # 计算卷积核w的内存偏移量（考虑分组：ci%wc获取当前分组的核通道）
            w_off = ((ni * wc + ci % wc) * ks * ks + (kh * ks + kw)) * h * w + hi * w + wi

            # 加载x和w的值（越界时填充0.0），并转换为计算精度CT
            x_val = tl.load(x_ptr + x_off, mask=m & b, other=0.0).to(CT)
            w_val = tl.load(w_ptr + w_off, mask=m, other=0.0).to(CT)

            # 累加x_val * w_val（仅有效位置参与计算），并转换为累加精度AT
            val += tl.where(b & m, x_val * w_val, 0.0).to(AT)

    # 将累加结果转换为计算精度CT，存储到输出o的对应位置（仅有效位置）
    tl.store(o_ptr + offs, val.to(CT), mask=m)


@triton.jit
def ska_bwd_x(
        go_ptr, w_ptr, gi_ptr,
        n, ic, h, w, ks, pad, wc,
        BS: tl.constexpr,
        CT: tl.constexpr, AT: tl.constexpr
):
    """
    Triton内核：计算输入特征图x的梯度（gi），对应SKA前向传播的反向传播
    功能：根据输出梯度go和卷积核w，反向推导输入x的梯度（链式法则）
    Args:
        go_ptr (tl.pointer): 输出特征图o的梯度（go）的GPU内存指针（[B, IC, H, W]）
        w_ptr (tl.pointer): 动态卷积核w的GPU内存指针（[B, WC, KS², H, W]）
        gi_ptr (tl.pointer): 输入特征图x的梯度（gi）的GPU内存指针（[B, IC, H, W]）
        其他参数：与ska_fwd一致
    """
    pid = tl.program_id(0)
    start = pid * BS
    offs = start + tl.arange(0, BS)
    ni, ci, hi, wi, m = _idx(offs, n, ic, h, w)
    val = tl.zeros((BS,), dtype=AT)

    # 遍历卷积核位置（反向传播需反转核的位置，对应前向的hin=hi+pad-kh）
    for kh in range(ks):
        ho = hi + pad - kh  # 输出特征图的高度索引（反向推导时的位置映射）
        hb = (ho >= 0) & (ho < h)
        for kw in range(ks):
            wo = wi + pad - kw  # 输出特征图的宽度索引
            b = hb & (wo >= 0) & (wo < w)

            # 计算输出梯度go的内存偏移量
            go_off = ((ni * ic + ci) * h + ho) * w + wo
            # 计算卷积核w的内存偏移量（与前向一致）
            w_off = ((ni * wc + ci % wc) * ks * ks + (kh * ks + kw)) * h * w + ho * w + wo

            # 加载go和w的值，累加梯度
            go_val = tl.load(go_ptr + go_off, mask=m & b, other=0.0).to(CT)
            w_val = tl.load(w_ptr + w_off, mask=m, other=0.0).to(CT)
            val += tl.where(b & m, go_val * w_val, 0.0).to(AT)

    # 存储输入梯度gi
    tl.store(gi_ptr + offs, val.to(CT), mask=m)


@triton.jit
def ska_bwd_w(
        go_ptr, x_ptr, gw_ptr,
        n, wc, h, w, ic, ks, pad,
        BS: tl.constexpr,
        CT: tl.constexpr, AT: tl.constexpr
):
    """
    Triton内核：计算动态卷积核w的梯度（gw），对应SKA前向传播的反向传播
    功能：根据输出梯度go和输入特征x，反向推导卷积核w的梯度（链式法则）
    Args:
        go_ptr (tl.pointer): 输出特征图o的梯度（go）的GPU内存指针（[B, IC, H, W]）
        x_ptr (tl.pointer): 输入特征图x的GPU内存指针（[B, IC, H, W]）
        gw_ptr (tl.pointer): 卷积核w的梯度（gw）的GPU内存指针（[B, WC, KS², H, W]）
        wc (int): 卷积核的分组通道数（WC）
        ic (int): 输入特征图的通道数（IC）
        其他参数：与ska_fwd一致
    """
    pid = tl.program_id(0)
    start = pid * BS
    offs = start + tl.arange(0, BS)
    ni, ci, hi, wi, m = _idx(offs, n, wc, h, w)  # 注意：此处通道数为WC（卷积核的通道数）

    # 遍历卷积核位置
    for kh in range(ks):
        hin = hi - pad + kh  # 输入特征图的高度索引
        hb = (hin >= 0) & (hin < h)
        for kw in range(ks):
            win = wi - pad + kw  # 输入特征图的宽度索引
            b = hb & (win >= 0) & (win < w)

            # 计算卷积核w的梯度gw的内存偏移量
            w_off = ((ni * wc + ci) * ks * ks + (kh * ks + kw)) * h * w + hi * w + wi
            val = tl.zeros((BS,), dtype=AT)

            # 遍历输入通道分组（每个卷积核通道ci对应IC//WC个输入通道）
            steps = (ic - ci + wc - 1) // wc  # 分组步数（向上取整）
            for s in range(tl.max(steps, axis=0)):
                cc = ci + s * wc  # 当前输入通道（分组内的通道偏移）
                cm = (cc < ic) & m & b  # 输入通道有效性掩码（cc<IC且索引有效）

                # 计算输入x和输出梯度go的内存偏移量
                x_off = ((ni * ic + cc) * h + hin) * w + win
                go_off = ((ni * ic + cc) * h + hi) * w + wi

                # 加载x和go的值，累加卷积核梯度
                x_val = tl.load(x_ptr + x_off, mask=cm, other=0.0).to(CT)
                go_val = tl.load(go_ptr + go_off, mask=cm, other=0.0).to(CT)
                val += tl.where(cm, x_val * go_val, 0.0).to(AT)

            # 存储卷积核梯度gw
            tl.store(gw_ptr + w_off, val.to(CT), mask=m)


class SkaFn(Function):
    """
    自定义自动求导函数：封装SKA的前向/反向传播（基于Triton内核）
    功能：通过Function类实现PyTorch的自动求导接口，将Triton内核与PyTorch生态兼容
    """

    @staticmethod
    @custom_fwd(device_type='cuda')  # 自定义前向传播（指定GPU设备）
    def forward(ctx, x: torch.Tensor, w: torch.Tensor) -> torch.Tensor:
        """
        前向传播：调用ska_fwd内核计算SKA的输出
        Args:
            ctx (torch.autograd.function.BackwardCFunction): 上下文对象，用于保存反向传播所需的变量
            x (torch.Tensor): 输入特征图，形状 [B, IC, H, W]
            w (torch.Tensor): 动态卷积核，形状 [B, WC, KS², H, W]（KS为核尺寸）
        Returns:
            torch.Tensor: 输出特征图，形状 [B, IC, H, W]
        """
        ks = int(math.sqrt(w.shape[2]))  # 从核元素数（KS²）推导核尺寸KS（如9→3）
        pad = (ks - 1) // 2  # 计算填充大小（确保输出尺寸=输入尺寸）
        ctx.ks, ctx.pad = ks, pad  # 保存核尺寸和填充，供反向传播使用

        n, ic, h, width = x.shape  # 解析输入x的维度（width=W）
        wc = w.shape[1]  # 解析卷积核w的分组通道数WC

        # 初始化输出张量o（与x同形状、同设备、同 dtype）
        o = torch.empty(n, ic, h, width, device=x.device, dtype=x.dtype)
        numel = o.numel()  # 输出张量的总元素数

        # 确保输入x和w在GPU上是连续存储的（Triton内核要求连续内存）
        x = x.contiguous()
        w = w.contiguous()

        # 定义Triton网格生成函数（根据block size=1024计算网格尺寸）
        grid = lambda meta: _grid(numel, meta["BS"])

        # 确定计算精度（CT）和累加精度（AT）：混合精度训练时用float16计算，float32累加
        ct = tl.float16 if x.dtype == torch.float16 else (tl.float32 if x.dtype == torch.float32 else tl.float64)
        at = tl.float32 if x.dtype == torch.float16 else ct

        # 调用Triton前向内核（BS=1024，CT/AT为上述精度）
        ska_fwd[grid](x, w, o, n, ic, h, width, ks, pad, wc, BS=1024, CT=ct, AT=at)

        # 保存反向传播所需的变量（输入x、卷积核w、精度类型ct/at）
        ctx.save_for_backward(x, w)
        ctx.ct, ctx.at = ct, at

        return o

    @staticmethod
    @custom_bwd(device_type='cuda')  # 自定义反向传播（指定GPU设备）
    def backward(ctx, go: torch.Tensor) -> tuple:
        """
        反向传播：调用ska_bwd_x/ska_bwd_w内核计算输入x和卷积核w的梯度
        Args:
            ctx: 前向传播保存的上下文对象
            go (torch.Tensor): 输出特征图o的梯度，形状 [B, IC, H, W]
        Returns:
            tuple: (gx, gw, None, None)，gx为x的梯度，gw为w的梯度，其余为占位符（因前向仅2个输入）
        """
        ks, pad = ctx.ks, ctx.pad  # 从上下文获取核尺寸和填充
        x, w = ctx.saved_tensors  # 从上下文获取前向的x和w
        n, ic, h, width = x.shape  # 解析x的维度
        wc = w.shape[1]  # 解析w的分组通道数
        go = go.contiguous()  # 确保输出梯度go是连续存储的
        gx = gw = None  # 初始化输入梯度gx和卷积核梯度gw
        ct, at = ctx.ct, ctx.at  # 从上下文获取精度类型

        # 计算输入x的梯度（仅当需要x的梯度时）
        if ctx.needs_input_grad[0]:
            gx = torch.empty_like(x)  # 初始化gx（与x同形状）
            numel = gx.numel()  # gx的总元素数
            # 调用Triton反向内核（计算gx）
            ska_bwd_x[lambda meta: _grid(numel, meta["BS"])](
                go, w, gx, n, ic, h, width, ks, pad, wc, BS=1024, CT=ct, AT=at
            )

        # 计算卷积核w的梯度（仅当需要w的梯度时）
        if ctx.needs_input_grad[1]:
            gw = torch.empty_like(w)  # 初始化gw（与w同形状）
            # w的总元素数=B×WC×KS²×H×W，此处numel=B×WC×H×W（因KS²已在核内遍历）
            numel = gw.numel() // w.shape[2]
            # 调用Triton反向内核（计算gw）
            ska_bwd_w[lambda meta: _grid(numel, meta["BS"])](
                go, x, gw, n, wc, h, width, ic, ks, pad, BS=1024, CT=ct, AT=at
            )

        return gx, gw, None, None  # 返回梯度（后两个None为占位符，匹配前向输入数量）


class SKA(torch.nn.Module):
    """
    小核聚合模块（Small Kernel Aggregation, SKA）：封装SkaFn为PyTorch模块
    功能：提供简洁的模块接口，便于集成到神经网络中（前向传播直接调用SkaFn）
    """

    def forward(self, x: torch.Tensor, w: torch.Tensor) -> torch.Tensor:
        # 调用自定义自动求导函数的apply方法，执行前向传播
        return SkaFn.apply(x, w)  # type: ignore


class Conv2d_BN(torch.nn.Sequential):
    """
    卷积+批量归一化（Conv2d + BatchNorm2d）的集成模块
    功能：将卷积层与BN层封装为一个序列，减少重复代码；支持参数初始化与层融合（推理优化）
    """

    def __init__(self, a, b, ks=1, stride=1, pad=0, dilation=1,
                 groups=1, bn_weight_init=1):
        """
        Args:
            a (int): 卷积层输入通道数
            b (int): 卷积层输出通道数
            ks (int): 卷积核大小（默认1，即1×1卷积）
            stride (int): 卷积步长（默认1）
            pad (int): 卷积填充（默认0）
            dilation (int): 卷积膨胀率（默认1）
            groups (int): 分组卷积组数（默认1，即普通卷积）
            bn_weight_init (int): BN层权重初始化值（默认1，确保初始时BN不改变特征）
        """
        super().__init__()
        # 添加卷积层（无偏置，因BN层已包含偏置）
        self.add_module('c', torch.nn.Conv2d(
            a, b, ks, stride, pad, dilation, groups, bias=False))
        # 添加BN层
        self.add_module('bn', torch.nn.BatchNorm2d(b))
        # 初始化BN层参数：权重=bn_weight_init，偏置=0
        torch.nn.init.constant_(self.bn.weight, bn_weight_init)
        torch.nn.init.constant_(self.bn.bias, 0)

    @torch.no_grad()  # 禁用梯度计算（仅用于推理阶段的层融合）
    def fuse(self):
        """
        融合卷积层与BN层：将BN的参数（均值、方差、权重、偏置）整合到卷积层中，
        生成一个等效的卷积层，减少推理时的计算量（避免BN的逐元素操作）
        Returns:
            m (torch.nn.Conv2d): 融合后的卷积层
        """
        c, bn = self._modules.values()  # 获取卷积层（c）和BN层（bn）
        # 计算融合后的卷积权重：BN权重 / sqrt(BN方差 + eps)，再与卷积权重相乘
        w = bn.weight / (bn.running_var + bn.eps) ** 0.5
        w = c.weight * w[:, None, None, None]  # 扩展维度以匹配卷积权重形状（[B, C, KH, KW]）
        # 计算融合后的卷积偏置：BN偏置 - (BN均值 * BN权重) / sqrt(BN方差 + eps)
        b = bn.bias - bn.running_mean * bn.weight / (bn.running_var + bn.eps) ** 0.5
        # 构建融合后的卷积层（参数与原卷积层一致）
        m = torch.nn.Conv2d(
            in_channels=w.size(1) * self.c.groups,  # 输入通道数（考虑分组卷积）
            out_channels=w.size(0),  # 输出通道数
            kernel_size=w.shape[2:],  # 卷积核大小
            stride=self.c.stride,
            padding=self.c.padding,
            dilation=self.c.dilation,
            groups=self.c.groups,
            device=c.weight.device  # 保持设备一致性
        )
        # 复制融合后的权重与偏置到新卷积层
        m.weight.data.copy_(w)
        m.bias.data.copy_(b)
        return m


class LKP(nn.Module):
    """
    大核生成模块（Large Kernel Predictor, LKP）：从输入特征图动态生成小卷积核
    功能：通过“卷积+激活+深度可分离卷积”的组合，提取输入特征的全局信息，
    生成适配SKA的动态小核（形状：[B, D//G, KS², H, W]，D为输入通道数，G为分组数）
    """

    def __init__(self, dim, lks, sks, groups):
        """
        Args:
            dim (int): 输入特征图的通道数（D）
            lks (int): 大卷积核的尺寸（用于提取全局信息，如7表示7×7深度可分离卷积）
            sks (int): 小卷积核的尺寸（用于SKA，如3表示3×3核，输出KS²=9个核元素）
            groups (int): 卷积核的分组数（G，用于SKA的分组卷积）
        """
        super().__init__()
        # 通道压缩与特征提取：1×1卷积（dim→dim//2）→ ReLU → 7×7深度可分离卷积 → 1×1卷积 → ReLU
        self.cv1 = Conv2d_BN(dim, dim // 2)  # 通道压缩：dim→dim//2
        self.act = nn.ReLU()  # 引入非线性，增强特征表达
        # 7×7深度可分离卷积（groups=dim//2）：提取全局空间信息，不增加参数量
        self.cv2 = Conv2d_BN(dim // 2, dim // 2, ks=lks, pad=(lks - 1) // 2, groups=dim // 2)
        self.cv3 = Conv2d_BN(dim // 2, dim // 2)  # 进一步精炼特征

        # 核生成：1×1卷积将通道数转换为“SK² × (dim//groups)”（SK²为小核元素数，dim//groups为分组通道数）
        self.cv4 = nn.Conv2d(dim // 2, sks ** 2 * dim // groups, kernel_size=1)
        # 分组归一化：对生成的核进行归一化，稳定核的数值范围
        self.norm = nn.GroupNorm(num_groups=dim // groups, num_channels=sks ** 2 * dim // groups)

        self.sks = sks  # 保存小核尺寸（SK）
        self.groups = groups  # 保存分组数（G）
        self.dim = dim  # 保存输入通道数（D）

    def forward(self, x):
        """
        前向传播：生成动态小卷积核
        Args:
            x (torch.Tensor): 输入特征图，形状 [B, dim, H, W]
        Returns:
            w (torch.Tensor): 动态小卷积核，形状 [B, dim//groups, SK², H, W]
        """
        # 特征提取与通道调整：cv1→act→cv2→cv3→act
        x = self.act(self.cv3(self.cv2(self.act(self.cv1(x)))))
        # 核生成与归一化：cv4（生成SK²×(dim//G)通道）→ norm（分组归一化）
        w = self.norm(self.cv4(x))
        b, _, h, width = w.size()  # 解析w的维度（b=B，h=H，width=W）
        # 调整核的形状：[B, SK²×(dim//G), H, W] → [B, dim//G, SK², H, W]（适配SKA的输入要求）
        w = w.view(b, self.dim // self.groups, self.sks ** 2, h, width)
        return w


class LSConv(nn.Module):
    """
    大核-小核卷积模块（Large-Small Convolution, LSConv）
    核心设计：通过LKP生成动态小核，再通过SKA应用小核进行卷积，结合残差连接与BN，
    实现“大核全局信息捕捉+小核高效计算”的平衡
    """

    def __init__(self, dim):
        """
        Args:
            dim (int): 输入/输出特征图的通道数（确保模块输入输出维度一致，便于级联）
        """
        super(LSConv, self).__init__()
        # 大核生成模块：lks=7（7×7大核提取全局信息），sks=3（3×3小核用于SKA），groups=8（分组数）
        self.lkp = LKP(dim, lks=7, sks=3, groups=8)
        # 小核聚合模块：应用动态小核进行卷积
        self.ska = SKA()
        # 批量归一化：对SKA的输出进行归一化，稳定训练
        self.bn = nn.BatchNorm2d(dim)

    def forward(self, x):
        """
        前向传播流程：生成动态小核→SKA卷积→BN→残差融合
        Args:
            x (torch.Tensor): 输入特征图，形状 [B, dim, H, W]
        Returns:
            torch.Tensor: 输出特征图，形状 [B, dim, H, W]（与输入一致）
        """
        # 步骤1：LKP生成动态小核w（[B, dim//8, 9, H, W]）
        w = self.lkp(x)
        # 步骤2：SKA应用小核w计算卷积输出→BN归一化→与原始输入x残差融合
        return self.bn(self.ska(x, w)) + x


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    x = torch.randn(1, 64, 32, 32).to(device)
    model = LSConv(dim=64)
    model = model.to(device)
    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("知乎、CSDN：十小大")
    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)
