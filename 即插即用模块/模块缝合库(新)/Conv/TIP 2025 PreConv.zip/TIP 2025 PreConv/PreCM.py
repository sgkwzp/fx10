import torch
import torch.nn as nn
import torch.nn.functional as F


class PreCM1(nn.Module):
    """
    PreCM1（旋转等变卷积变体1）：通过输入图像旋转拼接+共享卷积核，实现旋转等变性
    核心逻辑：将输入图像旋转为4个方向（0°、90°、180°、270°），拼接后统一卷积，
    确保不同旋转角度的输入对应一致的特征输出，适配语义分割中图像方向任意性问题
    """

    def __init__(self,
                 in_channels: int,
                 out_channels: int,
                 kernel_size: int,
                 stride: int,
                 dilation: int,
                 groups: int = 1,
                 bias: int = 0
                 ):
        """
        Args:
            in_channels (int): 输入特征图通道数（需与上游模块输出一致）
            out_channels (int): 输出特征图通道数（确保与输入通道数适配，支持即插即用）
            kernel_size (int): 卷积核大小（如3表示3×3卷积）
            stride (int): 卷积步长（默认1，确保输出尺寸与输入匹配）
            dilation (int): 卷积膨胀率（默认1，支持扩张卷积场景）
            groups (int): 分组卷积组数（默认1，=in_channels时为深度可分离卷积）
            bias (bool): 是否使用卷积偏置（默认0，即False，避免参数冗余）
        """
        super(PreCM1, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.kernel_size = kernel_size
        self.stride = stride
        self.groups = groups
        self.dilation = dilation
        self.bias = bias  # 未实际使用，预留扩展

        # 初始化卷积核参数：形状[out_channels, in_channels//groups, kernel_size, kernel_size]
        # 所有旋转方向共享同一卷积核，确保旋转等变性
        weight_tensor = torch.Tensor(out_channels, in_channels // groups, kernel_size, kernel_size).float()
        self.weight0 = nn.Parameter(weight_tensor)

        # 测试用卷积层（未实际参与前向，预留用于参数初始化校验）
        self.convtest = nn.Conv2d(in_channels // groups, out_channels, kernel_size, bias=False)

    def forward(self, input, output_shape):
        """
        前向传播流程：计算自适应填充→输入旋转拼接→填充→卷积→输出
        Args:
            input (torch.Tensor): 输入特征图，形状 [B, C, H, W]（B=批量，C=通道，H=高度，W=宽度）
            output_shape (list): 目标输出尺寸 [H_out, W_out]（确保卷积后尺寸匹配）
        Returns:
            torch.Tensor: 输出特征图，形状 [4B, out_channels, H_out, W_out]（4倍批量对应4个旋转方向）
        """
        ho, wo = output_shape[0], output_shape[1]  # 目标输出高、宽
        b, c, h, w = input.shape  # 解析输入维度

        # 步骤1：计算自适应填充（确保卷积后输出尺寸为output_shape）
        # 填充公式推导：基于卷积输出尺寸公式 H_out = (H_in + 2P - D*(K-1) -1)/S +1
        # 反向计算需补充的填充量，分为上下（pab）和左右（prl）方向
        pab = (ho - 1) * self.stride + self.dilation * (self.kernel_size - 1) + 1 - h
        prl = (wo - 1) * self.stride + self.dilation * (self.kernel_size - 1) + 1 - w
        # 对称填充：上下、左右分别均分填充量，确保特征中心对齐
        pb = int(pab // 2)
        pl = int(prl // 2)
        pa = pab - pb  # 上填充量
        pr = prl - pl  # 右填充量
        padding = (pa, pb, pl, pr)  # 填充顺序：(上, 下, 左, 右)

        # 步骤2：输入图像旋转拼接（生成4个方向的输入，确保旋转等变性）
        # 旋转方向：0°（原图）、90°（k=-1）、180°（k=-2）、270°（k=-3），沿(H,W)维度旋转
        input_rot = torch.cat([
            input,
            torch.rot90(input, k=-1, dims=(2, 3)),  # 逆时针旋转90°
            torch.rot90(input, k=-2, dims=(2, 3)),  # 逆时针旋转180°
            torch.rot90(input, k=-3, dims=(2, 3))  # 逆时针旋转270°
        ], dim=0)  # 沿批量维度拼接，形状变为[4B, C, H, W]

        # 步骤3：填充+卷积（共享卷积核，确保不同旋转方向特征一致）
        return F.conv2d(
            F.pad(input_rot, padding),  # 对旋转拼接后的输入进行填充
            weight=self.weight0,  # 共享卷积核
            bias=None,  # 无偏置
            stride=self.stride,
            groups=self.groups  # 分组卷积（如需）
        )


class PreCM2(nn.Module):
    """
    PreCM2（旋转等变卷积变体2）：通过4组独立卷积核分别处理旋转方向，再旋转融合
    核心逻辑：使用4×out_channels的卷积核（对应4个旋转方向），卷积后将各方向结果旋转回原方向并求和，
    相比PreCM1减少批量维度扩张，直接输出与输入批量一致的特征图
    """

    def __init__(self,
                 in_channels: int,
                 out_channels: int,
                 kernel_size: int,
                 stride: int,
                 dilation: int = 1,
                 groups: int = 1,
                 bias: int = 0,
                 ):
        super().__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.kernel_size = kernel_size
        self.stride = stride
        self.dilation = dilation
        self.groups = groups
        self.bias = bias  # 未实际使用

        # 初始化4组卷积核：形状[4×out_channels, in_channels//groups, kernel_size, kernel_size]
        # 4组核分别对应4个旋转方向的特征提取
        weight_tensor0 = torch.Tensor(4 * out_channels, in_channels // groups, kernel_size, kernel_size).float()
        self.weight0 = nn.Parameter(weight_tensor0)

        # 测试用卷积层（未实际参与前向，预留用于参数校验）
        self.convtest = nn.Conv2d(in_channels // groups, out_channels * 4, kernel_size)

    def forward(self, input: torch.Tensor, output_shape: list):
        """
        前向传播流程：计算自适应填充→多方向卷积→旋转融合→拼接输出
        Args:
            input (torch.Tensor): 输入特征图 [B, C, H, W]
            output_shape (list): 目标输出尺寸 [H_out, W_out]
        Returns:
            torch.Tensor: 输出特征图 [B, out_channels, H_out, W_out]（与输入批量一致）
        """
        ho, wo = output_shape[0], output_shape[1]
        b, c, h, w = input.shape

        # 步骤1：计算自适应填充（与PreCM1逻辑一致）
        pab = (ho - 1) * self.stride + self.dilation * (self.kernel_size - 1) + 1 - h
        prl = (wo - 1) * self.stride + self.dilation * (self.kernel_size - 1) + 1 - w
        pb = int(pab // 2)
        pl = int(prl // 2)
        pa = pab - pb
        pr = prl - pl
        padding = (pa, pb, pl, pr)

        # 步骤2：多方向卷积（用4组核同时处理输入，输出形状[B, 4×out_channels, H_out, W_out]）
        out2 = F.conv2d(
            F.pad(input, padding),
            weight=self.weight0,
            bias=None,
            stride=self.stride,
            dilation=self.dilation,
            groups=self.groups
        )

        # 步骤3：旋转融合（将4组核的输出旋转回原方向并求和，确保旋转等变性）
        batch = b  # 输入批量大小（PreCM2不扩张批量）
        oc = self.out_channels  # 单方向输出通道数
        out2list = []

        # 遍历4个旋转方向，对每个方向的输出进行旋转融合
        for i in range(4):
            # 每个方向的输出 = 4组核输出旋转后求和
            fused = (
                # 核组0的输出旋转i次（对应原方向）
                    torch.rot90(out2[:, i % 4 * oc: (i % 4 + 1) * oc, :, :], k=i, dims=(2, 3)) +
                    # 核组1的输出旋转(i-1)次（补偿核组1的旋转偏移）
                    torch.rot90(out2[:, (i - 1) % 4 * oc: ((i - 1) % 4 + 1) * oc, :, :], k=(i - 1), dims=(2, 3)) +
                    # 核组2的输出旋转(i-2)次
                    torch.rot90(out2[:, (i - 2) % 4 * oc: ((i - 2) % 4 + 1) * oc, :, :], k=(i - 2), dims=(2, 3)) +
                    # 核组3的输出旋转(i-3)次
                    torch.rot90(out2[:, (i - 3) % 4 * oc: ((i - 3) % 4 + 1) * oc, :, :], k=(i - 3), dims=(2, 3))
            )
            out2list.append(fused)

        # 步骤4：拼接输出（4个方向结果沿批量维度拼接，实际使用时可按需选择单方向或多方向）
        return torch.cat(out2list, dim=0)


class PreCM3(nn.Module):
    """
    PreCM3（旋转等变卷积变体3）：复用预训练卷积核（如测试用convtest的权重），简化旋转融合逻辑
    核心逻辑：输入批量拆分为4份（对应4个旋转方向），卷积后直接旋转求和，适配已有预训练模型的权重迁移
    """

    def __init__(self,
                 in_channels: int,
                 out_channels: int,
                 kernel_size: int,
                 stride: int,
                 dilation: int = 1,
                 bias: int = 0,
                 groups: int = 1
                 ):
        super(PreCM3, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.kernel_size = kernel_size
        self.stride = stride
        self.dilation = dilation
        self.bias = bias
        self.groups = groups

        # 初始化卷积核（未实际使用，复用convtest的权重）
        weight_tensor = torch.Tensor(out_channels, in_channels // groups, kernel_size, kernel_size).float()
        self.weight0 = nn.Parameter(weight_tensor)

        # 预训练卷积层（核心：复用其权重进行卷积，支持权重迁移）
        self.convtest = nn.Conv2d(in_channels // groups, out_channels, kernel_size)

    def forward(self, input: torch.Tensor, output_shape):
        """
        前向传播流程：计算自适应填充→预训练核卷积→批量拆分→旋转求和
        Args:
            input (torch.Tensor): 输入特征图 [4B, C, H, W]（批量需为4的倍数，对应4个旋转方向）
            output_shape (list): 目标输出尺寸 [H_out, W_out]
        Returns:
            torch.Tensor: 输出特征图 [B, out_channels, H_out, W_out]（旋转融合后批量恢复）
        """
        ho, wo = output_shape[0], output_shape[1]
        b, c, h, w = input.shape

        # 步骤1：计算自适应填充（与PreCM1/2逻辑一致）
        pab = (ho - 1) * self.stride + self.dilation * (self.kernel_size - 1) + 1 - h
        prl = (wo - 1) * self.stride + self.dilation * (self.kernel_size - 1) + 1 - w
        pb = int(pab // 2)
        pl = int(prl // 2)
        pa = pab - pb
        pr = prl - pl
        padding = (pa, pb, pl, pr)

        # 步骤2：预训练核卷积（复用convtest的权重，避免重新初始化）
        out3 = F.conv2d(
            F.pad(input, padding),
            weight=self.convtest.weight,  # 复用预训练权重
            bias=None,
            stride=self.stride,
            groups=self.groups
        )

        # 步骤3：批量拆分与旋转求和（输入批量4B拆分为4份，对应4个旋转方向）
        batch = b // 4  # 单旋转方向的批量大小
        return (
                torch.rot90(out3[0 * batch: 1 * batch], k=0, dims=(2, 3)) +  # 0°（不旋转）
                torch.rot90(out3[1 * batch: 2 * batch], k=1, dims=(2, 3)) +  # 顺时针旋转90°（k=1）
                torch.rot90(out3[2 * batch: 3 * batch], k=2, dims=(2, 3)) +  # 旋转180°
                torch.rot90(out3[3 * batch: 4 * batch], k=3, dims=(2, 3))  # 顺时针旋转270°
        )

if __name__ == '__main__':
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    x = torch.randn(4, 64, 32, 32).to(device)
    out1 = PreCM1(64, 64, 3, 1, 1).to(device)
    out2 = PreCM2(64, 64, 3, 1, 1).to(device)
    out3 = PreCM3(64, 64, 3, 1, 1).to(device)
    out1 = out1(x, [32, 32])
    out2 = out2(out1, [32, 32])
    out3 = out3(out2, [32, 32])

    print("微信公众号：十小大的底层视觉工坊")
    print("知乎、CSDN：十小大")
    print("输入特征维度：", x.shape)
    print("输出特征维度1：", out1.shape)
    print("输出特征维度2：", out2.shape)
    print("输出特征维度3：", out3.shape)

