import math
import torch
import numpy as np
import torch.nn as nn
from shiftadd.ops import AddShift_mp_module

use_sync_bn = True
def get_bn(channels):
    if use_sync_bn:
        return nn.SyncBatchNorm(channels)
    else:
        return nn.BatchNorm2d(channels)

class ShifthWiseConv2dImplicit(nn.Module):
    '''
    隐式移位卷积模块（SWConv核心实现）
    核心思想：通过"小卷积核+特征移位"模拟大卷积核效果，降低计算复杂度
    输入：特征图 [B, C_in, H, W]（B=批次，C_in=输入通道，H/W=特征图高/宽）
    输出：特征图 [B, C_out, H, W]（与输入尺寸一致，通道数通过拼接恢复）
    关键创新：
        1. Ghost特征拆分：将输入通道分为"移位组（rep）"和"静态组（ghost）"，降低计算量
        2. 多路径小卷积：通过LoRA分支生成多路径特征，配合移位操作覆盖大核感受野
        3. 残差融合：移位特征与原始特征残差连接，保留局部细节
    '''

    def __init__(self,
                 in_channels,
                 out_channels,
                 big_kernel,  # 目标模拟的大卷积核尺寸（如51）
                 small_kernel=3,  # 实际使用的小卷积核尺寸（如3）
                 stride=1,  # 卷积步长（默认1，保持特征尺寸）
                 group=1,  # 分组卷积参数（默认1，可设为通道数实现深度可分离）
                 bn=True,  # 是否使用批量归一化
                 use_small_conv=True,  # 是否启用小卷积分支（默认启用）
                 ghost_ratio=0.23,  # Ghost通道比例（静态组占比，默认23%）
                 N_path=2,  # 多路径数量（LoRA分支数，默认2）
                 N_rep=4,  # 特征拆分次数（多拆分增强移位覆盖度，默认4）
                 bias=False):  # 卷积是否使用偏置（默认不使用，BN已中心化）
        super().__init__()
        self.kernels = (small_kernel, big_kernel)  # 记录小核与目标大核尺寸
        self.stride = stride
        # 计算 padding：确保小卷积后特征尺寸不变，同时适配大核移位需求
        padding, real_pad = self.shift(self.kernels)
        self.pad = padding, real_pad  # padding=小核-1，real_pad=各移位路径的额外padding

        # 计算大核需拆分为多少个小核（nk=大核尺寸//小核尺寸，向上取整）
        self.nk = math.ceil(big_kernel / small_kernel)

        # 1. Ghost特征拆分：将输入通道分为"移位组（rep）"和"静态组（ghost）"
        ghostN = int(in_channels * ghost_ratio)  # 静态组通道数（不参与移位，降低计算）
        repN = in_channels - ghostN  # 移位组通道数（参与小卷积+移位）
        # 随机选择静态组通道（固定随机种子123，确保训练可复现）
        np.random.seed(123)
        ghost = np.random.choice(in_channels, ghostN, replace=False).tolist()
        ghost.sort()  # 排序便于索引
        rep = list(set(range(in_channels)) - set(ghost))  # 移位组通道（补集）
        rep.sort()
        assert len(rep) == repN, f'移位组通道数不匹配：实际{len(rep)}，预期{repN}'
        # 存储静态组和移位组的通道索引（后续通过index_select拆分）
        self.ghost = torch.IntTensor(ghost)
        self.rep = torch.IntTensor(rep)

        # 2. 多路径小卷积分支（LoRA分支）：生成多路径特征用于移位
        out_n = repN * self.nk  # 单路径输出通道数（移位组通道×小核数量）
        self.LoRA = None  # 合并后的LoRA卷积（初始为None，merge_branches后生效）
        # 初始化N_path个LoRA分支（每个分支为分组卷积，避免通道间干扰）
        self.LoRAs = nn.ModuleList([
            nn.Conv2d(repN, out_n,
                      kernel_size=small_kernel, stride=stride,
                      padding=padding, groups=repN,  # 分组卷积=深度可分离，降低计算
                      bias=False)
            for _ in range(N_path)
        ])

        self.device = None  # 设备记录（自动适配GPU/CPU）
        print(f'ghost_ratio={ghost_ratio},N_rep={N_rep},N_path={N_path}')  # 打印配置信息

        # 3. 批量归一化配置：对各路径输出单独BN，增强稳定性
        self.use_bn = bn
        # 自定义移位加法模块：实现多路径特征移位与拆分（核心算子）
        self.loras = AddShift_mp_module(big_kernel, small_kernel, repN, out_n, N_rep)
        if bn:
            # 三个路径的BN层（lora1/lora2为移位路径，small为小卷积路径）
            self.bn_lora1 = get_bn(repN)
            self.bn_lora2 = get_bn(repN)
            self.bn_small = get_bn(repN)
        else:
            self.bn_lora1 = None
            self.bn_lora2 = None
            self.bn_small = None

        self.inputsize = True  # 标记是否首次输入（用于打印输入尺寸）

    def ghost_mask(self):
        """
        Ghost掩码生成：通过卷积权重绝对值之和，筛选无效通道（权重为0的通道）
        功能：抑制静态组中无贡献的通道，降低冗余计算
        返回：掩码 [1, repN, 1, 1]（1表示有效通道，0表示无效通道）
        """
        weight = 0
        # 累加所有4D卷积权重的绝对值（通道维度求和）
        for name, tensor in self.named_parameters():
            if len(tensor.size()) == 4:  # 仅处理卷积权重
                weight += torch.sum(torch.abs(tensor.detach()), (1, 2, 3))
        # 按小核数量分组，判断每组是否有有效权重（>0）
        weight = torch.sum((weight > 0).reshape(-1, self.nk), 1)
        # 生成掩码：无效通道（weight==0）设为0，有效通道设为1
        ghost = (weight == 0).reshape(1, -1, 1, 1).float()
        return ghost

    def forward(self, inputs):
        """
        前向传播流程：特征拆分→多路径小卷积→特征移位→BN→残差融合→通道拼接
        """
        # 首次输入时打印尺寸信息（仅打印一次）
        if self.inputsize:
            print(f'shape:{inputs.shape}; kernel:{self.kernels}')
            self.inputsize = False

        # 解析输入维度
        ori_b, ori_c, ori_h, ori_w = inputs.shape

        # 自动适配设备（GPU/CPU）：首次前向时将通道索引移至对应设备
        if self.device is None:
            self.device = inputs.get_device()
            if self.device == -1:  # CPU设备
                self.device = None
            else:  # GPU设备
                self.ghost = self.ghost.to(self.device)
                self.rep = self.rep.to(self.device)

        # 1. 特征拆分：按通道索引分为静态组（ghost）和移位组（rep）
        ghost_inputs = torch.index_select(inputs, 1, self.ghost)  # [B, ghostN, H, W]（不参与移位）
        rep_inputs = torch.index_select(inputs, 1, self.rep)  # [B, repN, H, W]（参与移位）

        # 2. 多路径小卷积计算：LoRA分支生成多路径特征
        lora1_x = 0  # 移位路径1输出
        lora2_x = 0  # 移位路径2输出
        small_x = 0  # 小卷积路径输出
        out = 0  # 多路径LoRA特征累加结果

        # 若未合并LoRA分支：累加所有LoRA分支的输出（多路径融合）
        if self.LoRA is None:
            for ii, split_conv in enumerate(self.LoRAs):
                xx = split_conv(rep_inputs)  # 单路径小卷积：[B, out_n, H, W]
                out += xx  # 多路径特征累加
        else:
            # 若已合并LoRA分支：直接使用合并后的卷积（推理时加速）
            out = self.LoRA(rep_inputs)

        # 3. 特征移位操作：通过AddShift_mp_module拆分移位路径与小卷积路径
        # 输入：多路径特征out；输出：lora1_x（移位路径1）、lora2_x（移位路径2）、small_x（小卷积路径）
        x1, x2, x3 = self.loras(out, ori_b, ori_h, ori_w)
        lora1_x += x1
        lora2_x += x2
        small_x += x3

        # 4. 批量归一化：对各路径输出单独BN（增强稳定性）
        if self.use_bn:
            lora1_x = self.bn_lora1(lora1_x)
            lora2_x = self.bn_lora2(lora2_x)
            small_x = self.bn_small(small_x)

        # 5. 残差融合：移位路径+小卷积路径+原始移位组特征（保留局部细节）
        # 注：原始代码注释中包含ghost_mask抑制无效通道的逻辑，可按需启用
        x = lora1_x + lora2_x + small_x + rep_inputs

        # 6. 通道拼接：将移位组结果与静态组特征拼接，恢复输入通道数
        x = torch.cat([x, ghost_inputs], dim=1)  # [B, repN+ghostN, H, W] = [B, in_channels, H, W]

        return x

    def shift(self, kernels):
        '''
        移位参数计算：根据小核与大核尺寸，计算padding和各路径的额外移位padding
        核心逻辑：确保小卷积+移位后，感受野与大核一致，且特征尺寸不变
        参数：kernels - (small_kernel, big_kernel)
        返回：padding（小卷积padding）、real_pad（各移位路径的额外padding）
        '''
        mink, maxk = min(kernels), max(kernels)  # 小核、大核尺寸
        nk = math.ceil(maxk / mink)  # 大核拆分为nk个小核

        # 小卷积padding：设为mink-1，确保小卷积后特征尺寸不变（stride=1时）
        padding = mink - 1

        # 计算各移位路径的额外padding：确保移位后覆盖大核的所有位置
        mid = maxk // 2  # 大核中心点位置
        real_pad = []
        for i in range(nk):
            # 额外padding = 大核中心 - 第i个小核的中心 - 小卷积padding
            extra_pad = mid - i * mink - padding
            real_pad.append(extra_pad)

        return padding, real_pad

    def merge_branches(self):
        """
        LoRA分支合并：将多路径LoRA卷积合并为单个卷积（推理阶段加速）
        功能：训练时用多路径增强鲁棒性，推理时合并为单路径减少计算量
        """
        if self.LoRA is None:
            # 确定合并后卷积的参数（与单LoRA分支一致）
            bias = True if self.LoRAs[0].bias else False
            LoRA = nn.Conv2d(in_channels=self.LoRAs[0].in_channels,
                             out_channels=self.LoRAs[0].out_channels,
                             kernel_size=self.LoRAs[0].kernel_size,
                             stride=self.LoRAs[0].stride,
                             padding=self.LoRAs[0].padding,
                             dilation=self.LoRAs[0].dilation,
                             groups=self.LoRAs[0].groups,
                             bias=bias
                             )
            # 累加所有LoRA分支的权重和偏置
            weight, biasdata = 0, 0
            for merged_conv in self.LoRAs:
                weight += merged_conv.weight.data
                if bias:
                    biasdata += merged_conv.bias.data
            # 赋值合并后的权重和偏置
            LoRA.weight.data = weight
            if bias:
                LoRA.bias.data = biasdata
            # 替换为合并后的LoRA卷积，并删除原多路径分支
            self.LoRA = LoRA
            self.__delattr__('LoRAs')

if __name__ == '__main__':
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    x = torch.randn(1, 64, 32, 32).to(device)

    in_channels = 64
    out_channels = 64
    big_kernel = 51
    small_kernel = 3
    stride = 1
    group = 64
    bn = True
    ghost_ratio = 0.23
    N_path = 2
    N_rep = 4
    swconv = ShifthWiseConv2dImplicit(in_channels=in_channels, out_channels=out_channels,
                                    big_kernel=big_kernel, small_kernel=small_kernel,
                                    stride=stride, group=group, bn=bn,
                                    ghost_ratio=ghost_ratio, N_path=N_path, N_rep=N_rep
                                    ).to(device)
    y = swconv(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("知乎、CSDN：十小大")
    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)