import torch
import torch.nn as nn

class HLKConv(nn.Module):
    def __init__(self, dim, k_size):
        super().__init__()

        self.k_size = k_size

        if k_size == 7:
            self.conv0 = nn.Conv2d(dim, dim, kernel_size=3, stride=1, padding=((3-1)//2), groups=dim)
            self.conv_spatial = nn.Conv2d(dim, dim, kernel_size=3, stride=1, padding=2, groups=dim, dilation=2)
        elif k_size == 11:
            self.conv0 = nn.Conv2d(dim, dim, kernel_size=3, stride=1, padding=((3-1)//2), groups=dim)
            self.conv_spatial = nn.Conv2d(dim, dim, kernel_size=5, stride=1, padding=4, groups=dim, dilation=2)
        elif k_size == 23:
            self.conv0 = nn.Conv2d(dim, dim, kernel_size=5, stride=1, padding=((5-1)//2), groups=dim)
            self.conv_spatial = nn.Conv2d(dim, dim, kernel_size=7, stride=1, padding=9, groups=dim, dilation=3)
        elif k_size == 35:
            self.conv0 = nn.Conv2d(dim, dim, kernel_size=5, stride=1, padding=((5-1)//2), groups=dim)
            self.conv_spatial = nn.Conv2d(dim, dim, kernel_size=11, stride=1, padding=15, groups=dim, dilation=3)
        elif k_size == 41:
            self.conv0 = nn.Conv2d(dim, dim, kernel_size=5, stride=1, padding=((5-1)//2), groups=dim)
            self.conv_spatial = nn.Conv2d(dim, dim, kernel_size=13, stride=1, padding=18, groups=dim, dilation=3)
        elif k_size == 53:
            self.conv0 = nn.Conv2d(dim, dim, kernel_size=5, stride=1, padding=((5-1)//2), groups=dim)
            self.conv_spatial = nn.Conv2d(dim, dim, kernel_size=17, stride=1, padding=24, groups=dim, dilation=3)

        self.conv1 = nn.Conv2d(dim * 2, dim, 1)


    def forward(self, x):
        x = self.conv0(x)
        x = self.conv1(torch.cat([x, self.conv_spatial(x)], dim=1))
        return x

if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    x = torch.randn(1, 64, 32, 32).to(device)

    model = HLKConv(64, 53).to(device)
    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("VX: shixiaodayyds, 备注【即插即用】添加交流群")
    print("知乎、CSDN：十小大")
    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)
