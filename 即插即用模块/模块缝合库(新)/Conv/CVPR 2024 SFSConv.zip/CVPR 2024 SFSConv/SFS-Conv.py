'''
模块出处：Unleashing Channel Potential: Space-Frequency Selection Convolution for SAR Object Detection
文章链接：https://openaccess.thecvf.com/content/CVPR2024/papers/Li_Unleashing_Channel_Potential_Space-Frequency_Selection_Convolution_for_SAR_Object_Detection_CVPR_2024_paper.pdf
完整源码：https://github.com/like413/SFS-Conv

微信公众号：十小大的底层视觉工坊
知乎、CSDN：十小大
'''

import math
import numpy as np
import thop
import torch
import torch.nn as nn
import torch.nn.functional as F


def autopad(k, p=None, d=1):
    """
    自动计算卷积 padding 以实现“same”输出（输入输出尺寸一致）
    Args:
        k: 卷积核大小（int或tuple）
        p: 手动指定的padding（默认None，自动计算）
        d: 卷积 dilation 率
    Returns:
        计算后的padding（tuple）
    """
    # 当使用 dilation 时，等效核大小 = d*(k-1)+1
    if d > 1:
        k = d * (k - 1) + 1 if isinstance(k, int) else [d * (x - 1) + 1 for x in k]
    # 自动padding = 核大小//2（确保same输出）
    if p is None:
        p = k // 2 if isinstance(k, int) else [x // 2 for x in k]
    return p


class Conv(nn.Module):
    """
    基础卷积块：Conv2d + BatchNorm2d + 激活函数
    统一实现标准卷积流程，支持分组卷积、dilation、自定义激活
    """
    default_act = nn.SiLU()  # 默认激活函数（SiLU，适配现代CNN设计）

    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, d=1, act=True):
        """
        Args:
            c1: 输入通道数
            c2: 输出通道数
            k: 卷积核大小
            s: 步长
            p: padding（默认自动计算）
            g: 分组数（1=标准卷积，g=c1=c2=深度卷积）
            d: dilation率
            act: 激活函数（True=默认SiLU，None=无激活，或自定义Module）
        """
        super().__init__()
        self.conv = nn.Conv2d(
            c1, c2, k, s, autopad(k, p, d), groups=g, dilation=d, bias=False  # 无偏置（BN已包含）
        )
        self.bn = nn.BatchNorm2d(c2)  # 批量归一化，稳定训练
        # 激活函数选择
        self.act = (
            self.default_act
            if act is True
            else act
            if isinstance(act, nn.Module)
            else nn.Identity()  # 无激活时用恒等映射
        )

    def forward(self, x):
        """前向传播：卷积 → 归一化 → 激活"""
        x = self.conv(x)
        x = self.bn(x)
        x = self.act(x)
        return x


class ChannelAttention(nn.Module):
    """
    通道注意力模块（简化版）
    原理：全局平均池化（GAP）压缩空间信息 → Sigmoid生成通道权重
    """

    def __init__(self):
        super().__init__()
        self.pool = nn.AdaptiveAvgPool2d(1)  # GAP：(B,C,H,W)→(B,C,1,1)
        self.act = nn.Sigmoid()  # 归一化权重到[0,1]

    def forward(self, x: torch.Tensor):
        """生成通道权重并与输入相乘"""
        return self.act(self.pool(x))


class SpatialAttention(nn.Module):
    """
    空间注意力模块（简化版）
    原理：通道维度求均值+最大值 → 拼接 → 1×1卷积压缩 → Sigmoid生成空间权重
    """

    def __init__(self, kernel_size=3):
        super().__init__()
        # 根据核大小自动选择padding（7×7核用3 padding，3×3核用1 padding）
        padding = 3 if kernel_size == 7 else 1
        self.cv1 = nn.Conv2d(2, 1, kernel_size, padding=padding, bias=False)  # 2输入（均值+最大值）→1输出
        self.act = nn.Sigmoid()

    def forward(self, x):
        """生成空间权重并与输入相乘"""
        # 通道维度求均值和最大值（保留空间维度）
        avg_out = torch.mean(x, 1, keepdim=True)
        max_out = torch.max(x, 1, keepdim=True)[0]
        # 拼接后卷积+激活，生成空间权重
        x = self.cv1(torch.cat([avg_out, max_out], 1))
        return self.act(x)


class FractionalGaborFilter(nn.Module):
    """
    分数阶Gabor滤波器（FrGT核心）
    功能：生成多角度、多尺度的Gabor核，捕捉频率域纹理/边缘特征
    注：代码中简化实现，仅保留实部（注释中包含虚部逻辑，可扩展）
    """

    def __init__(self, in_channels, out_channels, kernel_size, order, angles, scales):
        """
        Args:
            in_channels: 输入通道数
            out_channels: 输出通道数
            kernel_size: 滤波器核大小（tuple，如(3,3)）
            order: 分数阶参数（控制Gabor核形状，默认0.25）
            angles: 滤波器角度列表（如[0,45,90,135]，捕捉不同方向特征）
            scales: 滤波器尺度列表（如[1,2,3,4]，捕捉不同频率特征）
        """
        super().__init__()
        self.real_weights = nn.ParameterList()  # 实部权重列表（可训练）
        # self.imag_weights = nn.ParameterList()  # 虚部权重列表（注释，可扩展）

        # 为每个角度+尺度组合生成Gabor核
        for angle in angles:
            for scale in scales:
                # 生成分数阶Gabor核（仅实部）
                real_weight = self.generate_fractional_gabor(in_channels, out_channels, kernel_size, order, angle,
                                                             scale)
                self.real_weights.append(nn.Parameter(real_weight))  # 加入可训练参数列表
                # self.imag_weights.append(nn.Parameter(imag_weight))  # 虚部核（注释）

    def generate_fractional_gabor(self, in_channels, out_channels, size, order, angle, scale):
        """
        生成单个分数阶Gabor核
        公式：exp(-((xθ² + (yθ/scale)²)^order)) * cos(2πxθ/scale)
        其中xθ、yθ是旋转后的坐标（对应指定角度）
        """
        # 生成[-1,1]范围内的网格坐标（覆盖核大小）
        x, y = np.meshgrid(np.linspace(-1, 1, size[0]), np.linspace(-1, 1, size[1]))
        # 坐标旋转（根据angle调整方向）
        x_theta = x * np.cos(angle) + y * np.sin(angle)
        y_theta = -x * np.sin(angle) + y * np.cos(angle)
        # 计算Gabor核实部（高斯包络+余弦调制）
        real_part = np.exp(-((x_theta ** 2 + (y_theta / scale) ** 2) ** order)) * np.cos(2 * np.pi * x_theta / scale)
        # imag_part = np.exp(-((x_theta ** 2 + (y_theta / scale) ** 2) ** order)) * np.sin(2 * np.pi * x_theta / scale)  # 虚部（注释）

        # 重塑为(1,1,H,W)并扩展到输出通道数
        real_weight = torch.tensor(real_part, dtype=torch.float32).view(1, 1, size[0], size[1])
        real_weight = real_weight.repeat(out_channels, 1, 1, 1)  # (out_channels,1,H,W)
        return real_weight  # , imag_weight  # 返回实部（虚部注释）

    def forward(self, x):
        """前向传播：所有Gabor核加权求和"""
        real_weights = [weight for weight in self.real_weights]
        # imag_weights = [weight for weight in self.imag_weights]  # 虚部权重（注释）
        # 实部核与输入相乘并求和（简化版，未考虑通道维度匹配，后续由GaborSingle补充）
        real_result = sum(weight * x for weight in real_weights)
        # imag_result = sum(weight * x for weight in imag_weights)  # 虚部计算（注释）
        return real_result  # - imag_result  # 返回实部结果（虚部组合注释）


class GaborSingle(nn.Module):
    """
    单分支分数阶Gabor感知单元
    功能：将FractionalGaborFilter与可训练参数结合，实现频率域特征提取
    """

    def __init__(self, in_channels, out_channels, kernel_size, order, angles, scales):
        super().__init__()
        self.gabor = FractionalGaborFilter(in_channels, out_channels, kernel_size, order, angles, scales)
        # 可训练参数t（调整Gabor核与输入的适配性）
        self.t = nn.Parameter(
            torch.randn(out_channels, in_channels, kernel_size[0], kernel_size[1]),
            requires_grad=True,
        )
        nn.init.normal_(self.t)  # 正态分布初始化
        self.relu = nn.ReLU(inplace=True)  # 激活函数

    def forward(self, x):
        """前向传播：Gabor滤波 → 卷积 → 激活 →  dropout → 池化"""
        # Gabor核与可训练参数t结合
        out = self.gabor(self.t)
        # 卷积操作（使用结合后的Gabor核，same padding）
        out = F.conv2d(x, out, stride=1, padding=(out.shape[-2] - 1) // 2)
        out = self.relu(out)  # 激活
        out = F.dropout(out, 0.3)  # dropout正则化（概率0.3）
        out = F.pad(out, (1, 0, 1, 0), mode="constant", value=0)  # 左上各补1个0（调整尺寸）
        out = F.max_pool2d(out, 2, stride=1, padding=0)  # 2×2最大池化（步长1，无padding）
        return out


class GaborFPU(nn.Module):
    """
    分数阶Gabor频率感知单元（FPU的一种实现）
    功能：4分支并行Gabor滤波，捕捉多频率特征，支持残差连接
    """

    def __init__(self, in_channels, out_channels, order=0.25, angles=[0, 45, 90, 135], scales=[1, 2, 3, 4]):
        super().__init__()
        # 4分支GaborSingle（每分支处理1/4通道）
        self.gabor = GaborSingle(in_channels // 4, out_channels // 4, (3, 3), order, angles, scales)
        self.fc = nn.Conv2d(out_channels, out_channels, kernel_size=1)  # 1×1卷积（通道融合）

    def forward(self, x):
        """前向传播：通道拆分 → 4分支Gabor滤波 → 拼接 → 融合 → 残差连接"""
        # 通道拆分为4组（每组in_channels//4通道）
        channels_per_group = x.shape[1] // 4
        x1, x2, x3, x4 = torch.split(x, channels_per_group, 1)
        # 4分支并行处理后拼接
        x_out = torch.cat(
            [self.gabor(x1), self.gabor(x2), self.gabor(x3), self.gabor(x4)], dim=1
        )
        x_out = self.fc(x_out)  # 1×1卷积融合通道特征
        # 残差连接（通道数匹配时）
        if x.shape[1] == x_out.shape[1]:
            x_out = x_out + x
        return x_out


class FrFTFilter(nn.Module):
    """
    分数阶傅里叶变换滤波器（FrFT核心）
    功能：生成FrFT核，在频率域捕捉全局周期性特征
    """

    def __init__(self, in_channels, out_channels, kernel_size, f, order):
        """
        Args:
            f: 频率参数（控制频率捕捉范围）
            order: 分数阶参数（控制变换阶数，默认0.25）
        """
        super().__init__()
        # 生成FrFT核并注册为缓冲区（不可训练，固定频率特征）
        self.register_buffer(
            "weight",
            self.generate_FrFT_filter(in_channels, out_channels, kernel_size, f, order),
        )

    def generate_FrFT_filter(self, in_channels, out_channels, kernel, f, p):
        """
        生成FrFT滤波器核
        公式：cos(-f*X/sin(p) + (f²+X²)/(2*tan(p))) * 同Y方向项
        其中X、Y为核坐标，p为分数阶参数
        """
        N = out_channels  # 输出通道数
        d_x, d_y = kernel[0], kernel[1]  # 核的高、宽
        # 生成[1, d_x]和[1, d_y]的坐标
        x = np.linspace(1, d_x, d_x)
        y = np.linspace(1, d_y, d_y)
        X, Y = np.meshgrid(x, y)  # 网格坐标

        # 初始化X、Y方向FrFT核和最终核
        real_FrFT_filterX = np.zeros([d_x, d_y, out_channels])
        real_FrFT_filterY = np.zeros([d_x, d_y, out_channels])
        real_FrFT_filter = np.zeros([d_x, d_y, out_channels])

        # 为每个输出通道生成FrFT核
        for i in range(N):
            # X方向FrFT核（余弦项）
            real_FrFT_filterX[:, :, i] = np.cos(-f * (X) / math.sin(p) + (f * f + X * X) / (2 * math.tan(p)))
            # Y方向FrFT核（余弦项）
            real_FrFT_filterY[:, :, i] = np.cos(-f * (Y) / math.sin(p) + (f * f + Y * Y) / (2 * math.tan(p)))
            # X×Y组合生成最终核
            real_FrFT_filter[:, :, i] = real_FrFT_filterY[:, :, i] * real_FrFT_filterX[:, :, i]

        # 扩展到输入通道数（每个输入通道共享相同的频率核）
        g_f = np.zeros((kernel[0], kernel[1], in_channels, out_channels))
        for i in range(N):
            g_f[:, :, :, i] = np.repeat(real_FrFT_filter[:, :, i: i + 1], in_channels, axis=2)

        # 重塑为(out_channels, in_channels, H, W)（适配Conv2d输入格式）
        g_f_real = g_f.reshape((out_channels, in_channels, kernel[0], kernel[1]))
        return torch.tensor(g_f_real).type(torch.FloatTensor)

    def forward(self, x):
        """前向传播：FrFT核与输入相乘（频率域特征提取）"""
        x = x * self.weight
        return x

    def generate_FrFT_list(self, in_channels, out_channels, kernel, f_list, p):
        """生成多频率FrFT核列表（备用接口）"""
        FrFT_list = []
        for f in f_list:
            FrFT_list.append(self.generate_FrFT_filter(in_channels, out_channels, kernel, f, p))
        return FrFT_list


class FrFTSingle(nn.Module):
    """
    单分支分数阶傅里叶感知单元
    功能：将FrFTFilter与可训练参数结合，实现特定频率特征提取
    """

    def __init__(self, in_channels, out_channels, kernel_size, f, order):
        super().__init__()
        self.fft = FrFTFilter(in_channels, out_channels, kernel_size, f, order)
        # 可训练参数t（调整FrFT核与输入的适配性）
        self.t = nn.Parameter(
            torch.randn(out_channels, in_channels, kernel_size[0], kernel_size[1]),
            requires_grad=True,
        )
        nn.init.normal_(self.t)  # 正态分布初始化
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        """前向传播：FrFT滤波 → 卷积 → 激活 → dropout → 池化"""
        out = self.fft(self.t)  # FrFT核与可训练参数结合
        out = F.conv2d(x, out, stride=1, padding=(out.shape[-2] - 1) // 2)  # 卷积
        out = self.relu(out)
        out = F.dropout(out, 0.3)  # 正则化
        out = F.pad(out, (1, 0, 1, 0), mode="constant", value=0)  # 尺寸调整
        out = F.max_pool2d(out, 2, stride=1, padding=0)  # 池化
        return out


class FourierFPU(nn.Module):
    """
    分数阶傅里叶频率感知单元（FPU的另一种实现）
    功能：4分支并行FrFT滤波（不同频率参数），捕捉多频率全局特征
    """

    def __init__(self, in_channels, out_channels, order=0.25):
        super().__init__()
        # 4分支FrFTSingle（不同频率参数f：0.25,0.5,0.75,1.0）
        self.fft1 = FrFTSingle(in_channels // 4, out_channels // 4, (3, 3), 0.25, order)
        self.fft2 = FrFTSingle(in_channels // 4, out_channels // 4, (3, 3), 0.50, order)
        self.fft3 = FrFTSingle(in_channels // 4, out_channels // 4, (3, 3), 0.75, order)
        self.fft4 = FrFTSingle(in_channels // 4, out_channels // 4, (3, 3), 1.00, order)
        self.fc = Conv(out_channels, out_channels, 1)  # 1×1卷积融合

    def forward(self, x):
        """前向传播：通道拆分 → 4分支FrFT → 拼接 → 融合 → 残差连接"""
        channels_per_group = x.shape[1] // 4
        x1, x2, x3, x4 = torch.split(x, channels_per_group, 1)  # 通道拆分
        # 4分支并行处理
        x_out = torch.cat([self.fft1(x1), self.fft2(x2), self.fft3(x3), self.fft4(x4)], dim=1)
        x_out = self.fc(x_out)  # 融合
        # 残差连接（通道匹配时）
        if x.shape[1] == x_out.shape[1]:
            x_out = x_out + x
        return x_out


class SPU(nn.Module):
    """
    空间感知单元（SPU）
    功能：双分支深度卷积（3×3+5×5），捕捉不同感受野的空间特征，支持残差连接
    对应Figure 3：通过多尺度卷积与特征交互，增强空间细节表达
    """

    def __init__(self, in_channels, out_channels):
        super().__init__()
        # 分支1：3×3深度卷积（分组数=输入通道数//2，降低计算量）
        self.c1 = Conv(in_channels // 2, in_channels // 2, 3, g=in_channels // 2)
        # 分支2：5×5深度卷积（输入=分支1输出+原分支2输入，增强特征交互）
        self.c2 = Conv(in_channels // 2, in_channels // 2, 5, g=in_channels // 2)
        # 1×1卷积：通道融合+维度调整（in_channels→out_channels）
        self.c3 = Conv(in_channels, out_channels, 1)

    def forward(self, x):
        """前向传播：通道拆分 → 双分支卷积 → 拼接 → 融合 → 残差连接"""
        # 通道拆分为2组（每组in_channels//2通道）
        x1, x2 = torch.split(x, x.shape[1] // 2, dim=1)
        x1 = self.c1(x1)  # 3×3深度卷积（小感受野，捕捉细节）
        x2 = self.c2(x2 + x1)  # 5×5深度卷积（大感受野，结合分支1特征）
        x_out = torch.cat([x1, x2], dim=1)  # 分支拼接
        x_out = self.c3(x_out)  # 通道融合
        # 残差连接（通道匹配时）
        if x.shape[1] == x_out.shape[1]:
            x_out = x_out + x
        return x_out


class SFS_Conv(nn.Module):
    """
    核心模块：Shunt-Filter-Select卷积（SFS-Conv）
    功能：空间分支（SPU）+ 频率分支（FPU）并行，结合注意力选择有效特征
    对应Figure 2：实现“分流-感知-选择”的完整流程
    """

    def __init__(self, in_channels, out_channels, order=0.25, filter="FrGT"):
        """
        Args:
            filter: 频率滤波器类型（"FrFT"=分数阶傅里叶，"FrGT"=分数阶Gabor）
        """
        super().__init__()
        # 1. 分流（Shunt）：1×1卷积降维，将输入分为空间分支和频率分支
        self.PWC0 = Conv(in_channels, in_channels // 2, 1)  # 空间分支输入（降维到1/2通道）
        self.PWC1 = Conv(in_channels, in_channels // 2, 1)  # 频率分支输入（降维到1/2通道）

        # 2. 感知（Filter）：空间感知+频率感知
        self.SPU = SPU(in_channels // 2, out_channels)  # 空间分支：SPU捕捉空间细节
        # 频率分支：根据filter选择FPU类型
        assert filter in ("FrFT", "FrGT"), "Filter must be FrFT or FrGT"
        if filter == "FrFT":
            self.FPU = FourierFPU(in_channels // 2, out_channels, order)  # FrFT捕捉全局频率
        elif filter == "FrGT":
            self.FPU = GaborFPU(in_channels // 2, out_channels, order)  # FrGT捕捉纹理频率

        # 3. 选择（Select）：1×1卷积融合+全局注意力加权
        self.PWC_o = Conv(out_channels, out_channels, 1)  # 输出融合
        self.advavg = nn.AdaptiveAvgPool2d(1)  # GAP：压缩空间信息，生成全局注意力权重

    def forward(self, x):
        """前向传播：分流 → 双分支感知 → 注意力选择 → 融合输出"""
        # 分流：输入分为空间分支和频率分支（各1/2通道）
        x_spa = self.SPU(self.PWC0(x))  # 空间分支：SPU处理
        x_fre = self.FPU(self.PWC1(x))  # 频率分支：FPU处理

        # 选择：全局注意力加权（软选择有效特征）
        out = torch.cat([x_spa, x_fre], dim=1)  # 双分支拼接（2×out_channels通道）
        # GAP+Softmax生成通道权重 → 与输入相乘（加权选择）
        out = F.softmax(self.advavg(out), dim=1) * out

        # 融合：拆分权重后的分支 → 求和 → 1×1卷积输出
        out1, out2 = torch.split(out, out.size(1) // 2, dim=1)  # 拆分为空间+频率权重分支
        return self.PWC_o(out1 + out2)  # 求和+融合，输出最终特征

if __name__ == "__main__":

    # 源码给出的计算Params和FLOPs
    channel = 256
    height = width = 20
    model = SFS_Conv(channel, channel)

    flops, params = thop.profile(model, inputs=(torch.randn(1, channel, height, width),), verbose=False)
    print(f"model FLOPs: {flops / (10**9)}G")
    print(f"model Params: {params / (10**6)}M")

    # 测试输入输出
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    x = torch.randn(1, 64, 32, 32).to(device)
    model = SFS_Conv(64,64)
    model.to(device)
    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("知乎、CSDN：十小大")
    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)

