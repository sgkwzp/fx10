'''
模块出处：InceptionNeXt: When Inception Meets ConvNeXt
文章链接：https://openaccess.thecvf.com/content/CVPR2024/papers/Yu_InceptionNeXt_When_Inception_Meets_ConvNeXt_CVPR_2024_paper.pdf
完整源码：https://github.com/sail-sg/inceptionnext

微信公众号：十小大的底层视觉工坊
知乎、CSDN：十小大
'''

import torch
import torch.nn as nn

class InceptionDWConv2d(nn.Module):
    """
     inception风格的深度可分离卷积模块（Inception Depthwise Convolution）
    核心设计：将输入通道拆分到4个并行分支（恒等分支+3个深度卷积分支），分别捕捉不同维度的空间特征，
             最终拼接输出，在低计算成本下实现多尺度、多方向的特征感知
    """

    def __init__(self, in_channels, square_kernel_size=3, band_kernel_size=11, branch_ratio=0.125):
        """
        Args:
            in_channels: 输入特征图的通道数（必须满足 in_channels - 3*gc > 0，gc为分支通道数）
            square_kernel_size: 正方形深度卷积的核大小（默认3×3，捕捉局部正方形区域特征）
            band_kernel_size: 长条状深度卷积的核大小（默认11，用于捕捉水平/垂直方向长距离特征）
            branch_ratio: 每个卷积分支的通道占比（默认0.125，即每个卷积分支通道数=in_channels×0.125）
        """
        super().__init__()
        # 计算单个卷积分支的通道数（gc：group channel），确保为整数
        gc = int(in_channels * branch_ratio)
        # 分支1：正方形深度卷积（square depthwise conv），默认3×3，捕捉局部正方形区域特征
        self.dwconv_hw = nn.Conv2d(
            gc, gc,  # 输入输出通道数均为gc（深度卷积通道数不变）
            square_kernel_size,  # 正方形核大小
            padding=square_kernel_size // 2,  # same padding（输入输出尺寸一致）
            groups=gc  # 深度卷积关键参数：分组数=通道数，每个通道独立卷积
        )
        # 分支2：水平长条深度卷积（horizontal band depthwise conv），1×11，捕捉水平方向长距离特征
        self.dwconv_w = nn.Conv2d(
            gc, gc,
            kernel_size=(1, band_kernel_size),  # 水平方向长条核（宽度=11，高度=1）
            padding=(0, band_kernel_size // 2),  # 仅在水平方向补零（same padding）
            groups=gc
        )
        # 分支3：垂直长条深度卷积（vertical band depthwise conv），11×1，捕捉垂直方向长距离特征
        self.dwconv_h = nn.Conv2d(
            gc, gc,
            kernel_size=(band_kernel_size, 1),  # 垂直方向长条核（高度=11，宽度=1）
            padding=(band_kernel_size // 2, 0),  # 仅在垂直方向补零（same padding）
            groups=gc
        )
        # 通道拆分索引：将输入通道分为4部分（恒等分支+3个卷积分支）
        # 恒等分支通道数 = 总通道数 - 3×卷积分支通道数（确保恒等分支占比最大，保留基础特征）
        self.split_indexes = (in_channels - 3 * gc, gc, gc, gc)

    def forward(self, x):
        """
        前向传播流程：通道拆分 → 多分支并行计算 → 通道拼接
        Args:
            x: 输入特征图，形状为 (batch_size, in_channels, height, width)
        Returns:
            输出特征图，形状与输入一致 (batch_size, in_channels, height, width)
        """
        # 1. 通道拆分：按split_indexes将输入分为4个分支
        # x_id：恒等分支（identity branch），不做卷积，保留原始特征
        # x_hw：正方形卷积分支输入，x_w：水平卷积分支输入，x_h：垂直卷积分支输入
        x_id, x_hw, x_w, x_h = torch.split(x, self.split_indexes, dim=1)

        # 2. 多分支计算：3个卷积分支分别处理，恒等分支直接保留
        # 3. 通道拼接：将4个分支的输出沿通道维度拼接，恢复原通道数
        return torch.cat(
            (x_id, self.dwconv_hw(x_hw), self.dwconv_w(x_w), self.dwconv_h(x_h)),
            dim=1,  # 沿通道维度（dim=1）拼接
        )

if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    x = torch.randn(1, 64, 32, 32).to(device)
    model = InceptionDWConv2d(64)
    model.to(device)
    y = model(x)

    print("微信公众号：十小大的底层视觉工坊")
    print("知乎、CSDN：十小大")
    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)