import torch
import torch.nn as nn

import torch
import torch.nn as nn


def fuse_conv_and_bn(conv, bn):
    """推理部署用：融合Conv2d和BatchNorm2d，提升推理速度，无精度损失"""
    fusedconv = nn.Conv2d(
        conv.in_channels, conv.out_channels,
        kernel_size=conv.kernel_size, stride=conv.stride,
        padding=conv.padding, dilation=conv.dilation,
        groups=conv.groups, bias=True
    ).requires_grad_(False).to(conv.weight.device)
    # 融合权重
    w_conv = conv.weight.view(conv.out_channels, -1)
    w_bn = torch.diag(bn.weight.div(torch.sqrt(bn.eps + bn.running_var)))
    fusedconv.weight.copy_(torch.mm(w_bn, w_conv).view(fusedconv.weight.shape))
    # 融合偏置
    b_conv = torch.zeros(conv.out_channels, device=conv.weight.device) if conv.bias is None else conv.bias
    b_bn = bn.bias - bn.weight.mul(bn.running_mean).div(torch.sqrt(bn.running_var + bn.eps))
    fusedconv.bias.copy_(torch.mm(w_bn, b_conv.reshape(-1, 1)).reshape(-1) + b_bn)
    return fusedconv


def autopad(k, p=None, d=1):
    """自动计算padding，保证卷积输出尺寸=输入尺寸（same padding）"""
    if d > 1:
        k = d * (k - 1) + 1 if isinstance(k, int) else [d * (x - 1) + 1 for x in k]
    if p is None:
        p = k // 2 if isinstance(k, int) else [x // 2 for x in k]
    return p


class Conv(nn.Module):
    """标准卷积基类：Conv2d + BN + 激活，支持部署时的Conv-BN融合"""
    default_act = nn.GELU()  # 默认激活函数，比ReLU训练更稳定

    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, d=1, act=True):
        super().__init__()
        self.conv = nn.Conv2d(c1, c2, k, s, autopad(k, p, d), groups=g, dilation=d, bias=False)
        self.bn = nn.BatchNorm2d(c2)
        self.act = self.default_act if act is True else act if isinstance(act, nn.Module) else nn.Identity()

    def forward(self, x):
        """训练前向：卷积+BN+激活"""
        return self.act(self.bn(self.conv(x)))

    def forward_fuse(self, x):
        """部署前向：融合Conv+BN后直接推理"""
        return self.act(self.conv(x))

    def convert_to_deploy(self):
        """部署转换：融合Conv和BN，删除BN层，更新前向方法"""
        if hasattr(self, "bn"):
            self.conv = fuse_conv_and_bn(self.conv, self.bn)
            delattr(self, "bn")
            self.forward = self.forward_fuse


class ConvolutionalGLU(nn.Module):
    """卷积门控线性单元：可选残差，增强特征表达，可作为CKConv的配套增强模块"""

    def __init__(self, in_features, hidden_features=None, out_features=None, act_layer=nn.GELU, drop=0.):
        super().__init__()
        out_features = out_features or in_features
        hidden_features = hidden_features or in_features
        hidden_features = int(2 * hidden_features / 3)
        self.fc1 = nn.Conv2d(in_features, hidden_features * 2, kernel_size=1)
        self.dwconv = nn.Sequential(
            nn.Conv2d(hidden_features, hidden_features, kernel_size=3, stride=1, padding=1, bias=True,
                      groups=hidden_features),
            act_layer()
        )
        self.fc2 = nn.Conv2d(hidden_features, out_features, kernel_size=1)
        self.drop = nn.Dropout(drop)
        self.conv1x1 = Conv(in_features, out_features, 1) if in_features != out_features else nn.Identity()

    def forward(self, x):
        x_shortcut = self.conv1x1(x)
        x, v = self.fc1(x).chunk(2, dim=1)
        x = self.dwconv(x) * v
        x = self.drop(x)
        x = self.fc2(x)
        x = self.drop(x)
        return x_shortcut + x


# ====================== CKConv核心模块 ======================
class CKConv(nn.Module):
    """
    Chinese Knot Convolution (中国结卷积)
    核心设计：多分支多尺度双路径设计，像中国结的经纬线交织，同时捕捉长距离方向特征+局部细节特征
    Args:
        c1: 输入通道数
        c2: 输出通道数
        kk: 多尺度卷积核尺寸列表，仅支持[3,5,7,9]中的值，默认[3,5,7]
        s: 卷积步长，1为保持尺寸，2为下采样
    """

    def __init__(self, c1, c2, kk=[3, 5, 7], s=1):
        super().__init__()
        # 输入合法性校验
        if not isinstance(kk, list) or not all(ki in [3, 5, 7, 9] for ki in kk):
            raise ValueError("kk必须是仅包含3/5/7/9的列表")
        self.kk = kk
        self.c1 = c1
        self.c2 = c2
        self.s = s
        self.branches = nn.ModuleDict()  # 存储每个核尺寸对应的中国结分支

        # 为每个核尺寸构建独立的中国结双路径分支
        for ki in kk:
            # 分支1：3×3深度卷积，捕捉局部细节特征（中国结的"结"）
            self.branches[f'k{ki}_body'] = Conv(c2, c2 // 2, (3, 3), s=1, g=c2 // 2)
            # 分支2：水平+垂直可分离卷积，捕捉长距离方向特征（中国结的"经纬线"）
            self.branches[f'k{ki}_head_h'] = Conv(c2, c2 // 2, (1, ki), s=s, p=(0, (ki - 1) // 2), g=c2 // 2)
            self.branches[f'k{ki}_head_v'] = Conv(c2 // 2, c2 // 2, (ki, 1), s=s, p=((ki - 1) // 2, 0), g=c2 // 2)
            # 分支融合：1×1深度卷积升维
            self.branches[f'k{ki}_conv2'] = nn.Conv2d(c2 // 2, c2, 1, groups=c2 // 2)

        # 多分支最终融合：分组卷积降低参数量，提升通道交互
        self.conv_fuse = nn.Conv2d(len(kk) * c2, c2, 1, groups=16)

    def forward(self, x):
        outputs = []
        # 每个核尺寸的分支并行前向
        for ki in self.kk:
            # 方向路径：水平卷积→垂直卷积，捕捉长距离方向结构
            y = self.branches[f'k{ki}_head_h'](x)
            y = self.branches[f'k{ki}_head_v'](y)
            # 局部路径：3×3深度卷积，捕捉局部细节
            ys = self.branches[f'k{ki}_body'](x)
            # 双路径相加（中国结式交织融合）
            out = ys + y
            # 1×1卷积升维
            out = self.branches[f'k{ki}_conv2'](out)
            outputs.append(out)
        # 所有分支通道拼接
        out = torch.cat(outputs, dim=1)
        # 分组卷积融合多尺度特征
        out = self.conv_fuse(out)
        return out


if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    x = torch.randn(1, 64, 32, 32).to(device)
    model = CKConv(64, 64, [3, 5, 7]).to(device)
    y = model(x)
    print("输入特征维度：", x.shape)
    print("输出特征维度：", y.shape)


